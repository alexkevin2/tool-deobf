# Luast-Deobf-Tool v1.3.0

Deflattener + source cleaner for the **luast v1.0.1** Luau obfuscator (the
generator behind `https://luast.clv.cloud`). It turns a control-flow-flattened
luast payload back into structured, readable Luau source — first by
recovering the control flow (deflatten stage), then by dissolving the
obfuscator's register-table scaffolding (source-cleaned stage) — and
verifies the result with hard gates before claiming success.

The artifact headers stamp the package version: the deflatten stage
stamps `v1.3.0` on `<stem>.deflattened.luau`, the clean stage stamps
its own `v1.3.0` on `<stem>.cleaned.luau`.

## Usage

```
python3 luast_deobf.py <input.lua> [-o OUTDIR] [--no-clean]
                              [--spoof-id auto|off]  (default auto)
```

`--spoof-id auto` (default) adds a **static-only** identity-gate
scan (see "Identity spoofing" below): `identity_report.json`
(unified `spoof-engine/1` schema) plus an Identity section in
`report.md`. `--spoof-id off` emits no identity artifacts and every
other output is byte-identical to the auto run. The tool never
executes the payload, so there are no forks and no mock environment
in this port: `forks` is always `[]` and branches stay
`unclassified`.

Outputs in `OUTDIR` (default `<input-stem>-luast-deobf/` next to the input):

| file | content |
|---|---|
| `<stem>.cleaned.luau` | **headline output**: structured + source-cleaned source (omitted under `--no-clean`) |
| `<stem>.deflattened.luau` | structured source (intermediate artifact of the deflatten stage) |
| `report.md` | verdict, accounting, kernel residue, clean-stage section |
| `manifest.json` | machine-readable verdict + counts + hashes (+ `clean` section) |
| `deflatten_map.json` | per-machine map: states → output line |
| `clean_map.json` | per-reference accounting of the clean stage (omitted under `--no-clean`) |
| `qa_report.json` | self-check QA for the cleaned output: simplify counts, raw-pattern counts, naming ratios, name-conflict downgrades, defects deliberately not fixed (omitted under `--no-clean`; also summarized in `report.md`) |

`--no-clean` skips the clean stage and reproduces the deflatten-only run
byte-identically (the pre-1.1.0 behavior and goldens).

Exit codes: `0` = FULL (every machine structured, clean stage complete,
all gates pass), `5` = PARTIAL (some machines kept as flagged dispatch
kernels, or the clean stage could not complete — exact reason in
`report.md` / `manifest.json`), `2` = not a luast v1.0.1 payload,
`1` = error / verification gate failure.

## Fingerprint (detect)

Tiered bar (evidence is printed on mismatch, including the pool-assign
index, flavor-A/B machine counts and the permutation-statement count):

- a constants pool table with **≥ 500 entries**, assigned at **index
  128** of a register table (luast's `akR[128]` layout — the index the
  whole downstream pipeline hardcodes; a big table at any other index
  does not count);
- **header present:** the header version must be exactly `1.0.1`
  (allowlist — any other luast version is rejected) AND at least one
  **flattened state machine**;
- **header absent:** the structural bar is higher — **≥ 10 machines**
  with **≥ 1 flavor-A (S = K − S) machine** AND **≥ 1
  pool-permutation statement group** (an Assign whose targets are all
  constant pool-index writes and whose values are all pool reads);
- a flattened state machine is a `while true` loop whose body applies
  the state transform `S = K − S` and then dispatches through a
  binary-search comparison tree over `S` (flavor A), or that dispatches
  directly on a state variable through a binary-search comparison
  **tree** on that same variable (flavor B: ≥ 2 tree nodes — a single
  comparison If is not a machine; note the tree threshold is 2, not
  3, because the reference payload contains 19 genuine 3-state
  machines whose dispatch tree has exactly 2 nodes);
- the pool threshold stays exactly ≥ 500 (not lowered, not raised to
  2,000 — index 128 + version + machines are the discriminators).

## Pipeline

1. **Parse** with the bundled `luau-ast` (the payload is never executed).
2. **Pool resolve.** luast permutes 78 pool slots at startup — the
   permutation statements sit in the main machine's entry state — so every
   read is resolved against the *post-permutation* (effective) pool.
   Scalar entries become literals; global/index entries become their
   expressions; function/table entries stay live references (identity).
3. **Machine extraction.** For every `while true` machine: state variable,
   transform constant K, dispatch spine, and the full state graph — per
   state value → block body, guarded transition paths, exits. Landing is
   proven by candidate evaluation (all state writes + inits), not interval
   guessing.
4. **Structuring.** Dominator/post-dominator region structuring:
   sequences, if/elseif/else at converging forks, `while true` loops from
   single-entry back-edges, `break`/`continue` for loop exits/restarts,
   common-prefix hoisting, bounded duplication of terminal epilogue
   blocks (flagged in the map). A machine that provably resists (multi-exit
   loop, irreducible overlap, dynamic transition) keeps its original
   dispatch as a **kernel**, flagged with a `-- [luast] KERNEL` comment
   and listed in the report with the forcing property.
5. **Scoped naming.** Pool-alias locals are dropped when every use is
   substituted, else renamed `pool` (block-scope collision-checked).
   Locals initialized from pool-proven globals are renamed CONFIRMED;
   state variables and dispatch scaffolding disappear where structured;
   state-init statements of structured machines are dropped.
6. **Source cleaning (SOURCE_CLEANED stage; `clean.py`).** Works on the
   deflattened AST and dissolves the register table `akR` and its
   constants pool `akR[128]`:
   - every register slot is classified from its write/read census.
     Slots written once with a side-effect-free value whose reads all
     follow are *eliminated* (reads take the defining value); dead slots
     are dropped; the remaining runtime registers become named fields of
     a single `state` table (`state.flySpeed`-style access);
   - pool reads are resolved by entry kind: scalars inlined as literals,
     globals rendered as the real global, function entries hoisted to
     named `local function` definitions placed in the deepest block that
     contains all of their reads (or at the pool's own position when the
     reads share only the chunk scope);
   - alias locals (`local x = akR`, `local y = x[128]`, second-order
     aliases included), the startup permutation statements, the pool
     table assignment and the `akR[N] = nil` prologue are deleted;
   - payload locals/parameters are renamed from usage evidence
     (**INFERRED**: service/child/instance patterns, pool-proven values,
     callback/UI/remote naming evidence) or given neutral role names
     (`arg1`, `key`, `value`, `v<k>`). No name is ever presented as the
     original — the full naming table with labels is in `clean_map.json`.
   - naming the registers as chunk-level locals instead of a state table
     is not a style choice: the reference payload has 154 chunk-level
     payload locals live across the whole chunk and ~109 register slots
     simultaneously live inside the machine region, and Luau allows at
     most 200 locals per function — a named-field state table is the
     only representation that keeps the cleaned source compilable.
   - the stage refuses (PARTIAL, with the reason) rather than guessing
     when a payload violates its proven invariants: dynamic register or
     pool indexing, bare register-table uses, register writes inside
     functions, pool writes outside the startup permutation.
7. **Gates (all must pass for FULL).**
   - `luau-compile` on the output exits 0;
   - the string/number **literal multiset of the output equals** the
     multiset derived from the input AST (no constant lost or invented);
   - per-machine accounting: every reachable state block is emitted
     exactly once (trampoline/epilogue re-emissions bounded and flagged);
     unreachable dispatch ranges are counted as dead and dropped.
   - clean stage: `luau-compile` on the cleaned output exits 0; the
     string/number literal multiset of the cleaned output equals the
     deflattened input's multiset adjusted by the exact per-edit ledger
     (every removed/inserted literal is booked; the ledger is in
     `clean_map.json`); **every** register-table/alias reference in the
     input (5,407 in the reference payload) is accounted in exactly one
     category of `clean_map.json` and zero survive; a statement/literal
     audit is run per hoisted function.

## Verdict semantics

- **FULL**: zero kernels, zero unresolved transitions, all gates pass,
  **and** the source-cleaned stage completed (register table dissolved,
  every reference accounted). A deflatten-only run (`--no-clean`) does
  not claim the SOURCE_CLEANED stage; its FULL covers structure recovery
  only, as in v1.0.0.
- **PARTIAL**: the source is still produced and still passes compile +
  literal gates, but one or more machines remain as dispatch kernels —
  the exact residue (machine, location, forcing property) is in
  `report.md` / `manifest.json` — or the clean stage refused on a proven
  invariant violation (reason recorded in the manifest's `clean`
  section and the report).

## Reference run (tests/sample/267757772.lua, Ouroboros-HWF)

- Machines: 367/367 structured, 0 kernels.
- Clean stage: 5,407 register-table/alias references → 0
  (3,233 reads + 1,454 writes became `state` fields; 331 pool reads
  became named functions; 134 alias declarations, 172 permutation
  references and the pool assignment deleted as scaffolding; the rest
  inlined/eliminated — full breakdown in `clean_map.json`).
- 128 registers became `state` fields (23 INFERRED names, 105 neutral);
  1 register eliminated to its defining literal; 19 dead registers
  dropped. 167 pool functions hoisted (164 in local block scope, 3 at
  the pool position; 14 INFERRED names, 153 neutral `poolFn<k>`).
  2,367 payload locals renamed (9 INFERRED, the rest neutral role
  names — most payload values are computed, so honest neutral names
  dominate; the logic, not the names, is the recovery).
- Lines: 17,103 (deflattened) → 14,215 (cleaned). `akR` occurrences in
  the cleaned source: 0. Gates: compile PASS, literal multiset PASS.

## Limits

- Targets the luast v1.0.1 generator only (other versions/generators →
  exit 2). Flavor coverage is pinned to the observed generator output.
- Original local/variable names destroyed by the obfuscator are not
  recovered; locals keep their generated names except for the
  pool-proven renames above.
- Constants that only exist at runtime (live game state) are not
  recoverable statically; none were present as unresolved transitions in
  the reference payload.
- Static analysis only: the payload is parsed and compile-checked,
  never executed. Remote resources a script references at runtime are
  listed in the source, never fetched.

## Identity spoofing (STATIC-ONLY port of the shared spoof engine)

The shared engine is vendored byte-identically next to
`luast_deobf.py` (`spoof_engine.py`, sha256 `d33daef8…35230d6b`,
canonical copy in Luraph-Deobf-Tool-v6) and driven by
`identity_scan.py`, which scans the **deflattened AST** for
`game.<field>` comparison gates:

- `game.<Field> == <const>` → `eq-const`; `~=` → `ne-const`
  (non-pass); `<`/`<=`/`>`/`>=` → bound kinds (non-pass: the bound
  is not the gate-PASS value); `<set>[game.<Field>]` with statically
  known numeric set keys → `set-membership` (one candidate per key).
  Field reads through a one-hop local alias (`local g = game`) count;
  method calls (`game:GetService(...)`) do not; a field read wrapped
  in `tostring()`/a call is a telemetry/display read, not a gate.
- Non-canonical `game.*` members count only when compared or
  set-indexed (SPOOF-SPEC §2.1 extension rule): a merely-read member
  such as an event is not an identity field and never becomes a gate.
- Fields seen only as string literals (constants-pool telemetry
  strings) are **presence-only**: they appear in `fields_seen` but
  never in `fields_read`, `candidates` or `gates`. Canonical fields
  read with no comparison gate site are reported `unknown` with
  `spoofed_value` null — never seeded, never claimed as gates.
- Machine-dispatch `state == const` is **not** an identity gate and
  is never reported: the scan only matches reads of the `game` object,
  on code where dispatch has already been structured away.
- Reference payload (HWF) result: `candidates` empty, `forks` empty,
  `unknown_fields` = `JobId`, `PlaceId` — both appear only as
  telemetry/display reads (`tostring(game.PlaceId)`,
  `tostring(game["JobId"])`, label assignments) and as pool strings,
  never in a comparison gate. No game ID is hardcoded anywhere in
  production code (audited by `tests/check_spoof.py`, which also
  covers a synthetic multi-gate fixture: eq-const + set-membership
  PlaceId gates and an eq-const CreatorId gate, both fields reported,
  forks `[]`).
- Gate annotations live in `report.md` only — the cleaned output is
  never annotated, so clean byte-identity is preserved.

## Changes in v1.3.0 vs v1.2.0 (self-audit round)

- New `simplify.py` pass in the clean stage (semantics-preserving
  only; anything unprovable is left alone and counted as residue):
  both-constant folding (301 nodes on the reference payload),
  provably-numeric identity folding (`x + 0`, 52 folds; `x * 1`
  with a non-numeric operand is deliberately NOT folded — a string
  operand would change type/error behaviour), constant-condition
  `if`/`if`-expression folding (71 + 2), negated-elseif collapse
  (732 chains: 98 collapsed to a single `if not C`, 634 truncated
  to an `else`; requires every intermediate condition pure — no
  calls, index bases only locals), dead consecutive assignments
  (339 dropped, 1 dead local value stripped), chunk-prologue nil
  compaction (35 `state.<f> = nil` no-ops dropped). Reference
  cleaned output: 14,215 → 13,740 lines; literal ledger
  10,132 removed / 2,552 inserted → 11,991 removed / 2,552 inserted
  (net per-key deltas; the compile + literal gates still pass
  exactly). `--no-clean` output is unchanged except the version
  header line, so the deflatten goldens still hold.
- Slot-reuse name-conflict fix in `clean.py`: `scan_patterns` no
  longer descends into function bodies (a function-valued slot no
  longer inherits a name from inside its body), and a corroboration
  rule downgrades a slot's INFERRED name to neutral `reg<slot>`
  when its evidence pattern appears in < 3 and < 25% of its ≥ 8
  non-nil writes (a VM register reused across machines is not the
  thing its first write happened to hold). On the reference
  payload: 13 downgrades, slot INFERRED 23 → 6, recorded per slot
  in `clean_map.json` (`name_conflict`) and in `qa_report.json`.
- Baked-in self-check: every clean run now writes `qa_report.json`
  (raw-pattern counts, naming ratios, simplify counts, defects
  deliberately not fixed with sample locations) and a Self-check QA
  section in `report.md`. Deliberate residue on the reference
  payload: `* 1` ×93 and `+ 0` ×4 (operand type unproven),
  impure negated-elseif chains ×32, duplicated epilogues in 3
  machines (deflatten-stage, see `deflatten_map.json`), unary
  minus on numbers ×27 (prints identically; not folded on purpose).
  A non-empty `simplify_miss` entry in qa_report would mean a tool
  bug, and the regression asserts it is empty.
- Goldens regenerated for v1.3.0: `--no-clean` outputs differ only
  in the version header line (and derived hashes), `deflatten_map`
  is byte-identical; cleaned output, `clean_map.json` and the new
  `qa_report.json` are re-pinned with the diff classes above. New
  output hashes: deflattened `977e2917…`, cleaned `8e05e0db…`
  (full hashes in `manifest.json` / `report.md`).
- Full audit trail: `tests/qa-audit-2026-10-24.md`.

## Changes in v1.2.0 vs v1.1.0

- Fingerprint upgrades U1–U6 (see "Fingerprint" above): pool-assign
  index pinned to 128; header version allowlist exactly 1.0.1;
  header-absent structural bar (≥ 10 machines, ≥ 1 flavor-A,
  ≥ 1 permutation group); flavor-B binary-search-tree requirement;
  pool threshold kept at ≥ 500; exit-2 evidence extended with the
  pool-assign index, flavor counts and permutation count. U4 note:
  the tree threshold is implemented as ≥ 2 nodes, not the literal
  ≥ 3 in the fingerprint report, because ≥ 3 would drop 19 genuine
  3-state machines from the reference payload and change its golden
  deflattened output — the ≥ 2 bar still excludes single-comparison
  If shapes, and all 367 reference machines still route.
- Static-only spoof port (shared `spoof_engine.py` vendored
  byte-identical; `identity_scan.py`; `--spoof-id auto|off`;
  `identity_report.json` in the unified `spoof-engine/1` schema;
  gate annotations in `report.md` only). No executor was added;
  no payload is executed on any path.
- Version fix: `TOOL_VERSION`/`CLEAN_VERSION` were both still
  `1.0.0` in the shipped v1.1.0 package; both are now `1.2.0`,
  consistently in headers, `manifest.json` (`tool_version`) and
  the clean section (`clean_version`). Goldens were regenerated
  for v1.2.0: vs the v1.1.0 goldens, the deflattened/cleaned
  outputs differ only in the version header line (and the hashes
  derived from it), `deflatten_map.json` is unchanged,
  `clean_map.json` differs only in its `clean_version` field, and
  `report.md` differs only by the added Identity section (plus the
  hash line it follows from). New output hashes: deflattened
  `6d71c8e6…`, cleaned `a7c6ef7b…` (full hashes in the regenerated
  `manifest.json` / `report.md`).
- Corpus stats (12 samples, `~/luau-deobf/corpus/`): the new
  detector routes exactly the luast golden (HWF `7a0fc3ad`) and
  rejects the other 11, including StealAnEggs `4c174a06` (7 shape
  matches under the old detector, still exit 2 — no index-128 pool)
  and the plain Ouroboros loader `d2d86e68` (exit 2).

## Regression

```
tests/regression.sh
```

Runs the tool in an isolated environment (fake HOME, persistent TMPDIR)
on the reference payload (`tests/sample/267757772.lua`) twice: with
`--no-clean` (deflatten outputs byte-identical to the goldens in
`tests/golden/`) and in default mode (cleaned output + `clean_map.json`
byte-identical to their goldens, compile PASS on both outputs, zero
textual `akR` residue, manifest clean section sane). It also checks
the identity reports (unified schema, forks `[]`, HWF presence-only),
`--spoof-id off` byte-identity (minus the Identity section),
determinism across `PYTHONHASHSEED` values, the negative control
(exit 2 with U6 evidence), the synthetic spoof suite
(`tests/check_spoof.py`), and — when the corpus tree is present —
the 12-sample detector sweep (`tests/check_corpus_detect.py`).
Results in `tests/regression_results.log`.

Bundled binaries (`bin/luau-ast`, `bin/luau-compile`) are the official
Luau toolchain builds used across this workspace's deobf tools.
