"""clean.py -- SOURCE_CLEANED stage for Luast-Deobf-Tool.

Operates on the parsed DEFLATTENED output AST (which is self-contained):
the obfuscator's register table `akR` and its constants pool `akR[128]`
are dissolved:

  * register slots become chunk-level locals (promoted), or are
    eliminated when a single side-effect-free write provably reaches
    every read (function reference / global / literal);
  * pool entries are inlined at read sites (scalars), rendered as real
    globals (global entries), or emitted as named `local function`
    definitions at the pool's own position (function entries);
  * alias locals (`local x = akR`, `local y = x[128]`, ...) and the
    permutation scaffolding are deleted;
  * payload locals/params are renamed from usage evidence
    (INFERRED) or given neutral role names.

Every edit is booked: literal multisets removed/inserted per edit and
per category, so the gate `input - removed + inserted == output` must
hold exactly, and every akR/alias reference in the input is accounted
in exactly one clean-map category.  Invariant violations (dynamic
indexing, bare table use, pool writes outside the permutation, ...)
raise CleanError instead of silently mis-compiling.
"""

import collections
import copy
import json
import re
import subprocess
import sys

sys.setrecursionlimit(1000000)

import luast_lib as L
from luast_lib import (T, unwrap, var_key, is_cnum, cnum, walk,
                       build_parents)


def loc_of(n):
    return n.get('location') if isinstance(n, dict) else None


def is_nil_expr(e):
    return T(unwrap(e)) == 'AstExprConstantNil'

CLEAN_VERSION = '1.3.0'


class CleanError(Exception):
    pass


# ---------------------------------------------------------------------
# literal accounting (same conventions as gates.py)
# ---------------------------------------------------------------------

def lit_add(acc, node):
    t = T(node)
    if t == 'AstExprConstantString':
        acc[('s', node.get('value'))] += 1
    elif t == 'AstExprConstantNumber':
        try:
            acc[('n', float(node.get('value')))] += 1
        except (TypeError, ValueError):
            pass


def lit_counter(node):
    acc = collections.Counter()
    walk(node, lambda n: lit_add(acc, n))
    return acc


def count_root_refs(node, akr_key, level, exclude_ids=None):
    """Count AstExprLocal references to akR or any alias local inside
    `node` (these are the references the clean map must account for).
    Subtrees whose root id is in `exclude_ids` are skipped (used for
    pool function entries, whose references are accounted when their
    hoisted definitions are transformed)."""
    cnt = [0]

    def f(n):
        if exclude_ids and id(n) in exclude_ids:
            return False
        if T(n) == 'AstExprLocal':
            k = var_key(n)
            if k == akr_key or k in level:
                cnt[0] += 1
        return True
    walk_pruned(node, f)
    return cnt[0]


def walk_pruned(node, fn):
    """Like luast_lib.walk, but fn may return False to prune a subtree."""
    if isinstance(node, dict):
        if fn(node) is False:
            return
        for v in node.values():
            walk_pruned(v, fn)
    elif isinstance(node, list):
        for v in node:
            walk_pruned(v, fn)


# ---------------------------------------------------------------------
# node constructors for minted AST fragments
# ---------------------------------------------------------------------

def mk_local_ref(name, loc_key):
    return {'type': 'AstExprLocal',
            'local': {'type': 'AstLocal', 'name': name,
                      'location': loc_key},
            'location': loc_key}


def mk_global(name):
    return {'type': 'AstExprGlobal', 'global': name,
            'location': 'clean:g'}


def mk_literal(entry):
    """Fresh AST node for a scalar pool entry (number/string/bool/nil)
    or a unary-minus number."""
    t = T(entry)
    if t == 'AstExprConstantNumber':
        return {'type': 'AstExprConstantNumber', 'value': entry['value'],
                'location': 'clean:lit'}
    if t == 'AstExprConstantString':
        return {'type': 'AstExprConstantString', 'value': entry['value'],
                'location': 'clean:lit'}
    if t == 'AstExprConstantBool':
        return {'type': 'AstExprConstantBool', 'value': entry['value'],
                'location': 'clean:lit'}
    if t == 'AstExprConstantNil':
        return {'type': 'AstExprConstantNil', 'location': 'clean:lit'}
    if t == 'AstExprUnary' and entry.get('op') == 'Minus':
        inner = unwrap(entry['expr'])
        if T(inner) == 'AstExprConstantNumber':
            # keep the dialect's shape: unary minus over a positive
            # constant (a bare negative ConstantNumber would reparse
            # to exactly this form anyway)
            return {'type': 'AstExprUnary', 'op': 'Minus',
                    'expr': {'type': 'AstExprConstantNumber',
                             'value': inner['value'],
                             'location': 'clean:lit'},
                    'location': 'clean:lit'}
    raise CleanError('pool entry is not a literal: %s' % t)


def is_pure(node):
    """No calls anywhere in the subtree (safe to drop / duplicate)."""
    bad = [False]

    def f(n):
        if T(n) in ('AstExprCall', 'AstExprFunction'):
            bad[0] = True
    walk(node, f)
    return not bad[0]


# ---------------------------------------------------------------------
# naming helpers
# ---------------------------------------------------------------------

KEYWORDS = {
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
    'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
    'repeat', 'return', 'then', 'true', 'until', 'while', 'continue',
    'export', 'type',
}

BUILTIN_GLOBALS = {
    'game', 'workspace', 'script', 'plugin', 'Enum', 'Instance',
    'BrickColor', 'Color3', 'ColorSequence', 'ColorSequenceKeypoint',
    'Vector3', 'Vector2', 'CFrame', 'UDim2', 'UDim', 'Rect', 'Random',
    'DateTime', 'NumberRange', 'NumberSequence', 'NumberSequenceKeypoint',
    'task', 'math', 'string', 'table', 'pairs', 'ipairs', 'next',
    'pcall', 'xpcall', 'select', 'typeof', 'tostring', 'tonumber',
    'print', 'warn', 'require', 'os', 'utf8', 'bit32', 'buffer',
    'coroutine', 'debug', 'setmetatable', 'getmetatable', 'rawget',
    'rawset', 'rawequal', 'rawlen', 'unpack', 'tick', 'time', 'wait',
    'spawn', 'delay', 'settings', 'UserSettings', 'shared', '_G',
    '_VERSION', 'loadstring', 'getfenv', 'setfenv', 'assert', 'error',
    'collectgarbage', 'gcinfo', 'elapsedTime', 'version', 'printidentity',
}

IDENT_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')


def camel(s, first_upper=False):
    parts = [p for p in re.split(r'[^0-9A-Za-z]+', s or '') if p]
    if not parts:
        return None
    if first_upper:
        name = ''.join(p[:1].upper() + p[1:] for p in parts)
    else:
        name = parts[0][:1].lower() + parts[0][1:] + ''.join(
            p[:1].upper() + p[1:] for p in parts[1:])
    if name and name[0].isdigit():
        name = 'n' + name
    if not name or name in KEYWORDS or not IDENT_RE.match(name):
        return None
    return name


def valid_ident(name):
    return bool(name) and bool(IDENT_RE.match(name)) \
        and name not in KEYWORDS


# ---------------------------------------------------------------------
# analysis
# ---------------------------------------------------------------------

class Analysis:
    pass


def analyze(root):
    """Full census of the deflattened AST: pool, aliases (fixpoint),
    register access census, invariants.  Raises CleanError on any
    pattern the cleaner cannot prove safe."""
    A = Analysis()
    A.root = root
    par = build_parents(root)
    A.par = par
    body = root['body']

    # --- locate akR declaration and the pool assignment -------------
    akr_key = None
    for s in body:
        if T(s) == 'AstStatLocal':
            for v in s['vars']:
                if v['name'] == 'akR':
                    akr_key = 'L:%s@%s' % (v['name'], v['location'])
    if akr_key is None:
        # fall back: the local referenced as base of the big table assign
        raise CleanError('akR declaration not found at chunk level')
    A.akr_key = akr_key

    def is_akr_local(e):
        e = unwrap(e)
        return T(e) == 'AstExprLocal' and var_key(e) == akr_key

    A.is_akr_local = is_akr_local

    pool_assign = None
    pool_topidx = None
    for i, s in enumerate(body):
        if T(s) != 'AstStatAssign':
            continue
        for var, val in zip(s['vars'], s.get('values') or []):
            v = unwrap(var)
            if (T(v) == 'AstExprIndexExpr' and is_akr_local(v['expr'])
                    and is_cnum(v['index'])
                    and int(cnum(v['index'])) == 128):
                vv = unwrap(val) if val is not None else None
                if vv is not None and T(vv) == 'AstExprTable' \
                        and len(vv.get('items') or []) > 500:
                    pool_assign, pool_topidx = s, i
    if pool_assign is None:
        raise CleanError('constants pool assignment not found')
    A.pool_assign = pool_assign
    A.pool_topidx = pool_topidx
    entries = [it['value']
               for it in unwrap(pool_assign['values'][0]).get('items')
               or []]
    pool = L.Pool(entries, akr_key)
    A.pool = pool
    aliases1 = L.collect_aliases(root, pool)
    pool.aliases = aliases1
    L.apply_permutation(pool, root, aliases1)
    A.perm_ids = {id(s) for s in pool.perm_stmts}

    # --- alias fixpoint ----------------------------------------------
    decls = []

    def find_decls(n):
        if T(n) == 'AstStatLocal':
            for v, val in zip(n['vars'], n.get('values') or []):
                if val is not None:
                    decls.append(('L:%s@%s' % (v['name'], v['location']),
                                  val))
    walk(root, find_decls)

    def classify_value(val):
        val = unwrap(val)
        if T(val) == 'AstExprLocal':
            k = var_key(val)
            if k == akr_key:
                return 'akr'
            return level.get(k)
        if T(val) == 'AstExprIndexExpr' and is_cnum(val['index']) \
                and int(cnum(val['index'])) == 128:
            if classify_value(val['expr']) == 'akr':
                return 'pool'
        return None

    level = {}
    changed = True
    while changed:
        changed = False
        for k, val in decls:
            if k in level:
                continue
            c = classify_value(val)
            if c:
                level[k] = c
                changed = True
    A.level = level

    def base_root(e):
        e = unwrap(e)
        if T(e) == 'AstExprLocal':
            k = var_key(e)
            if k == akr_key:
                return 'akr'
            if k in level:
                return level[k]
            return 'local'
        if T(e) == 'AstExprIndexExpr' and is_cnum(e['index']) \
                and int(cnum(e['index'])) == 128:
            if base_root(e['expr']) == 'akr':
                return 'pool'
        return 'other'
    A.base_root = base_root

    def in_perm(n):
        while n is not None:
            if id(n) in A.perm_ids:
                return True
            n = par.get(id(n))
        return False
    A.in_perm = in_perm

    # --- contexts ------------------------------------------------------
    func_entry_of = {}
    for i, e in enumerate(entries):
        u = unwrap(e)
        if T(u) == 'AstExprFunction':
            func_entry_of[id(u)] = i + 1
    A.func_entry_of = func_entry_of
    enc = {}
    order = [0]

    def mark(n, ctx):
        if isinstance(n, dict):
            enc[id(n)] = (ctx, order[0])
            order[0] += 1
            nctx = ctx
            if T(n) == 'AstExprFunction':
                nctx = func_entry_of.get(id(n), 'fn')
            for v in n.values():
                mark(v, nctx)
        elif isinstance(n, list):
            for v in n:
                mark(v, ctx)
    mark(root, 'chunk')
    A.enc = enc

    def seq(n):
        return A.enc.get(id(n), ('?', -1))[1]

    def ctx(n):
        return A.enc.get(id(n), ('?', -1))[0]
    A.seq = seq
    A.ctx = ctx

    # --- invariants: statement / expression dialect ------------------
    STMT_OK = {'AstStatBlock', 'AstStatIf', 'AstStatWhile',
               'AstStatRepeat', 'AstStatFor', 'AstStatForIn',
               'AstStatLocal', 'AstStatLocalFunction', 'AstStatAssign',
               'AstStatCompoundAssign', 'AstStatCall', 'AstStatReturn',
               'AstStatBreak', 'AstStatContinue', 'AstStatDo',
               'AstStatFunction', 'AstStatExpr'}
    bad_types = []

    def check_types(n):
        t = T(n)
        if t.startswith('AstStat') and t not in STMT_OK:
            bad_types.append(t)
    walk(root, check_types)
    if bad_types:
        raise CleanError('unsupported statement types: %s'
                         % sorted(set(bad_types)))

    def is_lvalue(n):
        p = par.get(id(n))
        if p is None:
            return False
        if T(p) == 'AstStatAssign':
            return any(v is n for v in p['vars'])
        if T(p) == 'AstStatCompoundAssign':
            return p.get('var') is n
        return False
    A.is_lvalue = is_lvalue

    # refs that sit inside an alias declaration's value are the
    # aliasing mechanism itself (deleted with the declaration), not
    # bare table uses
    decl_value_ref_ids = set()

    def mark_decl_values(n):
        if T(n) == 'AstStatLocal':
            for v, val in zip(n['vars'], n.get('values') or []):
                k = 'L:%s@%s' % (v['name'], v['location'])
                if k in level and val is not None:
                    def grab(m):
                        if T(m) == 'AstExprLocal':
                            kk = var_key(m)
                            if kk == akr_key or kk in level:
                                decl_value_ref_ids.add(id(m))
                    walk(val, grab)
    walk(root, mark_decl_values)

    # --- access census ---------------------------------------------------
    slot_reads = collections.defaultdict(list)
    slot_writes = collections.defaultdict(list)
    pool_reads = []          # (node, effective entry index)
    bare = []
    dyn = []

    def visit(n):
        t = T(n)
        if t == 'AstExprLocal':
            k = var_key(n)
            if k == akr_key or k in level:
                p = par.get(id(n))
                if not (p is not None and T(p) == 'AstExprIndexExpr'
                        and p.get('expr') is n) \
                        and id(n) not in decl_value_ref_ids:
                    bare.append(n)
            return
        if t != 'AstExprIndexExpr':
            return
        r = base_root(n['expr'])
        if r == 'pool':
            if not in_perm(n):
                if is_cnum(n['index']):
                    pool_reads.append((n, int(cnum(n['index']))))
                else:
                    dyn.append(('pool', n))
            return
        if r == 'akr':
            if not is_cnum(n['index']):
                dyn.append(('register', n))
                return
            slot = int(cnum(n['index']))
            if slot == 128:
                return  # pool base itself; part of a pool read / assign
            if is_lvalue(n):
                stmt = n
                while stmt is not None and T(stmt) not in (
                        'AstStatAssign', 'AstStatCompoundAssign'):
                    stmt = par.get(id(stmt))
                rhs = None
                if stmt is not None and T(stmt) == 'AstStatAssign':
                    for var, val in zip(stmt['vars'],
                                        stmt.get('values') or []):
                        if var is n:
                            rhs = val
                slot_writes[slot].append((n, stmt, rhs))
            else:
                slot_reads[slot].append(n)
    walk(root, visit)

    if bare:
        raise CleanError('bare akR/alias table uses: %d (first at %s)'
                         % (len(bare), loc_of(bare[0])))
    if dyn:
        raise CleanError('dynamic-index accesses: %s'
                         % [(k, loc_of(n)) for k, n in dyn[:5]])
    A.slot_reads = slot_reads
    A.slot_writes = slot_writes
    A.pool_reads = pool_reads

    # writes must be chunk-level statements
    for slot, ws in slot_writes.items():
        for node, stmt, rhs in ws:
            if ctx(node) != 'chunk':
                raise CleanError(
                    'register write to slot %d inside a function' % slot)
            if stmt is None or T(stmt) != 'AstStatAssign':
                raise CleanError(
                    'register write to slot %d is not a plain assign'
                    % slot)

    # pool writes only inside permutation statements
    def pool_writes(n):
        if T(n) == 'AstExprIndexExpr' and base_root(n['expr']) == 'pool' \
                and is_lvalue(n) and not in_perm(n):
            raise CleanError('pool write outside permutation at %s'
                             % loc_of(n))
    walk(root, pool_writes)

    # no AstExprGlobal named akR (would be an unbound read)
    def gcheck(n):
        if T(n) == 'AstExprGlobal' and n.get('global') == 'akR':
            raise CleanError('unbound global read of akR')
    walk(root, gcheck)

    # total input references (clean-map denominator)
    A.total_refs = count_root_refs(root, akr_key, level)
    A.input_literals = lit_counter(root)
    return A


# ---------------------------------------------------------------------
# naming decisions
# ---------------------------------------------------------------------

TITLE_KEYS = {'Title', 'Text', 'Name', 'Placeholder', 'PlaceholderText',
              'Header', 'TabName', 'SectionName'}
UI_METHODS = {'AddTab', 'CreateTab', 'NewTab', 'AddSection',
              'CreateSection', 'Section', 'AddButton', 'CreateButton',
              'AddToggle', 'CreateToggle', 'AddSlider', 'CreateSlider',
              'AddDropdown', 'CreateDropdown', 'AddInput', 'AddParagraph',
              'AddLabel', 'AddColorpicker', 'AddKeybind', 'AddTextbox'}
REMOTE_METHODS = {'FireServer', 'InvokeServer', 'FireAllClients',
                  'FireClient'}


def strings_in(node):
    out = []

    def f(n):
        if T(n) == 'AstExprConstantString':
            out.append(n['value'])
    walk(node, f)
    return out



def resolve_const_string(A, expr):
    """String value of an expression that is a string literal or a
    pool read of a string entry; None otherwise."""
    e = unwrap(expr)
    if T(e) == 'AstExprConstantString':
        return e['value']
    if T(e) == 'AstExprIndexExpr' and A.base_root(e['expr']) == 'pool' \
            and is_cnum(e['index']):
        entry = A.pool.entry(int(cnum(e['index'])))
        if entry is not None:
            entry = unwrap(entry)
            if T(entry) == 'AstExprConstantString':
                return entry['value']
    return None

def fn_name_evidence(A, fn_node):
    """(candidate, evidence) from a function body: UI title strings,
    remote-event names.  Deterministic: first hit in walk order whose
    camel form is usable."""
    found = []

    def visit(n):
        t = T(n)
        if t == 'AstExprTable':
            for it in n.get('items') or []:
                if it.get('key') is None:
                    continue
                ks = resolve_const_string(A, it['key'])
                vs = resolve_const_string(A, it['value'])
                if ks in TITLE_KEYS and vs is not None:
                    found.append((vs, "table %s = %r" % (ks, vs)))
        elif t == 'AstExprCall':
            f = unwrap(n['func'])
            if T(f) == 'AstExprIndexName':
                m = f.get('index')
                args = n.get('args') or []
                s0 = resolve_const_string(A, args[0]) if args else None
                if s0 is not None:
                    if m in UI_METHODS:
                        found.append((s0, 'UI call %s(%r)' % (m, s0)))
                    elif m in REMOTE_METHODS:
                        found.append((s0, 'remote %s(%r)' % (m, s0)))
                if m in REMOTE_METHODS:
                    base = unwrap(f['expr'])
                    rs = None
                    if T(base) == 'AstExprIndexExpr':
                        rs = resolve_const_string(A, base['index'])
                    elif T(base) == 'AstExprIndexName':
                        rs = base.get('index')
                    if rs:
                        found.append((rs, 'remote object %r :%s'
                                      % (rs, m)))
    walk(fn_node['body'], visit)
    for s, ev in found:
        c = camel(s)
        if c and len(c) >= 3:
            return c, ev
    return None, None


def scan_patterns(A, expr):
    """(name, evidence, pattern) candidates from service/child/instance
    patterns anywhere inside an expression subtree — except inside a
    nested function body.  A slot/local whose value IS a function must
    not inherit a name from something mentioned inside that function
    (v1.3.0 fix for the slot-reuse misnaming class: a function-valued
    register slot was named after a child its body happens to touch).
    `pattern` is a hashable identity of the evidence, used by the
    corroboration rule in decide_slots: ('call', method, arg) or
    ('string', value)."""
    found = []

    def visit(n):
        if T(n) != 'AstExprCall':
            return
        f = unwrap(n['func'])
        if T(f) != 'AstExprIndexName':
            return
        m = f.get('index')
        args = n.get('args') or []
        s = resolve_const_string(A, args[0]) if args else None
        if s is None:
            return
        base = unwrap(f['expr'])
        if m == 'GetService' and T(base) == 'AstExprGlobal' \
                and base.get('global') == 'game':
            if valid_ident(s):
                found.append((s, 'game:GetService(%r)' % s,
                              ('call', m, s)))
            else:
                c = camel(s, first_upper=True)
                if c:
                    found.append((c, 'game:GetService(%r)' % s,
                                  ('call', m, s)))
        elif m in ('WaitForChild', 'FindFirstChild',
                   'FindFirstChildOfClass', 'WaitForChildOfClass'):
            c = camel(s)
            if c:
                found.append((c, '%s(%r)' % (m, s), ('call', m, s)))
        elif m == 'new' and T(base) == 'AstExprGlobal' \
                and base.get('global') == 'Instance':
            c = camel(s, first_upper=True)
            if c:
                found.append((c, 'Instance.new(%r)' % s,
                              ('call', m, s)))

    def rec(n):
        # prune function bodies: their contents describe the function's
        # behaviour, not the value of the expression being scanned
        if isinstance(n, dict):
            if T(n) == 'AstExprFunction':
                return
            visit(n)
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)
    rec(expr)
    return found


def used_globals(root):
    out = set()

    def f(n):
        if T(n) == 'AstExprGlobal':
            out.add(n.get('global'))
    walk(root, f)
    return out


def chunk_local_names(root):
    out = set()
    for s in root['body']:
        if T(s) == 'AstStatLocal':
            out.update(v['name'] for v in s['vars'])
        elif T(s) == 'AstStatLocalFunction':
            out.add(s['name']['name'])
    return out


class Namer:
    """Uniqueness keeper: `used` holds every name that must not be
    shadowed or duplicated at chunk scope."""

    def __init__(self, seed):
        self.used = set(seed)

    def claim(self, cand):
        if cand is None or cand in self.used or not valid_ident(cand):
            return None
        self.used.add(cand)
        return cand

    def claim_unique(self, base):
        cand = base
        k = 2
        while cand in self.used or not valid_ident(cand):
            cand = '%s_%d' % (base, k)
            k += 1
        self.used.add(cand)
        return cand



def caller_evidence(A, fn_names, slot_disp):
    """Entry identity -> (candidate, evidence) from use sites: a pool
    function passed as a table 'Callback' value or as a direct argument
    of a named UI/remote call takes the call's label string."""
    par = A.par
    out = {}

    def eff_of(expr):
        e = unwrap(expr)
        if T(e) == 'AstExprIndexExpr' and is_cnum(e['index']):
            r = A.base_root(e['expr'])
            if r == 'pool':
                eff = A.pool.perm.get(int(cnum(e['index'])),
                                      int(cnum(e['index'])))
                ent = A.pool.entry(int(cnum(e['index'])))
                if ent is not None and T(unwrap(ent)) == \
                        'AstExprFunction':
                    return eff
            if r == 'akr':
                slot = int(cnum(e['index']))
                d = slot_disp.get(slot)
                if d and d['kind'] == 'eliminate' \
                        and d['target'][0] == 'fn':
                    return d['target'][1]
        return None

    def enclosing_call(node):
        n = par.get(id(node))
        while n is not None:
            if T(n) == 'AstExprCall':
                return n
            if T(n) in ('AstStatBlock', 'AstExprFunction'):
                return None
            n = par.get(id(n))
        return None

    def call_label(call):
        f = unwrap(call['func'])
        if T(f) != 'AstExprIndexName':
            return None
        args = call.get('args') or []
        if args:
            s = resolve_const_string(A, args[0])
            if s:
                return s, '%s(%r, ...)' % (f.get('index'), s)
        return None

    def visit(n):
        t = T(n)
        if t == 'AstExprTable':
            for it in n.get('items') or []:
                if it.get('key') is None:
                    continue
                ks = resolve_const_string(A, it['key'])
                if ks != 'Callback':
                    continue
                eff = eff_of(it['value'])
                if eff is None or eff in out:
                    continue
                call = enclosing_call(n)
                if call is not None:
                    lab = call_label(call)
                    if lab:
                        out[eff] = (lab[0], 'callback of ' + lab[1])
        elif t == 'AstExprCall':
            f = unwrap(n['func'])
            if T(f) == 'AstExprIndexName':
                args = n.get('args') or []
                s0 = resolve_const_string(A, args[0]) if args else None
                if s0:
                    for a in args[1:]:
                        eff = eff_of(a)
                        if eff is not None and eff not in out:
                            out[eff] = (s0, 'argument of %s(%r, ...)'
                                        % (f.get('index'), s0))
    walk(A.root, visit)
    res = {}
    for eff, (s, ev) in out.items():
        c = camel(s)
        if c and len(c) >= 3:
            res[eff] = (c, ev)
    return res

def decide_functions(A):
    """literal index -> (name, label, evidence) for function entries."""
    seed = used_globals(A.root) | chunk_local_names(A.root) \
        | BUILTIN_GLOBALS
    namer = Namer(seed)
    out = {}
    pool = A.pool
    fn_lits = [i + 1 for i, e in enumerate(pool.entries)
               if T(unwrap(e)) == 'AstExprFunction']
    for lit in sorted(fn_lits):
        entry = unwrap(pool.entry(lit, effective=False))
        cand, ev = fn_name_evidence(A, entry)
        name = namer.claim(cand) if cand else None
        if name:
            out[lit] = (name, 'INFERRED', ev)
        else:
            name = namer.claim_unique('poolFn%d' % lit)
            out[lit] = (name, 'neutral',
                        'no naming evidence in body')
    return out, namer


def classify_elim_target(A, rhs):
    """For a single-write slot: can the write be eliminated, reads
    replaced by a side-effect-free target?  Returns a tuple or None."""
    r = unwrap(rhs)
    t = T(r)
    if t == 'AstExprGlobal':
        return ('global', r['global'])
    if t in ('AstExprConstantString', 'AstExprConstantNumber',
             'AstExprConstantBool'):
        return ('literal', r)
    if t == 'AstExprIndexExpr' and A.base_root(r['expr']) == 'pool' \
            and is_cnum(r['index']):
        lit = int(cnum(r['index']))
        entry = A.pool.entry(lit)
        if entry is not None:
            entry = unwrap(entry)
        if entry is None:
            return None
        et = T(entry)
        if et == 'AstExprFunction':
            return ('fn', A.pool.perm.get(lit, lit))
        if et == 'AstExprGlobal':
            return ('global', entry['global'])
        if et in ('AstExprConstantString', 'AstExprConstantNumber',
                  'AstExprConstantBool', 'AstExprConstantNil',
                  'AstExprUnary'):
            try:
                mk_literal(entry)
                return ('pool-literal', entry)
            except CleanError:
                return None
        if et in ('AstExprIndexName', 'AstExprIndexExpr') \
                and is_pure(entry) \
                and count_root_refs(entry, A.akr_key, A.level) == 0:
            return ('pool-expr', entry)
    return None


def slot_name_evidence(A, writes):
    """First naming hit across writes (in program order), plus its
    pattern identity for the corroboration rule.  Returns
    (candidate, evidence, pattern) or (None, None, None)."""
    for node, stmt, rhs in writes:
        if rhs is None:
            continue
        for cand, ev, pat in scan_patterns(A, rhs):
            return cand, ev, pat
        r = unwrap(rhs)
        if T(r) == 'AstExprConstantString':
            c = camel(r['value'])
            if c and len(c) >= 3:
                return c, 'string value %r' % r['value'], \
                    ('string', r['value'])
    return None, None, None


def _write_matches_pattern(A, rhs, pat):
    """Does this write's RHS (top level, function bodies pruned)
    exhibit the evidence pattern?"""
    if rhs is None or pat is None:
        return False
    if pat[0] == 'string':
        r = unwrap(rhs)
        return T(r) == 'AstExprConstantString' \
            and r['value'] == pat[1]
    return any(p == pat for _, _, p in scan_patterns(A, rhs))


def decide_slots(A, fn_names, namer):
    """slot -> disposition dict:
       {'kind': 'dead'}
       {'kind': 'eliminate-nil'}
       {'kind': 'eliminate', 'target': (...), 'via': write seq info}
       {'kind': 'promote', 'name': ..., 'label': ..., 'evidence': ...}
    """
    seq = A.seq
    out = {}
    slots = sorted(set(A.slot_reads) | set(A.slot_writes))
    for slot in slots:
        writes = sorted(A.slot_writes.get(slot, []),
                        key=lambda w: seq(w[0]))
        reads = A.slot_reads.get(slot, [])
        nonnil = [(n, s, r) for (n, s, r) in writes
                  if r is not None and not is_nil_expr(r)]
        if not reads:
            out[slot] = {'kind': 'dead'}
            continue
        if not nonnil:
            out[slot] = {'kind': 'eliminate-nil'}
            continue
        disp = None
        if len(nonnil) == 1:
            wnode, wstmt, wrhs = nonnil[0]
            last_write = writes[-1][0] is wnode
            reads_after = all(seq(r) > seq(wnode) for r in reads)
            if last_write and reads_after:
                tgt = classify_elim_target(A, wrhs)
                if tgt is not None:
                    disp = {'kind': 'eliminate', 'target': tgt,
                            'write': wnode}
        if disp is None:
            cand, ev, pat = slot_name_evidence(A, writes)
            conflict = None
            if cand is not None:
                # Corroboration rule (v1.3.0, slot-reuse fix): a
                # register slot is VM scratch reused across machines,
                # so a name drawn from ONE write is only trustworthy
                # when the evidence pattern reappears across the
                # slot's writes.  With < 8 non-nil writes a single
                # defining write is the whole story and is kept; with
                # >= 8, an uncorroborated name (< 3 supporting writes
                # and < 25% of non-nil writes) is a misnomer for most
                # of the slot's live ranges and is downgraded.
                support = sum(
                    1 for (_, _, r) in nonnil
                    if _write_matches_pattern(A, r, pat))
                if len(nonnil) >= 8 and (support < 3
                                         or support < 0.25 * len(nonnil)):
                    conflict = {
                        'candidate': cand, 'evidence': ev,
                        'supporting_writes': support,
                        'nonnil_writes': len(nonnil),
                        'reason': 'evidence pattern appears in %d of '
                                  '%d non-nil writes; slot is reused '
                                  'across machines, so the single-write '
                                  'name would misdescribe most uses'
                                  % (support, len(nonnil)),
                    }
                    cand = None
            name = namer.claim(cand) if cand else None
            if name:
                disp = {'kind': 'promote', 'name': name,
                        'label': 'INFERRED', 'evidence': ev}
            else:
                name = namer.claim_unique('reg%d' % slot)
                disp = {'kind': 'promote', 'name': name,
                        'label': 'neutral',
                        'evidence': 'runtime register, %d writes / %d reads'
                                    % (len(writes), len(reads))}
                if conflict is not None:
                    disp['name_conflict'] = conflict
        out[slot] = disp
    return out


def compute_placement(A, fn_names, slot_disp):
    """Where each hoisted pool function is defined: the deepest
    AstStatBlock containing all of its reads (direct pool reads plus
    reads arriving via eliminated register slots), or 'poolpos' (the
    pool assignment's own position) when the reads share only the
    chunk block.  Returns (placement, dropped): placement maps the
    entry identity to a block id or 'poolpos'; dropped lists entries
    with no reads at all."""
    par = A.par
    reads = collections.defaultdict(list)
    for node, lit in A.pool_reads:
        eff = A.pool.perm.get(lit, lit)
        if eff in fn_names:
            reads[eff].append(node)
    for slot, d in slot_disp.items():
        if d['kind'] == 'eliminate' and d['target'][0] == 'fn':
            reads[d['target'][1]].extend(A.slot_reads.get(slot, []))

    def blocks_of(node):
        out = []
        n = par.get(id(node))
        while n is not None:
            if T(n) == 'AstStatBlock':
                out.append(n)
            n = par.get(id(n))
        return out

    placement = {}
    dropped = []
    for eff in sorted(fn_names):
        nodes = reads.get(eff, [])
        if not nodes:
            dropped.append(eff)
            continue
        chains = [blocks_of(n) for n in nodes]
        common = None
        for c in chains[0]:
            if all(any(x is c for x in ch) for ch in chains[1:]):
                common = c
                break
        if common is None or common is A.root:
            placement[eff] = 'poolpos'
        else:
            placement[eff] = id(common)
    return placement, dropped


def collect_decls(root):
    """All local declarations with their enclosing-function context.
    Returns (decls, fn_parent) where fn ids are id(AstExprFunction)
    or 0 for the chunk."""
    decls = []
    fn_parent = {0: None}
    fn_node = {0: root}

    def rec(n, fnid):
        if isinstance(n, dict):
            t = n.get('type')
            cur = fnid
            if t == 'AstExprFunction':
                cur = id(n)
                fn_parent[cur] = fnid
                fn_node[cur] = n
                for i, a in enumerate(n.get('args') or []):
                    decls.append({'key': 'L:%s@%s' % (a['name'],
                                                      a['location']),
                                  'name': a['name'], 'kind': 'param',
                                  'argidx': i, 'init': None, 'fn': cur,
                                  'node': a})
            elif t == 'AstStatLocal':
                vals = n.get('values') or []
                for i, v in enumerate(n['vars']):
                    decls.append({'key': 'L:%s@%s' % (v['name'],
                                                      v['location']),
                                  'name': v['name'], 'kind': 'local',
                                  'argidx': i,
                                  'init': vals[i] if i < len(vals)
                                          else None,
                                  'fn': fnid, 'node': v})
            elif t == 'AstStatLocalFunction':
                decls.append({'key': 'L:%s@%s' % (n['name']['name'],
                                                  n['name']['location']),
                              'name': n['name']['name'],
                              'kind': 'localfn', 'argidx': 0,
                              'init': n['func'], 'fn': fnid,
                              'node': n['name']})
            elif t == 'AstStatFor':
                v = n['var']
                decls.append({'key': 'L:%s@%s' % (v['name'],
                                                  v['location']),
                              'name': v['name'], 'kind': 'for',
                              'argidx': 0, 'init': None, 'fn': fnid,
                              'node': v})
            elif t == 'AstStatForIn':
                for i, v in enumerate(n['vars']):
                    decls.append({'key': 'L:%s@%s' % (v['name'],
                                                      v['location']),
                                  'name': v['name'], 'kind': 'forin',
                                  'argidx': i, 'init': None, 'fn': fnid,
                                  'node': v})
            for v in n.values():
                rec(v, cur)
        elif isinstance(n, list):
            for v in n:
                rec(v, fnid)
    rec(root, 0)
    return decls, fn_parent, fn_node


def decide_locals(A, fn_names, slot_disp, namer,
                  extra_chunk_names=()):
    """Rename plan for every payload local: {key: (new, label, ev)}.
    Alias locals and akR itself are excluded (deleted / dissolved)."""
    root = A.root
    decls, fn_parent, fn_node = collect_decls(root)
    skip = set(A.level) | {A.akr_key}

    # globals referenced inside each function subtree (shadowing guard)
    globals_cache = {}

    def globals_in(fnid):
        if fnid not in globals_cache:
            globals_cache[fnid] = used_globals(fn_node[fnid])
        return globals_cache[fnid]

    # keys invoked as functions somewhere
    called_keys = set()

    def find_calls(n):
        if T(n) == 'AstExprCall':
            f = unwrap(n['func'])
            if T(f) == 'AstExprLocal':
                called_keys.add(var_key(f))
    walk(root, find_calls)

    # first assignment RHS per local (for init-less decls)
    first_assign = {}
    par = A.par

    def find_refs(n):
        if T(n) != 'AstExprLocal':
            return
        k = var_key(n)
        p = par.get(id(n))
        if p is not None and T(p) == 'AstStatAssign':
            for var, val in zip(p['vars'], p.get('values') or []):
                if var is n and val is not None:
                    cur = first_assign.get(k)
                    if cur is None or A.seq(n) < A.seq(cur[0]):
                        first_assign[k] = (n, val)
    walk(root, find_refs)

    def init_evidence(expr):
        if expr is None:
            return None, None
        e = unwrap(expr)
        t = T(e)
        if t == 'AstExprIndexExpr' and A.base_root(e['expr']) == 'pool' \
                and is_cnum(e['index']):
            lit = int(cnum(e['index']))
            entry = A.pool.entry(lit)
            if entry is not None:
                entry = unwrap(entry)
                et = T(entry)
                if et == 'AstExprFunction':
                    eff = A.pool.perm.get(lit, lit)
                    return fn_names[eff][0], \
                        'initialized from pool function %s' \
                        % fn_names[eff][0]
                if et == 'AstExprGlobal':
                    return entry['global'], 'pool global %s' % entry['global']
                if et == 'AstExprConstantString':
                    c = camel(entry['value'])
                    if c and len(c) >= 3:
                        return c, 'pool string %r' % entry['value']
            return None, None
        if t == 'AstExprGlobal':
            return e['global'], 'global %s' % e['global']
        if t == 'AstExprIndexName':
            base = unwrap(e['expr'])
            if T(base) == 'AstExprGlobal':
                c = camel('%s %s' % (base['global'], e['index']))
                if c:
                    return c, 'global field %s.%s' % (base['global'],
                                                       e['index'])
            return None, None
        if t == 'AstExprFunction':
            return fn_name_evidence(A, e)
        for cand, ev, _pat in scan_patterns(A, e):
            return cand, ev
        if t == 'AstExprConstantString':
            c = camel(e['value'])
            if c and len(c) >= 3:
                return c, 'string value %r' % e['value']
        return None, None

    originals = collections.defaultdict(set)
    for d in decls:
        if d['key'] not in skip:
            originals[d['fn']].add(d['name'])
    chunk_extra = {v[0] for v in fn_names.values()}
    chunk_extra |= {d['name'] for d in slot_disp.values()
                    if d['kind'] == 'promote'}
    chunk_extra |= set(extra_chunk_names)
    taken = collections.defaultdict(set)
    counters = collections.defaultdict(int)
    chosen = {}

    def ancestor_names(fnid):
        out = set()
        f = fn_parent.get(fnid)
        while f is not None:
            out |= taken[f]
            if f == 0:
                out |= chunk_extra
            f = fn_parent.get(f)
        return out

    def ok(cand, d):
        if not valid_ident(cand):
            return False
        fnid = d['fn']
        if cand in globals_in(fnid):
            return False
        if cand in originals[fnid] and cand != d['name']:
            return False
        if cand in taken[fnid]:
            return False
        if cand in ancestor_names(fnid):
            return False
        if fnid == 0 and cand in chunk_extra:
            return False
        return True

    plan = {}
    for d in sorted((d for d in decls if d['key'] not in skip),
                    key=lambda d: A.seq(d['node'])):
        fnid = d['fn']
        cand = None
        ev = None
        label = None
        if d['kind'] == 'param':
            if d['key'] in called_keys:
                cand, ev, label = 'callback', \
                    'parameter is invoked as a function', 'INFERRED'
            else:
                cand = 'arg%d' % (d['argidx'] + 1)
                ev, label = 'parameter #%d' % (d['argidx'] + 1), 'neutral'
        elif d['kind'] == 'for':
            cand, ev, label = 'i', 'numeric for-loop variable', 'neutral'
        elif d['kind'] == 'forin':
            cand = ('key', 'value')[d['argidx']] if d['argidx'] < 2 \
                else None
            ev, label = 'generic for-loop variable', 'neutral'
        else:
            cand, ev = init_evidence(d['init'])
            if cand:
                label = 'INFERRED'
            elif d['init'] is None and d['key'] in first_assign:
                cand, ev = init_evidence(first_assign[d['key']][1])
                if cand:
                    label = 'INFERRED'
                    ev = 'first assignment: ' + ev
        if cand is None or not ok(cand, d):
            counters[fnid] += 1
            cand = 'v%d' % counters[fnid]
            while not ok(cand, d):
                counters[fnid] += 1
                cand = 'v%d' % counters[fnid]
            label = 'neutral'
            ev = ev or 'no naming evidence'
        plan[d['key']] = (cand, label, ev)
        taken[fnid].add(cand)
        chosen[d['key']] = cand
    return plan


# ---------------------------------------------------------------------
# transform
# ---------------------------------------------------------------------

class Book:
    def __init__(self):
        self.removed = collections.Counter()
        self.inserted = collections.Counter()
        self.per_ctx_removed = collections.defaultdict(
            collections.Counter)
        self.per_ctx_inserted = collections.defaultdict(
            collections.Counter)

    def rm(self, node, ctx):
        c = lit_counter(node)
        self.removed += c
        self.per_ctx_removed[ctx] += c

    def ins(self, node, ctx):
        c = lit_counter(node)
        self.inserted += c
        self.per_ctx_inserted[ctx] += c


def count_stmts(node):
    cnt = [0]

    def f(n):
        t = T(n)
        if t and t.startswith('AstStat'):
            cnt[0] += 1
    walk(node, f)
    return cnt[0]


class Transformer:
    def __init__(self, A, fn_names, slot_disp, placement=None,
                 state_name='state'):
        self.A = A
        self.fn_names = fn_names
        self.disp = slot_disp
        self.book = Book()
        self.refcats = collections.Counter()
        self.ctx = 'chunk'
        self.fn_audit = {}
        self.stmt_deleted = collections.Counter()   # per ctx
        self.dead_expr_kept = 0
        self.state_name = state_name
        self.reg_order = [s for s in sorted(slot_disp)
                          if slot_disp[s]['kind'] == 'promote']
        placement = placement or {}
        self.poolpos_lits = sorted(
            e for e, p in placement.items() if p == 'poolpos')
        self.pending = collections.defaultdict(list)
        for e, p in placement.items():
            if p != 'poolpos':
                self.pending[p].append(e)
        for v in self.pending.values():
            v.sort()

    def state_ref(self):
        return mk_local_ref(self.state_name, 'clean:state')

    def state_field(self, field):
        return {'type': 'AstExprIndexName',
                'expr': self.state_ref(),
                'index': field,
                'location': 'clean:field'}

    # -- booking helpers ---------------------------------------------
    def book_refs(self, node, category, exclude_ids=None):
        self.refcats[category] += count_root_refs(
            node, self.A.akr_key, self.A.level, exclude_ids)

    # -- entry ---------------------------------------------------------
    def transform_root(self, root):
        new = dict(root)
        new['body'] = self.rw_stmt_list(root['body'])
        return new

    def rw_block(self, block):
        new = dict(block)
        body = self.rw_stmt_list(block.get('body') or [])
        pending = self.pending.get(id(block))
        if pending:
            body = self.build_fn_defs(pending) + body
        new['body'] = body
        return new

    def rw_stmt_list(self, stmts):
        out = []
        for s in stmts:
            if id(s) in self.A.perm_ids:
                self.book.rm(s, self.ctx)
                self.book_refs(s, 'permutation statements (deleted)')
                self.stmt_deleted[self.ctx] += 1
                continue
            if s is self.A.pool_assign:
                self.book.rm(s, self.ctx)
                fn_ids = {id(e) for e in self.A.pool.entries
                          if T(unwrap(e)) == 'AstExprFunction'}
                self.book_refs(s, 'pool table assignment (deleted)',
                               exclude_ids=fn_ids)
                self.stmt_deleted[self.ctx] += 1
                out.extend(self.build_fn_defs(self.poolpos_lits))
                continue
            out.extend(self.rw_stmt(s))
        return out

    # -- function definitions from pool entries ------------------------
    def build_fn_defs(self, lits):
        defs = []
        for lit in lits:
            name = self.fn_names[lit][0]
            entry = unwrap(self.A.pool.entry(lit,
                                                 effective=False))
            fn = copy.deepcopy(entry)
            self.book.ins(fn, ('poolFn', lit))
            prev = self.ctx
            self.ctx = ('poolFn', lit)
            body = self.rw_block(fn['body'])
            self.ctx = prev
            fn2 = dict(fn)
            fn2['body'] = body
            defs.append({'type': 'AstStatLocalFunction',
                         'location': 'clean:fn%d' % lit,
                         'name': {'type': 'AstLocal', 'name': name,
                                  'location': 'clean:fn%d' % lit},
                         'func': fn2})
            self.fn_audit[lit] = {
                'name': name,
                'stmts_in': count_stmts(entry['body']),
                'stmts_out': count_stmts(body),
                'deleted': self.stmt_deleted[('poolFn', lit)],
                'lit_in': lit_counter(entry['body']),
                'lit_out': lit_counter(body),
            }
        return defs

    def reg_decl_stmts(self):
        if not self.reg_order:
            return []
        return [{'type': 'AstStatLocal',
                 'location': 'clean:state',
                 'vars': [{'type': 'AstLocal', 'name': self.state_name,
                           'location': 'clean:state'}],
                 'values': [{'type': 'AstExprTable',
                             'location': 'clean:state',
                             'items': []}]}]

    # -- pool / register read resolution -------------------------------
    def resolve_pool_read(self, n):
        A = self.A
        lit = int(cnum(n['index']))
        entry = A.pool.entry(lit)
        eff = A.pool.perm.get(lit, lit)
        if entry is None:
            raise CleanError('pool read of missing entry %d' % lit)
        entry = unwrap(entry)
        et = T(entry)
        self.book.rm(n, self.ctx)
        if et == 'AstExprFunction':
            self.book_refs(n, 'pool read -> named function')
            name = self.fn_names[eff][0]
            return mk_local_ref(name, 'clean:fn%d' % eff)
        if et == 'AstExprGlobal':
            self.book_refs(n, 'pool read -> global')
            return mk_global(entry['global'])
        if et in ('AstExprConstantString', 'AstExprConstantNumber',
                  'AstExprConstantBool', 'AstExprConstantNil',
                  'AstExprUnary'):
            node = mk_literal(entry)
            self.book.ins(node, self.ctx)
            self.book_refs(n, 'pool read -> literal inlined')
            return node
        if et in ('AstExprIndexName', 'AstExprIndexExpr'):
            if count_root_refs(entry, A.akr_key, A.level) != 0:
                raise CleanError(
                    'pool entry %d expression references the pool' % lit)
            node = copy.deepcopy(entry)
            self.book.ins(node, self.ctx)
            self.book_refs(n, 'pool read -> expression copied')
            return self.rw_expr(node)
        raise CleanError('pool entry %d has unhandled type %s'
                         % (lit, et))

    def resolve_slot_read(self, n, slot):
        d = self.disp[slot]
        kind = d['kind']
        self.book.rm(n, self.ctx)
        if kind == 'promote':
            self.book_refs(n, 'register read -> state field')
            return self.state_field(d['name'])
        if kind == 'eliminate-nil':
            self.book_refs(n, 'register read -> nil (never written '
                              'non-nil)')
            return {'type': 'AstExprConstantNil',
                    'location': 'clean:nil'}
        if kind == 'eliminate':
            tgt = d['target']
            if tgt[0] == 'fn':
                self.book_refs(n, 'register read -> eliminated to '
                                  'function')
                eff = tgt[1]
                return mk_local_ref(self.fn_names[eff][0],
                                    'clean:fn%d' % eff)
            if tgt[0] == 'global':
                self.book_refs(n, 'register read -> eliminated to '
                                  'global')
                return mk_global(tgt[1])
            if tgt[0] == 'literal':
                node = copy.deepcopy(tgt[1])
                self.book.ins(node, self.ctx)
                self.book_refs(n, 'register read -> eliminated to '
                                  'literal')
                return node
            if tgt[0] == 'pool-literal':
                node = mk_literal(tgt[1])
                self.book.ins(node, self.ctx)
                self.book_refs(n, 'register read -> eliminated to '
                                  'literal')
                return node
            if tgt[0] == 'pool-expr':
                node = copy.deepcopy(tgt[1])
                self.book.ins(node, self.ctx)
                self.book_refs(n, 'register read -> eliminated to '
                                  'expression')
                return self.rw_expr(node)
        raise CleanError('slot %d read with disposition %s'
                         % (slot, kind))

    # -- expressions -----------------------------------------------------
    def rw_expr(self, n):
        t = T(n)
        if t == 'AstExprIndexExpr':
            r = self.A.base_root(n['expr'])
            if r == 'pool':
                return self.resolve_pool_read(n)
            if r == 'akr':
                if not is_cnum(n['index']):
                    raise CleanError('dynamic register index survived '
                                     'analysis')
                slot = int(cnum(n['index']))
                if slot == 128:
                    raise CleanError('bare pool table value reached '
                                     'transform at %s' % loc_of(n))
                return self.resolve_slot_read(n, slot)
            n2 = dict(n)
            n2['expr'] = self.rw_expr(n['expr'])
            idx = n.get('index')
            n2['index'] = self.rw_expr(idx) if isinstance(idx, dict) \
                else idx
            return n2
        if t == 'AstExprLocal':
            k = var_key(n)
            if k == self.A.akr_key or k in self.A.level:
                raise CleanError('bare akR/alias reference survived '
                                 'analysis at %s' % loc_of(n))
            return n
        if t == 'AstExprFunction':
            n2 = dict(n)
            n2['body'] = self.rw_block(n['body'])
            return n2
        return self.rw_generic(n)

    def rw_generic(self, n):
        """Rebuild a node rw_expr has already dispatched, transforming
        only its children."""
        if isinstance(n, dict):
            return {k: self.rw_any(v) for k, v in n.items()}
        if isinstance(n, list):
            return [self.rw_any(v) for v in n]
        return n

    def rw_any(self, v):
        if isinstance(v, dict):
            t = v.get('type')
            if t and t.startswith('AstExpr'):
                return self.rw_expr(v)
            if t and t.startswith('AstStat'):
                raise CleanError('statement %s in expression position'
                                 % t)
            return {k: self.rw_any(x) for k, x in v.items()}
        if isinstance(v, list):
            return [self.rw_any(x) for x in v]
        return v

    def rw_exprs(self, xs):
        return [self.rw_expr(x) for x in xs]

    # -- statements ------------------------------------------------------
    def rw_stmt(self, n):
        t = T(n)
        if t == 'AstStatBlock':
            return [self.rw_block(n)]
        if t == 'AstStatLocal':
            return self.rw_local(n)
        if t == 'AstStatAssign':
            return self.rw_assign(n)
        if t == 'AstStatLocalFunction':
            n2 = dict(n)
            fn = dict(n['func'])
            fn['body'] = self.rw_block(n['func']['body'])
            n2['func'] = fn
            return [n2]
        if t == 'AstStatIf':
            n2 = dict(n)
            n2['condition'] = self.rw_expr(n['condition'])
            n2['thenbody'] = self.rw_block(n['thenbody'])
            eb = n.get('elsebody')
            if eb is not None:
                if T(eb) == 'AstStatIf':
                    n2['elsebody'] = self.rw_stmt(eb)[0]
                else:
                    n2['elsebody'] = self.rw_block(eb)
            return [n2]
        if t == 'AstStatWhile':
            n2 = dict(n)
            n2['condition'] = self.rw_expr(n['condition'])
            n2['body'] = self.rw_block(n['body'])
            return [n2]
        if t == 'AstStatRepeat':
            n2 = dict(n)
            n2['body'] = self.rw_block(n['body'])
            n2['condition'] = self.rw_expr(n['condition'])
            return [n2]
        if t == 'AstStatFor':
            n2 = dict(n)
            n2['from'] = self.rw_expr(n['from'])
            n2['to'] = self.rw_expr(n['to'])
            if n.get('step') is not None:
                n2['step'] = self.rw_expr(n['step'])
            n2['body'] = self.rw_block(n['body'])
            return [n2]
        if t == 'AstStatForIn':
            n2 = dict(n)
            n2['values'] = self.rw_exprs(n['values'])
            n2['body'] = self.rw_block(n['body'])
            return [n2]
        if t == 'AstStatDo':
            n2 = dict(n)
            n2['body'] = self.rw_block(n['body'])
            return [n2]
        if t == 'AstStatCall':
            return [{'type': 'AstStatCall',
                     'location': n.get('location'),
                     'call': self.rw_expr(n['call'])}]
        if t == 'AstStatExpr':
            n2 = dict(n)
            n2['expr'] = self.rw_expr(n['expr'])
            return [n2]
        if t == 'AstStatReturn':
            n2 = dict(n)
            key = 'list' if 'list' in n else 'values'
            n2[key] = self.rw_exprs(n.get(key) or [])
            return [n2]
        if t == 'AstStatCompoundAssign':
            n2 = dict(n)
            n2['var'] = self.rw_expr(n['var'])
            n2['value'] = self.rw_expr(n['value'])
            return [n2]
        if t in ('AstStatBreak', 'AstStatContinue'):
            return [n]
        raise CleanError('unsupported statement in transform: %s' % t)

    def rw_local(self, n):
        A = self.A
        out_vars = []
        out_vals = []
        extras = []
        vals = n.get('values') or []
        deleted = False
        for i, v in enumerate(n['vars']):
            key = 'L:%s@%s' % (v['name'], v['location'])
            val = vals[i] if i < len(vals) else None
            if key == A.akr_key:
                extras.extend(self.reg_decl_stmts())
                if val is not None:
                    self.book.rm(val, self.ctx)
                deleted = True
                continue
            if key in A.level:
                if val is not None:
                    self.book.rm(val, self.ctx)
                    self.book_refs(val, 'alias declaration (deleted)')
                deleted = True
                continue
            out_vars.append(v)
            if val is not None:
                out_vals.append(self.rw_expr(val))
        res = list(extras)
        if out_vars:
            n2 = dict(n)
            n2['vars'] = out_vars
            n2['values'] = out_vals
            res.append(n2)
        elif deleted:
            self.stmt_deleted[self.ctx] += 1
        return res

    def rw_assign(self, n):
        A = self.A
        vars_ = n['vars']
        vals = n.get('values') or []
        pairs = [(vars_[i], vals[i] if i < len(vals) else None)
                 for i in range(len(vars_))]
        out_vars = []
        out_vals = []
        extras = []
        dropped = False
        for var, val in pairs:
            u = unwrap(var)
            if T(u) == 'AstExprIndexExpr' \
                    and A.base_root(u['expr']) == 'pool':
                raise CleanError('pool write outside permutation at %s'
                                 % loc_of(n))
            if T(u) == 'AstExprIndexExpr' \
                    and A.base_root(u['expr']) == 'akr' \
                    and is_cnum(u['index']):
                slot = int(cnum(u['index']))
                if slot == 128:
                    if val is None or is_nil_expr(val):
                        self.book.rm(u, self.ctx)
                        self.book_refs(u, 'pool slot nil clear '
                                          '(scaffolding)')
                        if val is not None:
                            self.book.rm(val, self.ctx)
                        dropped = True
                        continue
                    raise CleanError('pool table write outside its '
                                     'assignment at %s' % loc_of(n))
                d = self.disp[slot]
                kind = d['kind']
                if kind == 'promote':
                    self.book.rm(u, self.ctx)
                    self.book_refs(u, 'register write -> state field')
                    out_vars.append(self.state_field(d['name']))
                    if val is not None:
                        out_vals.append(self.rw_expr(val))
                    continue
                if kind == 'eliminate':
                    if val is None or is_nil_expr(val):
                        self.book.rm(u, self.ctx)
                        self.book_refs(u, 'register write -> nil '
                                          'write dropped')
                        if val is not None:
                            self.book.rm(val, self.ctx)
                        dropped = True
                        continue
                    if d['write'] is not u:
                        raise CleanError(
                            'eliminated slot %d written more than once '
                            'with a value' % slot)
                    self.book.rm(u, self.ctx)
                    self.book_refs(u, 'register write -> eliminated '
                                      'slot write')
                    if val is not None:
                        self.book.rm(val, self.ctx)
                        self.book_refs(val, 'register write -> '
                                            'eliminated slot write')
                    dropped = True
                    continue
                if kind == 'eliminate-nil':
                    self.book.rm(u, self.ctx)
                    self.book_refs(u, 'register write -> nil write '
                                      'dropped')
                    if val is not None:
                        self.book.rm(val, self.ctx)
                        self.book_refs(val, 'register write -> nil '
                                            'write dropped')
                    dropped = True
                    continue
                if kind == 'dead':
                    self.book.rm(u, self.ctx)
                    self.book_refs(u, 'register write -> dead slot')
                    if val is not None:
                        if is_pure(val):
                            self.book.rm(val, self.ctx)
                            self.book_refs(val, 'register write -> '
                                                'dead slot')
                        else:
                            self.book_refs(val, 'register write -> '
                                                'dead slot, value kept')
                            rv = self.rw_expr(val)
                            if T(unwrap(rv)) == 'AstExprCall':
                                extras.append({'type': 'AstStatCall',
                                               'location':
                                                   n.get('location'),
                                               'call': rv})
                            else:
                                extras.append({
                                    'type': 'AstStatLocal',
                                    'location': n.get('location'),
                                    'vars': [{'type': 'AstLocal',
                                              'name': '_',
                                              'location':
                                                  'clean:dead'}],
                                    'values': [rv]})
                            self.dead_expr_kept += 1
                    dropped = True
                    continue
                raise CleanError('slot %d write, disposition %s'
                                 % (slot, kind))
            out_vars.append(self.rw_expr(var))
            if val is not None:
                out_vals.append(self.rw_expr(val))
        if len(pairs) > 1 and extras:
            # splitting a multi-variable assign would reorder RHS
            # side effects; refuse rather than risk it
            raise CleanError('multi-variable assign with impure dead '
                             'value at %s' % loc_of(n))
        res = list(extras)
        if out_vars:
            n2 = dict(n)
            n2['vars'] = out_vars
            n2['values'] = out_vals
            res.append(n2)
        elif dropped:
            self.stmt_deleted[self.ctx] += 1
        return res


# ---------------------------------------------------------------------
# rename application + printing
# ---------------------------------------------------------------------

def apply_renames(root, renames):
    """renames: {'L:name@location': new_name}.  Mutates every embedded
    AstLocal copy (declarations and references share the location)."""
    if not renames:
        return
    loc_new = {}
    for k, new in renames.items():
        loc_new[k.rsplit('@', 1)[1]] = new

    def key_of(d):
        return 'L:%s@%s' % (d['name'], d['location'])

    def rec(n):
        if isinstance(n, dict):
            t = n.get('type')
            if t == 'AstExprLocal':
                k = key_of(n['local'])
                if k in renames:
                    n['local']['name'] = renames[k]
            elif t == 'AstStatLocal':
                for v in n['vars']:
                    k = key_of(v)
                    if k in renames:
                        v['name'] = renames[k]
            elif t == 'AstStatLocalFunction':
                k = key_of(n['name'])
                if k in renames:
                    n['name']['name'] = renames[k]
            elif t == 'AstExprFunction':
                for a in n.get('args') or []:
                    k = key_of(a)
                    if k in renames:
                        a['name'] = renames[k]
            elif t == 'AstStatFor':
                k = key_of(n['var'])
                if k in renames:
                    n['var']['name'] = renames[k]
            elif t == 'AstStatForIn':
                for v in n['vars']:
                    k = key_of(v)
                    if k in renames:
                        v['name'] = renames[k]
            for v in n.values():
                rec(v)
        elif isinstance(n, list):
            for v in n:
                rec(v)
    rec(root)

    def verify(n):
        if T(n) == 'AstExprLocal':
            loc = n['local']['location']
            if loc in loc_new and n['local']['name'] != loc_new[loc]:
                raise CleanError('rename verification failed at %s'
                                 % loc)
    walk(root, verify)


class _NoPool:
    akr_key = ('__clean_no_pool__',)

    def scalar(self, n):
        return ('missing', n)


CLEAN_HEADER = (
    '-- Cleaned by Luast-Deobf-Tool clean stage v%s (luast v1.0.1 '
    'family).\n'
    '-- Register table dissolved into a named-field state table;\n'
    '-- constants pool inlined or hoisted to named local functions.\n'
    '-- See clean_map.json.'
    % CLEAN_VERSION)


def print_clean(root):
    from printer import Printer
    pr = Printer(_NoPool(), set(), '')
    return pr.stmts(root['body'])


def parse_ast(path, tool_dir):
    import os
    r = subprocess.run([os.path.join(tool_dir, 'bin', 'luau-ast'), path],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise CleanError('luau-ast failed on %s: %s'
                         % (path, r.stderr[:300]))
    return json.loads(r.stdout)['root']


def _norm(counter):
    return {k: v for k, v in counter.items() if v != 0}


def _counter_eq(a, b):
    return _norm(a) == _norm(b)


# ---------------------------------------------------------------------
# orchestration
# ---------------------------------------------------------------------

def run_clean(deflatten_root, out_path, tool_dir, tool_version=None):
    """Runs the whole clean stage.  Returns the info dict for the
    manifest/report and clean_map.json.  Raises CleanError on any
    invariant or gate failure (caller reports PARTIAL)."""
    import os
    root = copy.deepcopy(deflatten_root)
    A = analyze(root)
    fn_names, namer = decide_functions(A)
    state_name = namer.claim_unique('state')
    slot_disp = decide_slots(A, fn_names, namer)
    for eff, (cand, ev) in sorted(
            caller_evidence(A, fn_names, slot_disp).items()):
        name = namer.claim(cand)
        if name:
            fn_names[eff] = (name, 'INFERRED', ev)
    placement, dropped_fns = compute_placement(A, fn_names, slot_disp)
    plan = decide_locals(A, fn_names, slot_disp, namer,
                         extra_chunk_names={state_name})

    tr = Transformer(A, fn_names, slot_disp, placement=placement,
                     state_name=state_name)
    new_root = tr.transform_root(root)
    apply_renames(new_root, {k: v[0] for k, v in plan.items()})

    # --- residue gate: no akR/alias references survive -----------------
    residue = count_root_refs(new_root, A.akr_key, A.level)
    if residue:
        raise CleanError('%d akR/alias references survive the transform'
                         % residue)

    def no_akr_global(n):
        if T(n) == 'AstExprGlobal' and n.get('global') == 'akR':
            raise CleanError('global akR reference in cleaned AST')
    walk(new_root, no_akr_global)

    # --- clean-map accounting gate --------------------------------------
    accounted = sum(tr.refcats.values())
    if accounted != A.total_refs:
        raise CleanError('clean map accounts for %d of %d akR/alias '
                         'references' % (accounted, A.total_refs))

    # --- simplify pass (v1.3.0) + ledger adjustment ----------------
    # The simplify pass rewrites only provably-equivalent patterns;
    # its literal/statement deltas are folded into the books above so
    # the gates below stay exact, and the per-function figures are
    # recomputed from the simplified AST and re-checked (a delta
    # bookkeeping bug fails the run instead of shipping a wrong gate).
    import simplify as simp_mod
    simp = simp_mod.Simplifier(state_name)
    new_root = simp.transform_root(new_root)
    for ctx, delta in simp.lit_delta.items():
        for k, d in delta.items():
            if d > 0:
                tr.book.inserted[k] += d
                tr.book.per_ctx_inserted[ctx][k] += d
            elif d < 0:
                tr.book.removed[k] += -d
                tr.book.per_ctx_removed[ctx][k] += -d
    _fn_bodies = {}

    def _find_defs(n):
        if T(n) == 'AstStatLocalFunction':
            loc = n.get('location') or ''
            if loc.startswith('clean:fn'):
                try:
                    _fn_bodies[int(loc[len('clean:fn'):])] = \
                        n['func']['body']
                except ValueError:
                    pass
    walk(new_root, _find_defs)
    for lit, au in tr.fn_audit.items():
        if lit not in _fn_bodies:
            raise CleanError('simplified AST lost pool function %d'
                             % lit)
        au['stmts_out'] = count_stmts(_fn_bodies[lit])
        au['lit_out'] = lit_counter(_fn_bodies[lit])

    # --- per-function statement/literal audit ----------------------------
    for lit, au in sorted(tr.fn_audit.items()):
        ctx = ('poolFn', lit)
        if au['stmts_out'] != au['stmts_in'] - au['deleted'] \
                + simp.stmt_delta.get(ctx, 0):
            raise CleanError(
                'statement audit failed for pool function %d: '
                '%d in, %d deleted, simplify delta %d, %d out'
                % (lit, au['stmts_in'], au['deleted'],
                   simp.stmt_delta.get(ctx, 0), au['stmts_out']))
        booked = tr.book.per_ctx_inserted[ctx] \
            - tr.book.per_ctx_removed[ctx]
        if not _counter_eq(booked, au['lit_out']):
            raise CleanError(
                'literal audit failed for pool function %d' % lit)

    # --- print + write -----------------------------------------------------
    lines = print_clean(new_root)
    text = CLEAN_HEADER + '\n' + '\n'.join(lines) + '\n'
    with open(out_path, 'w') as f:
        f.write(text)

    # --- compile gate -------------------------------------------------------
    r = subprocess.run([os.path.join(tool_dir, 'bin', 'luau-compile'),
                        out_path], capture_output=True, text=True)
    if r.returncode != 0:
        raise CleanError('luau-compile failed on cleaned output: %s'
                         % r.stderr[:400])

    # --- literal multiset gate ------------------------------------------------
    out_root = parse_ast(out_path, tool_dir)
    out_lits = lit_counter(out_root)
    expected = collections.Counter()
    keys = set(A.input_literals) | set(tr.book.removed) \
        | set(tr.book.inserted)
    for k in keys:
        v = A.input_literals.get(k, 0) - tr.book.removed.get(k, 0) \
            + tr.book.inserted.get(k, 0)
        if v < 0:
            raise CleanError('literal ledger goes negative at %r'
                             % (k,))
        if v:
            expected[k] = v
    if not _counter_eq(expected, out_lits):
        diff = []
        for k in sorted(set(expected) | set(out_lits), key=repr):
            if expected.get(k, 0) != out_lits.get(k, 0):
                diff.append((k, expected.get(k, 0), out_lits.get(k, 0)))
        raise CleanError('literal multiset gate failed: %s'
                         % (diff[:10],))

    # --- metrics --------------------------------------------------------------
    read_eff = set()
    for node, lit in A.pool_reads:
        read_eff.add(A.pool.perm.get(lit, lit))
    never_read = []
    for lit in range(1, len(A.pool.entries) + 1):
        if A.pool.perm.get(lit, lit) not in read_eff \
                and lit not in read_eff:
            never_read.append(lit)
    by_kind = collections.Counter()
    for lit in never_read:
        by_kind[A.pool.scalar(lit)[0]] += 1

    registers = {}
    for slot in sorted(slot_disp):
        d = slot_disp[slot]
        e = {'disposition': d['kind'],
             'reads': len(A.slot_reads.get(slot, [])),
             'writes': len(A.slot_writes.get(slot, []))}
        if d['kind'] == 'promote':
            e['name'] = d['name']
            e['label'] = d['label']
            e['evidence'] = d['evidence']
            if 'name_conflict' in d:
                e['name_conflict'] = d['name_conflict']
        elif d['kind'] == 'eliminate':
            tgt = d['target']
            e['target_kind'] = tgt[0]
            e['target'] = (fn_names[tgt[1]][0] if tgt[0] == 'fn'
                           else str(tgt[1]) if tgt[0] == 'global'
                           else 'literal/expression')
        registers[str(slot)] = e

    functions = {}
    for lit in sorted(fn_names):
        name, label, ev = fn_names[lit]
        if lit in dropped_fns:
            pl = 'dropped (never referenced)'
        elif placement.get(lit) == 'poolpos':
            pl = 'pool position (chunk scope)'
        else:
            pl = 'local block scope'
        functions[str(lit)] = {'name': name, 'label': label,
                               'evidence': ev, 'placement': pl}

    rename_labels = collections.Counter(v[1] for v in plan.values())
    fn_labels = collections.Counter(v[1] for v in fn_names.values())
    slot_labels = collections.Counter(
        d['label'] for d in slot_disp.values() if d['kind'] == 'promote')

    audit_samples = []
    by_size = sorted(tr.fn_audit.items(),
                     key=lambda kv: kv[1]['stmts_in'])
    picks = []
    if by_size:
        picks = [by_size[len(by_size) // 2], by_size[-1], by_size[0]]
    seen = set()
    for lit, au in picks:
        if lit in seen:
            continue
        seen.add(lit)
        audit_samples.append({
            'pool_index': lit, 'name': fn_names[lit][0],
            'statements_in': au['stmts_in'],
            'statements_deleted': au['deleted'],
            'statements_out': au['stmts_out'],
            'literals_in': sum(au['lit_in'].values()),
            'literals_out': sum(au['lit_out'].values()),
            'audit': 'PASS'})

    # --- self-check QA (v1.3.0): describes the shipped output, does
    # not gate it (the compile/literal gates above do that) ---------
    import qa as qa_mod
    name_conflicts = [
        {'slot': slot, 'field': d['name'], **d['name_conflict']}
        for slot, d in sorted(slot_disp.items())
        if 'name_conflict' in d]
    qa_counts = qa_mod.analyze(new_root, state_name)
    qa_report = {
        'tool': 'Luast-Deobf-Tool',
        'tool_version': tool_version,
        'clean_version': CLEAN_VERSION,
        'stage': 'SOURCE_CLEANED',
        'simplify': dict(sorted(simp.stats.items())),
        'name_conflicts': name_conflicts,
        'naming': {
            'functions_by_label': dict(sorted(fn_labels.items())),
            'slots_by_label': dict(sorted(slot_labels.items())),
            'locals_by_label': dict(sorted(rename_labels.items())),
        },
        'raw_patterns': qa_counts['raw_patterns'],
        'sample_locations': qa_counts['sample_locations'],
        'defects_not_fixed': qa_counts['defects_not_fixed'],
        'notes': [
            'raw_patterns are AST counts on the shipped cleaned '
            'output.',
            'defects_not_fixed lists patterns the v1.3.0 passes '
            'deliberately left alone because equivalence could not '
            'be proven from the AST (see simplify.py); a '
            'simplify_miss entry, if ever non-empty, is a tool bug.',
            'Duplicated epilogues (deflatten-stage emission) are '
            'reported per machine in deflatten_map.json, not here.',
        ],
    }
    qa_summary = {
        'simplify': dict(sorted(simp.stats.items())),
        'name_conflicts': len(name_conflicts),
        'raw_patterns': qa_counts['raw_patterns'],
        'defects_not_fixed': [
            {'category': d['category'], 'count': d['count']}
            for d in qa_counts['defects_not_fixed']],
    }

    clean_map = {
        'stage': 'SOURCE_CLEANED',
        'clean_version': CLEAN_VERSION,
        'simplify': dict(sorted(simp.stats.items())),
        'name_conflicts': name_conflicts,
        'input_refs_total': A.total_refs,
        'refs_accounted': accounted,
        'output_refs_remaining': 0,
        'refs_by_category': dict(sorted(tr.refcats.items())),
        'registers': registers,
        'functions': functions,
        'pool': {
            'entries': len(A.pool.entries),
            'never_read_entries': len(never_read),
            'never_read_by_kind': dict(sorted(by_kind.items())),
        },
        'renames': {
            'payload_locals': len(plan),
            'by_label': dict(sorted(rename_labels.items())),
            'table': {k: {'new': v[0], 'label': v[1], 'evidence': v[2]}
                      for k, v in sorted(plan.items())},
        },
        'literal_gate': {
            'removed_literals': sum(tr.book.removed.values()),
            'inserted_literals': sum(tr.book.inserted.values()),
            'removed_by_kind': {
                'string': sum(v for (t, _), v in tr.book.removed.items()
                              if t == 's'),
                'number': sum(v for (t, _), v in tr.book.removed.items()
                              if t == 'n')},
            'inserted_by_kind': {
                'string': sum(v for (t, _), v in tr.book.inserted.items()
                              if t == 's'),
                'number': sum(v for (t, _), v in tr.book.inserted.items()
                              if t == 'n')},
        },
    }
    info = {
        'ok': True,
        'clean_version': CLEAN_VERSION,
        'refs_before': A.total_refs,
        'refs_after': 0,
        'refs_by_category': dict(sorted(tr.refcats.items())),
        'akr_text_occurrences_after': text.count('akR'),
        'registers_promoted': sum(1 for d in slot_disp.values()
                                  if d['kind'] == 'promote'),
        'registers_eliminated': sum(1 for d in slot_disp.values()
                                    if d['kind'].startswith('eliminate')),
        'registers_dead': sum(1 for d in slot_disp.values()
                              if d['kind'] == 'dead'),
        'dead_value_statements_kept': tr.dead_expr_kept,
        'functions_hoisted': len(fn_names) - len(dropped_fns),
        'functions_in_blocks': sum(1 for p in placement.values()
                                   if p != 'poolpos'),
        'functions_at_pool_position': sum(
            1 for p in placement.values() if p == 'poolpos'),
        'functions_dropped_unreferenced': len(dropped_fns),
        'state_table': state_name,
        'state_fields': sum(1 for d in slot_disp.values()
                            if d['kind'] == 'promote'),
        'function_names_by_label': dict(sorted(fn_labels.items())),
        'slot_names_by_label': dict(sorted(slot_labels.items())),
        'locals_renamed': len(plan),
        'local_names_by_label': dict(sorted(rename_labels.items())),
        'pool_entries': len(A.pool.entries),
        'pool_never_read': len(never_read),
        'cleaned_lines': text.count('\n'),
        'compile': 'PASS',
        'literal_gate': 'PASS',
        'audit_samples': audit_samples,
        'qa_summary': qa_summary,
        'qa_report': qa_report,
        'clean_map': clean_map,
    }
    return info
