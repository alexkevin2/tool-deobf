# driver.py — full deflatten pipeline over a parsed luast payload AST:
# naming pre-pass -> structured emission -> gates data.
import collections, json, sys
import luast_lib as L
from luast_lib import T, unwrap, var_key, is_cnum, cnum, walk, build_parents
import extract as ex
import printer as prn
import deflatten as dfl

def local_refs(root):
    """var_key -> list of AstExprLocal nodes referencing it."""
    refs = collections.defaultdict(list)
    def visit(n):
        if T(n) == 'AstExprLocal':
            loc = n['local']
            refs['L:%s@%s' % (loc['name'], loc['location'])].append(n)
    walk(root, visit)
    return refs

def reassigned_keys(root):
    """var_keys that are assignment targets anywhere (Assign/Compound)."""
    keys = set()
    def visit(n):
        t = T(n)
        if t == 'AstStatAssign':
            for v in n['vars']:
                keys.add(var_key(v))
        elif t == 'AstStatCompoundAssign':
            keys.add(var_key(n['var']))
    walk(root, visit)
    return keys

def function_subtree(root, node):
    """Nearest enclosing AstExprFunction/AstStatLocalFunction func or root."""
    return node

def naming_pass(root, pool, aliases, parent, pr):
    """Compute rename map + drop sets.
    - CONFIRMED renames: a never-reassigned local whose only definition
      initializes it from a pool entry that is a plain global (game,
      workspace, task, ...) is renamed to that global's name when the
      name is free in the enclosing function scope.
    - Pool alias locals: dropped when every use is a pool read that the
      printer substitutes; renamed 'pool' otherwise (collision-safe).
    Returns (rename, drop_stmt_ids, stats)."""
    rename = {}
    stats = collections.Counter()
    reassign = reassigned_keys(root)
    refs = local_refs(root)

    # enclosing function per node (chunk = root block)
    enc_func = {}
    def mark(n, f):
        if isinstance(n, dict):
            enc_func[id(n)] = f
            nf = n if T(n) in ('AstExprFunction',) else f
            for v in n.values():
                mark(v, nf)
        elif isinstance(n, list):
            for v in n:
                mark(v, f)
    mark(root, root)

    # names declared per function scope
    func_locals = collections.defaultdict(set)
    def decls(n):
        if T(n) == 'AstStatLocal':
            for v in n['vars']:
                func_locals[id(enc_func[id(n)])].add(v['name'])
        elif T(n) == 'AstStatLocalFunction':
            func_locals[id(enc_func[id(n)])].add(n['name']['name'])
        elif T(n) in ('AstStatFor',):
            func_locals[id(enc_func[id(n)])].add(n['var']['name'])
        elif T(n) == 'AstStatForIn':
            for v in n['vars']:
                func_locals[id(enc_func[id(n)])].add(v['name'])
    walk(root, decls)
    # function params count as declarations of that function
    def params(n):
        if T(n) == 'AstExprFunction':
            for a in n['args']:
                func_locals[id(n)].add(a['name'])
    walk(root, params)

    claimed = collections.defaultdict(set)   # func id -> names claimed by renames

    # CONFIRMED global renames
    def visit_local(n):
        if T(n) != 'AstStatLocal':
            return
        vals = n.get('values') or []
        for var, val in zip(n['vars'], vals):
            if val is None:
                continue
            key = 'L:%s@%s' % (var['name'], var['location'])
            if key in reassign:
                continue
            v = unwrap(val)
            # value must be exactly a pool read of a global entry
            idx = pr.pool_ref(v) if False else None
            base = unwrap(v['expr']) if T(v) == 'AstExprIndexExpr' else None
            if T(v) == 'AstExprIndexExpr' and is_cnum(v['index']) and \
               L.is_pool_ref(base, pool, aliases):
                e = pool.entry(int(cnum(v['index'])))
                if e is not None and T(e) == 'AstExprGlobal':
                    gname = e['global']
                    f = enc_func[id(n)]
                    fid = id(f)
                    if gname == var['name']:
                        stats['already_named'] += 1
                        continue
                    if gname in func_locals[fid] or gname in claimed[fid]:
                        stats['rename_collision'] += 1
                        continue
                    rename[key] = gname
                    claimed[fid].add(gname)
                    stats['renamed_confirmed'] += 1
    walk(root, visit_local)

    # alias handling
    drop_ids = set()
    alias_keys = {ak for ak in aliases}
    # declarations of alias locals: find AstStatLocal statements that define them
    def visit_alias_decl(n):
        if T(n) != 'AstStatLocal':
            return
        vals = n.get('values') or []
        keys = ['L:%s@%s' % (v['name'], v['location']) for v in n['vars']]
        if len(keys) == 1 and keys[0] in alias_keys:
            key = keys[0]
            live = 0
            for r in refs.get(key, []):
                # classify the use: parent is IndexExpr with this local as base?
                live += 1  # refined below by caller via use census
            stats['alias_decl_seen'] += 1
    walk(root, visit_alias_decl)

    # precise alias use census: a use is DEAD (substituted away) iff the
    # ref is the base of a pool IndexExpr whose substitution is a literal,
    # or the base itself is the pool-table ref akR[128] (prints literally).
    par = parent
    decl_index = {}
    def index_decls(n):
        if T(n) == 'AstStatLocal':
            for v in n['vars']:
                decl_index['L:%s@%s' % (v['name'], v['location'])] = n
    walk(root, index_decls)
    block_claims = set()
    for key in alias_keys:
        live = 0
        for r in refs.get(key, []):
            p = par.get(id(r))
            dead = False
            if p is not None and T(p) == 'AstExprIndexExpr' and unwrap(p['expr']) is r:
                if is_cnum(p['index']):
                    sub = pr.pool_substitute(int(cnum(p['index'])), None)
                    if sub is not None:
                        dead = True
                # dynamic index or unsubtitutable -> live
            if not dead:
                live += 1
        decl = decl_index.get(key)
        if live == 0:
            stats['alias_dropped'] += 1
            if decl is not None:
                drop_ids.add(id(decl))
        else:
            stats['alias_kept'] += 1
            # rename to 'pool' when collision-free in its BLOCK scope:
            # no 'pool' declared in the decl block or its ancestors, no
            # other renamed alias in the same block, and no use passes
            # through a nested block that declares 'pool'
            if decl is not None and _alias_pool_rename_ok(
                    decl, refs.get(key, []), par, block_claims):
                rename[key] = 'pool'
                stats['alias_renamed_pool'] += 1
    return rename, drop_ids, stats

def _block_declared_names(block):
    names = set()
    for s in block.get('body', []):
        t = T(s)
        if t == 'AstStatLocal':
            for v in s['vars']:
                names.add(v['name'])
        elif t == 'AstStatLocalFunction':
            names.add(s['name']['name'])
        elif t == 'AstStatFor':
            names.add(s['var']['name'])
        elif t == 'AstStatForIn':
            for v in s['vars']:
                names.add(v['name'])
    return names

def _ancestor_blocks(node, par):
    """AstStatBlock ancestors of node, nearest first."""
    out = []
    n = par.get(id(node))
    while n is not None:
        if T(n) == 'AstStatBlock':
            out.append(n)
        n = par.get(id(n))
    return out

def _alias_pool_rename_ok(decl, uses, par, block_claims):
    blocks = _ancestor_blocks(decl, par)
    if not blocks:
        return False
    own = blocks[0]
    if id(own) in block_claims:
        return False
    declared = {}
    def names_of(b):
        if id(b) not in declared:
            ns = _block_declared_names(b)
            fn = par.get(id(b))
            if fn is not None and T(fn) == 'AstExprFunction':
                for a in fn['args']:
                    ns.add(a['name'])
            declared[id(b)] = ns
        return declared[id(b)]
    for b in blocks:
        if 'pool' in names_of(b):
            return False
    for r in uses:
        for b in _ancestor_blocks(r, par):
            if b is own:
                break
            if 'pool' in names_of(b):
                return False
    block_claims.add(id(own))
    return True

def state_init_drops(root, pool, aliases, parent, machines, ok_while_ids=None):
    """Init statements of LOCAL state vars: droppable when the state var
    has no references outside its machine While + the init itself.
    Kernel machines keep their init (the original loop still runs)."""
    refs = local_refs(root)
    drops = set()
    kept = 0
    for m in machines:
        if not m['machine']:
            continue
        if ok_while_ids is not None and id(m['while']) not in ok_while_ids:
            kept += 1
            continue
        svar = m['svar']
        if not svar.startswith('L:'):
            continue
        r = ex.find_init_stmt(m['while'], svar, parent)
        if r is None:
            continue
        stmt, _ = r
        if T(stmt) not in ('AstStatLocal', 'AstStatAssign'):
            continue
        # refs to the state var outside the machine while (and outside
        # the init statement itself — its target/value are part of it)?
        inside = set()
        walk(m['while'], lambda n: inside.add(id(n)))
        walk(stmt, lambda n: inside.add(id(n)))
        outside = [n for n in refs.get(svar, []) if id(n) not in inside]
        if outside:
            kept += 1
            continue
        if len(stmt['vars']) > 1:
            kept += 1
            continue
        drops.add(id(stmt))
    return drops, kept

def build(src_path_ast, src_text):
    import sys as _sys
    _sys.setrecursionlimit(100000)
    root = src_path_ast
    pool, _pool_idx = L.find_pool(root)
    # U1 defence-in-depth: detect() already requires index 128, but
    # the pipeline itself must never run on a pool at another index
    # (every resolver hardcodes 128).
    if _pool_idx != 128:
        raise RuntimeError('pool table not at index 128 (got %r); '
                           'refusing to deflatten' % (_pool_idx,))
    aliases = L.collect_aliases(root, pool)
    parent = build_parents(root)
    nperm = L.apply_permutation(pool, root, aliases)
    machines = ex.extract_all(root, pool, aliases, parent)
    perm_ids = {id(s) for s in pool.perm_stmts}

    # ---- pre-pass: structuring outcome per machine (scratch printer) ----
    scratch = prn.Printer(pool, aliases, src_text, perm_node_ids=perm_ids)
    outcomes = {}      # id(while) -> ('ok', structurer) | ('kernel', reason)
    machine_nums = {}  # id(while) -> number in AST order
    for m in machines:
        if not m['machine']:
            continue
        key = id(m['while'])
        machine_nums[key] = len(machine_nums) + 1
        if m['residue']:
            outcomes[key] = ('kernel', 'extraction residue: ' + m['residue'][0]['reason'])
            continue
        if m['entry_leaf'] is None:
            outcomes[key] = ('kernel', f"entry spans {len(m['entry_leaves'])} leaves")
            continue
        try:
            st = dfl.MachineStructurer(m, scratch)
            st.run()
            m['_reachable'] = st.reachable
            m['_trampolines'] = st.trampolines
            m['_emitted'] = dict(st.emitted)
            m['_dup_epilogues'] = dict(st.duplicated_epilogues)
            m['_hoisted'] = dict(st.hoisted_prefix)
            outcomes[key] = ('ok', st)
        except dfl.Kernel as k:
            outcomes[key] = ('kernel', k.reason)
        except RecursionError:
            outcomes[key] = ('kernel', 'structurer recursion limit')

    # ---- naming (real printer) ----
    pr = prn.Printer(pool, aliases, src_text, perm_node_ids=perm_ids)
    rename, drop_alias, nstats = naming_pass(root, pool, aliases, parent, pr)
    ok_ids = {k for k, v in outcomes.items() if v[0] == 'ok'}
    init_drops, init_kept = state_init_drops(root, pool, aliases, parent,
                                             machines, ok_while_ids=ok_ids)
    pr.rename = rename
    pr.drop_alias_locs = set(drop_alias) | set(init_drops)

    results = {'machines': [], 'kernels': [], 'kernel_while_ids': set()}
    recorded = set()

    def emit_machine(wnode, pr):
        key = id(wnode)
        out = outcomes.get(key)
        if out is None:
            return None   # not a machine (plain/wrapper while): generic
        num = machine_nums[key]
        m = next(mm for mm in machines if id(mm['while']) == key)
        if out[0] == 'kernel':
            if key not in recorded:
                recorded.add(key)
                results['kernels'].append({'machine': num, 'while_loc': wnode['location'],
                                            'reason': out[1]})
                results['kernel_while_ids'].add(key)
            return 'KERNEL machine #%d: %s' % (num, out[1])
        st = out[1]
        st.pr = pr
        st.emitted = collections.Counter()
        st.loop_stack = []
        st.loop_exits = []
        st._steps = 0
        st.hoisted_prefix = {}
        try:
            lines = st.run()
        except dfl.Kernel as k:
            if key not in recorded:
                recorded.add(key)
                results['kernels'].append({'machine': num, 'while_loc': wnode['location'],
                                            'reason': 'print-pass: ' + k.reason})
                results['kernel_while_ids'].add(key)
            return 'KERNEL machine #%d: %s' % (num, k.reason)
        if key not in recorded:
            recorded.add(key)
            reach = m.get('_reachable') or set(m['leaf_info'])
            results['machines'].append({
                'machine': num, 'while_loc': wnode['location'],
                'flavor': m['flavor'], 'states': len(m['leaf_info']),
                'states_reachable': len(reach),
                'states_dead': len(m['leaf_info']) - len(reach),
                'values': sum(len(v) for v in m['leaf_states'].values()),
                'duplicated_epilogues': m.get('_dup_epilogues') or {}})
        head = pr.pad() + f"-- [luast] machine #{num}: {len(m['leaf_info'])} states structured"
        return [head] + lines

    pr.emit_machine = emit_machine
    lines = pr.stmts(root['body'])
    results['machines'].sort(key=lambda r: r['machine'])
    results['kernels'].sort(key=lambda r: r['machine'])
    return {'lines': lines, 'pool': pool, 'aliases': aliases, 'machines': machines,
            'results': results, 'rename': rename, 'naming_stats': dict(nstats),
            'init_drops': len(init_drops), 'init_kept': init_kept,
            'permuted_slots': nperm, 'printer': pr}
