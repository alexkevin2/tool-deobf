#!/bin/bash
# Luast-Deobf-Tool regression (v1.3.0): isolated env (fake HOME, persistent TMPDIR).
# Checks:
#   --no-clean run (spoof auto): exit 0 (FULL), deflatten outputs
#     byte-identical to tests/golden/, output compiles.
#   default run (clean stage on, spoof auto): exit 0 (FULL), cleaned
#     output + clean_map.json + qa_report.json byte-identical to their
#     goldens, cleaned output compiles, zero textual akR residue,
#     manifest clean ok, QA section present in report.md and QA
#     foldable-pattern counts zero (no simplify_miss).
#   identity_report.json (both runs): unified spoof-engine/1 schema,
#     route luast, forks [], HWF candidates {} with PlaceId/JobId as
#     presence-only/telemetry reads (unknown_fields, never gates).
#   --spoof-id off: no identity artifacts; every output except
#     report.md byte-identical to the auto run, and the off report
#     is exactly the auto report minus the Identity section.
#   determinism: --no-clean runs under PYTHONHASHSEED=0 and =12345
#     produce byte-identical outputs (including identity_report).
#   negative control -> exit 2 with U6 evidence fields.
#   synthetic spoof suite (tests/check_spoof.py): multi-gate fixture,
#     telemetry negative, vendored-engine sha, no-hardcode audit.
#   corpus detect (tests/check_corpus_detect.py) when the corpus
#     tree is present (skipped in the standalone zip context).
set -u
TOOL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d "$TOOL_DIR/tests/.regwork.XXXXXX")"
export HOME="$WORK/home"
export TMPDIR="$WORK/tmp"
mkdir -p "$HOME" "$TMPDIR"
LOG="$TOOL_DIR/tests/regression_results.log"
: > "$LOG"
FAIL=0
say() { echo "$@" | tee -a "$LOG"; }

# ---- deflatten stage only (--no-clean): legacy goldens ----
OUT="$WORK/out-noclean"
python3 "$TOOL_DIR/luast_deobf.py" "$TOOL_DIR/tests/sample/267757772.lua" -o "$OUT" --no-clean >> "$LOG" 2>&1
rc=$?
if [ $rc -eq 0 ]; then say "PASS sample --no-clean exit 0 (FULL)"; else say "FAIL sample --no-clean exit $rc (want 0)"; FAIL=1; fi

for f in 267757772.deflattened.luau report.md manifest.json deflatten_map.json; do
    if cmp -s "$OUT/$f" "$TOOL_DIR/tests/golden/$f"; then
        say "PASS byte-identical (--no-clean) $f"
    else
        say "FAIL differs from golden (--no-clean): $f"; FAIL=1
    fi
done

if "$TOOL_DIR/bin/luau-compile" "$OUT/267757772.deflattened.luau" > /dev/null 2>&1; then
    say "PASS luau-compile on deflattened output"
else
    say "FAIL luau-compile on deflattened output"; FAIL=1
fi

# ---- full run with clean stage: cleaned goldens ----
OUTC="$WORK/out-clean"
python3 "$TOOL_DIR/luast_deobf.py" "$TOOL_DIR/tests/sample/267757772.lua" -o "$OUTC" >> "$LOG" 2>&1
rc=$?
if [ $rc -eq 0 ]; then say "PASS sample exit 0 (FULL, cleaned)"; else say "FAIL sample exit $rc (want 0)"; FAIL=1; fi

for f in 267757772.cleaned.luau clean_map.json qa_report.json; do
    if cmp -s "$OUTC/$f" "$TOOL_DIR/tests/golden/$f"; then
        say "PASS byte-identical (cleaned) $f"
    else
        say "FAIL differs from golden (cleaned): $f"; FAIL=1
    fi
done

python3 - "$OUTC/qa_report.json" >> "$LOG" 2>&1 <<'PYEOF'
import json, sys
q = json.load(open(sys.argv[1]))
raw = q.get('raw_patterns') or {}
miss = [d for d in q.get('defects_not_fixed') or []
        if d.get('category') == 'simplify_miss']
ok = (raw.get('both_constant_binary') == 0
      and raw.get('if_constant_condition') == 0
      and raw.get('ifexpr_constant_condition') == 0
      and raw.get('identity_add0_provably_numeric') == 0
      and raw.get('identity_mul1_provably_numeric') == 0
      and raw.get('dead_consecutive_assign') == 0
      and raw.get('prologue_nil_remaining') == 0
      and not miss
      and q.get('simplify', {}).get('prologue_nil_dropped') == 35)
print('qa_report gates:', 'OK' if ok else 'BAD %r' % (q,))
sys.exit(0 if ok else 1)
PYEOF
if [ $? -eq 0 ]; then say "PASS qa_report gates (no simplify_miss, foldables zero)"; else say "FAIL qa_report gates"; FAIL=1; fi

if grep -q 'Self-check QA' "$OUTC/report.md"; then
    say "PASS report.md carries Self-check QA section"
else
    say "FAIL report.md missing Self-check QA section"; FAIL=1
fi

if "$TOOL_DIR/bin/luau-compile" "$OUTC/267757772.cleaned.luau" > /dev/null 2>&1; then
    say "PASS luau-compile on cleaned output"
else
    say "FAIL luau-compile on cleaned output"; FAIL=1
fi

AKR_COUNT="$(grep -c 'akR' "$OUTC/267757772.cleaned.luau" || true)"
if [ "$AKR_COUNT" = "0" ]; then
    say "PASS akR residue in cleaned output: 0"
else
    say "FAIL akR residue in cleaned output: $AKR_COUNT (want 0)"; FAIL=1
fi

python3 - "$OUTC/manifest.json" >> "$LOG" 2>&1 <<'PYEOF'
import json, sys
m = json.load(open(sys.argv[1]))
c = m.get('clean') or {}
ok = (m.get('verdict') == 'FULL' and c.get('ok') is True
      and c.get('refs_before') == 5407 and c.get('refs_after') == 0
      and c.get('compile') == 'PASS' and c.get('literal_gate') == 'PASS')
print('manifest clean section:', 'OK' if ok else 'BAD %r' % (c,))
sys.exit(0 if ok else 1)
PYEOF
if [ $? -eq 0 ]; then say "PASS manifest clean section"; else say "FAIL manifest clean section"; FAIL=1; fi

# ---- identity reports (auto runs) ----
python3 - "$OUT/identity_report.json" "$OUTC/identity_report.json" >> "$LOG" 2>&1 <<'PYEOF'
import json, sys
ok = True
for p in sys.argv[1:]:
    r = json.load(open(p))
    good = (r.get('schema_version') == 'spoof-engine/1'
            and r.get('route') == 'luast'
            and r.get('forks') == []
            and r.get('candidates') == {}
            and 'PlaceId' in (r.get('fields_seen') or [])
            and 'JobId' in (r.get('fields_seen') or [])
            and r.get('unknown_fields') == ['JobId', 'PlaceId'])
    print(p, 'OK' if good else 'BAD %r' % (r,))
    ok = ok and good
sys.exit(0 if ok else 1)
PYEOF
if [ $? -eq 0 ]; then say "PASS identity_report.json (auto, HWF presence-only)"; else say "FAIL identity_report.json (auto)"; FAIL=1; fi

if grep -q '## Identity spoofing' "$OUT/report.md" && grep -q '## Identity spoofing' "$OUTC/report.md"; then
    say "PASS report.md carries Identity section (auto)"
else
    say "FAIL report.md missing Identity section (auto)"; FAIL=1
fi

# ---- off mode: byte-identity except report section ----
OUTOFF="$WORK/out-off"
python3 "$TOOL_DIR/luast_deobf.py" "$TOOL_DIR/tests/sample/267757772.lua" -o "$OUTOFF" --no-clean --spoof-id off >> "$LOG" 2>&1
rc=$?
if [ $rc -eq 0 ]; then say "PASS sample --spoof-id off exit 0"; else say "FAIL sample --spoof-id off exit $rc (want 0)"; FAIL=1; fi
OFFOK=1
if [ -e "$OUTOFF/identity_report.json" ]; then say "FAIL off run emitted identity_report.json"; OFFOK=0; fi
for f in 267757772.deflattened.luau manifest.json deflatten_map.json; do
    cmp -s "$OUTOFF/$f" "$OUT/$f" || { say "FAIL off differs from auto: $f"; OFFOK=0; }
done
python3 - "$OUT/report.md" "$OUTOFF/report.md" >> "$LOG" 2>&1 <<'PYEOF'
import sys
auto = open(sys.argv[1]).read()
off = open(sys.argv[2]).read()
marker = '\n## Identity spoofing'
assert marker in auto, 'auto report lacks Identity section'
assert marker not in off, 'off report carries Identity section'
sys.exit(0 if auto.split(marker)[0].rstrip('\n') + '\n' == off else 1)
PYEOF
if [ $? -eq 0 ] && [ $OFFOK -eq 1 ]; then say "PASS off-mode byte-identity (minus Identity section)"; else say "FAIL off-mode byte-identity"; FAIL=1; fi

# ---- determinism across PYTHONHASHSEED ----
OUTA="$WORK/out-seed0"
OUTB="$WORK/out-seed12345"
PYTHONHASHSEED=0 python3 "$TOOL_DIR/luast_deobf.py" "$TOOL_DIR/tests/sample/267757772.lua" -o "$OUTA" --no-clean >> "$LOG" 2>&1
PYTHONHASHSEED=12345 python3 "$TOOL_DIR/luast_deobf.py" "$TOOL_DIR/tests/sample/267757772.lua" -o "$OUTB" --no-clean >> "$LOG" 2>&1
DET=1
for f in 267757772.deflattened.luau report.md manifest.json deflatten_map.json identity_report.json; do
    cmp -s "$OUTA/$f" "$OUTB/$f" || { say "FAIL nondeterministic across PYTHONHASHSEED: $f"; DET=0; }
done
if [ $DET -eq 1 ]; then say "PASS determinism across PYTHONHASHSEED"; else FAIL=1; fi

# ---- negative control ----
python3 "$TOOL_DIR/luast_deobf.py" "$TOOL_DIR/tests/negative.lua" -o "$WORK/neg" > "$WORK/neg.log" 2>&1
rc=$?
if [ $rc -eq 2 ]; then say "PASS negative exit 2"; else say "FAIL negative exit $rc (want 2)"; FAIL=1; fi
if grep -q 'pool_assign_index' "$WORK/neg.log" && grep -q 'permutation_statements' "$WORK/neg.log" && grep -q 'machines_flavor_a' "$WORK/neg.log"; then
    say "PASS negative evidence carries U6 fields"
else
    say "FAIL negative evidence missing U6 fields"; FAIL=1
fi
cat "$WORK/neg.log" >> "$LOG"

# ---- synthetic spoof suite ----
python3 "$TOOL_DIR/tests/check_spoof.py" >> "$LOG" 2>&1
if [ $? -eq 0 ]; then say "PASS tests/check_spoof.py"; else say "FAIL tests/check_spoof.py"; FAIL=1; fi

# ---- corpus detect (only when the corpus tree is present) ----
CORPUS_DIR="$TOOL_DIR/../../corpus/samples"
if [ -d "$CORPUS_DIR" ]; then
    python3 "$TOOL_DIR/tests/check_corpus_detect.py" "$CORPUS_DIR" >> "$LOG" 2>&1
    if [ $? -eq 0 ]; then say "PASS tests/check_corpus_detect.py (12 samples)"; else say "FAIL tests/check_corpus_detect.py"; FAIL=1; fi
else
    say "SKIP corpus detect (corpus tree absent in standalone zip context)"
fi

if [ $FAIL -eq 0 ]; then say "ALL CHECKS PASS"; else say "REGRESSION FAILED"; fi
rm -rf "$WORK"
exit $FAIL
