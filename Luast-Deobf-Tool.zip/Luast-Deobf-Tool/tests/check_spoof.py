#!/usr/bin/env python3
"""check_spoof.py — static spoof-port checks for Luast-Deobf-Tool.

Runs WITHOUT executing any payload: the synthetic fixtures below are
parsed with the bundled luau-ast and scanned with identity_scan.py
only. All numeric values in the fixtures are clearly-labelled TEST
DATA (synthetic, not real game IDs) — they must never appear in
production code (see the audit in check_audit.py / regression.sh).

Checks:
  S1  synthetic deflattened-AST fixture: eq-const PlaceId gate +
      set-membership PlaceId gate + eq-const CreatorId gate ->
      collect_events() extraction, unified spoof-engine/1 report,
      gates for BOTH fields, forks == [], branches unclassified.
  S2  telemetry negative: tostring(game.PlaceId) only -> no
      candidates, no gate claim (field read -> unknown, never seeded).
  S3  vendored spoof_engine.py byte-identity vs the canonical copy
      (or vs the pinned sha256 when the canonical tree is absent).
  S4  no-hardcode audit over production code (excludes tests/ and
      the vendored engine's PROBE_VALUE, triaged separately).
"""
import hashlib, json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = os.path.dirname(HERE)
sys.path.insert(0, TOOL)

import identity_scan as iscan
import spoof_engine as se

# ---------------------------------------------------------------- TEST DATA
# The values below are SYNTHETIC TEST DATA ONLY, invented for this
# fixture. They are not real game IDs and must not be copied into
# production code, defaults, or fallbacks.
TEST_EQ_PLACE = 100000001
TEST_SET_KEYS = (100000002, 100000003)
TEST_EQ_CREATOR = 200000002

FIXTURE = """-- TEST DATA ONLY: synthetic deflattened-AST fixture, not a real script.
local allowed = {}
allowed[%d] = true
allowed[%d] = true
if allowed[game.PlaceId] then
    print("pass")
end
if game.PlaceId == %d then
    print("eq-pass")
end
if game.CreatorId == %d then
    print("creator-pass")
end
""" % (TEST_SET_KEYS[0], TEST_SET_KEYS[1], TEST_EQ_PLACE, TEST_EQ_CREATOR)

TELEMETRY = """-- TEST DATA ONLY: telemetry negative (no gate).
local label = tostring(game.PlaceId)
local job = game["JobId"]
print(label, job)
"""

EXPECTED_ENGINE_SHA = 'd33daef82bd5c0ffb086daef4978fd0423fa30dfd0024741507b080d35230d6b'
CANONICAL = os.path.expanduser(
    '~/luau-deobf/tools/Luraph-Deobf-Tool-v6/spoof_engine.py')

FAIL = []


def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ((' — ' + detail) if detail and not cond else ''))
    if not cond:
        FAIL.append(name)


def parse_src(src):
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, 'fixture.luau')
        open(p, 'w').write(src)
        r = subprocess.run([os.path.join(TOOL, 'bin', 'luau-ast'), p],
                           capture_output=True, text=True)
        assert r.returncode == 0, r.stderr[:400]
        return json.loads(r.stdout)['root']


def build_report(scan):
    cands = {}
    se.collect_events(cands, scan['events'], fields=scan['extra_fields'])
    se.sort_candidates(cands)
    seed_d = se.build_seed(cands)
    seed = [{'field': f, 'value': seed_d[f], 'source': 'static'}
            for f in sorted(seed_d)]
    rep = se.build_report(route='luast', candidates=cands,
                          fields_read=scan['fields_read'],
                          fields_seen=scan['fields_seen'],
                          forks=[], seed=seed, captures=[],
                          contradictions=[], identity_reads=[],
                          notes=['static-only port: no payload execution, '
                                 'no forks, branches unclassified.'],
                          extra_fields=scan['extra_fields'])
    return rep, cands, seed_d


def main():
    # S1: multi-gate synthetic fixture
    scan = iscan.scan(parse_src(FIXTURE))
    rep, cands, seed_d = build_report(scan)
    check('S1 schema', rep['schema_version'] == 'spoof-engine/1', rep['schema_version'])
    check('S1 route', rep['route'] == 'luast', rep['route'])
    pc = cands.get('PlaceId', [])
    kinds = {(c['value'], c['kind']) for c in pc}
    check('S1 PlaceId eq-const', (TEST_EQ_PLACE, 'eq-const') in kinds, str(kinds))
    check('S1 PlaceId set-membership x2',
          all((k, 'set-membership') in kinds for k in TEST_SET_KEYS), str(kinds))
    cc = cands.get('CreatorId', [])
    check('S1 CreatorId eq-const',
          (TEST_EQ_CREATOR, 'eq-const') in {(c['value'], c['kind']) for c in cc}, str(cc))
    gates = {g['field']: g for g in rep['gates']}
    check('S1 multi-gate: both fields reported',
          set(gates) == {'PlaceId', 'CreatorId'}, str(sorted(gates)))
    check('S1 PlaceId gate forked (multi-candidate)',
          gates.get('PlaceId', {}).get('status') == 'forked', str(gates.get('PlaceId')))
    check('S1 CreatorId gate seeded (single candidate)',
          gates.get('CreatorId', {}).get('status') == 'seeded', str(gates.get('CreatorId')))
    check('S1 forks empty (static-only)', rep['forks'] == [], str(rep['forks']))
    check('S1 unknown_fields empty', rep['unknown_fields'] == [], str(rep['unknown_fields']))
    check('S1 seed only unambiguous field', seed_d == {'CreatorId': TEST_EQ_CREATOR}, str(seed_d))

    # S2: telemetry negative
    scan2 = iscan.scan(parse_src(TELEMETRY))
    rep2, cands2, _ = build_report(scan2)
    check('S2 telemetry: no candidates', cands2 == {}, str(cands2))
    check('S2 telemetry: PlaceId read, JobId read',
          set(scan2['fields_read']) == {'PlaceId', 'JobId'}, str(scan2['fields_read']))
    g2 = {g['field']: g for g in rep2['gates']}
    check('S2 telemetry: gates unknown, spoofed null',
          all(g2[f]['status'] == 'unknown' and g2[f]['spoofed_value'] is None
              for f in ('PlaceId', 'JobId')), str(g2))
    check('S2 telemetry: unknown_fields lists both',
          rep2['unknown_fields'] == ['JobId', 'PlaceId'], str(rep2['unknown_fields']))

    # S3: vendored engine byte-identity
    vendored = os.path.join(TOOL, 'spoof_engine.py')
    vsha = hashlib.sha256(open(vendored, 'rb').read()).hexdigest()
    check('S3 vendored engine sha == pinned', vsha == EXPECTED_ENGINE_SHA, vsha)
    if os.path.isfile(CANONICAL):
        csha = hashlib.sha256(open(CANONICAL, 'rb').read()).hexdigest()
        check('S3 vendored engine == canonical copy', vsha == csha, csha)
    else:
        print('S3 canonical copy absent (zip context) — pinned-sha check only')

    # S4: no-hardcode audit over production code
    prod = []
    for name in sorted(os.listdir(TOOL)):
        if name.endswith('.py') and name != 'spoof_engine.py':
            prod.append(os.path.join(TOOL, name))
    hits = []
    for p in prod:
        txt = open(p).read()
        for v in (str(TEST_EQ_PLACE), str(TEST_EQ_CREATOR)) + \
                tuple(str(k) for k in TEST_SET_KEYS):
            if v in txt:
                hits.append((os.path.basename(p), v))
    check('S4 fixture values absent from production code', not hits, str(hits))
    import re
    long_hits = []
    for p in prod:
        for i, ln in enumerate(open(p).read().split('\n'), 1):
            for m in re.findall(r'\b\d{9,}\b', ln):
                long_hits.append((os.path.basename(p), i, m))
    check('S4 no 9+-digit literals in production code', not long_hits, str(long_hits[:5]))

    print('ALL CHECKS PASS' if not FAIL else 'CHECKS FAILED: %s' % FAIL)
    return 0 if not FAIL else 1


if __name__ == '__main__':
    sys.exit(main())
