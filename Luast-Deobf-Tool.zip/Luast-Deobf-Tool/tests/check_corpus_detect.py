#!/usr/bin/env python3
"""check_corpus_detect.py — run luast_deobf.detect() over the 12-sample
training corpus (~/luau-deobf/corpus/samples/) and prove the U1-U6
fingerprint still routes exactly the luast golden and rejects the
other 11 samples (exit-2 equivalent).

Usage: python3 tests/check_corpus_detect.py [corpus-samples-dir]
Default dir is ../../corpus/samples relative to the tool dir.
Exits 0 only if: HWF (7a0fc3ad) matched, and every other sample
not matched — including StealAnEggs (4c174a06, 7 shape matches but
no index-128 pool) and the plain Ouroboros loader (d2d86e68).
Static AST parsing only; no payload is executed, nothing fetched.
"""
import glob, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = os.path.dirname(HERE)
sys.path.insert(0, TOOL)

import luast_deobf as ld

GOLDEN_PREFIX = '7a0fc3ad'


def main():
    samples = sys.argv[1] if len(sys.argv) > 1 else \
        os.path.join(TOOL, '..', '..', 'corpus', 'samples')
    files = sorted(glob.glob(os.path.join(samples, '*.luau')))
    if not files:
        print('corpus samples dir empty/missing: %s (skipping)' % samples)
        return 0
    fail = []
    for p in files:
        r = subprocess.run([os.path.join(TOOL, 'bin', 'luau-ast'), p],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print('%-45s AST-PARSE-FAIL (not counted as matched)' % os.path.basename(p))
            continue
        root = json.loads(r.stdout)['root']
        text = open(p).read()
        matched, version, ev = ld.detect(root, text)
        want = os.path.basename(p).startswith(GOLDEN_PREFIX)
        ok = (matched == want)
        print('%-45s matched=%-5s want=%-5s %s ev=%s'
              % (os.path.basename(p), matched, want,
                 'OK' if ok else 'MISMATCH', ev))
        if not ok:
            fail.append(os.path.basename(p))
    print('CORPUS DETECT: %s' % ('ALL OK' if not fail else 'FAILURES: %s' % fail))
    return 0 if not fail else 1


if __name__ == '__main__':
    sys.exit(main())
