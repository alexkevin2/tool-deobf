-- Negative control: a plain hand-written Luau script.
-- Has a while(true) loop and if/else logic but NO luast constants pool
-- and NO flattened state machine -> the tool must reject it (exit 2).
local config = { speed = 16, enabled = true, name = "plain" }
local state = 0

local function step(dt)
    state += 1
    if state > 100 then
        state = 0
    end
    return state
end

while true do
    local s = step(0.1)
    if s == 50 then
        print(config.name, s)
        break
    end
end

print("done", config.speed)
