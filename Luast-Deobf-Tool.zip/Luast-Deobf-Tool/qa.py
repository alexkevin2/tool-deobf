"""qa.py -- baked-in self-check for the Luast-Deobf-Tool clean stage
(v1.3.0).

Analyzes the FINAL cleaned AST (after simplify.py) and reports raw
patterns, naming ratios and residue the tool deliberately did NOT
fix, so the next person to read an output does not have to discover
its rough edges by hand.  Counts are AST counts (the printer is
faithful, so they match the shipped text); `sample_locations` are
luau-ast locations of the first few occurrences in walk order.

A qa_report.json is written on every clean-stage run, and a short
section is appended to report.md.  The report never changes the
verdict: it describes the output, it does not gate it (the compile
and literal gates in clean.py do that).
"""

import collections
import json

from luast_lib import T


def _strip(n):
    while isinstance(n, dict) and T(n) in ('AstExprGroup',
                                           'AstExprTypeAssertion'):
        n = n['expr']
    return n


def _norm(n):
    if isinstance(n, dict):
        return {k: _norm(v) for k, v in n.items()
                if k not in ('location', 'luauType')}
    if isinstance(n, list):
        return [_norm(v) for v in n]
    return n


def _walk(node, fn):
    if isinstance(node, dict):
        fn(node)
        for v in node.values():
            _walk(v, fn)
    elif isinstance(node, list):
        for v in node:
            _walk(v, fn)


def _loc(n):
    return n.get('location') if isinstance(n, dict) else None


def _num(n):
    try:
        return float(_strip(n)['value'])
    except (TypeError, ValueError, KeyError):
        return None


def _is_const(n, kind):
    return T(_strip(n)) == kind


def _has_call_or_fn(node):
    bad = [False]

    def f(n):
        if T(n) in ('AstExprCall', 'AstExprFunction'):
            bad[0] = True
    _walk(node, f)
    return bad[0]


def _cond_pure(node):
    bad = [False]

    def f(n):
        t = T(n)
        if t in ('AstExprCall', 'AstExprFunction'):
            bad[0] = True
        elif t in ('AstExprIndexExpr', 'AstExprIndexName'):
            if T(_strip(n['expr'])) != 'AstExprLocal':
                bad[0] = True
    _walk(node, f)
    return not bad[0]


def _provably_numeric(n):
    n = _strip(n)
    t = T(n)
    if t == 'AstExprConstantNumber':
        return True
    if t == 'AstExprBinary' and n.get('op') in (
            'Add', 'Sub', 'Mul', 'Div', 'Mod', 'Pow'):
        return True
    if t == 'AstExprUnary' and n.get('op') in ('Minus', 'Len'):
        return True
    if t == 'AstExprCall':
        f = _strip(n['func'])
        if T(f) == 'AstExprIndexName':
            base = _strip(f['expr'])
            if T(base) == 'AstExprGlobal' \
                    and base.get('global') in ('math', 'bit32'):
                return True
            if T(base) == 'AstExprGlobal' \
                    and base.get('global') == 'vector' \
                    and f.get('index') == 'dot':
                return True
    return False


def _samples(counter_dict, limit=5):
    return {k: v[:limit] for k, v in counter_dict.items()}


def analyze(root, state_name='state'):
    """Returns the qa dict (JSON-serializable)."""
    c = collections.Counter()
    locs = collections.defaultdict(list)

    def note(key, node):
        c[key] += 1
        if len(locs[key]) < 5:
            locs[key].append(_loc(node))

    def visit(n):
        t = T(n)
        if t == 'AstExprBinary':
            op = n.get('op')
            l, r = _strip(n['left']), _strip(n['right'])
            lt, rt = T(l), T(r)
            if op in ('Add', 'Sub', 'Mul') \
                    and lt == 'AstExprConstantNumber' \
                    and rt == 'AstExprConstantNumber':
                note('both_constant_binary', n)
            if op == 'Mul' and ((_num(l) == 1) or (_num(r) == 1)):
                note('identity_mul1', n)
                other = r if _num(l) == 1 else l
                if _provably_numeric(other):
                    note('identity_mul1_provably_numeric', n)
            if op == 'Add' and ((_num(l) == 0) or (_num(r) == 0)):
                note('identity_add0', n)
                other = r if _num(l) == 0 else l
                if _provably_numeric(other):
                    note('identity_add0_provably_numeric', n)
            if op == 'Sub' and _num(r) == 0:
                note('identity_sub0', n)
                if _provably_numeric(l):
                    note('identity_sub0_provably_numeric', n)
            if op == 'Concat' and lt == 'AstExprConstantString' \
                    and rt == 'AstExprConstantString':
                note('both_constant_binary', n)
            if op in ('CompareEq', 'CompareNe', 'CompareLt', 'CompareLe',
                      'CompareGt', 'CompareGe') \
                    and lt in ('AstExprConstantNumber',
                               'AstExprConstantString',
                               'AstExprConstantBool') \
                    and rt in ('AstExprConstantNumber',
                               'AstExprConstantString',
                               'AstExprConstantBool'):
                note('both_constant_binary', n)
            if op in ('And', 'Or') and lt == 'AstExprConstantBool' \
                    and rt == 'AstExprConstantBool':
                note('both_constant_binary', n)
        elif t == 'AstExprUnary':
            inner = _strip(n['expr'])
            if n.get('op') == 'Not' \
                    and T(inner) == 'AstExprConstantBool':
                # foldable by simplify.py; remaining ones are a miss
                note('constant_unary', n)
            elif n.get('op') == 'Minus' \
                    and T(inner) == 'AstExprConstantNumber':
                # NOT folded on purpose: `-5` prints identically
                # whether it is a unary node or a bare negative
                # constant, and the bare form would break the
                # literal ledger's reparse counting (see
                # simplify.py).  Informational only, never a miss.
                note('unary_minus_on_number', n)
        elif t == 'AstStatIf':
            cond = _strip(n['condition'])
            if T(cond) == 'AstExprConstantBool':
                note('if_constant_condition', n)
        elif t == 'AstExprIfElse':
            cond = _strip(n['condition'])
            if T(cond) == 'AstExprConstantBool':
                note('ifexpr_constant_condition', n)
        elif t == 'AstExprGlobal' and n.get('global') == 'akR':
            note('akr_global_remaining', n)
    _walk(root, visit)

    # negated-elseif chains (matching an earlier condition or not)
    def visit_if(n):
        if T(n) != 'AstStatIf':
            return
        chain = []
        cur = n
        while cur is not None and T(cur) == 'AstStatIf':
            chain.append(cur)
            eb = cur.get('elsebody')
            cur = eb if (eb is not None and T(eb) == 'AstStatIf') \
                else None
        for i in range(1, len(chain)):
            cond = _strip(chain[i]['condition'])
            if T(cond) == 'AstExprUnary' and cond.get('op') == 'Not':
                inner = _strip(cond['expr'])
                for j in range(i):
                    if _norm(inner) == _norm(
                            _strip(chain[j]['condition'])):
                        note('neg_elseif_matching_earlier', chain[i])
                        if not all(_cond_pure(_strip(chain[k][
                                'condition'])) for k in range(j, i)):
                            note('neg_elseif_matching_impure',
                                 chain[i])
                        break
    _walk(root, visit_if)

    # state nil assignments: total + chunk-prologue run remaining
    nil_total = [0]

    def count_nil(n):
        if T(n) == 'AstStatAssign' and len(n.get('vars') or []) == 1:
            v = _strip(n['vars'][0])
            vals = n.get('values') or []
            if T(v) == 'AstExprIndexName' and len(vals) == 1:
                base = _strip(v['expr'])
                if T(base) == 'AstExprLocal' \
                        and base['local']['name'] == state_name \
                        and T(_strip(vals[0])) == 'AstExprConstantNil':
                    nil_total[0] += 1
    _walk(root, count_nil)
    prologue = 0
    for s in root.get('body') or []:
        if T(s) == 'AstStatLocal' and len(s.get('vars') or []) == 1 \
                and s['vars'][0]['name'] == state_name:
            continue
        tmp = {'type': 'AstStatAssign', 'vars': s.get('vars') or [],
               'values': s.get('values') or []}
        # reuse the same predicate by direct check
        if T(s) == 'AstStatAssign' and len(s.get('vars') or []) == 1:
            v = _strip(s['vars'][0])
            vals = s.get('values') or []
            if T(v) == 'AstExprIndexName' and len(vals) == 1:
                base = _strip(v['expr'])
                if T(base) == 'AstExprLocal' \
                        and base['local']['name'] == state_name \
                        and T(_strip(vals[0])) == 'AstExprConstantNil':
                    prologue += 1
                    continue
        break
    c['state_nil_assign_total'] = nil_total[0]
    c['prologue_nil_remaining'] = prologue

    # dead consecutive assigns still present (guard-passing pairs
    # should be zero; guard-blocked pairs are residue by design)
    def target_key(var):
        v = _strip(var)
        if T(v) == 'AstExprLocal':
            return ('local', v['local']['name'],
                    v['local']['location'])
        if T(v) == 'AstExprIndexName':
            base = _strip(v['expr'])
            if T(base) == 'AstExprLocal' \
                    and base['local']['name'] == state_name:
                return ('state', v['index'])
        return ('expr', json.dumps(_norm(v), sort_keys=True))

    def target_read_in(key, values):
        found = [False]

        def f(n):
            if found[0]:
                return
            if key[0] == 'local' and T(n) == 'AstExprLocal':
                if (n['local']['name'], n['local']['location']) \
                        == (key[1], key[2]):
                    found[0] = True
            elif key[0] == 'state' and T(n) == 'AstExprIndexName':
                base = _strip(n['expr'])
                if T(base) == 'AstExprLocal' \
                        and base['local']['name'] == state_name \
                        and n['index'] == key[1]:
                    found[0] = True
            elif key[0] == 'expr' and T(n) in (
                    'AstExprIndexExpr', 'AstExprIndexName',
                    'AstExprLocal', 'AstExprGlobal'):
                if json.dumps(_norm(n), sort_keys=True) == key[1]:
                    found[0] = True
        for v in values:
            _walk(v, f)
        return found[0]

    def scan_block(body):
        for i in range(len(body) - 1):
            a, b = body[i], body[i + 1]
            if T(a) == 'AstStatAssign' and T(b) == 'AstStatAssign' \
                    and len(a.get('vars') or []) == 1 \
                    and len(b.get('vars') or []) == 1:
                key = target_key(a['vars'][0])
                if key == target_key(b['vars'][0]) \
                        and a.get('values'):
                    if not _has_call_or_fn(a['values'][0]) \
                            and not target_read_in(
                                key, b.get('values') or []):
                        note('dead_consecutive_assign', a)
                    elif not _has_call_or_fn(a['values'][0]):
                        note('dead_consecutive_blocked_by_rhs_read', a)

    def scan(n):
        if isinstance(n, dict):
            if T(n) == 'AstStatBlock':
                scan_block(n.get('body') or [])
            for v in n.values():
                scan(v)
        elif isinstance(n, list):
            for v in n:
                scan(v)
    scan(root)

    raw = {
        'both_constant_binary': c['both_constant_binary'],
        'constant_unary': c['constant_unary'],
        'unary_minus_on_number': c['unary_minus_on_number'],
        'if_constant_condition': c['if_constant_condition'],
        'ifexpr_constant_condition': c['ifexpr_constant_condition'],
        'identity_mul1': c['identity_mul1'],
        'identity_mul1_provably_numeric':
            c['identity_mul1_provably_numeric'],
        'identity_add0': c['identity_add0'],
        'identity_add0_provably_numeric':
            c['identity_add0_provably_numeric'],
        'identity_sub0': c['identity_sub0'],
        'identity_sub0_provably_numeric':
            c['identity_sub0_provably_numeric'],
        'neg_elseif_matching_earlier':
            c['neg_elseif_matching_earlier'],
        'neg_elseif_matching_impure':
            c['neg_elseif_matching_impure'],
        'state_nil_assign_total': c['state_nil_assign_total'],
        'prologue_nil_remaining': c['prologue_nil_remaining'],
        'dead_consecutive_assign': c['dead_consecutive_assign'],
        'dead_consecutive_blocked_by_rhs_read':
            c['dead_consecutive_blocked_by_rhs_read'],
        'akr_global_remaining': c['akr_global_remaining'],
    }
    not_fixed = []
    if raw['identity_mul1']:
        not_fixed.append({
            'category': 'identity_mul1',
            'count': raw['identity_mul1'],
            'reason': 'operand type unproven (a string operand would '
                      'change type/error behaviour if folded)',
            'sample_locations': locs['identity_mul1']})
    if raw['identity_add0'] - raw['identity_add0_provably_numeric']:
        not_fixed.append({
            'category': 'identity_add0_non_numeric_operand',
            'count': raw['identity_add0']
            - raw['identity_add0_provably_numeric'],
            'reason': 'operand type unproven',
            'sample_locations': locs['identity_add0']})
    if raw['neg_elseif_matching_impure']:
        not_fixed.append({
            'category': 'neg_elseif_matching_impure',
            'count': raw['neg_elseif_matching_impure'],
            'reason': 'matched condition contains a call (or a '
                      'non-local index base), so re-evaluation is not '
                      'provably identical',
            'sample_locations': locs['neg_elseif_matching_impure']})
    if raw['dead_consecutive_blocked_by_rhs_read']:
        not_fixed.append({
            'category': 'dead_consecutive_blocked_by_rhs_read',
            'count': raw['dead_consecutive_blocked_by_rhs_read'],
            'reason': 'second assignment reads the target, so '
                      'dropping the first would change the value read',
            'sample_locations':
                locs['dead_consecutive_blocked_by_rhs_read']})
    if raw['both_constant_binary'] or raw['constant_unary'] \
            or raw['if_constant_condition'] \
            or raw['ifexpr_constant_condition'] \
            or raw['identity_mul1_provably_numeric'] \
            or raw['identity_add0_provably_numeric'] \
            or raw['identity_sub0_provably_numeric'] \
            or raw['dead_consecutive_assign']:
        not_fixed.append({
            'category': 'simplify_miss',
            'count': raw['both_constant_binary'] + raw['constant_unary']
            + raw['if_constant_condition']
            + raw['ifexpr_constant_condition']
            + raw['identity_mul1_provably_numeric']
            + raw['identity_add0_provably_numeric']
            + raw['identity_sub0_provably_numeric']
            + raw['dead_consecutive_assign'],
            'reason': 'pattern the v1.3.0 passes should have folded '
                      'but did not — treat as a tool bug, not residue',
            'sample_locations': []})
    return {'raw_patterns': raw,
            'sample_locations': _samples(locs),
            'defects_not_fixed': not_fixed}
