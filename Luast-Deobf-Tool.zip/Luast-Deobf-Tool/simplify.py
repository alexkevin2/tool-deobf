"""simplify.py -- semantics-preserving simplification pass for the
Luast-Deobf-Tool clean stage (v1.3.0).

Runs on the CLEANED AST (after register/pool dissolution and renames),
before printing.  Every rewrite below is provable from the AST alone;
anything that cannot be proven is left untouched and counted by qa.py
as residue, never silently rewritten:

  * constant folding: binary/unary operations whose operands are all
    constants (integer-safe Add/Sub/Mul, comparisons on constants,
    bool And/Or, string Concat, unary Minus/Not).  No Div/Mod/Pow
    folding (no such both-constant nodes occur, and zero-divisor /
    float edge cases are not worth it); a fold whose result would be
    inf, nan or a negative zero is skipped.
  * identity folding (`x * 1`, `x + 0`, `x - 0`) ONLY when the other
    operand is provably numeric-or-error: a number literal, an
    arithmetic node, unary Minus/Len, a math.*/bit32.* call, or
    vector.dot.  A bare local/index operand is NOT folded: `s * 1`
    for a numeric string `s` yields a number, while `s` alone yields
    a string, and for a non-numeric string the original errors.
  * constant conditions: `if true/false then` statements (the kept
    branch is emitted as its own AstStatBlock, which the printer
    renders as `do ... end`, so locals never leak scope) and
    constant-condition if-expressions (folded to the chosen branch;
    the unchosen branch is never evaluated in Luau, so dropping it
    cannot drop a side effect).
  * negated-elseif collapse: in a chain, an `elseif not (C)` whose
    `C` (group-stripped, location-insensitive) equals an earlier
    condition, where every condition from that earlier branch up to
    the negated one is pure (no calls/functions; index bases only
    locals), is provably taken: reaching it means the earlier
    condition evaluated false, no statement ran in between, and the
    pure conditions cannot have changed value.  The negated branch
    becomes the `else` (later branches are dead), or, when the
    matching branch is the first, is immediately followed, and has an
    empty then-body, the whole chain collapses to `if not C then ...`.
    Constant elseif conditions are handled the same way (a `true`
    elseif truncates the chain; a `false` elseif is dropped).
  * dead consecutive assignments: within one block, `T = <pure>` (no
    calls/functions in the RHS) immediately followed by `T = <...>`
    where the second RHS does not read `T` — the first write is
    unobservable and is dropped.  Also `local x = <pure>` immediately
    followed by `x = <...>` (RHS does not read `x`): the initial
    value is dropped, the declaration kept.  Multi-variable assigns
    and compound assigns are never touched.
  * prologue nil compaction: at the very top of the chunk, `state.<f>
    = nil` assignments before any other statement are no-ops (the
    state table is a fresh `{}`; assigning nil to an absent field is
    indistinguishable from absence) and are dropped.  Mid-body nil
    assignments are meaningful deletions and are kept.

The pass books everything it changes so the clean stage can keep its
gates exact: `lit_delta[ctx]` is a per-context Counter of
(post - pre) literal-multiset changes, and `stmt_delta[ctx]` is the
per-context statement-count change (contexts: 'chunk' or
('poolFn', lit) for hoisted pool functions, keyed by the
`clean:fn<lit>` location the clean stage stamps on their
definitions).  clean.py folds these deltas into its literal ledger
and per-function audit, then re-verifies both against the simplified
AST, so a bookkeeping bug fails the run instead of shipping a
wrong gate.
"""

import collections
import math
import re

import luast_lib as L
from luast_lib import T, unwrap


def _strip(n):
    while isinstance(n, dict) and T(n) in ('AstExprGroup',
                                           'AstExprTypeAssertion'):
        n = n['expr']
    return n


def _norm(n):
    """Structural form ignoring source locations (use-site locations
    differ between two reads of the same variable)."""
    if isinstance(n, dict):
        return {k: _norm(v) for k, v in n.items()
                if k not in ('location', 'luauType')}
    if isinstance(n, list):
        return [_norm(v) for v in n]
    return n


def _walk(node, fn):
    if isinstance(node, dict):
        fn(node)
        for v in node.values():
            _walk(v, fn)
    elif isinstance(node, list):
        for v in node:
            _walk(v, fn)


def _lit_counter(node):
    acc = collections.Counter()

    def f(n):
        t = T(n)
        if t == 'AstExprConstantString':
            acc[('s', n.get('value'))] += 1
        elif t == 'AstExprConstantNumber':
            try:
                acc[('n', float(n.get('value')))] += 1
            except (TypeError, ValueError):
                pass
    _walk(node, f)
    return acc


def _count_stmts(node):
    cnt = [0]

    def f(n):
        if T(n) and T(n).startswith('AstStat'):
            cnt[0] += 1
    _walk(node, f)
    return cnt[0]


def _is_num_const(n):
    n = _strip(n)
    return T(n) == 'AstExprConstantNumber'


def _num_val(n):
    try:
        return float(_strip(n)['value'])
    except (TypeError, ValueError, KeyError):
        return None


def _is_bool_const(n):
    return T(_strip(n)) == 'AstExprConstantBool'


def _is_str_const(n):
    return T(_strip(n)) == 'AstExprConstantString'


def _has_call_or_fn(node):
    bad = [False]

    def f(n):
        if T(n) in ('AstExprCall', 'AstExprFunction'):
            bad[0] = True
    _walk(node, f)
    return bad[0]


def _cond_pure(node):
    """Strict purity for re-evaluation reasoning: no calls, no
    function values, and every index base is a plain local (a state
    field or payload local of a fresh/plain table).  A global base
    (e.g. `game.X`) or a computed base is excluded: metamethods or
    host objects could observe the re-evaluation."""
    bad = [False]

    def f(n):
        t = T(n)
        if t in ('AstExprCall', 'AstExprFunction'):
            bad[0] = True
        elif t in ('AstExprIndexExpr', 'AstExprIndexName'):
            if T(_strip(n['expr'])) != 'AstExprLocal':
                bad[0] = True
    _walk(node, f)
    return not bad[0]


def _provably_numeric(n):
    """True when evaluating n either errors or yields a number, so
    `n * 1` / `n + 0` / `n - 0` may be replaced by `n`."""
    n = _strip(n)
    t = T(n)
    if t == 'AstExprConstantNumber':
        return True
    if t == 'AstExprBinary' and n.get('op') in (
            'Add', 'Sub', 'Mul', 'Div', 'Mod', 'Pow'):
        return True
    if t == 'AstExprUnary' and n.get('op') in ('Minus', 'Len'):
        return True
    if t == 'AstExprCall':
        f = _strip(n['func'])
        if T(f) == 'AstExprIndexName':
            base = _strip(f['expr'])
            if T(base) == 'AstExprGlobal' \
                    and base.get('global') in ('math', 'bit32'):
                return True
            if T(base) == 'AstExprGlobal' \
                    and base.get('global') == 'vector' \
                    and f.get('index') == 'dot':
                return True
    return False


def _is_one(n):
    v = _num_val(n)
    return v is not None and v == 1


def _is_zero(n):
    v = _num_val(n)
    return v is not None and v == 0


def _mk_num(v):
    if float(v) == int(v) and abs(v) < 1e15:
        v = int(v)
    return {'type': 'AstExprConstantNumber', 'value': v,
            'location': 'clean:fold'}


def _mk_bool(v):
    return {'type': 'AstExprConstantBool', 'value': bool(v),
            'location': 'clean:fold'}


def _is_ascii(s):
    try:
        return all(ord(c) < 128 for c in s)
    except TypeError:
        return False


class Simplifier:
    def __init__(self, state_name='state'):
        self.state_name = state_name
        self.stats = collections.Counter()
        self.lit_delta = collections.defaultdict(collections.Counter)
        self.stmt_delta = collections.defaultdict(int)
        self.ctx = 'chunk'
        self._ctx_stack = []

    # -- booking ---------------------------------------------------
    def _book_lit(self, old, new):
        pre = _lit_counter(old)
        post = _lit_counter(new)
        for k in set(pre) | set(post):
            d = post.get(k, 0) - pre.get(k, 0)
            if d:
                self.lit_delta[self.ctx][k] += d

    def _book_stmt(self, old, new):
        d = _count_stmts(new) - _count_stmts(old)
        if d:
            self.stmt_delta[self.ctx] += d

    def _push_ctx(self, node):
        loc = node.get('location') or ''
        m = re.match(r'clean:fn(\d+)$', loc)
        if m:
            self._ctx_stack.append(self.ctx)
            self.ctx = ('poolFn', int(m.group(1)))
            return True
        return False

    def _pop_ctx(self, pushed):
        if pushed:
            self.ctx = self._ctx_stack.pop()

    # -- entry -----------------------------------------------------
    def transform_root(self, root):
        new = dict(root)
        new['body'] = self._stmt_list(root.get('body') or [],
                                      chunk_top=True)
        return new

    # -- expressions -----------------------------------------------
    def _any(self, v):
        if isinstance(v, dict):
            if (v.get('type') or '').startswith('AstExpr'):
                return self._expr(v)
            return {k: self._any(x) for k, x in v.items()}
        if isinstance(v, list):
            return [self._any(x) for x in v]
        return v

    def _expr(self, n):
        t = T(n)
        if t == 'AstExprBinary':
            left = self._expr(n['left'])
            right = self._expr(n['right'])
            base = dict(n)
            base['left'] = left
            base['right'] = right
            folded = self._fold_binary(base)
            if folded is not base:
                self._book_lit(base, folded)
            return folded
        if t == 'AstExprUnary':
            inner = self._expr(n['expr'])
            base = dict(n)
            base['expr'] = inner
            folded = self._fold_unary(base)
            if folded is not base:
                self._book_lit(base, folded)
            return folded
        if t == 'AstExprIfElse':
            cond = self._expr(n['condition'])
            te = self._expr(n['trueExpr'])
            fe = self._expr(n['falseExpr']) \
                if n.get('falseExpr') is not None else None
            base = dict(n)
            base['condition'] = cond
            base['trueExpr'] = te
            base['falseExpr'] = fe
            c = _strip(cond)
            if T(c) == 'AstExprConstantBool':
                chosen = te if c['value'] else fe
                if chosen is not None:
                    self.stats['folded_if_const_expr'] += 1
                    self._book_lit(base, chosen)
                    return chosen
            return base
        if t == 'AstExprFunction':
            fn = dict(n)
            fn['body'] = self._block(n['body'])
            return fn
        if t == 'AstExprGroup':
            g = dict(n)
            g['expr'] = self._expr(n['expr'])
            return g
        # generic expression: rebuild children (calls, indexes,
        # tables, ...); statement-containing nodes never occur here
        # except AstExprFunction, handled above
        return {k: self._any(v) for k, v in n.items()}

    def _fold_unary(self, n):
        # Only Not-on-bool is folded.  Unary Minus on a number is
        # deliberately NOT folded: it prints identically (`-5`), and
        # a bare negative ConstantNumber would reparse as
        # Unary(Minus, positive) — a different literal-multiset key
        # than the clean stage's ledger counts (clean.py's mk_literal
        # keeps the unary-minus shape for exactly this reason).
        inner = _strip(n['expr'])
        if n.get('op') == 'Not' and T(inner) == 'AstExprConstantBool':
            self.stats['folded_unary'] += 1
            return _mk_bool(not inner['value'])
        return n

    def _fold_binary(self, n):
        op = n.get('op')
        left, right = _strip(n['left']), _strip(n['right'])
        lt, rt = T(left), T(right)
        if op in ('Add', 'Sub', 'Mul') and lt == 'AstExprConstantNumber' \
                and rt == 'AstExprConstantNumber':
            a, b = _num_val(left), _num_val(right)
            if a is not None and b is not None \
                    and math.isfinite(a) and math.isfinite(b):
                r = {'Add': a + b, 'Sub': a - b, 'Mul': a * b}[op]
                if math.isfinite(r) and not (
                        r == 0 and (math.copysign(1, a) < 0
                                    or math.copysign(1, b) < 0)):
                    self.stats['folded_binary'] += 1
                    # Negative results MUST stay in unary-minus
                    # shape: a bare negative ConstantNumber prints
                    # as `-x` but reparses as Unary(Minus, x), so
                    # the literal ledger (which counts the reparsed
                    # form) would disagree with the booked delta.
                    if r < 0:
                        return {'type': 'AstExprUnary', 'op': 'Minus',
                                'expr': _mk_num(-r),
                                'location': 'clean:fold'}
                    return _mk_num(r)
            return n
        if op in ('CompareEq', 'CompareNe', 'CompareLt', 'CompareLe',
                  'CompareGt', 'CompareGe'):
            if lt == 'AstExprConstantNumber' \
                    and rt == 'AstExprConstantNumber':
                a, b = _num_val(left), _num_val(right)
                if a is None or b is None:
                    return n
                res = {'CompareEq': a == b, 'CompareNe': a != b,
                       'CompareLt': a < b, 'CompareLe': a <= b,
                       'CompareGt': a > b, 'CompareGe': a >= b}[op]
                self.stats['folded_binary'] += 1
                return _mk_bool(res)
            if lt == 'AstExprConstantString' \
                    and rt == 'AstExprConstantString':
                a, b = left['value'], right['value']
                if op in ('CompareEq', 'CompareNe'):
                    res = (a == b) if op == 'CompareEq' else (a != b)
                    self.stats['folded_binary'] += 1
                    return _mk_bool(res)
                if _is_ascii(a) and _is_ascii(b):
                    res = {'CompareLt': a < b, 'CompareLe': a <= b,
                           'CompareGt': a > b, 'CompareGe': a >= b}[op]
                    self.stats['folded_binary'] += 1
                    return _mk_bool(res)
            if lt == 'AstExprConstantBool' \
                    and rt == 'AstExprConstantBool' \
                    and op in ('CompareEq', 'CompareNe'):
                res = (left['value'] == right['value']) \
                    if op == 'CompareEq' \
                    else (left['value'] != right['value'])
                self.stats['folded_binary'] += 1
                return _mk_bool(res)
            return n
        if op in ('And', 'Or') and lt == 'AstExprConstantBool' \
                and rt == 'AstExprConstantBool':
            res = (left['value'] and right['value']) if op == 'And' \
                else (left['value'] or right['value'])
            self.stats['folded_binary'] += 1
            return _mk_bool(res)
        if op == 'Concat' and lt == 'AstExprConstantString' \
                and rt == 'AstExprConstantString':
            self.stats['folded_binary'] += 1
            return {'type': 'AstExprConstantString',
                    'value': left['value'] + right['value'],
                    'location': 'clean:fold'}
        # identity ops, provably-numeric operand only.  NOTE: the
        # caller (_expr) books the literal delta for the replacement
        # exactly once; do NOT book here as well.
        if op == 'Mul' and (_is_one(left) or _is_one(right)):
            other = right if _is_one(left) else left
            if _provably_numeric(other):
                self.stats['folded_identity'] += 1
                return other
            return n
        if op == 'Add' and (_is_zero(left) or _is_zero(right)):
            other = right if _is_zero(left) else left
            if _provably_numeric(other):
                self.stats['folded_identity'] += 1
                return other
            return n
        if op == 'Sub' and _is_zero(right) \
                and _provably_numeric(left):
            self.stats['folded_identity'] += 1
            return left
        return n

    # -- statements --------------------------------------------------
    def _block(self, block):
        new = dict(block)
        new['body'] = self._stmt_list(block.get('body') or [])
        return new

    def _stmt(self, n):
        """Returns a list of statements (usually one; zero when the
        statement is provably dead, e.g. `if false then ... end`)."""
        t = T(n)
        if t == 'AstStatBlock':
            return [self._block(n)]
        if t == 'AstStatIf':
            return self._if(n)
        if t == 'AstStatLocalFunction':
            pushed = self._push_ctx(n)
            try:
                fn = dict(n['func'])
                fn['body'] = self._block(n['func']['body'])
                n2 = dict(n)
                n2['func'] = fn
                return [n2]
            finally:
                self._pop_ctx(pushed)
        if t == 'AstStatWhile':
            n2 = dict(n)
            n2['condition'] = self._expr(n['condition'])
            n2['body'] = self._block(n['body'])
            return [n2]
        if t == 'AstStatRepeat':
            n2 = dict(n)
            n2['body'] = self._block(n['body'])
            n2['condition'] = self._expr(n['condition'])
            return [n2]
        if t == 'AstStatFor':
            n2 = dict(n)
            n2['from'] = self._expr(n['from'])
            n2['to'] = self._expr(n['to'])
            if n.get('step') is not None:
                n2['step'] = self._expr(n['step'])
            n2['body'] = self._block(n['body'])
            return [n2]
        if t == 'AstStatForIn':
            n2 = dict(n)
            n2['values'] = [self._expr(v) for v in n.get('values') or []]
            n2['body'] = self._block(n['body'])
            return [n2]
        if t == 'AstStatDo':
            return [self._block(n)]
        if t == 'AstStatLocal':
            n2 = dict(n)
            n2['values'] = [self._expr(v)
                            for v in n.get('values') or []]
            return [n2]
        if t == 'AstStatAssign':
            n2 = dict(n)
            n2['vars'] = [self._expr(v) for v in n.get('vars') or []]
            n2['values'] = [self._expr(v)
                            for v in n.get('values') or []]
            return [n2]
        if t == 'AstStatCompoundAssign':
            n2 = dict(n)
            n2['var'] = self._expr(n['var'])
            n2['value'] = self._expr(n['value'])
            return [n2]
        if t == 'AstStatCall':
            n2 = dict(n)
            n2['call'] = self._expr(n['call'])
            return [n2]
        if t == 'AstStatExpr':
            n2 = dict(n)
            n2['expr'] = self._expr(n['expr'])
            return [n2]
        if t == 'AstStatReturn':
            n2 = dict(n)
            key = 'list' if 'list' in n else 'values'
            n2[key] = [self._expr(v) for v in n.get(key) or []]
            return [n2]
        if t in ('AstStatBreak', 'AstStatContinue'):
            return [n]
        if t == 'AstStatFunction':
            fn = dict(n['func'])
            fn['body'] = self._block(n['func']['body'])
            n2 = dict(n)
            n2['func'] = fn
            return [n2]
        # unknown statement type: keep verbatim rather than risk it
        return [n]

    def _if(self, n):
        """Transform one if-chain; returns a statement list."""
        cond = self._expr(n['condition'])
        thenbody = self._block(n['thenbody'])
        eb = n.get('elsebody')
        if eb is not None:
            if T(eb) == 'AstStatIf':
                eb_list = self._if(eb)
                if not eb_list:
                    eb = None
                elif len(eb_list) == 1:
                    eb = eb_list[0]
                else:
                    # cannot happen: _if returns at most one node for
                    # an if-chain position (a block is one node)
                    eb = eb_list[0]
            else:
                eb = self._block(eb)
        node = dict(n)
        node['condition'] = cond
        node['thenbody'] = thenbody
        node['elsebody'] = eb
        c = _strip(cond)
        if T(c) == 'AstExprConstantBool':
            self.stats['folded_if_const_stmt'] += 1
            if c['value']:
                self._book_stmt(node, thenbody)
                self._book_lit(node, thenbody)
                return [thenbody]
            if eb is None:
                self.stmt_delta[self.ctx] -= _count_stmts(node)
                self._book_lit(node, {'type': 'AstStatBlock',
                                      'body': []})
                return []
            self._book_stmt(node, eb)
            self._book_lit(node, eb)
            return [eb]
        return [self._collapse_chain(node)]

    def _collapse_chain(self, node):
        """Negated-elseif / constant-elseif chain surgery on an
        already child-transformed chain.  Returns one node."""
        chain = []
        cur = node
        while cur is not None and T(cur) == 'AstStatIf':
            chain.append(cur)
            eb = cur.get('elsebody')
            cur = eb if (eb is not None and T(eb) == 'AstStatIf') \
                else None
        # constant elseif branches first (no purity question: a
        # constant does not depend on state).  NOTE: counts are
        # snapshotted BEFORE mutating the chain — the head node is
        # mutated in place, so counting after would see no change.
        pre_stmts = _count_stmts(node)
        pre_lits = _lit_counter(node)

        def book_truncation():
            self.stmt_delta[self.ctx] += \
                _count_stmts(chain[0]) - pre_stmts
            post = _lit_counter(chain[0])
            for k in set(pre_lits) | set(post):
                d = post.get(k, 0) - pre_lits.get(k, 0)
                if d:
                    self.lit_delta[self.ctx][k] += d

        false_dropped = False
        i = 1
        while i < len(chain):
            c = _strip(chain[i]['condition'])
            if T(c) == 'AstExprConstantBool':
                if c['value']:
                    # this branch is always taken: it becomes the else
                    chain[i - 1]['elsebody'] = chain[i]['thenbody']
                    self.stats['elseif_const_true_truncated'] += 1
                    book_truncation()
                    return chain[0]
                # never taken: unlink it and keep scanning
                chain[i - 1]['elsebody'] = chain[i].get('elsebody')
                self.stats['elseif_const_false_dropped'] += 1
                false_dropped = True
                chain.pop(i)
                continue
            i += 1
        # negated branch matching an earlier condition
        for i in range(1, len(chain)):
            c = _strip(chain[i]['condition'])
            if T(c) != 'AstExprUnary' or c.get('op') != 'Not':
                continue
            inner = _strip(c['expr'])
            for j in range(i):
                if _norm(inner) != _norm(_strip(chain[j]['condition'])):
                    continue
                if not all(_cond_pure(_strip(chain[k]['condition']))
                           for k in range(j, i)):
                    break
                # provably taken: everything after it is dead
                if j == 0 and i == 1 and not chain[0]['thenbody'].get(
                        'body'):
                    res = {'type': 'AstStatIf',
                           'location': chain[i].get('location'),
                           'condition': chain[i]['condition'],
                           'thenbody': chain[i]['thenbody'],
                           'elsebody': None}
                    self.stats['neg_chain_collapsed'] += 1
                    self._book_stmt(node, res)
                    self._book_lit(node, res)
                    return res
                chain[i - 1]['elsebody'] = chain[i]['thenbody']
                self.stats['neg_chain_truncated'] += 1
                book_truncation()
                return chain[0]
        if false_dropped:
            book_truncation()
        return node

    # -- statement lists ---------------------------------------------
    def _is_state_nil_assign(self, s):
        if T(s) != 'AstStatAssign' or len(s.get('vars') or []) != 1:
            return False
        v = _strip(s['vars'][0])
        vals = s.get('values') or []
        if T(v) != 'AstExprIndexName' or len(vals) != 1:
            return False
        base = _strip(v['expr'])
        return T(base) == 'AstExprLocal' \
            and base['local']['name'] == self.state_name \
            and T(_strip(vals[0])) == 'AstExprConstantNil'

    def _target_key(self, var):
        v = _strip(var)
        if T(v) == 'AstExprLocal':
            return ('local', v['local']['name'], v['local']['location'])
        if T(v) == 'AstExprIndexName':
            base = _strip(v['expr'])
            if T(base) == 'AstExprLocal' \
                    and base['local']['name'] == self.state_name:
                return ('state', v['index'])
        return ('expr', _norm(v))

    def _target_read_in(self, key, values):
        found = [False]

        def f(n):
            if found[0]:
                return
            if key[0] == 'local' and T(n) == 'AstExprLocal':
                if (n['local']['name'], n['local']['location']) \
                        == (key[1], key[2]):
                    found[0] = True
            elif key[0] == 'state' and T(n) == 'AstExprIndexName':
                base = _strip(n['expr'])
                if T(base) == 'AstExprLocal' \
                        and base['local']['name'] == self.state_name \
                        and n['index'] == key[1]:
                    found[0] = True
            elif key[0] == 'expr' and T(n) in (
                    'AstExprIndexExpr', 'AstExprIndexName',
                    'AstExprLocal', 'AstExprGlobal'):
                if _norm(n) == key[1]:
                    found[0] = True
        for v in values:
            _walk(v, f)
        return found[0]

    def _stmt_list(self, stmts, chunk_top=False):
        out = []
        for s in stmts:
            out.extend(self._stmt(s))
        if chunk_top:
            # prologue nil compaction: drop the initial run of
            # state.<f> = nil before any other statement
            kept = []
            dropping = True
            state_decl_seen = False
            for s in out:
                if dropping:
                    if T(s) == 'AstStatLocal' and len(
                            s.get('vars') or []) == 1 \
                            and s['vars'][0]['name'] == self.state_name:
                        state_decl_seen = True
                        kept.append(s)
                        continue
                    if self._is_state_nil_assign(s):
                        self.stats['prologue_nil_dropped'] += 1
                        self.stmt_delta[self.ctx] -= _count_stmts(s)
                        self._book_lit(s, {'type': 'AstStatBlock',
                                           'body': []})
                        continue
                    dropping = False
                kept.append(s)
            out = kept
        # dead consecutive assignments (fixpoint scan: after a drop,
        # re-examine the same index)
        i = 0
        while i + 1 < len(out):
            a, b = out[i], out[i + 1]
            dropped = False
            if T(a) == 'AstStatAssign' and T(b) == 'AstStatAssign' \
                    and len(a.get('vars') or []) == 1 \
                    and len(b.get('vars') or []) == 1:
                key = self._target_key(a['vars'][0])
                if key == self._target_key(b['vars'][0]) \
                        and a.get('values') \
                        and not _has_call_or_fn(a['values'][0]) \
                        and not self._target_read_in(
                            key, b.get('values') or []):
                    self.stats['dead_assign_dropped'] += 1
                    self.stmt_delta[self.ctx] -= _count_stmts(a)
                    self._book_lit(a, {'type': 'AstStatBlock',
                                       'body': []})
                    out.pop(i)
                    dropped = True
            elif T(a) == 'AstStatLocal' and T(b) == 'AstStatAssign' \
                    and len(a.get('vars') or []) == 1 \
                    and a.get('values') \
                    and len(b.get('vars') or []) == 1:
                key = self._target_key(
                    {'type': 'AstExprLocal', 'local': a['vars'][0],
                     'location': a['vars'][0]['location']})
                if key == self._target_key(b['vars'][0]) \
                        and not _has_call_or_fn(a['values'][0]) \
                        and not self._target_read_in(
                            key, b.get('values') or []):
                    # keep the declaration, drop only its dead value
                    self.stats['dead_local_value_stripped'] += 1
                    self._book_lit(a['values'][0],
                                   {'type': 'AstExprConstantNil',
                                    'location': 'clean:fold'})
                    a2 = dict(a)
                    a2['values'] = []
                    out[i] = a2
            if not dropped:
                i += 1
        return out
