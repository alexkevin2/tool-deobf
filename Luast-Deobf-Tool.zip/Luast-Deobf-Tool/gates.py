# gates.py — output verification gates for the luast deflattener.
#
# Literal-multiset gate: the multiset of string/number literals in the
# deflattened output must equal the multiset derivable from the input
# AST after accounting for (a) pool substitution at read sites,
# (b) machine scaffolding removal (only extracted paths of reachable
# leaves count, with emission multiplicities and prefix hoisting),
# (c) dropped alias/state-init statements, (d) verbatim permutation
# statements, (e) kernel machines printed in full.
import collections
from luast_lib import T, unwrap

def expected_literals(root, pool, aliases, machines, pr, drop_ids,
                      kernel_ids=frozenset()):
    cnt = collections.Counter()
    machine_whiles = {id(m['while']): m for m in machines if m['machine']}
    perm_ids = {id(s) for s in pool.perm_stmts}

    def count_any(e, verbatim=False):
        if isinstance(e, dict):
            if id(e) in perm_ids:
                verbatim = True
            if id(e) in machine_whiles and id(e) not in kernel_ids:
                m = machine_whiles[id(e)]
                reach = m.get('_reachable')
                emitted = m.get('_emitted')
                hoisted = m.get('_hoisted') or {}
                for lid, info in m['leaf_info'].items():
                    if reach is not None and lid not in reach:
                        continue
                    mult = emitted.get(lid, 0) if emitted is not None else 1
                    k = hoisted.get(lid, 0)
                    for _ in range(mult):
                        if k and info['paths']:
                            for s in info['paths'][0]['stmts'][:k]:
                                count_any(s)
                        for p in info['paths']:
                            for s in p['stmts'][k:]:
                                count_any(s)
                            for cond, _pol in p['guards']:
                                count_any(cond)
                            if p['end'][0] == 'return' and p.get('raw') is not None:
                                count_any(p['raw'])
                return
            if id(e) in drop_ids:
                return
            t = T(e)
            if t == 'AstExprConstantString':
                cnt[('s', e['value'])] += 1
                return
            if t == 'AstExprConstantNumber':
                cnt[('n', float(e['value']))] += 1
                return
            n = None if verbatim else pr.pool_ref(unwrap(e))
            if n is not None:
                sub = pr.pool_substitute(n, None)
                if sub is not None:
                    kind, val = pool.scalar(n)
                    if kind in ('string', 'number'):
                        cnt[('s' if kind == 'string' else 'n',
                             val if kind == 'string' else float(val))] += 1
                    elif kind == 'expr':
                        count_any(val)
                    return
            for v in e.values():
                count_any(v, verbatim)
        elif isinstance(e, list):
            for v in e:
                count_any(v, verbatim)

    count_any(root)
    return cnt

def output_literals(ast_root):
    cnt = collections.Counter()
    def visit(n):
        t = T(n)
        if t == 'AstExprConstantString':
            cnt[('s', n['value'])] += 1
        elif t == 'AstExprConstantNumber':
            cnt[('n', float(n['value']))] += 1
    def walk(n):
        if isinstance(n, dict):
            visit(n)
            for v in n.values():
                walk(v)
        elif isinstance(n, list):
            for v in n:
                walk(v)
    walk(ast_root)
    return cnt

def literal_gate(root, pool, aliases, machines, pr, drop_ids, kernel_ids,
                 out_ast_root):
    exp = expected_literals(root, pool, aliases, machines, pr, drop_ids,
                            kernel_ids)
    got = output_literals(out_ast_root)
    missing = exp - got
    extra = got - exp
    return {'expected': sum(exp.values()), 'got': sum(got.values()),
            'missing': sum(missing.values()), 'extra': sum(extra.values()),
            'pass': not missing and not extra,
            'missing_sample': [(str(k), v) for k, v in list(missing.items())[:10]],
            'extra_sample': [(str(k), v) for k, v in list(extra.items())[:10]]}
