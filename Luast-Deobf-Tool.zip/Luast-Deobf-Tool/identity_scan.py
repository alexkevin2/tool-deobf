#!/usr/bin/env python3
"""identity_scan.py — STATIC-ONLY identity-gate scanner for Luast.

Scans the *deflattened* AST (structured, pool-resolved code) for
game-identity gates and feeds them to the shared spoof engine via
``spoof_engine.collect_events()``. This module never executes the
payload, never fetches anything, and never invents a value: every
candidate comes from a comparison site actually present in the
deflattened AST.

Gate shapes recognised (direct operands only — a field read wrapped
in ``tostring()``/a call/arithmetic is a telemetry/display read, NOT
a gate):

  * ``game.<Field> == <const>`` (either operand order) -> eq-const
  * ``game.<Field> ~= <const>`` -> ne-const (non-pass kind)
  * ``game.<Field> <|<=|>|>= <const>`` (normalised to field-on-left)
    -> lt/gt/le/ge-bound (non-pass kinds: the bound is not the
    gate-PASS value)
  * ``<set>[game.<Field>]`` where ``<set>`` is a local table whose
    constant numeric keys were collected statically -> set-membership
    (one candidate per known key)

Field reads recognised: ``game.<Field>`` (AstExprIndexName, op '.')
and ``game["<Field>"]`` (AstExprIndexExpr, constant-string index),
plus the same forms through a one-hop local alias (``local g = game``).
A method call (``game:GetService(...)``, op ':') is NOT a field read.

Machine-dispatch comparisons (``state == const`` inside a flattened
machine) are NOT identity gates and are never reported: this scanner
runs on the deflattened AST, where machine dispatch has already been
structured away, and it only matches reads of the ``game`` object.

Fields seen only as string literals (e.g. ``"PlaceId"`` inside a
constants-pool telemetry string) are reported as *presence-only*:
they appear in ``fields_seen`` but never in ``fields_read``,
``candidates`` or ``gates``. Canonical fields actually read but with
no comparison gate site are reported as ``fields_read`` (the unified
report then marks them ``unknown`` with ``spoofed_value`` null) —
never as gates, never seeded.

Non-canonical ``game.*`` members (e.g. an event such as
``DescendantAdded``) are NOT identity fields merely because they are
read: per SPOOF-SPEC §2.1's extension rule, they count only when
compared against a constant or a set. A merely-read non-canonical
member therefore appears in neither ``fields_read`` nor ``gates``;
one that IS compared/set-indexed appears as an ``extra_field``.

Returns from ``scan(root)``:
  {
    'fields_seen': sorted list (reads + presence-only),
    'fields_read': {field: [location strings]},
    'presence_only': sorted list (string-literal presence, never read),
    'extra_fields': sorted list (non-canonical game.* members compared
                     or set-indexed),
    'events': [collect_events() event dicts],
    'gate_sites': [human-readable site strings, same order as events],
  }
"""
import sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from luast_lib import T, unwrap, walk, var_key, is_cnum, cnum

try:
    import spoof_engine as _se
    IDENTITY_FIELDS = _se.IDENTITY_FIELDS
except Exception:  # pragma: no cover - engine is vendored next to us
    IDENTITY_FIELDS = ('PlaceId', 'JobId', 'CreatorId', 'PlaceVersion',
                       'GameId')

BIN_OP = {
    'CompareEq': 'eq',
    'CompareNe': 'ne',
    'CompareLt': 'lt',
    'CompareGt': 'gt',
    'CompareLe': 'le',
    'CompareGe': 'ge',
}
FLIP = {'lt': 'gt', 'gt': 'lt', 'le': 'ge', 'ge': 'le',
        'eq': 'eq', 'ne': 'ne'}


def _const_value(e):
    """Static scalar value of an expression, or None."""
    e = unwrap(e)
    t = T(e)
    if t == 'AstExprConstantNumber':
        return e['value']
    if t == 'AstExprConstantString':
        return e['value']
    if t == 'AstExprConstantBool':
        return e['value']
    if t == 'AstExprUnary' and e.get('op') == 'Minus':
        v = _const_value(e['expr'])
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return -v
    return None


def _is_const(e):
    e = unwrap(e)
    return T(e) in ('AstExprConstantNumber', 'AstExprConstantString',
                    'AstExprConstantBool') or (
        T(e) == 'AstExprUnary' and e.get('op') == 'Minus'
        and _is_const(e['expr']))


class _Scan:
    def __init__(self, root):
        self.root = root
        self.aliases = set()      # var_key strings of locals = game
        self.fields_read = {}     # field -> [loc, ...]
        self.presence = set()     # canonical fields seen as strings only
        self.events = []
        self.gate_sites = []
        self.assign_targets = set()  # id() of IndexExpr Assign targets
        self.set_keys = {}        # var_key -> set of numeric keys

    # ---- pass 0: game aliases + assign targets -------------------
    def _pass0(self):
        def visit(n):
            if T(n) == 'AstStatLocal':
                for v, val in zip(n['vars'], n.get('values') or []):
                    if val is not None and T(unwrap(val)) == 'AstExprGlobal' \
                            and unwrap(val).get('global') == 'game':
                        self.aliases.add('L:%s@%s' % (v['name'],
                                                      v['location']))
            if T(n) == 'AstStatAssign':
                for v in n['vars']:
                    self.assign_targets.add(id(unwrap(v)))
        walk(self.root, visit)

    # ---- field read recognition ----------------------------------
    def _field_of(self, e):
        """Field name if e is a game.<Field> read, else None."""
        e = unwrap(e)
        t = T(e)
        if t == 'AstExprIndexName' and e.get('op') == '.':
            base = unwrap(e['expr'])
            if T(base) == 'AstExprGlobal' and base.get('global') == 'game':
                return e['index']
            if T(base) == 'AstExprLocal' and var_key(base) in self.aliases:
                return e['index']
            return None
        if t == 'AstExprIndexExpr':
            base = unwrap(e['expr'])
            idx = unwrap(e['index'])
            if T(idx) == 'AstExprConstantString':
                if T(base) == 'AstExprGlobal' and base.get('global') == 'game':
                    return idx['value']
                if T(base) == 'AstExprLocal' and var_key(base) in self.aliases:
                    return idx['value']
        return None

    def _note_read(self, field, loc):
        lst = self.fields_read.setdefault(field, [])
        if loc not in lst:
            lst.append(loc)

    # ---- pass 1: set keys ----------------------------------------
    def _collect_set_keys(self):
        def table_keys(table, var):
            for it in table.get('items') or []:
                k = it.get('key')
                if k is not None and is_cnum(unwrap(k)):
                    self.set_keys.setdefault(var, set()).add(cnum(unwrap(k)))

        def visit(n):
            if T(n) == 'AstStatLocal':
                for v, val in zip(n['vars'], n.get('values') or []):
                    if val is not None and T(unwrap(val)) == 'AstExprTable':
                        table_keys(unwrap(val),
                                   'L:%s@%s' % (v['name'], v['location']))
            if T(n) == 'AstStatAssign':
                for var, val in zip(n['vars'], n.get('values') or []):
                    var = unwrap(var)
                    if T(var) == 'AstExprIndexExpr' and is_cnum(var['index']):
                        base = unwrap(var['expr'])
                        if T(base) == 'AstExprLocal':
                            self.set_keys.setdefault(var_key(base), set()) \
                                .add(cnum(var['index']))
                    if val is not None and T(unwrap(val)) == 'AstExprTable' \
                            and T(var) == 'AstExprLocal':
                        table_keys(unwrap(val), var_key(var))
        walk(self.root, visit)

    # ---- pass 2: reads, comparisons, set-indexing ----------------
    def _pass2(self):
        def visit(n):
            t = T(n)
            if t == 'AstExprIndexName' or t == 'AstExprIndexExpr':
                f = self._field_of(n)
                if f is not None:
                    self._note_read(f, n.get('location', '?'))
            if t == 'AstExprConstantString' and n['value'] in IDENTITY_FIELDS:
                self.presence.add(n['value'])
            if t == 'AstExprBinary' and n.get('op') in BIN_OP:
                self._comparison(n)
            if t == 'AstExprIndexExpr' and id(n) not in self.assign_targets:
                self._set_index(n)
        walk(self.root, visit)

    def _comparison(self, n):
        op = BIN_OP[n['op']]
        left, right = unwrap(n['left']), unwrap(n['right'])
        field = None
        const = None
        flipped = False
        if self._field_of(left) is not None and _is_const(right):
            field, const = self._field_of(left), _const_value(right)
        elif self._field_of(right) is not None and _is_const(left):
            field, const = self._field_of(right), _const_value(left)
            flipped = True
        if field is None or const is None:
            return
        if flipped:
            op = FLIP[op]
        loc = n.get('location', '?')
        self.events.append({'field': field, 'op': op, 'value': const,
                            'proto': 'deflattened', 'pc': loc,
                            'pattern': 'game.%s %s %r' % (field, op, const)})
        self.gate_sites.append('game.%s %s %r @ %s' % (field, op, const, loc))

    def _set_index(self, n):
        idx = unwrap(n['index'])
        field = self._field_of(idx)
        if field is None:
            return
        base = unwrap(n['expr'])
        if T(base) != 'AstExprLocal':
            return  # global/unknown table: keys not statically known
        keys = self.set_keys.get(var_key(base))
        if not keys:
            return
        loc = n.get('location', '?')
        for k in sorted(keys):
            self.events.append({'field': field, 'op': 'in-set', 'value': k,
                                'proto': 'deflattened', 'pc': loc,
                                'pattern': 'set-membership: [%s][game.%s]'
                                           % (var_key(base), field)})
            self.gate_sites.append(
                'set-membership: game.%s in keys %s @ %s'
                % (field, sorted(keys), loc))

    def run(self):
        self._pass0()
        self._collect_set_keys()
        self._pass2()
        # Filter reads to identity fields: canonical fields (any
        # read) + non-canonical fields that were actually compared
        # or set-indexed (extension rule). Merely-read non-canonical
        # members (events, services accessed by field, ...) are not
        # identity fields and must not become unknown gates.
        event_fields = {e['field'] for e in self.events}
        fields_read = {}
        for f, locs in self.fields_read.items():
            if f in IDENTITY_FIELDS:
                fields_read[f] = list(locs)
        for e in self.events:
            if e['field'] not in fields_read:
                lst = fields_read.setdefault(e['field'], [])
                if e['pc'] not in lst:
                    lst.append(e['pc'])
        read_fields = set(fields_read)
        presence_only = sorted(self.presence - read_fields)
        extra = sorted(f for f in event_fields
                       if f not in IDENTITY_FIELDS)
        seen = sorted(read_fields | self.presence)
        return {
            'fields_seen': seen,
            'fields_read': {f: fields_read[f]
                            for f in sorted(fields_read)},
            'presence_only': presence_only,
            'extra_fields': extra,
            'events': self.events,
            'gate_sites': self.gate_sites,
        }


def scan(root):
    """Scan a deflattened AST root. See module docstring."""
    return _Scan(root).run()
