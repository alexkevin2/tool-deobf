#!/usr/bin/env python3
"""luast v1.0.1 — shared AST helpers, pool extraction, machine extraction.

AST dialect: luau-ast JSON (root = AstStatBlock). Node locations are
"line,col - line,col" (0-based). Locals are identified by
(name, declaration location) — the JSON encoder embeds the AstLocal
record at every reference, so the pair is a stable identity.
"""
import json, re, collections

# ---------------------------------------------------------------- AST utils

def unwrap(e):
    while isinstance(e, dict) and e.get('type') == 'AstExprGroup':
        e = e['expr']
    return e

def T(n):
    return n.get('type') if isinstance(n, dict) else None

def is_cnum(e):
    return T(unwrap(e)) == 'AstExprConstantNumber'

def cnum(e):
    return unwrap(e)['value']

def is_local(e):
    return T(unwrap(e)) == 'AstExprLocal'

def lkey_of_localnode(loc):
    return (loc['name'], loc['location'])

def lkey(e):
    return lkey_of_localnode(unwrap(e)['local'])

def var_key(e):
    """Stable identity string for an lvalue expression (local or index chain)."""
    e = unwrap(e)
    t = T(e)
    if t == 'AstExprLocal':
        return 'L:%s@%s' % lkey(e)
    if t == 'AstExprIndexExpr':
        return 'I:%s[%s]' % (var_key(e['expr']), expr_key(e['index']))
    if t == 'AstExprGlobal':
        return 'G:' + e['global']
    if t == 'AstExprIndexName':
        return 'N:%s.%s' % (var_key(e['expr']), e['index'])
    return '?:' + str(t)

def expr_key(e):
    e = unwrap(e)
    t = T(e)
    if t == 'AstExprConstantNumber':
        return repr(e['value'])
    if t == 'AstExprConstantString':
        return 'str:' + e['value']
    return var_key(e) if t in ('AstExprLocal', 'AstExprIndexExpr', 'AstExprGlobal', 'AstExprIndexName') else t

def else_kind(ifnode):
    """Classify an If's elsebody: ('if', node) for an elseif link (this
    luau-ast encoder puts the elseif If directly in elsebody), ('block',
    blocknode) for a plain else block, ('none', None)."""
    eb = ifnode.get('elsebody')
    if eb is None:
        return ('none', None)
    if T(eb) == 'AstStatIf':
        return ('if', eb)
    if T(eb) == 'AstStatBlock':
        if not eb.get('body'):
            return ('none', None)
        return ('block', eb)
    return ('none', None)

def else_stmts(ifnode):
    """Statement list of an If's else branch ([] if absent/empty)."""
    k, v = else_kind(ifnode)
    if k == 'if':
        return [v]
    if k == 'block':
        return v['body']
    return []

def then_stmts(ifnode):
    return ifnode['thenbody'].get('body') or []

def walk(node, fn):
    if isinstance(node, dict):
        fn(node)
        for v in node.values():
            walk(v, fn)
    elif isinstance(node, list):
        for v in node:
            walk(v, fn)

def build_parents(root):
    parent = {}
    def rec(n, p):
        if isinstance(n, dict):
            parent[id(n)] = p
            for v in n.values():
                rec(v, n)
        elif isinstance(n, list):
            for v in n:
                rec(v, p)
    rec(root, None)
    return parent

def parse_loc(loc):
    a, b = loc.split(' - ')
    l1, c1 = map(int, a.split(','))
    l2, c2 = map(int, b.split(','))
    return (l1, c1), (l2, c2)

class Source:
    def __init__(self, text):
        self.text = text
        self.lines = text.split('\n')
        self.starts = [0]
        for ln in self.lines:
            self.starts.append(self.starts[-1] + len(ln) + 1)
    def span(self, loc):
        (l1, c1), (l2, c2) = parse_loc(loc)
        return self.text[self.starts[l1] + c1: self.starts[l2] + c2]
    def offset(self, loc):
        (l1, c1), _ = parse_loc(loc)
        return self.starts[l1] + c1

# ---------------------------------------------------------------- pool

class Pool:
    """The akR[128] constants table. entries[i] = AST expr for pool[i+1].

    luast executes a one-time permutation of pool slots inside the main
    machine (descramble): afterwards slot n holds the literal entry
    perm[n]. self.perm maps slot -> literal entry index (identity for
    unpermuted slots). scalar(n) answers for the EFFECTIVE (post-
    permutation) pool by default — the pool as all feature code sees it.
    """
    def __init__(self, entries, akr_key):
        self.entries = entries          # 0-based list; pool index n -> entries[n-1]
        self.akr_key = akr_key          # var_key of the akR local
        self.perm = {}                  # slot -> literal entry index held after permutation
        self.perm_stmts = []            # the permutation Assign nodes, source order

    def __len__(self):
        return len(self.entries)

    def entry(self, n, effective=True):
        if effective:
            n = self.perm.get(n, n)
        if 1 <= n <= len(self.entries):
            return self.entries[n - 1]
        return None

    def scalar(self, n, effective=True):
        """Python value for scalar pool entries, else ('expr', node)."""
        e = self.entry(n, effective)
        if e is None:
            return ('missing', n)
        t = T(e)
        if t == 'AstExprConstantNumber':
            return ('number', e['value'])
        if t == 'AstExprConstantString':
            return ('string', e['value'])
        if t == 'AstExprConstantBool':
            return ('bool', e['value'])
        if t == 'AstExprConstantNil':
            return ('nil', None)
        return ('expr', e)

def apply_permutation(pool, root, aliases):
    """Find the pool-permutation statements (Assign nodes whose targets
    are ALL constant pool-index writes and whose values are ALL pool
    reads) and simulate them in source order over entry identities.
    Fills pool.perm / pool.perm_stmts. Returns number of permuted slots."""
    stmts = []
    def visit(n):
        if T(n) == 'AstStatAssign':
            vars_ = [unwrap(v) for v in n['vars']]
            vals = n.get('values') or []
            if vars_ and len(vars_) == len(vals) and all(
                    T(v) == 'AstExprIndexExpr' and is_cnum(v['index'])
                    and is_pool_ref(v['expr'], pool, aliases) for v in vars_) and all(
                    T(unwrap(x)) == 'AstExprIndexExpr' and is_cnum(unwrap(x)['index'])
                    and is_pool_ref(unwrap(x)['expr'], pool, aliases) for x in vals):
                stmts.append(n)
    walk(root, visit)
    stmts.sort(key=lambda n: parse_loc(n['location'])[0])
    cur = list(range(1, len(pool) + 1))
    for n in stmts:
        rhs = [cur[int(cnum(unwrap(x)['index'])) - 1] for x in n['values']]
        for v, newval in zip(n['vars'], rhs):
            cur[int(cnum(unwrap(v)['index'])) - 1] = newval
    pool.perm = {s: cur[s - 1] for s in range(1, len(pool) + 1) if cur[s - 1] != s}
    pool.perm_stmts = stmts
    return len(pool.perm)

def count_permutation_statements(pool, root, aliases):
    """Count pool-permutation statements WITHOUT mutating the pool:
    Assign nodes whose targets are ALL constant pool-index writes and
    whose values are ALL pool reads (the same shape
    apply_permutation() simulates). Used by detect() for the U3
    header-absent structural bar; the count itself is evidence, not
    a pipeline step."""
    n_stmt = 0
    def visit(n):
        nonlocal n_stmt
        if T(n) == 'AstStatAssign':
            vars_ = [unwrap(v) for v in n['vars']]
            vals = n.get('values') or []
            if vars_ and len(vars_) == len(vals) and all(
                    T(v) == 'AstExprIndexExpr' and is_cnum(v['index'])
                    and is_pool_ref(v['expr'], pool, aliases) for v in vars_) and all(
                    T(unwrap(x)) == 'AstExprIndexExpr' and is_cnum(unwrap(x)['index'])
                    and is_pool_ref(unwrap(x)['expr'], pool, aliases) for x in vals):
                n_stmt += 1
    walk(root, visit)
    return n_stmt

def find_pool(root):
    """Locate `akR` local and the akR[128] = { ... } assignment."""
    akr = None
    # the register table local: `local akR = {}` at chunk top; find any
    # local whose name is akR (header says generated by luast; name may vary
    # in other builds — fall back to: local assigned an empty table and later
    # indexed-assign [bigtable]).
    cands = []
    def visit(n):
        nonlocal akr
        if T(n) == 'AstStatLocal':
            for v, val in zip(n['vars'], n.get('values') or []):
                if T(unwrap(val)) == 'AstExprTable' and not unwrap(val).get('items'):
                    cands.append(lkey_of_localnode(v))
    walk(root, visit)
    pool_assign = None
    def visit2(n):
        nonlocal pool_assign
        if T(n) == 'AstStatAssign':
            for var, val in zip(n['vars'], n.get('values') or []):
                var = unwrap(var)
                if T(var) == 'AstExprIndexExpr' and is_cnum(var['index']):
                    idx = cnum(var['index'])
                    base = unwrap(var['expr'])
                    if T(unwrap(val)) == 'AstExprTable' and len(unwrap(val).get('items') or []) > 500:
                        pool_assign = (var_key(base) if is_local(base) else None, idx, unwrap(val))
    walk(root, visit2)
    assert pool_assign, 'pool table assignment not found'
    base_key, idx, table = pool_assign
    items = table['items']
    entries = []
    for it in items:
        # implicit-index items have key None
        entries.append(it['value'])
    return Pool(entries, base_key), idx

# ------------------------------------------------------- value resolution

def resolve_number(e, pool, aliases):
    """Resolve an expression to a number if statically possible.
    Returns (value, None) or (None, reason). aliases: set of local keys
    (var_key strings) known to alias the pool table in the current scope."""
    e = unwrap(e)
    t = T(e)
    if t == 'AstExprConstantNumber':
        return e['value'], None
    if t == 'AstExprIndexExpr':
        base = unwrap(e['expr'])
        idxe = unwrap(e['index'])
        if is_cnum(idxe):
            idx = int(cnum(idxe))
            if is_pool_ref(base, pool, aliases):
                kind, val = pool.scalar(idx)
                if kind == 'number':
                    return val, None
                return None, f'pool[{idx}] is {kind}, not a number'
            if var_key(base) == pool.akr_key:
                return None, 'akR slot ref (not a state constant)'
        return None, 'dynamic index expression'
    if t == 'AstExprUnary' and e['op'] == 'Minus':
        v, err = resolve_number(e['expr'], pool, aliases)
        return (-v, None) if err is None else (None, err)
    return None, f'unresolved expr type {t}'

def is_pool_ref(e, pool, aliases):
    """Is expression e exactly the pool table (akR[128] or an alias local)?"""
    e = unwrap(e)
    t = T(e)
    if t == 'AstExprLocal':
        return var_key(e) in aliases
    if t == 'AstExprIndexExpr':
        base = unwrap(e['expr'])
        if is_cnum(e['index']) and int(cnum(e['index'])) == 128 and var_key(base) == pool.akr_key:
            return True
    return False

def collect_aliases(root, pool):
    """All local var_keys whose (single) defining value is the pool table.
    Returns set of var_key strings. Conservative: local declared with the
    pool as its value (AstStatLocal) — reassignment disqualifies, checked
    by counting Assign targets."""
    assign_targets = collections.Counter()
    def cnt(n):
        if T(n) == 'AstStatAssign':
            for v in n['vars']:
                assign_targets[var_key(v)] += 1
    walk(root, cnt)
    aliases = set()
    def visit(n):
        if T(n) == 'AstStatLocal':
            for v, val in zip(n['vars'], n.get('values') or []):
                if val is not None and is_pool_ref(val, pool, aliases):
                    k = 'L:%s@%s' % (v['name'], v['location'])
                    if assign_targets.get(k, 0) == 0:
                        aliases.add(k)
    # two passes for alias-of-alias chains (rare)
    walk(root, visit)
    walk(root, visit)
    return aliases
