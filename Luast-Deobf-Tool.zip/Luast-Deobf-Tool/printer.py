# printer.py — AST -> Luau source printer for the luast deflattener.
#
# Prints the payload AST back to Luau with pool substitution at print
# time (through an effective, post-permutation pool): scalar pool reads
# become literals, global/index entries become their expressions,
# function-valued pool reads stay as live akR[128][n] references.
# Statements of flattened machines are never printed through here: the
# structurer replaces machine While nodes via the emit_machine hook.
import luast_lib as L
from luast_lib import T, unwrap, var_key, is_cnum, cnum

BINOP = {
    'Add': ('+', 5, 'L'), 'Sub': ('-', 5, 'L'), 'Mul': ('*', 6, 'L'),
    'Div': ('/', 6, 'L'), 'FloorDiv': ('//', 6, 'L'), 'Mod': ('%', 6, 'L'),
    'Pow': ('^', 8, 'R'), 'Concat': ('..', 4, 'R'),
    'CompareEq': ('==', 3, 'L'), 'CompareNe': ('~=', 3, 'L'),
    'CompareLt': ('<', 3, 'L'), 'CompareLe': ('<=', 3, 'L'),
    'CompareGt': ('>', 3, 'L'), 'CompareGe': ('>=', 3, 'L'),
    'And': ('and', 2, 'L'), 'Or': ('or', 1, 'L'),
}
UNOP = {'Not': 'not ', 'Minus': '-', 'Len': '#'}
COMPOUND = {'Add': '+=', 'Sub': '-=', 'Mul': '*=', 'Div': '/=', 'FloorDiv': '//=',
            'Mod': '%=', 'Pow': '^=', 'Concat': '..='}

def fmt_number(v):
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, int):
        return str(v)
    if v == int(v) and abs(v) < 1e15:
        return str(int(v))
    return repr(v)

def fmt_string(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif ch == '\t':
            out.append('\\t')
        elif 32 <= o < 127:
            out.append(ch)
        else:
            for b in ch.encode('utf-8'):
                out.append('\\%d' % b)
    return '"' + ''.join(out) + '"'

class Printer:
    def __init__(self, pool, aliases, src, emit_machine=None,
                 rename=None, drop_alias_locs=None, perm_node_ids=None):
        self.pool = pool
        self.aliases = aliases          # alias var_key -> pool index expr key info
        self.src = src
        self.emit_machine = emit_machine  # fn(while_node, ind) -> list[str] | None
        self.rename = rename or {}        # local var_key -> new name
        self.drop_alias_locs = drop_alias_locs or set()  # alias decl statement ids
        self.perm_node_ids = perm_node_ids or set()      # ids of permutation stmts: print verbatim
        self.expr_hook = None             # fn(node) -> str|None custom substitution
        self.ind = 0

    # ---------- helpers ----------
    def pad(self):
        return '    ' * self.ind

    def local_name(self, node):
        """Name for an AstLocal object."""
        key = 'L:%s@%s' % (node['name'], node['location'])
        return self.rename.get(key, node['name'])

    def expr_local_name(self, node):
        loc = node['local']
        key = 'L:%s@%s' % (loc['name'], loc['location'])
        return self.rename.get(key, loc['name'])

    # ---------- pool ----------
    def pool_ref(self, node):
        """If node (already unwrapped) is a pool read akR[128][n] / alias[n]
        with constant n, return n else None."""
        if T(node) != 'AstExprIndexExpr' or not is_cnum(node['index']):
            return None
        base = unwrap(node['expr'])
        if L.is_pool_ref(base, self.pool, self.aliases):
            return int(cnum(node['index']))
        return None

    def pool_substitute(self, n, ind_txt):
        """Replacement text for a pool read, or None to print the raw ref.
        Scalar (effective pool) -> literal; global/indexname expr -> its
        text; function/table expr -> keep the live reference."""
        kind, val = self.pool.scalar(n)  # effective pool
        if kind == 'number':
            return fmt_number(val)
        if kind == 'string':
            return fmt_string(val)
        if kind == 'bool':
            return 'true' if val else 'false'
        if kind == 'nil':
            return 'nil'
        if kind == 'expr':
            t = T(val)
            if t == 'AstExprGlobal':
                return val['global']
            if t == 'AstExprIndexName':
                base = self.expr(val['expr'])
                if T(unwrap(val['expr'])) in ('AstExprGlobal', 'AstExprLocal'):
                    return base + '.' + val['index']
                return '(' + base + ').' + val['index']
            if t == 'AstExprIndexExpr':
                base = self.expr(val['expr'])
                if T(unwrap(val['expr'])) in ('AstExprGlobal', 'AstExprLocal'):
                    return base + '[' + self.expr(val['index']) + ']'
                return '(' + base + ')[' + self.expr(val['index']) + ']'
            return None  # function / table / call-valued: keep live ref
        return None

    # ---------- expressions ----------
    def expr(self, node, ctx_prec=0):
        node = unwrap(node)
        if self.expr_hook is not None:
            r = self.expr_hook(node)
            if r is not None:
                return r
        t = T(node)
        if t == 'AstExprConstantNil':
            return 'nil'
        if t == 'AstExprConstantBool':
            return 'true' if node['value'] else 'false'
        if t == 'AstExprConstantNumber':
            return fmt_number(node['value'])
        if t == 'AstExprConstantString':
            return fmt_string(node['value'])
        if t == 'AstExprGlobal':
            return node['global']
        if t == 'AstExprLocal':
            return self.expr_local_name(node)
        if t == 'AstExprVarargs':
            return '...'
        if t == 'AstExprGroup':
            return '(' + self.expr(node['expr']) + ')'
        if t == 'AstExprIndexName':
            return self.primary(node['expr']) + '.' + node['index']
        if t == 'AstExprIndexExpr':
            n = self.pool_ref(node)
            if n is not None:
                sub = self.pool_substitute(n, None)
                if sub is not None:
                    return sub
            return self.primary(node['expr']) + '[' + self.expr(node['index']) + ']'
        if t == 'AstExprCall':
            return self.call(node)
        if t == 'AstExprFunction':
            return self.func_expr(node)
        if t == 'AstExprTable':
            return self.table(node)
        if t == 'AstExprIfElse':
            s = 'if ' + self.expr(node['condition']) + ' then ' + self.expr(node['trueExpr'])
            if node.get('falseExpr') is not None:
                s += ' else ' + self.expr(node['falseExpr'])
            return '(' + s + ')' if ctx_prec > 0 else s
        if t == 'AstExprUnary':
            op = UNOP[node['op']]
            inner = self.expr(node['expr'], 7)
            s = op + inner
            return '(' + s + ')' if ctx_prec > 7 else s
        if t == 'AstExprBinary':
            sym, prec, assoc = BINOP[node['op']]
            lp = prec if assoc == 'L' else prec + 1
            rp = prec + 1 if assoc == 'L' else prec
            # comparisons are non-associative: force parens on nested compares
            if prec == 3:
                lp = rp = 4
            s = self.expr(node['left'], lp) + ' ' + sym + ' ' + self.expr(node['right'], rp)
            return '(' + s + ')' if ctx_prec > prec else s
        if t == 'AstExprTypeAssertion':
            return self.expr(node['expr'])
        raise ValueError(f"unhandled expr type {t}")

    def primary(self, node):
        """Expression in postfix position (call/index base): parenthesize
        anything that is not a primary."""
        node = unwrap(node)
        n = self.pool_ref(node)
        if n is not None:
            sub = self.pool_substitute(n, None)
            if sub is not None:
                kind, val = self.pool.scalar(n)
                if kind == 'expr':
                    return sub          # global / index chain is a primary
                return '(' + sub + ')'  # literal needs parens as a base
        t = T(node)
        if t in ('AstExprLocal', 'AstExprGlobal', 'AstExprIndexExpr',
                 'AstExprIndexName', 'AstExprCall', 'AstExprVarargs'):
            return self.expr(node)
        if t == 'AstExprGroup':
            return self.expr(node)
        return '(' + self.expr(node) + ')'

    def call(self, node):
        args = ', '.join(self.expr(a) for a in node['args'])
        f = unwrap(node['func'])
        if node.get('self') and T(f) == 'AstExprIndexName':
            return self.primary(f['expr']) + ':' + f['index'] + '(' + args + ')'
        return self.primary(node['func']) + '(' + args + ')'

    def func_params(self, node):
        ps = [self.local_name(a) for a in node['args']]
        if node.get('vararg'):
            ps.append('...')
        return ', '.join(ps)

    def func_expr(self, node):
        head = 'function(' + self.func_params(node) + ')'
        body = node['body']['body']
        if not body:
            return head + ' end'
        self.ind += 1
        lines = self.stmts(body)
        self.ind -= 1
        return head + '\n' + '\n'.join(lines) + '\n' + self.pad() + 'end'

    def table(self, node):
        items = node['items']
        if not items:
            return '{}'
        parts = []
        simple = True
        for it in items:
            v = unwrap(it['value'])
            if it['kind'] == 'item':
                if T(v) not in ('AstExprConstantNumber', 'AstExprConstantString',
                                'AstExprConstantBool', 'AstExprConstantNil',
                                'AstExprLocal', 'AstExprGlobal'):
                    simple = False
                parts.append(self.expr(it['value']))
            elif it['kind'] == 'general':
                simple = False
                k = unwrap(it['key'])
                if T(k) == 'AstExprConstantString' and _is_ident(k['value']):
                    parts.append(k['value'] + ' = ' + self.expr(it['value']))
                else:
                    parts.append('[' + self.expr(it['key']) + '] = ' + self.expr(it['value']))
            else:
                raise ValueError(f"table item kind {it['kind']}")
        one = '{' + ', '.join(parts) + '}'
        if simple and len(one) <= 100 and '\n' not in one:
            return one
        pad2 = self.pad() + '    '
        return '{\n' + ',\n'.join(pad2 + p for p in parts) + '\n' + self.pad() + '}'

    # ---------- statements ----------
    def stmts(self, lst):
        out = []
        for s in lst:
            out.extend(self.stmt(s))
        return out

    def block_lines(self, blocknode):
        self.ind += 1
        lines = self.stmts(blocknode['body'])
        self.ind -= 1
        return lines

    def stmt(self, node):
        t = T(node)
        p = self.pad()
        if id(node) in self.drop_alias_locs and t in ('AstStatLocal', 'AstStatAssign'):
            return []
        if t == 'AstStatBlock':
            lines = [p + 'do']
            lines += self.block_lines(node)
            lines.append(p + 'end')
            return lines
        if t == 'AstStatExpr':
            # trailing ';' — a following statement may start with '('
            s = self.expr(node['expr'])
            if s.startswith('('):
                return [p + ';' + s + ';']
            return [p + s + ';']
        if t == 'AstStatLocal':
            names = ', '.join(self.local_name(v) for v in node['vars'])
            vals = node.get('values') or []
            if vals:
                return [p + 'local ' + names + ' = ' +
                        ', '.join(self.expr(v) for v in vals)]
            return [p + 'local ' + names]
        if t == 'AstStatAssign':
            lhs = ', '.join(self.lhs(v) for v in node['vars'])
            vals = node.get('values') or []
            verbatim = id(node) in self.perm_node_ids
            if verbatim:
                rhs = ', '.join(self.expr_verbatim(v) for v in vals)
            else:
                rhs = ', '.join(self.expr(v) for v in vals)
            return [p + lhs + ' = ' + rhs]
        if t == 'AstStatCompoundAssign':
            return [p + self.lhs(node['var']) + ' ' + COMPOUND[node['op']] + ' ' +
                    self.expr(node['value'])]
        if t == 'AstStatReturn':
            vals = node.get('list') or node.get('values') or []
            if vals:
                return [p + 'return ' + ', '.join(self.expr(v) for v in vals)]
            return [p + 'return']
        if t == 'AstStatBreak':
            return [p + 'break']
        if t == 'AstStatContinue':
            return [p + 'continue']
        if t == 'AstStatIf':
            return self.if_stmt(node)
        if t == 'AstStatWhile':
            if self.emit_machine is not None:
                r = self.emit_machine(node, self)
                if isinstance(r, list):
                    return r
                if isinstance(r, str) and r.startswith('KERNEL'):
                    return [p + '-- [luast] ' + r] + self.while_generic(node)
            return self.while_generic(node)
        if t == 'AstStatRepeat':
            lines = [p + 'repeat']
            lines += self.block_lines(node['body'])
            lines.append(p + 'until ' + self.expr(node['condition']))
            return lines
        if t == 'AstStatFor':
            lines = [p + 'for ' + self.local_name(node['var']) + ' = ' +
                     self.expr(node['from']) + ', ' + self.expr(node['to']) +
                     ((', ' + self.expr(node['step'])) if node.get('step') is not None else '') + ' do']
            lines += self.block_lines(node['body'])
            lines.append(p + 'end')
            return lines
        if t == 'AstStatForIn':
            names = ', '.join(self.local_name(v) for v in node['vars'])
            vals = ', '.join(self.expr(v) for v in node['values'])
            lines = [p + 'for ' + names + ' in ' + vals + ' do']
            lines += self.block_lines(node['body'])
            lines.append(p + 'end')
            return lines
        if t == 'AstStatLocalFunction':
            fn = node['func']
            head = p + 'local function ' + self.local_name(node['name']) + '(' + \
                self.func_params(fn) + ')'
            body = fn['body']['body']
            if not body:
                return [head + ' end']
            lines = [head]
            lines += self.block_lines(fn['body'])
            lines.append(p + 'end')
            return lines
        if t == 'AstStatFunction':
            raise ValueError('AstStatFunction not expected in luast output')
        raise ValueError(f"unhandled stmt type {t}")

    def while_generic(self, node):
        p = self.pad()
        cond = self.expr(unwrap(node['condition']))
        lines = [p + 'while ' + cond + ' do']
        lines += self.block_lines(node['body'])
        lines.append(p + 'end')
        return lines

    def lhs(self, node):
        node = unwrap(node)
        t = T(node)
        if t == 'AstExprLocal':
            return self.expr_local_name(node)
        if t == 'AstExprGlobal':
            return node['global']
        if t == 'AstExprIndexName':
            return self.primary(node['expr']) + '.' + node['index']
        if t == 'AstExprIndexExpr':
            # never pool-substitute an assignment target
            return self.primary(node['expr']) + '[' + self.expr(node['index']) + ']'
        raise ValueError(f"bad lhs type {t}")

    def expr_verbatim(self, node):
        """Print with pool substitution disabled (permutation statements
        must read the live pre-permutation pool)."""
        saved = self.expr_hook
        self.expr_hook = lambda n: None
        saved_pool = self.pool
        class NoSub:
            pass
        # temporarily neuter pool_ref by clearing aliases view
        old = self.aliases
        self.aliases = {}
        oldpool = self.pool
        class FakePool:
            akr_key = ('__none__', '')
        self.pool = FakePool()
        try:
            return self.expr(node)
        finally:
            self.expr_hook = saved
            self.aliases = old
            self.pool = oldpool

    def if_stmt(self, node):
        p = self.pad()
        lines = []
        cur = node
        first = True
        while True:
            kw = 'if' if first else 'elseif'
            lines.append(p + kw + ' ' + self.expr(cur['condition']) + ' then')
            self.ind += 1
            lines += self.stmts(cur['thenbody']['body'])
            self.ind -= 1
            eb = cur.get('elsebody')
            if eb is None:
                break
            if T(eb) == 'AstStatIf':
                cur = eb
                first = False
                continue
            lines.append(p + 'else')
            self.ind += 1
            lines += self.stmts(eb['body'])
            self.ind -= 1
            break
        lines.append(p + 'end')
        return lines

def _is_ident(s):
    if not s:
        return False
    if not (s[0].isalpha() or s[0] == '_'):
        return False
    return all(c.isalnum() or c == '_' for c in s)
