#!/usr/bin/env python3
"""luast v1.0.1 machine extraction: detect flattened state machines in the
AST, parse their dispatch trees, resolve transitions, build state graphs.

Output model per machine:
  flavor: 'A' (loop-head S = K - S) or 'B' (direct dispatch)
  K: transform constant (flavor A) else None
  states: {eff_value: leaf_id}  (leaf ids index into leaves)
  leaves: [{block, values:set, outcomes:[...], prefix:[stmts]}]
  outcomes: {guards:[(condAST, polarity)], extra:[stmts],
             kind:'goto'|'break'|'return'|'dynamic', value:eff number|None,
             raw: exprAST|None, note}
  entry: {leaf_id, values}
  residue: [{where, reason}]
"""
import sys, collections
sys.path.insert(0, '/home/hatch/luau-deobf/work/luast-deflattener/dev')
from luast_lib import *

CMP_OPS = {'CompareLt', 'CompareLe', 'CompareGt', 'CompareGe', 'CompareEq', 'CompareNe'}
FLIP = {'CompareLt': 'CompareGt', 'CompareGt': 'CompareLt',
        'CompareLe': 'CompareGe', 'CompareGe': 'CompareLe',
        'CompareEq': 'CompareEq', 'CompareNe': 'CompareNe'}

def cond_parts(cond, svar):
    """If cond is `S <cmp> num` or `num <cmp> S`, return (op, num) normalized
    to S on the left. Else None."""
    c = unwrap(cond)
    if T(c) != 'AstExprBinary' or c['op'] not in CMP_OPS:
        return None
    l, r = unwrap(c['left']), unwrap(c['right'])
    if var_key(l) == svar and is_cnum(r):
        return (c['op'], cnum(r))
    if var_key(r) == svar and is_cnum(l):
        return (FLIP[c['op']], cnum(l))
    return None

def eval_cond(op, num, v):
    if op == 'CompareLt': return v < num
    if op == 'CompareLe': return v <= num
    if op == 'CompareGt': return v > num
    if op == 'CompareGe': return v >= num
    if op == 'CompareEq': return v == num
    if op == 'CompareNe': return v != num
    raise ValueError(op)

class Spine:
    """Decision-tree view of a dispatch if-chain. Leaves are statement
    lists: {'stmts': [...], 'src': blocknode-or-ifnode-or-None}."""
    def __init__(self, root_if, svar):
        self.root = root_if
        self.svar = svar
        self.leaves = []           # list of {'stmts', 'src'}
        self.leaf_index = {}       # key -> leaf id
        self.bad = None            # reason if tree unparsable
        self.tree = self._parse_if(root_if)

    def _leaf(self, stmts, src):
        return ('leaf', {'stmts': stmts, 'src': src})

    def _descend(self, block):
        """block -> ('if', ...) tree node | ('leaf', {...})"""
        if block is None:
            return self._leaf([], None)
        body = block['body']
        if len(body) == 1 and T(body[0]) == 'AstStatIf' and cond_parts(body[0]['condition'], self.svar):
            return self._parse_if(body[0])
        if len(body) == 1 and T(body[0]) == 'AstStatBlock':
            return self._descend(body[0])
        return self._leaf(body, block)

    def _parse_if(self, ifnode):
        cp = cond_parts(ifnode['condition'], self.svar)
        if cp is None:
            self.bad = f"spine condition not S-vs-const at {ifnode['location']}"
            return self._leaf([], None)
        then_p = self._descend(ifnode['thenbody'])
        ek, ev = else_kind(ifnode)
        if ek == 'if':
            if cond_parts(ev['condition'], self.svar):
                else_p = self._parse_if(ev)
            else:
                else_p = self._leaf([ev], ev)
        elif ek == 'block':
            else_p = self._descend(ev)
        else:
            else_p = self._leaf([], None)
        return ('if', cp[0], cp[1], then_p, else_p)

    def leaf_for(self, v):
        node = self.tree
        while node[0] == 'if':
            _, op, num, tp, ep = node
            node = tp if eval_cond(op, num, v) else ep
        leaf = node[1]
        src = leaf['src']
        key = ('n',) if src is None else ('s', id(src))
        if key not in self.leaf_index:
            self.leaf_index[key] = len(self.leaves)
            self.leaves.append(leaf)
        return self.leaf_index[key]

# ---------------------------------------------------------- transitions

def stmts_write_state(stmts, svar, cross_loops=False):
    """Any assignment to the state var inside stmts (not crossing function
    boundaries; crosses Ifs and, if cross_loops, loops)."""
    found = []
    def rec(n, in_func):
        if isinstance(n, dict):
            t = T(n)
            if t == 'AstExprFunction':
                return
            if t == 'AstStatAssign':
                for v in n['vars']:
                    if var_key(v) == svar:
                        found.append(n)
            if t == 'AstStatCompoundAssign' and var_key(n['var']) == svar:
                found.append(n)
            if not cross_loops and t in ('AstStatWhile', 'AstStatFor', 'AstStatForIn', 'AstStatRepeat'):
                # still scan condition-side exprs? writes can't hide in exprs
                return
            for val in n.values():
                rec(val, in_func)
        elif isinstance(n, list):
            for v in n:
                rec(v, in_func)
    rec(stmts, False)
    return found

def contains_terminator(stmts):
    for s in stmts:
        if T(s) in ('AstStatBreak', 'AstStatReturn', 'AstStatContinue'):
            return True
        if T(s) == 'AstStatIf':
            if contains_terminator(then_stmts(s)):
                return True
            if contains_terminator(else_stmts(s)):
                return True
    return False

def if_is_control(ifnode, svar):
    """An If is a control statement if any branch writes state or terminates."""
    for stmts in (then_stmts(ifnode), else_stmts(ifnode)):
        if stmts and (stmts_write_state(stmts, svar) or contains_terminator(stmts)):
            return True
    return False

def value_outcomes(expr, pool, aliases, flavor, K):
    """Expand a state-value expression into [(guardchain, eff_value, rawexpr)]
    or [(guardchain, None, rawexpr)] with kind dynamic if unresolvable.
    guardchain: list of (condAST, polarity)."""
    e = unwrap(expr)
    t = T(e)
    if t == 'AstExprIfElse':
        out = []
        for g, sub in ((True, e['trueExpr']), (False, e['falseExpr'])):
            if sub is None:
                continue
            for gc, val, raw in value_outcomes(sub, pool, aliases, flavor, K):
                out.append(([(e['condition'], g)] + gc, val, raw))
        return out
    v, err = resolve_number(e, pool, aliases)
    if err is None:
        eff = (K - v) if flavor == 'A' else v
        return [([], eff, e)]
    return [([], None, e)]

def _path(guards=None, stmts=None, end=('fall', None), raw=None, note=''):
    return {'guards': guards or [], 'stmts': stmts or [], 'end': end,
            'raw': raw, 'note': note}

def _compose(paths_a, paths_b):
    """Sequential composition of two path sets."""
    out = []
    for a in paths_a:
        if a['end'][0] in ('break', 'return'):
            out.append(a)
            continue
        for b in paths_b:
            end = b['end'] if b['end'][0] != 'fall' else a['end']
            out.append({'guards': a['guards'] + b['guards'],
                        'stmts': a['stmts'] + b['stmts'],
                        'end': end, 'raw': b['raw'] or a['raw'],
                        'note': (a['note'] + ' ' + b['note']).strip()})
    return out

def analyze_stmts(stmts, svar, pool, aliases, flavor, K, ctx):
    """Analyze a block's statement list into execution PATHS.
    Returns (paths, ctx). Each path: {guards:[(condAST,polarity)],
    stmts:[statements to emit, state writes removed], end:(kind,value)
    with kind in 'goto'|'break'|'return'|'fall'|'dynamic'}."""
    paths = [_path()]
    i = 0
    n = len(stmts)
    while i < n:
        s = stmts[i]
        t = T(s)
        seg = None
        if t == 'AstStatAssign' and any(var_key(v) == svar for v in s['vars']):
            if len(s['vars']) != 1:
                ctx.append(f'multi-target state assign at {s["location"]}')
                seg = [_path(end=('dynamic', None), raw=s, note='multi-target assign')]
            else:
                seg = []
                for gc, val, raw in value_outcomes(s['values'][0], pool, aliases, flavor, K):
                    if val is not None:
                        seg.append(_path(guards=gc, end=('goto', val), raw=raw))
                    else:
                        seg.append(_path(guards=gc, end=('dynamic', None), raw=raw,
                                         note='unresolved transition value'))
        elif t == 'AstStatBreak':
            seg = [_path(end=('break', None))]
            paths = _compose(paths, seg)
            if i + 1 < n:
                ctx.append(f'unreachable statements after break at {s["location"]}')
            return paths, ctx
        elif t == 'AstStatReturn':
            seg = [_path(end=('return', None), raw=s)]
            paths = _compose(paths, seg)
            if i + 1 < n:
                ctx.append(f'unreachable statements after return at {s["location"]}')
            return paths, ctx
        elif t == 'AstStatContinue':
            seg = [_path(end=('fall', None), note='continue')]
        elif t == 'AstStatCompoundAssign' and var_key(s['var']) == svar:
            seg = [_path(end=('dynamic', None), raw=s, note='compound state assign')]
        elif t == 'AstStatIf' and if_is_control(s, svar):
            seg = []
            tpaths, ctx = analyze_stmts(then_stmts(s), svar, pool, aliases, flavor, K, ctx)
            for o in tpaths:
                o = dict(o)
                o['guards'] = [(s['condition'], True)] + o['guards']
                seg.append(o)
            if else_stmts(s):
                epaths, ctx = analyze_stmts(else_stmts(s), svar, pool, aliases, flavor, K, ctx)
                for o in epaths:
                    o = dict(o)
                    o['guards'] = [(s['condition'], False)] + o['guards']
                    seg.append(o)
            else:
                seg.append(_path(guards=[(s['condition'], False)], note='if-no-else'))
        else:
            seg = [_path(stmts=[s])]
        paths = _compose(paths, seg)
        i += 1
    return paths, ctx

# ---------------------------------------------------------- machine find

def detect_machine(wnode):
    """Return dict(flavor, K, svar, spine_root) or None if not a machine."""
    body = wnode['body']['body']
    if not body:
        return None
    s0 = body[0]
    # Flavor A: S = K - S then dispatch
    if T(s0) == 'AstStatAssign' and len(s0.get('vars', [])) == 1 and s0.get('values'):
        v = unwrap(s0['values'][0])
        var = unwrap(s0['vars'][0])
        if (T(v) == 'AstExprBinary' and v.get('op') == 'Sub'
                and is_cnum(v['left']) and var_key(v['right']) == var_key(var)):
            svar = var_key(var)
            rest = body[1:]
            root_if = find_dispatch(rest, svar)
            if root_if is not None:
                return {'flavor': 'A', 'K': cnum(v['left']), 'svar': svar,
                        'state_node': var, 'root_if': root_if}
    # Flavor B: body is a single If (possibly in a Block) dispatching on a local
    root_if = None
    if len(body) == 1:
        cand = body[0]
        if T(cand) == 'AstStatIf':
            root_if = cand
        elif T(cand) == 'AstStatBlock' and len(cand['body']) == 1 and T(cand['body'][0]) == 'AstStatIf':
            root_if = cand['body'][0]
    if root_if is not None:
        c = unwrap(root_if['condition'])
        if T(c) == 'AstExprBinary' and c['op'] in CMP_OPS:
            for side, other in ((c['left'], c['right']), (c['right'], c['left'])):
                if is_cnum(other) and T(unwrap(side)) in ('AstExprLocal', 'AstExprIndexExpr'):
                    svar = var_key(side)
                    # U4: flavor B must be a binary-search comparison
                    # TREE on the same state var, not a single
                    # comparison If. The tree is the Spine parse of
                    # the dispatch chain; every tree node is on
                    # `svar` by construction (Spine.bad otherwise).
                    # Threshold is >= 2 tree nodes, NOT >= 3: the
                    # reference payload contains 19 genuine 3-state
                    # machines whose dispatch tree has exactly 2
                    # nodes (e.g. `if S < 1 ... elseif S < 2 ... else
                    # ... end`); a literal >= 3 bar would drop them
                    # and change the golden deflattened output.
                    # A single-comparison If (1 node) still does not
                    # count as a machine.
                    spine = Spine(root_if, svar)
                    if spine.bad is not None:
                        return None
                    def _tree_nodes(node):
                        if node[0] == 'if':
                            return 1 + _tree_nodes(node[3]) + _tree_nodes(node[4])
                        return 0
                    if _tree_nodes(spine.tree) < 2:
                        return None
                    return {'flavor': 'B', 'K': None, 'svar': svar,
                            'state_node': unwrap(side), 'root_if': root_if}
    return None

def find_dispatch(stmts, svar):
    for s in stmts:
        if T(s) == 'AstStatIf' and cond_parts(s['condition'], svar):
            return s
        if T(s) == 'AstStatBlock':
            r = find_dispatch(s['body'], svar)
            if r is not None:
                return r
    return None

def find_init(wnode, svar, parent):
    """Find the last write to the state var before the while, in the
    enclosing block's statement list. Returns value expr or None."""
    r = find_init_stmt(wnode, svar, parent)
    return r[1] if r else None

def find_init_stmt(wnode, svar, parent):
    """Like find_init but returns (statement_node, value_expr)."""
    blk = parent.get(id(wnode))
    if blk is None or T(blk) != 'AstStatBlock':
        return None
    stmts = blk['body']
    idx = next((i for i, s in enumerate(stmts) if s is wnode), None)
    if idx is None:
        return None
    for s in reversed(stmts[:idx]):
        if T(s) == 'AstStatAssign':
            for var, val in zip(s['vars'], s.get('values') or []):
                if var_key(var) == svar:
                    return (s, val)
        if T(s) == 'AstStatLocal':
            for var, val in zip(s['vars'], s.get('values') or []):
                if val is not None and ('L:%s@%s' % (var['name'], var['location'])) == svar:
                    return (s, val)
    return None

def extract_all(root, pool, aliases, parent):
    machines = []
    whiles = []
    walk(root, lambda n: whiles.append(n) if T(n) == 'AstStatWhile'
         and T(n['condition']) == 'AstExprConstantBool'
         and n['condition'].get('value') is True else None)
    for w in whiles:
        det = detect_machine(w)
        if det is None:
            machines.append({'while': w, 'machine': False})
            continue
        m = {'while': w, 'machine': True, **det}
        svar, flavor, K = det['svar'], det['flavor'], det['K']
        spine = Spine(det['root_if'], svar)
        m['spine'] = spine
        m['residue'] = []
        if spine.bad:
            m['residue'].append({'where': 'spine', 'reason': spine.bad})
        # init
        init_expr = find_init(w, svar, parent)
        m['init_expr'] = init_expr
        cand = set()
        entry_vals = []
        if init_expr is not None:
            for gc, val, raw in value_outcomes(init_expr, pool, aliases, flavor, K):
                if val is not None:
                    cand.add(val)
                    entry_vals.append(val)
                else:
                    m['residue'].append({'where': 'init', 'reason': 'init value unresolved'})
        else:
            m['residue'].append({'where': 'init', 'reason': 'no init write found before loop'})
        # candidate values from all state writes anywhere in the loop body
        writes = stmts_write_state(w['body']['body'], svar, cross_loops=True)
        m['n_state_writes'] = len(writes)
        for a in writes:
            if T(a) != 'AstStatAssign':
                continue
            for var, val in zip(a['vars'], a.get('values') or []):
                if var_key(var) == svar:
                    for gc, v2, raw in value_outcomes(val, pool, aliases, flavor, K):
                        if v2 is not None:
                            cand.add(v2)
        m['candidates'] = cand
        # evaluate candidates -> leaves
        leaf_states = collections.defaultdict(set)
        for v in sorted(cand):
            lid = spine.leaf_for(v)
            leaf_states[lid].add(v)
        m['leaf_states'] = dict(leaf_states)
        # entries
        m['entry_leaves'] = sorted({l for l in leaf_states
                                     if leaf_states[l] & set(entry_vals)})
        m['entry_leaf'] = m['entry_leaves'][0] if len(m['entry_leaves']) == 1 else None
        m['entry_values'] = entry_vals
        # analyze each landed leaf
        m['leaf_info'] = {}
        for lid, leaf in enumerate(spine.leaves):
            if lid not in leaf_states:
                continue
            if leaf['src'] is None and not leaf['stmts']:
                m['leaf_info'][lid] = {'paths': [
                    {'guards': [], 'stmts': [], 'end': ('goto_leaf', lid), 'target_leaf': lid,
                     'raw': None, 'note': 'empty leaf fall=self'}]}
                continue
            ctx = []
            paths, ctx = analyze_stmts(leaf['stmts'], svar, pool, aliases, flavor, K, ctx)
            for p in paths:
                kind, val = p['end']
                if kind == 'goto':
                    p['target_leaf'] = spine.leaf_for(val)
                    p['end'] = ('goto_leaf', p['target_leaf'])
                elif kind == 'fall':
                    # no state write: S keeps the dispatch value, so the
                    # next dispatch lands on this same leaf in both flavors
                    p['target_leaf'] = lid
                    p['end'] = ('goto_leaf', lid)
                    p['note'] = (p['note'] + ' fall=self').strip()
                elif kind == 'dynamic':
                    m['residue'].append({'where': f'leaf {lid}', 'reason': 'dynamic transition: ' + p['note']})
            m['leaf_info'][lid] = {'paths': paths}
            for note in ctx:
                m['residue'].append({'where': f'leaf {lid}', 'reason': note})
        machines.append(m)
    return machines
