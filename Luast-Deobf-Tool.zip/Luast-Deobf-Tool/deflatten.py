# deflatten.py — structure an extracted luast state machine back into
# structured Luau (sequences, if/else, while loops), or fall back to a
# flagged kernel (the original dispatch loop) when a region provably
# resists structuring. Never invents a transition: every emitted branch
# is an extracted path; every extracted block is emitted exactly once
# (accounted in self.emitted).
import collections
from luast_lib import T, unwrap

EXIT = ('__exit__',)
RETURNED = ('__returned__',)
BROKE = ('__broke__',)        # body ended by exiting the machine from inside a loop whose continuation is EXIT
RESTARTED = ('__restarted__',)

class Kernel(Exception):
    def __init__(self, reason):
        self.reason = reason

def guards_text(pr, guards):
    parts = []
    for cond, pol in guards:
        s = pr.expr(cond)
        if T(unwrap(cond)) == 'AstExprBinary':
            s = '(' + s + ')'
        if not pol:
            s = 'not ' + (s if s.startswith('(') else '(' + s + ')')
        parts.append(s)
    return ' and '.join(parts)

class MachineStructurer:
    def __init__(self, machine, pr):
        self.m = machine
        self.pr = pr
        self.leaves = machine['leaf_info']          # id -> {paths}
        self.nodes = list(self.leaves.keys())
        self.entry_leaf = machine['entry_leaf']
        # edges
        self.succ = collections.defaultdict(set)
        self.pred = collections.defaultdict(set)
        self.has_exit = set()      # nodes with a break/exit path
        self.pure_exit = set()     # nodes whose every path ends exit/return-less... (all paths end 'exit')
        for u, info in self.leaves.items():
            all_exit = True
            for p in info['paths']:
                e = p['end']
                if e[0] == 'goto_leaf':
                    self.succ[u].add(e[1]); self.pred[e[1]].add(u)
                    all_exit = False
                elif e[0] == 'break':
                    self.has_exit.add(u)
                else:
                    all_exit = False
            if all_exit and len(info['paths']) == 1:
                self.pure_exit.add(u)
        self.emitted = collections.Counter()
        self.duplicated_epilogues = {}
        self.hoisted_prefix = {}
        self.loop_stack = []
        self.loop_exits = []
        self._steps = 0
        self._analyze()
        # reachability from entry (landed leaves may be dead dispatch ranges)
        self.reachable = set()
        stack = [self.entry_leaf]
        while stack:
            x = stack.pop()
            if x in self.reachable or x not in self.leaves:
                continue
            self.reachable.add(x)
            stack.extend(self.succ.get(x, ()))
        # trampolines: blocks with no statements at all (pure control
        # transfers). Re-emitting them in converging branches emits at
        # most a break/return line and is semantically free.
        self.trampolines = set()
        for u in self.reachable:
            info = self.leaves[u]
            if info['paths'] and all(not p['stmts'] for p in info['paths']):
                self.trampolines.add(u)
        # epilogue blocks: small blocks whose every path terminates the
        # machine (break/return, possibly via a short chain). Converging
        # branches may each emit a copy — bounded and flagged, since the
        # block executes exactly once per execution path either way.
        self.epilogues = set()
        for u in self.reachable:
            info = self.leaves[u]
            if sum(len(p['stmts']) for p in info['paths']) <= 3 and \
               all(not p['guards'] for p in info['paths']) and \
               self._is_terminal(u):
                self.epilogues.add(u)

    # ---------- graph analysis ----------
    @staticmethod
    def _bitdom(start, preds, n):
        """Iterative dominators with bitsets. preds: list of pred-index
        lists. Returns dom as list of int bitmasks."""
        ALL = (1 << n) - 1
        dom = [ALL] * n
        dom[start] = 1 << start
        changed = True
        while changed:
            changed = False
            for i in range(n):
                if i == start:
                    continue
                ps = preds[i]
                if not ps:
                    new = 1 << i
                else:
                    new = ALL
                    for p in ps:
                        new &= dom[p]
                    new |= 1 << i
                if new != dom[i]:
                    dom[i] = new; changed = True
        return dom

    @staticmethod
    def _bits_to_sets(dom, idx2node):
        out = {}
        for i, mask in enumerate(dom):
            s = set()
            m = mask
            while m:
                b = m & -m
                s.add(idx2node[b.bit_length() - 1])
                m ^= b
            out[idx2node[i]] = s
        return out

    def _analyze(self):
        nodes = self.nodes
        idx = {u: i for i, u in enumerate(nodes)}
        n = len(nodes)
        preds = [[] for _ in range(n)]
        for u in nodes:
            for p in self.pred.get(u, ()):
                if p in idx:
                    preds[idx[u]].append(idx[p])
        dom = self._bitdom(idx[self.entry_leaf], preds, n)
        self.dom = self._bits_to_sets(dom, nodes)
        self.idom = {}
        for i, u in enumerate(nodes):
            if u == self.entry_leaf:
                self.idom[u] = None
                continue
            strict = dom[i] & ~(1 << i)
            # deepest strict dominator = largest dom bit count
            best, bestc = None, -1
            m = strict
            while m:
                b = m & -m
                j = b.bit_length() - 1
                c = dom[j].bit_count()
                if c > bestc:
                    best, bestc = nodes[j], c
                m ^= b
            self.idom[u] = best
        # post-dominators: graph + virtual EXIT as extra node index n
        exit_i = n
        rpreds = [[] for _ in range(n + 1)]   # preds in the REVERSED graph
        for u in nodes:
            i = idx[u]
            for v in self.succ[u]:
                rpreds[idx[v]].append(i)
            for p in self.leaves[u]['paths']:
                if p['end'][0] in ('break', 'return'):
                    rpreds[exit_i].append(i)
                    break
        # reversed graph's "preds" for node x = successors of x in G'
        gp_succ = [[] for _ in range(n + 1)]
        for x in range(n + 1):
            for pre in rpreds[x]:
                gp_succ[pre].append(x)
        pdom_b = self._bitdom(exit_i, gp_succ, n + 1)
        idx2node = nodes + [EXIT]
        self.pdom = self._bits_to_sets(pdom_b, idx2node)
        self.ipdom = {}
        for i, u in enumerate(nodes):
            strict = pdom_b[i] & ~(1 << i)
            best, bestc = None, -1
            m = strict
            while m:
                b = m & -m
                j = b.bit_length() - 1
                c = pdom_b[j].bit_count()
                if c > bestc:
                    best, bestc = idx2node[j], c
                m ^= b
            self.ipdom[u] = best
        # natural loops
        self.loops = {}   # header -> set(nodes)
        self.back_edges = []
        for u in nodes:
            for v in self.succ[u]:
                if v in self.dom[u]:   # v dominates u -> back edge
                    self.back_edges.append((u, v))
                    loop = {v, u}
                    stack = [u]
                    while stack:
                        x = stack.pop()
                        for p in self.pred.get(x, ()):
                            if p not in loop and p != v:
                                loop.add(p); stack.append(p)
                    self.loops.setdefault(v, set()).update(loop)
        # laminarity check
        hs = list(self.loops)
        self.irreducible = None
        for i in range(len(hs)):
            for j in range(i + 1, len(hs)):
                a, b = self.loops[hs[i]], self.loops[hs[j]]
                if a & b and not (a <= b or b <= a):
                    self.irreducible = (hs[i], hs[j])
        # innermost loop per node
        self.node_loop = {}
        for n in nodes:
            containing = [h for h in hs if n in self.loops[h]]
            if containing:
                self.node_loop[n] = min(containing, key=lambda h: len(self.loops[h]))

    # ---------- emission ----------
    def run(self):
        if self.irreducible:
            raise Kernel(f'irreducible: overlapping loops at {self.irreducible}')
        lines, reached = self.seq(self.entry_leaf, {EXIT})
        if reached not in (EXIT, RETURNED):
            raise Kernel(f'top-level seq ended at {reached!r}')
        missing = [u for u in self.reachable
                   if self.emitted[u] == 0 and u not in self.trampolines]
        if missing:
            raise Kernel(f'{len(missing)} blocks never emitted (e.g. {missing[:3]})')
        tmiss = [u for u in self.reachable
                 if self.emitted[u] == 0 and u in self.trampolines]
        if tmiss:
            raise Kernel(f'{len(tmiss)} trampoline blocks never emitted (e.g. {tmiss[:3]})')
        dup = [u for u, c in self.emitted.items()
               if c > 1 and u not in self.trampolines and u not in self.epilogues]
        if dup:
            raise Kernel(f'{len(dup)} blocks emitted more than once (e.g. {dup[:3]})')
        tdup = [u for u, c in self.emitted.items()
                if c > 8 and u in self.trampolines]
        if tdup:
            raise Kernel(f'trampoline blocks emitted >8 times (e.g. {tdup[:3]})')
        edup = {u: c for u, c in self.emitted.items()
                if c > 1 and u in self.epilogues}
        if any(c > 4 for c in edup.values()) or len(edup) > 4:
            raise Kernel(f'epilogue duplication out of bounds {edup}')
        self.duplicated_epilogues = edup
        return lines

    def print_stmts(self, stmts):
        return self.pr.stmts(stmts)

    def seq(self, start, stops):
        """Emit from `start` until a stop node / EXIT / RETURNED.
        Returns (lines, reached)."""
        lines = []
        node = start
        first = True
        while True:
            self._steps += 1
            if self._steps > 40 * max(1, len(self.nodes)) + 1000:
                raise Kernel('emission runaway (probable trampoline cycle)')
            if node == EXIT:
                return lines, EXIT
            if node == RETURNED:
                return lines, RETURNED
            if not first and node in stops:
                return lines, node
            first = False
            if node in self.loops and node not in stops:
                lns, cont = self.emit_loop(node, stops)
                lines += lns
                if cont in (EXIT, RETURNED):
                    return lines, cont
                node = cont
                continue
            info = self.leaves[node]
            self.emitted[node] += 1
            if node in self.pure_exit:
                lines += self.print_stmts_all(info)
                if self.loop_stack:
                    lines.append(self.pr.pad() + 'break')
                    return lines, BROKE
                return lines, EXIT
            paths = info['paths']
            if len(paths) == 1 and not paths[0]['guards']:
                p = paths[0]
                lines += self.print_stmts(p['stmts'])
                e = p['end']
                if e[0] == 'goto_leaf':
                    node = e[1]; continue
                if e[0] == 'break':
                    if self.loop_stack:
                        lines.append(self.pr.pad() + 'break')
                        return lines, BROKE
                    return lines, EXIT
                if e[0] == 'return':
                    lines += self.return_lines(p, node)
                    return lines, RETURNED
                raise Kernel(f'node {node}: unknown path end {e[0]!r}')
            # conditional node
            clns, outcome = self.emit_conditional(node, stops)
            lines += clns
            if isinstance(outcome, tuple) and outcome[0] == 'join':
                node = outcome[1]; continue
            return lines, outcome

    def print_stmts_all(self, info):
        out = []
        for p in info['paths']:
            out += self.print_stmts(p['stmts'])
        return out

    def return_lines(self, p, node):
        raw = p.get('raw')
        vals = ((raw.get('list') or raw.get('values') or [])
                if raw is not None else [])
        if not vals:
            return [self.pr.pad() + 'return']
        return [self.pr.pad() + 'return ' + ', '.join(self.pr.expr(v) for v in vals)]

    def emit_conditional(self, node, stops):
        """Try join candidates in order; a candidate is accepted only
        when every branch verifies against it."""
        last = None
        for join in self.join_candidates(node):
            snap_e = collections.Counter(self.emitted)
            snap_s = self._steps
            try:
                return self._emit_conditional_join(node, join, stops)
            except Kernel as k:
                self.emitted = snap_e
                self._steps = snap_s
                last = k
        raise last if last is not None else Kernel(f'node {node}: no join candidates')

    def _emit_conditional_join(self, node, join, stops):
        """Emit the node's decision list as if/elseif/else whose branches
        converge at `join` (or terminate the region). Returns
        (lines, outcome) with outcome 'join' or a terminal sentinel."""
        pr = self.pr
        paths = self.leaves[node]['paths']
        p = pr.pad()
        # hoist the statement prefix shared by every path (same stmt
        # objects, from path composition) out of the conditional
        prefix = []
        if len(paths) > 1:
            first = paths[0]['stmts']
            k = 0
            while k < len(first) and all(
                    k < len(pth['stmts']) and pth['stmts'][k] is first[k]
                    for pth in paths[1:]):
                k += 1
            if k:
                prefix = self.print_stmts(first[:k])
                self.hoisted_prefix[node] = k
                paths = [dict(pth, stmts=pth['stmts'][k:]) for pth in paths]
        pr.ind += 1
        try:
            branches = []   # (guard_text or None for else, lines, outcome)
            any_join = False
            for pth in paths:
                g = guards_text(pr, pth['guards']) if pth['guards'] else None
                blines = self.print_stmts(pth['stmts'])
                e = pth['end']
                if e[0] == 'goto_leaf':
                    v = e[1]
                    if v == join:
                        branches.append((g, blines, 'join')); any_join = True
                    else:
                        sub, reached = self.seq(v, stops | {join})
                        if reached == join:
                            branches.append((g, blines + sub, 'join')); any_join = True
                        elif reached == EXIT and join == EXIT:
                            branches.append((g, blines + sub, 'join')); any_join = True
                        elif reached == RETURNED:
                            branches.append((g, blines + sub, 'returned'))
                        elif reached == BROKE:
                            branches.append((g, blines + sub, 'broke'))
                        elif self.loop_stack and reached == self.loop_stack[-1]:
                            # branch restarts the innermost emitted loop
                            branches.append((g, blines + sub + [p + '    continue'], 'join'))
                            any_join = True
                        elif self.loop_stack and reached == self.loop_exits[-1]:
                            # branch leaves the innermost emitted loop
                            branches.append((g, blines + sub + [p + '    break'], 'join'))
                            any_join = True
                        elif reached in stops:
                            # branch leaves this region to an ancestor stop;
                            # sound only if no branch continues at the join
                            branches.append((g, blines + sub, ('region', reached)))
                        else:
                            raise Kernel(f'node {node}: branch to {v} reached {reached!r}, join is {join!r}')
                elif e[0] == 'break':
                    if self.loop_stack:
                        branches.append((g, blines + [p + '    break'], 'broke'))
                    else:
                        branches.append((g, blines, 'exit'))
                else:  # return
                    branches.append((g, blines + self.return_lines(pth, node), 'returned'))
            # prune empty join branches whose guards carry no literals/pool
            # reads (dropping them must not drop a single constant)
            def guard_free(pth):
                def has_lit(e):
                    if isinstance(e, dict):
                        if T(e) in ('AstExprConstantString', 'AstExprConstantNumber'):
                            return True
                        if self.pr.pool_ref(e) is not None:
                            return True
                        return any(has_lit(v) for v in e.values())
                    if isinstance(e, list):
                        return any(has_lit(v) for v in e)
                    return False
                return not any(has_lit(c) for c, _ in pth['guards'])
            branches = [b for b, pth in zip(branches, paths)
                        if not (b[2] == 'join' and not b[1] and guard_free(pth))]
            outcomes = {b[2] for b in branches}
            regions = {b[2][1] for b in branches
                       if isinstance(b[2], tuple) and b[2][0] == 'region'}
            if any_join:
                bad = {o for o in outcomes
                       if o not in ('join', 'returned', 'broke', 'exit')
                       and not (isinstance(o, tuple) and o[0] == 'region')}
                if bad:
                    raise Kernel(f'node {node}: mixed branch outcomes {outcomes}')
                if regions:
                    raise Kernel(f'node {node}: join and region outcomes mixed')
                if 'broke' in outcomes and not self.loop_stack:
                    raise Kernel(f'node {node}: broke outside loop')
                if 'exit' in outcomes and join != EXIT:
                    raise Kernel(f'node {node}: machine-exit branch but join is not EXIT')
                final = ('join', join)
            else:
                if outcomes <= {'returned'}:
                    final = RETURNED
                elif outcomes <= {'broke', 'returned'}:
                    final = BROKE
                elif outcomes <= {'exit', 'returned'}:
                    final = EXIT
                elif len(regions) == 1 and all(
                        o in ('returned', 'broke', 'exit') or
                        (isinstance(o, tuple) and o[0] == 'region')
                        for o in outcomes):
                    final = regions.pop()
                else:
                    raise Kernel(f'node {node}: branch outcomes {outcomes} without a join branch')
        finally:
            pr.ind -= 1
        # render if/elseif/else
        lines = []
        n = len(branches)
        for i, (g, blines, _) in enumerate(branches):
            if g is None and i == n - 1 and n > 1:
                lines.append(p + 'else')
            elif g is None:
                # unconditional non-final path: everything after is dead
                lines.extend(blines)
                continue
            elif i == 0:
                lines.append(p + 'if ' + g + ' then')
            else:
                lines.append(p + 'elseif ' + g + ' then')
            pr.ind += 1
            lines.extend(blines)
            pr.ind -= 1
        if not (n == 1 and branches[0][0] is None):
            if any(b[0] is not None or n > 1 for b in branches):
                lines.append(p + 'end')
        return prefix + lines, final

    def _is_terminal(self, u, _seen=None):
        """True when every path starting at u ends in break/return
        (following goto chains; cycles without a terminal end are not
        terminal). Such nodes are exits in name only: they never fall
        through to a live continuation."""
        if _seen is None:
            _seen = set()
        if u in _seen:
            return False
        _seen.add(u)
        info = self.leaves.get(u)
        if info is None:
            return False
        for p in info['paths']:
            e = p['end']
            if e[0] in ('break', 'return'):
                continue
            if e[0] == 'goto_leaf':
                if not self._is_terminal(e[1], _seen):
                    return False
                continue
            return False
        return True

    def join_candidates(self, node):
        """Ordered join candidates for a conditional node: the earliest
        node reachable from every goto branch target (the merge the
        branches actually converge on, ignoring terminal branches),
        then the plain ipdom, then EXIT."""
        targets = []
        for p in self.leaves[node]['paths']:
            if p['end'][0] == 'goto_leaf' and p['end'][1] not in targets:
                targets.append(p['end'][1])
        cands = []
        if len(targets) >= 2:
            reach = {}
            for t in targets:
                seen = set()
                stack = [t]
                while stack:
                    x = stack.pop()
                    if x in seen:
                        continue
                    seen.add(x)
                    stack.extend(self.succ.get(x, ()))
                reach[t] = seen
            common = set.intersection(*[reach[t] | {t} for t in targets])
            minimal = [c for c in common
                       if all(o == c or o in self._reach_from(c) for o in common)]
            if len(minimal) == 1:
                cands.append(minimal[0])
        ip = self.ipdom.get(node)
        if ip is not None and ip not in cands:
            cands.append(ip)
        if EXIT not in cands:
            cands.append(EXIT)
        return cands

    def _reach_from(self, c):
        if not hasattr(self, '_reach_cache'):
            self._reach_cache = {}
        if c not in self._reach_cache:
            seen = set()
            stack = [c]
            while stack:
                x = stack.pop()
                if x in seen:
                    continue
                seen.add(x)
                stack.extend(self.succ.get(x, ()))
            self._reach_cache[c] = seen
        return self._reach_cache[c]

    def _fold_exits(self, exits):
        """Exit targets that are pure trampolines (single unguarded path
        ending in break, or a goto chain into another exit) fold away:
        they are emitted inline as a prologue before the break."""
        exits = set(exits)
        progress = True
        while progress:
            progress = False
            for e in list(exits):
                if e == EXIT:
                    continue
                info = self.leaves.get(e)
                if info is None:
                    continue
                ps = info['paths']
                if len(ps) == 1 and not ps[0]['guards']:
                    end = ps[0]['end']
                    if end[0] == 'goto_leaf' and end[1] in exits and end[1] != e:
                        exits.discard(e); progress = True
        return exits

    def emit_loop(self, header, stops):
        loop_nodes = self.loops[header]
        # exit targets: goto edges leaving the loop
        exits = set()
        for u in loop_nodes:
            for v in self.succ[u]:
                if v not in loop_nodes:
                    exits.add(v)
        exits = self._fold_exits(exits)
        # terminal exits (chains ending in break/return) are not
        # continuations: the body seq emits them inline as terminals
        cont_exits = {e for e in exits if not self._is_terminal(e)}
        if len(cont_exits) > 1:
            raise Kernel(f'loop @{header}: multi-exit {sorted(cont_exits)[:4]}')
        exit_t = cont_exits.pop() if cont_exits else EXIT
        # a literal break inside the body exits the whole MACHINE; that is
        # only structurable when the loop's continuation is the machine exit
        if exit_t != EXIT and any(u in self.has_exit for u in loop_nodes):
            raise Kernel(f'loop @{header}: machine-break inside loop with live continuation')
        body_stops = set(stops) | {header}
        if exit_t != EXIT:
            body_stops.add(exit_t)
        pr = self.pr
        p = pr.pad()
        self.loop_stack.append(header)
        self.loop_exits.append(exit_t)
        pr.ind += 1
        try:
            body, reached = self.seq(header, body_stops)
        finally:
            pr.ind -= 1
            self.loop_stack.pop()
            self.loop_exits.pop()
        if reached not in (header, exit_t, EXIT, BROKE, RETURNED):
            raise Kernel(f'loop @{header}: body ended at {reached!r}')
        lines = [p + 'while true do']
        lines += body
        lines.append(p + 'end')
        return lines, exit_t
