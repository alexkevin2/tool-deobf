#!/bin/sh
# run_regression.sh — isolated regression for Luraph-Deobf-Tool-v6.
#
#   Part A (bootstrap route): StealAnEggs.luau via AUTO routing —
#     golden checks incl. the v6 clean stage (full_clean.luau
#     byte-identical to the case deliverable).
#   Part B (method corpus): the 6 v5-era corpus entries via AUTO
#     routing — exit codes + primary-output sha256 must equal the
#     pristine-v5 goldens (tests/golden/corpus_sha256.json).
#   Part D (upgrade outputs): buffer-route lifted.luau and
#     method-route cleaned.luau/clean_map.json against
#     tests/golden/upgrade_sha256.json (checked inside the
#     Part B corpus output dirs).
#   Part E (spoof feature): the --spoof-id game-ID spoofing —
#     behavior-test fixtures as controls, identity_report golden
#     + gate-pass fork evidence on the bundled sample, off-mode
#     byte-identity with the v5 goldens, synthetic units
#     (tests/check_spoof.py).
#   Part Q (QA upgrade, v6.2.0): tests/check_qa.py — vendored
#     copies byte-identical, --qa-clean off restores v6.1.0 bytes,
#     default-on goldens + pass counts + no hardcoded game IDs.
#   Part C (negative controls): MoonVeil loader + a plain Luau
#     script must be rejected with exit 2.
#
# Usage: tests/run_regression.sh [path-to-StealAnEggs.luau]
#   Inputs are NOT bundled (except the corpus sample); defaults
#   point at the original case locations, overridable per entry
#   via CORPUS_<NAME> / NEG_MOONVEIL env vars (see the golden file).
#
# Isolation: the tool is copied into a fresh temp dir and run from
# there with a fake HOME and a scrubbed environment (env -i).
# TMPDIR may point at persistent storage: a VM restart wipes /tmp
# mid-run (observed 2026-10-23). Results are appended to
# tests/regression_results.log.
set -u
TOOL_SRC=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
RAW=${1:-${BVM_SAMPLE_RAW:-/home/hatch/luau-deobf/work/stealaneggs/stealaneggs_raw.luau}}
UPSTREAM=${LURAPH_UPSTREAM_DIR:-/home/hatch/luau-deobf/tools/Deobfuscator-Luraph-V15}
MOONVEIL=${NEG_MOONVEIL:-/home/hatch/luau-deobf/work/moonveil-loader-210-20261021-213232/muse-luau/input/loader_test.lua}
LOG="$TOOL_SRC/tests/regression_results.log"

if [ ! -f "$RAW" ]; then
    echo "regression: sample file not found: $RAW" >&2
    exit 2
fi

TMP=$(mktemp -d "${TMPDIR:-/tmp}/v6-regression.XXXXXX")
mkdir -p "$TMP/fakehome"
cp -r "$TOOL_SRC" "$TMP/tool"
find "$TMP/tool" -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true
OUT="$TMP/out-bootstrap"
SCRUB="HOME=$TMP/fakehome PATH=$PATH LURAPH_UPSTREAM_DIR=$UPSTREAM"

echo "=== v6 regression run $(date -u +%Y-%m-%dT%H:%M:%SZ) ===" | tee -a "$LOG"
echo "stealaneggs: $RAW" | tee -a "$LOG"
echo "upstream clone: $UPSTREAM" | tee -a "$LOG"
echo "tmp: $TMP" | tee -a "$LOG"
FAIL=0

# ---------------- Part A: bootstrap route ----------------
echo "--- Part A: bootstrap route (StealAnEggs, auto) ---" | tee -a "$LOG"
START=$(date +%s)
env -i $SCRUB python3 "$TMP/tool/luraph_v6.py" "$RAW" -o "$OUT" \
    > "$TMP/bootstrap_stdout.log" 2>&1
TOOL_EXIT=$?
END=$(date +%s)
echo "tool exit=$TOOL_EXIT wall=$((END - START))s" | tee -a "$LOG"
grep -E "route selected|verdict:" "$TMP/bootstrap_stdout.log" | tee -a "$LOG"
for f in lifted.luau full.luau full_clean.luau; do
    "$TMP/tool/bin/luau-compile" "$OUT/$f" > /dev/null 2>&1
    echo "luau-compile $f exit=$?" | tee -a "$LOG"
    [ $? -eq 0 ] || true
done
# (compile results are asserted via check_outputs/manifest below;
#  the loop above is informational except full_clean, checked here)
"$TMP/tool/bin/luau-compile" "$OUT/full_clean.luau" > /dev/null 2>&1 \
    || FAIL=1
python3 "$TOOL_SRC/tests/check_outputs.py" "$OUT" \
    "$TOOL_SRC/tests/golden" "$TOOL_EXIT" > "$TMP/check_a.log" 2>&1
CHECK_A=$?
cat "$TMP/check_a.log" | tee -a "$LOG"
[ "$CHECK_A" -eq 0 ] || FAIL=1

# ---------------- Part B: method corpus ----------------
echo "--- Part B: method corpus (6 entries, auto) ---" | tee -a "$LOG"
env -i $SCRUB python3 "$TOOL_SRC/tests/check_corpus.py" \
    "$TMP/tool" "$TMP/corpus" > "$TMP/check_b.log" 2>&1
CHECK_B=$?
cat "$TMP/check_b.log" | tee -a "$LOG"
[ "$CHECK_B" -eq 0 ] || FAIL=1

# ---------------- Part D: upgrade outputs ----------------
echo "--- Part D: upgrade outputs (buffer lift + method clean) ---" | tee -a "$LOG"
python3 "$TOOL_SRC/tests/check_upgrade.py" \
    "$TMP/tool" "$TMP/corpus" > "$TMP/check_d.log" 2>&1
CHECK_D=$?
cat "$TMP/check_d.log" | tee -a "$LOG"
[ "$CHECK_D" -eq 0 ] || FAIL=1

# ---------------- Part E: --spoof-id feature ----------------
echo "--- Part E: game-ID spoofing (--spoof-id) ---" | tee -a "$LOG"
python3 "$TOOL_SRC/tests/check_spoof.py" \
    "$TMP/tool" "$TMP/spoof" > "$TMP/check_e.log" 2>&1
CHECK_E=$?
cat "$TMP/check_e.log" | tee -a "$LOG"
[ "$CHECK_E" -eq 0 ] || FAIL=1

# ---------------- Part Q: QA upgrade (v6.2.0) ----------------
echo "--- Part Q: QA upgrade (v6.2.0, check_qa.py) ---" | tee -a "$LOG"
python3 "$TOOL_SRC/tests/check_qa.py" \
    "$TMP/tool" "$TMP/qa" > "$TMP/check_q.log" 2>&1
CHECK_Q=$?
cat "$TMP/check_q.log" | tee -a "$LOG"
[ "$CHECK_Q" -eq 0 ] || FAIL=1

# ---------------- Part C: negative controls ----------------
echo "--- Part C: negative controls (expect exit 2) ---" | tee -a "$LOG"
printf 'local x = 1\nprint(x + 2)\n' > "$TMP/plain.luau"
for neg in "$MOONVEIL" "$TMP/plain.luau"; do
    env -i $SCRUB python3 "$TMP/tool/luraph_v6.py" "$neg" \
        -o "$TMP/neg-out" > "$TMP/neg.log" 2>&1
    NEG_EXIT=$?
    echo "negative $neg -> exit $NEG_EXIT" | tee -a "$LOG"
    [ "$NEG_EXIT" -eq 2 ] || FAIL=1
done

if [ "$FAIL" -ne 0 ]; then
    echo "REGRESSION FAILED (workdir kept at $TMP)" | tee -a "$LOG"
    exit 1
fi
echo "REGRESSION PASS — ALL PARTS (workdir kept at $TMP)" | tee -a "$LOG"
exit 0
