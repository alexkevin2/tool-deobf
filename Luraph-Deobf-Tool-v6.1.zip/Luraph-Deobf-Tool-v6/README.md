# Luraph Deobf Tool v6 (standalone)

One CLI for every Luraph family this project handles, with
**automatic variant routing**. v6 merges the two previous
standalone tools — their engines are kept verbatim as route
engines under `routes/`, so every previously verified output is
reproduced byte-identically (the regression below proves it):

| merged tool | v6 home | route |
|---|---|---|
| Luraph-Deobf-Tool-v5 (CLI `luraph151.py`) | `routes/method/` | **method** — v15.1 method-based pipeline + upstream (v15.0/v14.x) + buffer-variant sub-routes |
| Luraph-BootstrapVM-Deobf v2.1 (CLI `luraph_bvm.py`) | `routes/bootstrap/` | **bootstrap** — v15.1 virtualized-bootstrap sub-variant (StealAnEggs family) |

v6 also folds the StealAnEggs **source-cleaning pass**
(`clean.py`/`clean_lib.py`, developed in the case) into the
bootstrap route as a first-class stage: the route's headline
deliverable is now the cleaned source (`full_clean.luau`), with
the raw lift kept alongside as ground truth.

## Changelog

- **2026-10-24 — self-audit QA upgrade (v6.2.0; audit in
  `tests/qa-audit-2026-10-24.md`).** Every run now emits
  `qa_report.json` + a `## QA self-check` section in `report.md`
  (raw-pattern counts, INFERRED/neutral ratios, unstructured
  residue, defects detected but NOT fixed with locations). New
  `qa_clean.py` (vendored byte-identical into both routes) runs
  after the route's clean stage, all passes provable-only:
  isolated literal folding, `if true`/`if false` cleanup,
  kind-conflict downgrade to neutral, trailing-nil compaction,
  self-assign / unused-`T` removal, straight-line dead-write
  elimination. Measured fixes: StealAnEggs `full_clean.luau`
  2,036 → 2,002 lines (34 dead writes removed, sha
  `8cbf32ff…`), JjsKhanhly `cleaned.luau` 673 → 668 lines
  (nil ×4, self-assign ×1, unused `T` ×4, renames `n8`→`r8`,
  `s2`→`r2`; totals still 1/1/35), buffer `lifted.luau`
  30,347 → 30,325 lines (nil ×172, dead ×22). Counted residue,
  deliberately NOT rewritten: `lshift(x, 0)` ×24 (errors on
  nil/non-number), `q+N-M` arithmetic ×150 (double rounding is
  not associative), `__descriptor` ×54 (runtime link-registry
  keys), empty `while true` ×3 (faithful infinite loops), the 2
  proven kernels, buffer kernel protos ×22. `--qa-clean off`
  restores exact v6.1.0 bytes for those three files (verified:
  cleaned `6feebab4…`, buffer lifted `13023dfe…`); method
  `lifted.luau`, `ops.json`, `protos.json` and
  `identity_report.json` are byte-identical in both modes.
  Regression gains Part Q (`tests/check_qa.py`).
- **2026-10-24 — fingerprint upgrades L1–L7 (v6.1.0; corpus
  `FINGERPRINT-REPORT.md`).** Corpus now 12 samples (6 Luraph +
  AntiLua ×2, MoonVeil, XHider, luast, plain). **L1 (P0):** a
  foreign-family header in the first 4096 chars vetoes
  buffer-variant evidence only at v6 auto-routing — this fixes
  the estate's clearest live misroute: AntiLua mos_hub
  (`66a48505…`, bufvar True, all method markers False) was
  routed method→buffer; it now exits 2 with an evidence
  summary, and no golden changes route (StealAnEggs still
  bootstrap-first; jjs/bf-tester/hune/buffer×2 still method;
  MoonVeil/luast/XHider/AntiLua-unversioned/plain still exit 2).
  **L2 (P0):** `is_buffer_variant()` itself now vetoes
  bootstrap cheap markers (`MY=[==[`+`LPH`, `\bFz=function`)
  and any Luraph version header — the screen is NOT tightened
  to literal `buffer.read*` (the true buffer golden has 0 such
  hits; readers are slot-table-installed by name), so the
  buffer golden still routes and StealAnEggs/bf-tester no
  longer trip the screen. **L3 (P1):** `buffer_route()` body-
  grammar failure (no contiguous `readu8` run > 1000, or
  `parse_body` exception) now returns **exit 2 (REJECTED)**
  instead of 5 — a misroute can no longer masquerade as a
  PARTIAL; the buffer golden still parses and still exits 5
  with byte-identical `protos.json`. **L4 (conservative):**
  bootstrap `detect()` gains an EOF-anchored entry-tail-shape
  conjunct (last 8192 chars) alongside the retained literal
  `:vY()(` gate — the literal was NOT demoted, because with a
  single bootstrap sample there is no evidence a future build
  reuses a different entry name (a future worker with a second
  bootstrap sample may demote it). StealAnEggs still passes
  all checks (now 12 incl. the new shape check).
  **L5 (documented, not relaxed):** bootstrap thresholds are
  fragile on the single sample (numeric slots 6 vs ≥ 5;
  `_Y={` at offset 1,579,840 vs gate ≥ 1,000,000) — kept as
  hard gates; any fallback needs a second bootstrap sample.
  **L6 (P2):** version-header scan widened 400 → 2000 chars,
  comment-line anchored (golden headers at offset 33
  unchanged; a payload-embedded header string does not route).
  **L7 (documented precedence):** bootstrap → version-header
  (upstream for ≠ 15.1) → method sub-routes; inside the method
  route, headerless files still check buffer before structural
  (pre-existing order preserved — the report's
  "structural → buffer" shorthand was NOT implemented as a
  reorder, since no golden distinguishes the two). The
  2026-10-24 spoof-engine upgrade (entry below) was already
  in this code and is unchanged by this round; this entry
  documents it in the changelog lineage — what changed vs
  the previous zip (`aee6a740…`, pre-spoof-engine) is the
  spoof engine + L1–L7 together.
- **2026-10-24 — shared dynamic game-ID spoof engine (v1.0.0).**
  The v6 spoof feature is now factored into one standalone
  pure-stdlib module, `spoof_engine.py` (canonical copy at the
  tool root; byte-identical vendored copies in `routes/method/`
  and `routes/bootstrap/modules/stageE/`; distribution mirror in
  `~/luau-deobf/tools-shared/`), specified by `SPOOF-SPEC.md`
  (same mirror). The two route `identity.py` modules are now
  thin adapters over the engine and `mocks.py` takes its field
  set from it. Behaviour and report bytes are unchanged: the
  Part E golden (`identity_report.json` sha256 `155b89f2…c5a`)
  still passes, `--spoof-id off` is still byte-identical to
  legacy outputs, and the no-hardcode audit (no game-ID literal
  in production code) is now enforced by
  `tests/check_spoof_engine.py`. Sibling ports (MoonVeil, Luast,
  Luau-Deobf-Tool) build from `SPOOF-SPEC.md` §10.
- **2026-10-23 (evening) — game-ID spoofing feature.**
  `--spoof-id auto|off` (default `auto`) on both routes:
  static identity-gate candidate extraction, seeded /
  self-calibrating mock environments, differential behavior
  forks (method route), new `identity_report.json` artifact +
  report section; regression gains Part E. All additive —
  `--spoof-id off` is byte-identical to the previous build.
  Details: `FEATURE-REPORT.md` and the *Game-ID spoofing*
  section below.
- **2026-10-23 — regular-Luraph upgrade** (buffer-variant
  semantics crack + lifter, method source-clean stage 6b;
  regression Part D). Details: `UPGRADE-REPORT.md`.
- **2026-10-23 — v6.1**: bootstrap clean stage replaced by the
  case's restructuring cleaner (elseif collapse 627 → 261).
- **2026-10-23 — v6**: initial merge of the v5 method tool and
  the BootstrapVM v2.1 tool behind one auto-routing CLI.

## Usage

```
python3 luraph_v6.py <file.luau> [-o outdir] [--route auto|bootstrap|method]
                     [--luau path] [--force] [--clean-work]
                     [--spoof-id auto|off]
```

`--route auto` (the default) is what the regression exercises;
the other values force a route. `--luau` / `--force` apply to the
method route, `--clean-work` to the bootstrap route.
`--spoof-id` (default `auto`) enables the game-ID spoofing
feature described in the next-but-one section; `off` restores
the exact pre-feature behaviour on both routes.

## Routing

| # | fingerprint | route taken |
|---|---|---|
| 1 | **Bootstrap-VM**: Luraph v15.1 header + `return setmetatable({...})` numeric-keyed VM table + blob field `MY=[==[` with `LPH` magic + gsub pattern field `YY="[ -'}~]"` + replacement table `_Y` + entry tail `):vY()(` + builder `Fz=function` present + stage-1 field extractor succeeds on the file | **bootstrap** |
| 2 | Any other Luraph evidence: version header of **any** version (v15.0/v14.x → upstream sub-route), **structural v15.1** fingerprint (`string.unpack` deserializer + long-bracket blob + `}).t(` entry, header may be stripped), or **buffer-variant** fingerprint (`buffer` global + ≥5 reader names, minus L2 vetoes) | **method** |
| 3 | Neither, or buffer-variant evidence vetoed by a foreign-family header (L1) | **rejected, exit 2**, detected-evidence summary printed; no output is produced — the tool never emits garbage for a family it does not recognise |

Buffer-route failure note (L3): a file that trips the buffer
screen but whose body grammar does not validate (no contiguous
`readu8` run > 1000, or `parse_body` exception) is **rejected,
exit 2** — it is no longer reported as PARTIAL (exit 5 is kept
only when the body parses).

The bootstrap fingerprint is checked first: bootstrap files also
contain buffer-reader names and a v15.1 header, and the method
pipeline cannot read them (their bootstrap is itself virtualized).

## Routes

### method (v5 engine + additive upgrade stages)

1. **detect** header / structural markers for v15.1.
2. **fold** conservative integer constant folding.
3. **dump** run the target in the bundled standalone Luau CLI
   with `string.unpack` hooked (`runner_template.luau`); the
   deserializer parses the whole proto tree eagerly, so all
   protos/constants are dumped in one run. *Safety: this stage
   executes the target inside the Luau CLI sandbox (no network,
   no io in that runtime) — the upstream tool's established
   approach. Only run scripts you own or are authorised to
   analyse, on an isolated machine, with no real credentials.*
4. **parse** rebuild the proto tree from the unpack log; the
   parse must consume the log exactly or the run is rejected.
   The XOR key for tag-3 strings is auto-extracted from the
   folded source (best string-score candidate wins).
5. **extract** opcode-name table + handler bodies from the VM
   source; handlers are classified by normalised signature
   (`semantics.py`) — per-build renaming is tolerated.
6. **lift** devirtualise to structured Luau; verified with
   `luau-compile`.

Sub-routes inside the method engine (unchanged v5 behaviour):
- **upstream**: a Luraph header of any version ≠ 15.1 is handed
  to the upstream **Deobfuscator-Luraph-V15** clone when
  available (`LURAPH_UPSTREAM_DIR`, else a `Deobfuscator-Luraph-V15`
  directory next to this tool, else `~/luau-deobf/tools/...`).
  v6 always passes an absolute output dir (with a relative one,
  v5's upstream route wrote its result into the clone's tree and
  misreported failure — v6 fixes that by construction). Without
  the clone: guidance printed, exit 3.
- **buffer**: buffer-based builds (no `string.unpack`) are dumped
  through the buffer-proxy runner; the header stream and the
  varint body grammar are parsed with exact-consumption
  validation → `protos.json` + `binary.bin` + `constant_pool.txt`.
  **Since the 2026-10-23 upgrade the sub-route also lifts source:**
  the variant's protos run on a stage-1 VM whose interpreter the
  payload installs at state slot 55; all 162 dispatch opcodes are
  classified from their handler bodies (`optable_buffer.json`) and
  the packed instructions decode exactly into the VM's operand
  streams (verified against dynamic builder dumps), so the route
  emits `lifted.luau` (structured Luau where the CFG allows, exact
  dispatch-kernel transcriptions otherwise; luau-compile checked).
  The sub-route still ends **PARTIAL (exit 5)** with named
  residues: CLOSURE child identity binds through the
  deserializer's deferred link registry (rendered
  `__descriptor(id)`), the per-proto X field's role is
  unconfirmed, and kernel protos are transcriptions, not
  structured control flow. See `UPGRADE-REPORT.md`.

**Source-clean stage (method route, since the upgrade):** after a
successful lift, stage 6b (`clean.py`) promotes the register
table `R[k]` to real locals with evidence-labelled names
(CONFIRMED single-definition global bindings, initialised at
declaration from the outer global; INFERRED derivations such as
`game.PlaceId` chains and closures; neutral kind names otherwise)
→ `cleaned.luau` + `clean_map.json` (per-proto accounting
anchored to `lift_report.json`; string-literal multiset verified
unchanged; luau-compile checked). Protos whose register table
escapes or is dynamically indexed are kept verbatim and listed
in the map with the reason. `lifted.luau` is never modified.

Outputs (in the outdir): folded.luau, protos.json, opnames.json,
handlers.json, ops.json, disasm.txt, lifted.luau,
lift_report.json, cleaned.luau, clean_map.json, unpack.log,
runner.luau, report.md — or `deobfuscated_upstream.lua`
(upstream) / buffer artifacts incl. lifted.luau (buffer).

### bootstrap (BootstrapVM engine, verbatim + clean stage)

The target is **never executed in a Luau runtime** on this
route: the bootstrap's machinery is re-implemented as static
Python transcriptions validated against live VM captures, and
the payload interpreter is executed in context by a Python AST
interpreter over the live simulator objects, with permissive
logged mocks.

1. **stage 1** static blob decode (gsub alphabet repair →
   in-place Ascii85 → structure table E → payload chunk) →
   `stage1/{gsub,src,dst}.bin`. Oracle-verified byte-identical.
2. **stage 2** table parse → Fz builder simulation → eager
   materialization → symbolic disassembly walk of the root proto
   → fast state-178 child census (cross-check only) →
   access-order materialization → static lift (`lifted.luau`).
3. **stage E (executor)** the slot-15209 payload interpreter
   runs in context (requires `EXEC_ACT_BUDGET=2000000`, set by
   the driver), so child protos materialize with real captures
   and streams decrypt in place. dz children are walked from
   build-time snapshots; bz children are constant artifacts
   (single-table group + verbatim slot utility closure). →
   `full.luau` (root + all recovered children).
4. **clean (new in v6)** renders the same 796 walked
   instructions as idiomatic Luau: structured control flow
   where the jump graph is safely structurable, promoted +
   renamed registers, CONFIRMED stdlib names for the factory
   aliases, `CONST_UNRESOLVED_*` placeholders for unresolved
   constants (never invented values). → **`full_clean.luau`**
   (headline deliverable) + `clean_map.json` (796/796
   instructions mapped, with per-proto form + reasons) +
   `clean_stats.json` (equivalence audit: cleaned rendering vs
   fresh translation per record, 796 checked / 0 problems on
   the reference sample).
5. **clean2 — restructuring (new in v6.1; internal bootstrap
   version 2.2.0; the default clean stage, clean remains as
   fallback)** rebuilds the *completed* walk graph: stage2's
   children walk now also harvests the walks' JMPR target
   unions (`stage2/jmpr_harvest.json`) — the dynamic edges the
   per-record first-visit serialization drops, which is what
   fragmented v6's graphs at the VM's trampoline hubs.
   `build_cfg2.py` assembles the completed graph (796 nodes /
   830 edges on the reference sample, every proto 100%
   reachable); `clean2.py`/`clean2_lib.py` then elide the
   trampoline hubs by constant propagation over the dispatch
   register and structure with loop-aware joins, validated
   candidate joins, bounded flagged duplication of shared
   tails, and dispatch scoped to provably irreducible SCC
   kernels only. Reference-sample result: 525/796 instructions
   in real structured control flow, 262 in two scoped kernels
   (root mode-C segment, child9 multi-entry SCC), 6 in
   terminal cycles, 35 duplicated (flagged 1:N in the map);
   `elseif` lines 627 → 261 (260 inside the kernels);
   luau-compile PASS; audit 796/796, 0 problems. The v6 clean
   stage runs automatically as fallback if clean2 ever fails
   (the manifest records which structurer produced the
   headline). Full analysis: the case's STRUCTURE-REPORT.md.

Full stage-by-stage detail lives in the route driver's docstring
(`routes/bootstrap/luraph_bvm.py`) and the generated `report.md`
/ `manifest.json` of each run.

## Exit codes

Route semantics are preserved from the merged tools:

| code | meaning |
|---|---|
| 0 | full recovery (method route success; bootstrap FULL_RECOVERY) |
| 5 | **PARTIAL** — the bootstrap route's expected verdict today; the method buffer sub-route; or a pipeline stage failed on a fingerprint-matching file |
| 2 | not a recognised Luraph family (v6-level rejection with evidence summary), input missing, the method route's own rejection, or a buffer body-grammar failure (L3) |
| 3 / 4 | method-route internals preserved from v5 (upstream clone unavailable / proto-parse mismatch) |

## Game-ID spoofing (`--spoof-id auto`, default)

Luraph payloads commonly hide their real body behind an identity
gate — `game.PlaceId == <expected>` (or `JobId`, `CreatorId`,
`PlaceVersion`, `GameId`) — and serve a decoy branch to any
environment whose ID does not match. Generic mocks always take
the decoy. This feature finds the expected ID and serves it back,
automatically, on both routes. It is **analysis-side only**: it
configures the local mock environments the tool itself runs; it
never contacts a server, and the gate-pass path's remote loads
stay logged mock interactions (`HttpGet` returns an inert empty
string — nothing is fetched or executed).

Three mechanisms, all feeding one new artifact per run,
`identity_report.json`, plus a short `## Identity spoofing`
section in the route's `report.md`:

1. **Static extraction (no execution required).** Method route:
   a symbolic provenance pass over the recovered protos finds
   identity-field reads (`game.PlaceId` & friends) flowing into
   equality comparisons, set-membership tests, or bounds —
   candidates carry site evidence (proto, pc, pattern). (On the
   bundled JjsKhanhly sample it recovers `PlaceId = 9391468976`,
   a set-membership gate at root pc 5.) Buffer sub-route: the
   decoded constant pool is scanned (weak evidence class — its
   VM stream is not dataflow-modelled). Bootstrap route: the
   stage-2 walk records are scanned for instructions whose
   constants co-refer to an identity field and a number; the
   materializer output contributes presence evidence.
2. **Seeded / self-calibrating mocks.** Where the tool executes
   payload code, identity fields are served deliberately:
   - *Method route* — a behavior runner executes the lifted
     source against a mock env whose `game.__index` serves a
     static candidate when one exists (source `seed`), else a
     distinctive probe value (source `probe`); every identity
     read is logged. Note the shipped mechanism: Luau's `__eq`
     does **not** fire for table-vs-number comparisons (verified
     against the bundled binary), so a Lua-side sentinel cannot
     capture the expected value at comparison time — capture
     therefore happens at *read time* via the static candidates,
     and ambiguity is resolved by forking (below), not by `__eq`.
   - *Bootstrap route* — the Python executor's game mock serves
     pre-seeded fields (exactly-one-candidate fields) and a
     per-field **sentinel** object otherwise; the executor's
     equality decision hook *does* see both operands, so the
     first scalar a sentinel is compared against is **captured
     and adopted** for the rest of the run, and later comparisons
     that demand a different value are logged as contradictions.
3. **Branch forking (method route).** When candidates disagree
   (multiple distinct values for one field), the behavior run is
   repeated once per value (≤ 4 forks per field, ≤ 9 total) and
   each fork records its outcome: prints (the decoy branch's
   signature is usually unmistakable — e.g. 161 insult prints),
   mock calls, and remote-load attempts. The bootstrap route's
   sweep is a single canonical deterministic run, so it does not
   fork; ambiguity there surfaces as logged contradictions.

**Limits.** IDs computed at runtime from non-constant
expressions are only caught where an execution actually compares
them (bootstrap comparison capture; method-route forks over
pool-harvested candidates). IDs checked server-side cannot be
spoofed locally at all — out of scope by construction.
`--spoof-id off` produces byte-identical legacy outputs: no
`identity_report.json`, no report section (regression Part E
proves this against the v5 goldens). Design + validation:
`FEATURE-REPORT.md`. **Shared engine (2026-10-24):** the
portable semantics behind this section now live in
`spoof_engine.py` (pure stdlib, no Luau dependency), specified
by `SPOOF-SPEC.md` — gate model, fork/seed strategy, sentinel
capture, unified `identity_report.json` schema, and the
never-hardcode rule with its audit. The v6 routes keep their
legacy report shapes for golden compatibility (see
`SPOOF-SPEC.md` §6.2); new ports emit the unified schema.

## Known limits — bootstrap route (reference sample numbers)

Verdict on StealAnEggs is **PARTIAL (exit 5)**. The residue is
small, exactly enumerated, and mostly *proven* rather than
unknown:

- **270 of 434 referenced constants stay placeholders.**
  Coverage ends at a capture/register fidelity wall inside
  proto5 (mode C pc 35): a SETTABLE-class op whose base/key/value
  registers are all nil in every reachable executor state
  (identical under both mock policies; 2,254,995 organic steps,
  2 mock decisions). No mock value is invented to paper over it;
  the placeholders render as `CONST_UNRESOLVED_*` in the cleaned
  source.
- **2 of 9 dynamic DECRYPTSTRs stay ENCRYPTED** (sites C:30 and
  C:5735 are never executed in any reached state). The 7 reached
  ones decrypt in context to **binary blobs** — verified by
  256-key brute force to contain no readable text.
- **child18 is a proven phantom, not a missing proto.** Only 16
  dz factory calls exist (root + 15 children); child18's
  would-be factory args are incoherent garbage, reproduced
  byte-identically across re-probes (its build reads slot
  753511, not a function slot). It stays a labeled stub.
- **Dispatch survives only inside 2 scoped kernels** in
  `full_clean.luau` (262 of 796 instructions, v6.1 clean2
  stage): root/`main`'s 190-instruction mode-C segment (a
  single-entry SCC whose six internal back edges create
  overlapping natural loops sharing the C111/C121 continuation
  points — structuring was attempted, and the exact failure is
  documented in the case's STRUCTURE-REPORT.md) and
  child9/`bezierCurveFn`'s 72-instruction multi-entry SCC
  (entries A17/A46/A93/A115 — no goto-free structured form
  exists). The other 525 instructions are real structured
  control flow, 6 sit in terminal `while true do end` cycles,
  3 trampoline-hub instructions are elided (their dispatch
  register is provably constant at every in-edge), and 35 are
  duplicated shared tails (flagged 1:N in `clean_map.json`).
  (The v6 clean stage, retained as fallback, structured only
  158/796 and kept 638 in whole-proto dispatch.) Register
  promotion applies to 13 protos; root, child9 and child15
  keep a `regs` table for stated reasons (dynamic indices /
  vararg spills).
- **1 UNIMPL** (mode C op 110, no transcribed handler body)
  renders as an `UNIMPL(...)` call; 124 visited instructions have
  UNKNOWN semantics — handler bodies transcribed verbatim with a
  one-line observed-effect note.
- The static census (stage 2) is **phantom-prone, cross-check
  only**: of its 47 descriptors only 2 are real children (34 are
  plain constants, 11 garbage). The authoritative child set
  (20 protos: 11 organic + 2 census + 7 grandchildren) comes
  from the executor sweep.
- Method-call / `game:GetService` idiom conversion provably
  fires **0** times on this payload: every fetch in the walked
  code indexes tables by *integer* keys (the VM's hash-keyed
  constant tables), so no `obj:Method()` pattern exists in
  provable form. The conversion machinery is in place and fires
  automatically if a future walk resolves string keys.
- The Fz/interpreter transcriptions are specific to this build
  family; a new build that changes the FSM/interpreter bodies
  may fail a later stage (reported honestly, exit 5).

Method route limits after the upgrade: the buffer sub-route
lifts source but keeps the named residues above (descriptor-
bound closures, unconfirmed X field, dispatch-kernel protos);
the clean stage names registers per-proto evidence only (a
register reused as a generic temp stays neutral — on the
JjsKhanhly reference payload that is most registers, by design);
the upstream sub-route needs the external
Deobfuscator-Luraph-V15 clone.

## Regression test

```
tests/run_regression.sh [path-to-StealAnEggs.luau]
```

Isolated (tool copied to a fresh temp dir, fake HOME, scrubbed
environment; `TMPDIR` may point at persistent storage — a VM
restart wipes `/tmp` mid-run). Six parts (A–E + Q):

- **Part A — bootstrap route**: StealAnEggs via auto routing.
  Golden checks (`tests/check_outputs.py` vs `tests/golden/`):
  exit 5 / verdict PARTIAL, stage-1 sha256s, 304-pair root
  visited set, 47-descriptor census (cross-check), root
  constants 794/434/1228, executor child set == 20 real
  children, 15 dz walked / 4 bz artifacts / 1 unrecovered,
  constants 164/434, `full.luau` = 796 instructions, bz slots
  {41, 41, 41, 67}, clean `luau-compile` of all three lifts —
  **plus the clean checks: `full_clean.luau` byte-identical
  to the case golden (sha256 `8cbf32ff…` since v6.2.0's qa_clean
  stage, 2,002 lines; was `d50a955d…7f47` under v6.1), clean_map
  796/796, manifest clean.ok, and a `qa_report.json` with
  dead == 34.**
- **Part B — method corpus** (`tests/check_corpus.py` vs
  `tests/golden/corpus_sha256.json`): 6 case entries — bundled
  sample (= the JjsKhanhly file), the JjsKhanhly case input,
  BF-Tester (upstream), Hune (upstream), luraph_payload
  (buffer), NNVN cache (buffer; == luraph_payload bytes). Each
  must reproduce the pristine-v5 exit code and primary-output
  sha256 byte-identically (6/6). Goldens were generated from
  the unmodified v5 tool on 2026-10-23; the BF-Tester golden
  also matches that case's historical deliverable byte-for-byte.
- **Part D — upgrade outputs** (`tests/check_upgrade.py` vs
  `tests/golden/upgrade_sha256.json`): the buffer corpus outputs
  must contain `lifted.luau` with the v6.2.0 golden sha256,
  compiling, with the report stating the cracked-semantics
  verdict and the structured/kernel split; the JjsKhanhly corpus
  outputs must contain `cleaned.luau` with the v6.2.0 golden
  sha256, compiling, and a `clean_map.json` whose totals match
  the golden (promoted/skipped protos, CONFIRMED/INFERRED/neutral
  counts, literal multiset preserved) plus the v6.2.0 renames
  (`root.0.0:8` → `r8`, `root:2` → `r2`).
- **Part E — spoof feature** (`tests/check_spoof.py` vs
  `tests/golden/spoof_sha256.json`): the v5-era behavior-test
  fixtures as controls (hand-written `PlaceId` 9391468976 → gate
  pass with `HttpGet` + remote-payload run; 12345 → exactly 161
  insult prints, no HTTP); a v6 `--spoof-id auto` run on the
  bundled sample must reproduce the golden `identity_report.json`
  (candidate 9391468976, set-membership @ root pc 5; fork 0 shows
  the gate-pass path with the ID served from a static seed, no
  hand-written game table); a `--spoof-id off` run must produce
  no identity artifacts and byte-identical v5-golden primaries;
  synthetic units cover the no-identity negative, an `eq-const`
  gate, the bootstrap static extraction, and the executor mock
  sentinel flow.
- **Part Q — QA upgrade** (`tests/check_qa.py`): vendored
  `qa_clean.py`/`qa_report.py` copies byte-identical;
  `--qa-clean off` restores the v6.1.0 goldens while still
  emitting `qa_report.json` (enabled false); default-on runs
  match the v6.2.0 goldens with the exact pass counts above,
  clean_map renames `r8`/`r2`, unchanged totals and identity
  report; buffer descriptor sites == 54 and kernel protos == 22;
  no 10-digit game-ID literal in the new modules.
- **Part C — negative controls**: the MoonVeil loader and a
  plain Luau script must both exit 2.

Results are appended to `tests/regression_results.log`.
Corpus/case input paths default to the original case locations
and are overridable via env (`CORPUS_*`, `NEG_MOONVEIL`,
`LURAPH_UPSTREAM_DIR`, `BVM_SAMPLE_RAW`). The raw targets are
**not** bundled; `sample/` holds clearly-labeled tool outputs
only.

## Layout

```
luraph_v6.py            single CLI (detect -> route -> delegate)
bin/                    bundled Luau CLI (Linux x64 + .exe)
routes/method/          v5 engine (luraph151.py + modules;
                        additive stages [3c]/[6b] in luraph151.py)
                        + upgrade additions: buffer_lifter.py
                        (buffer-variant pool/decode/op-table/lift),
                        optable_buffer.json, bodies_buffer.json,
                        clean.py (method source-clean stage)
                        + spoof additions: identity.py (static
                        extraction + behavior forks),
                        runner_behavior.luau,
                        runner_buffer_behavior.luau
UPGRADE-REPORT.md       2026-10-23 regular-Luraph upgrade report
FEATURE-REPORT.md       2026-10-23 game-ID spoofing feature report
routes/bootstrap/       BootstrapVM engine (luraph_bvm.py,
                        modules/{static,stage2,stageE(+clean)},
                        its own bin/ for luau-ast/luau-compile)
                        + spoof additions: stageE/identity.py,
                        IdSentinel in stageE/mocks.py, cmpeq
                        capture in stageE/executor.py
sample/method/          v5 sample input + expected outputs
sample/bootstrap/       bootstrap-route outputs on StealAnEggs
tests/                  run_regression.sh, check_outputs.py,
                        check_corpus.py, golden/, regression log
```

Python 3.10+. No imports from outside the package.
