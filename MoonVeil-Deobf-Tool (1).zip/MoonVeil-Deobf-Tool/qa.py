#!/usr/bin/env python3
"""qa.py — self-check QA report for MoonVeil runs (moonveil-qa/1).

Every run of moonveil2 emits qa_report.json plus a QA section in
report.md. Counts are defined here, measured on the FINAL delivered
files (decrypted + linearized), so the report describes what the
user actually receives — not what an intermediate stage looked like.

Count definitions (code-segment counts exclude string/comment
contents via fold.split_segments, except where noted):
  unfolded_pure_arith: digit-operator-digit runs in code, e.g.
    `1+2` (state-var arithmetic like `355-G` or `11448/e` is not
    counted: it is runtime logic, not a foldable constant).
  double_parens: `((N))` in code.
  single_parens: `(N)` in code (kept deliberately in call/index
    contexts by clean.py; the count is informational).
  plus_minus: `+-` in code (post-clean residue = non-digit/(
    followers only, which clean.py leaves alone on purpose).
  if_true: `if true then` in code.
  negated_conditionals: `if|elseif not (` in code.
  nil_init_decls: `local <names> = <values containing nil>` in code.
  nil_clear_statements: `;`- or newline-separated code chunks
    containing an assignment whose RHS mentions nil.
  helper_cache_refs: `<cache>[` references in code. After a
    complete substitution these are exactly the helper
    DEFINITIONS (dead scaffolding kept for table shape); any
    call site would also match, so this count is cross-checked
    against unresolved_helper_calls.
  unresolved_helper_calls: `:Helper(` call sites remaining for
    the classified helpers (must be 0 on a complete run).
  cache_or_sites: `<cache>[k] or <var>:` idiom sites remaining.
  frag_string_call_sites: textual `.<fragment-field>"` sites in
    the full text (the L1982 blob-chain shape; the Ta pair
    path is substituted away, so any remainder is residue).
  probe_leaks: occurrences of `PROBE_VALUE` or the probe marker
    digits in the FULL delivered text (strings included: a probe
    inside a string literal in delivered source would still be
    a leak). The probe value is passed in by the caller (from
    spoof_engine) and is never retyped here.
  while_true / repeat_until_false: loop wrappers in code.
  tierB_blocks: `-- state N` markers in linearized output.
  kept_loops: [{function, reason}] parsed from cfg.md KEPT lines.
  slot_conflicts / multi_role_fields: computed by the caller
    from roles (a field is conflicted when it is both an
    instantiated field and a combiner/fragment field).
  names: {inferred: 0 (this tool assigns no semantic names),
    neutral: <number of link names>} — INFERRED is 0 by design
    and must stay 0; any future name assignment must come with
    evidence in naming_evidence.json, never from assertion.

`residue` lists every defect class with count > 0 that was
detected but NOT fixed, with up to 10 locations each (line
numbers in the scanned file, or cfg.md lines for KEPT loops).
A clean run still reports residue honestly: residue is not
failure, it is the known-unknown list for the next round.
"""
import re

SCHEMA = 'moonveil-qa/1'


def _code_segments(src):
    import fold as fold_mod
    return ''.join(s for k, s in fold_mod.split_segments(src)
                   if k == 'code')


def _locations(text, pattern, limit=10):
    out = []
    for m in re.finditer(pattern, text):
        out.append(text[:m.start()].count('\n') + 1)
        if len(out) >= limit:
            break
    return out


def scan_text(src, roles=None, probe_value=None):
    code = _code_segments(src)
    counts = {}
    counts['unfolded_pure_arith'] = len(re.findall(
        r'(?<![\w.])\d+\s*[-+*]\s*-?\d+', code))
    counts['double_parens'] = len(re.findall(r'\(\(\d+\)\)', code))
    counts['single_parens'] = len(re.findall(r'\(\d+\)', code))
    counts['plus_minus'] = len(re.findall(r'\+-', code))
    counts['if_true'] = len(re.findall(r'\bif\s+true\s+then\b', code))
    counts['negated_conditionals'] = len(re.findall(
        r'\b(?:if|elseif)\s+not\s*\(', code))
    counts['nil_init_decls'] = len(re.findall(
        r'\blocal\s+(?:[A-Za-z_]\w*\s*,\s*)*[A-Za-z_]\w*\s*=\s*'
        r'[^\n;]*\bnil\b', code))
    chunks = re.split(r'[;\n]', code)
    counts['nil_clear_statements'] = sum(
        1 for ch in chunks
        if re.search(r'=\s*[^=]*\bnil\b', ch) or ',nil' in ch.replace(' ', ''))
    counts['while_true'] = len(re.findall(r'\bwhile\s+true\s+do\b', code))
    counts['repeat_until_false'] = len(re.findall(r'\buntil\s+false\b', code))
    counts['tierB_blocks'] = len(re.findall(r'-- state -?\d+', src))
    counts['probe_leaks'] = 0
    if probe_value is not None:
        counts['probe_leaks'] = (
            src.count('PROBE_VALUE') + src.count(str(probe_value)))
    if roles:
        cache = roles.get('cache')
        if cache:
            counts['helper_cache_refs'] = len(re.findall(
                r'\.' + re.escape(cache) + r'\[', code))
            counts['cache_or_sites'] = len(re.findall(
                r'\.' + re.escape(cache) +
                r'\[\s*-?\d+\s*\]\s*or\s*\w+:', code))
        else:
            counts['helper_cache_refs'] = 0
            counts['cache_or_sites'] = 0
        helpers = list(roles.get('numeric_helpers') or [])
        if roles.get('string_helper'):
            helpers.append(roles['string_helper'])
        counts['unresolved_helper_calls'] = sum(
            len(re.findall(r':' + re.escape(h) + r'\(', code))
            for h in helpers)
        frag = roles.get('fragment_field')
        counts['frag_string_call_sites'] = (
            len(re.findall(r'\.' + re.escape(frag) + r'"', src))
            if frag else 0)
    return counts


def parse_kept(cfg_text):
    kept = []
    for i, line in enumerate(cfg_text.splitlines(), 1):
        if 'KEPT' in line:
            m = re.search(r'function\s+(.+?):\s*KEPT\s+original loop\s*\((.+)\)',
                          line)
            if m:
                kept.append({'function': m.group(1), 'reason': m.group(2),
                             'cfg_line': i})
            else:
                kept.append({'function': line.strip(), 'reason': 'unknown',
                             'cfg_line': i})
    return kept


def build_qa(decrypted, linearized, roles, cfg_text,
             slot_conflicts, multi_role_fields, naming_evidence,
             clean_stats, compile_ok, equivalence_ok, probe_value=None):
    dec = scan_text(decrypted, roles, probe_value)
    lin = scan_text(linearized, roles, probe_value)
    kept = parse_kept(cfg_text or '')
    perm = roles.get('permutation') or {}
    qa = {
        'schema': SCHEMA,
        'compile_ok': compile_ok,
        'equivalence_ok': equivalence_ok,
        'clean': clean_stats,
        'decrypted': dec,
        'linearized': lin,
        'kept_loops': kept,
        'kept_loop_count': len(kept),
        'names': {'inferred': 0, 'neutral': len(perm)},
        'slot_conflicts': slot_conflicts,
        'multi_role_fields': multi_role_fields,
        'naming_evidence_links': sorted(naming_evidence.keys()),
        'naming_evidence': naming_evidence,
    }
    residue = []
    def _add(name, count, locations, why):
        if count:
            residue.append({'category': name, 'count': count,
                            'locations': locations[:10], 'why_not_fixed': why})
    _add('nil_clear_statements', dec['nil_clear_statements'],
         _locations(_code_segments(decrypted), r'\bnil\b'),
         'needs flow analysis (later reads / closure captures); '
         'textual removal would be unsound')
    _add('kept_loops', len(kept),
         [k['cfg_line'] for k in kept],
         'linearize proof failure (dynamic transition / missing '
         'entry / unreachable leaves); kept original loop is correct')
    _add('helper_definitions_dead', dec['helper_cache_refs'],
         _locations(_code_segments(decrypted),
                     r'\.' + re.escape(roles.get('cache', '')) + r'\['),
         'positional table elements; deleting one shifts the '
         'permutation')
    _add('frag_string_call_sites', dec['frag_string_call_sites'],
         _locations(decrypted, r'\.' + re.escape(
             roles.get('fragment_field', '')) + r'"') if roles.get('fragment_field') else [],
         'blob chain through unclassified terminal closure; '
         'evaluating it would be payload-adjacent execution beyond '
         'the proven helper-shape scope')
    _add('slot_conflicts', len(slot_conflicts), [],
         'same table slot addressed by both linker phases; '
         'renaming would break identity')
    _add('plus_minus_residue', dec['plus_minus'],
         _locations(_code_segments(decrypted), r'\+-'),
         'clean.py folds digit/(` followers only; identifier '
         'followers left alone')
    _add('single_parens_kept', dec['single_parens'],
         _locations(_code_segments(decrypted), r'\(\d+\)'),
         'call/index contexts kept by the clean.py guard')
    _helpers = list(roles.get('numeric_helpers') or [])
    if roles.get('string_helper'):
        _helpers.append(roles['string_helper'])
    _add('unresolved_helper_calls', dec['unresolved_helper_calls'],
         _locations(_code_segments(decrypted),
                     r':(?:' + '|'.join(re.escape(h) for h in _helpers) + r')\(')
         if _helpers else [],
         'classified helper call sites that evaluation did not '
         'resolve (must be 0 on a complete run)')
    _add('probe_leaks', dec['probe_leaks'] + lin['probe_leaks'], [],
         'trace/probe markers must never appear in delivered source')
    qa['residue'] = residue
    return qa


def report_section(qa):
    d, lin = qa['decrypted'], qa['linearized']
    lines = ['\n## self-check QA (moonveil-qa/1)\n']
    lines.append(f"- luau-compile decrypted: {qa['compile_ok']}; "
                 f"literal-multiset equivalence after clean: "
                 f"{qa['equivalence_ok']}")
    c = qa['clean']
    lines.append(f"- clean passes applied: double-parens "
                 f"{c.get('double_parens', 0)}, safe single-parens "
                 f"{c.get('single_parens', 0)}, plus-minus "
                 f"{c.get('plus_minus', 0)}, local-nil-drop "
                 f"{c.get('local_nil_drop', 0)}, if-true-unwrap "
                 f"{c.get('if_true_unwrap', 0)}, negated-flip "
                 f"{c.get('negated_flip', 0)}")
    lines.append(f"- raw patterns in decrypted: unfolded constants "
                 f"{d['unfolded_pure_arith']}, `if true` "
                 f"{d['if_true']}, negated conditionals "
                 f"{d['negated_conditionals']}, double parens "
                 f"{d['double_parens']}, plus-minus residue "
                 f"{d['plus_minus']}, nil-init decls "
                 f"{d['nil_init_decls']}, nil-clear statements "
                 f"{d['nil_clear_statements']}")
    lines.append(f"- link residue in decrypted: unresolved helper "
                 f"calls {d['unresolved_helper_calls']}, cache-or "
                 f"sites {d['cache_or_sites']}, helper cache refs "
                 f"(definitions) {d['helper_cache_refs']}, fragment "
                 f"string-call sites {d['frag_string_call_sites']}, "
                 f"probe leaks {d['probe_leaks'] + lin['probe_leaks']}")
    lines.append(f"- structuring: linearized tier-B blocks "
                 f"{lin['tierB_blocks']}, KEPT loops "
                 f"{qa['kept_loop_count']} "
                 f"({'; '.join(k['function'] + ': ' + k['reason'] for k in qa['kept_loops']) or 'none'})")
    lines.append(f"- names: INFERRED {qa['names']['inferred']} / "
                 f"neutral {qa['names']['neutral']}; slot conflicts: "
                 f"{qa['slot_conflicts'] or 'none'}; links with "
                 f"string-key evidence: "
                 f"{qa['naming_evidence_links'] or 'none'}")
    if qa['residue']:
        lines.append('- defects detected but NOT fixed (residue):')
        for r in qa['residue']:
            lines.append(f"  - {r['category']}: {r['count']} "
                         f"(locations {r['locations']}) — "
                         f"{r['why_not_fixed']}")
    else:
        lines.append('- defects detected but NOT fixed: none')
    return '\n'.join(lines) + '\n'
