#!/usr/bin/env python3
"""clean.py — semantics-preserving cleanup passes for MoonVeil output.

Applied to the DECRYPTED source (after substitution, before linearize)
in moonveil2. Every pass is deliberately narrow; anything it cannot
prove safe is left untouched and counted as residue by qa.py instead
of being silently rewritten.

Passes (all operate on CODE segments only — strings and comments are
split out first with fold.split_segments, so a `+-` or `((5))` inside
a string literal, e.g. the L1982 encoded blob, is never touched):

  P1 double-paren collapse: `((N))` -> `(N)` for bare integer
     literals. The inner pair is redundant in every context.
  P2 safe single-paren collapse: `(N)` -> `N` only when the `(` is
     NOT a call/index context (previous token is not a non-keyword
     identifier, `]` or `)`) and the next token is not `(`, `[`,
     `:` or `.`, AND no token glue can occur (a keyword directly
     hugging the paren, e.g. `or(232)`, is kept — collapsing it
     would produce the identifier `or232`). So `x(5)` (call args),
     `a[ (5) ]`-style index contexts and `(5)..` concat-glue
     cases are all kept.
  P3 plus-minus spelling: `+-` -> `-` when followed by a digit or
     `(` (`a+-77` is `a + (-77)`). `+-` followed by an identifier
     is left alone (counted as residue).
  P4 local-decl trailing-nil drop: `local a, b = 1, nil` ->
     `local a, b = 1`; `local a = nil` -> `local a`. Safe ONLY for
     local declarations (uninitialised locals default to nil);
     trailing nils in an ASSIGNMENT to existing variables are
     never dropped (`a, b = 1, nil` keeps `b`'s old value if the
     nil is removed, so that shape is out of scope).
  P5 if-true unwrap: `if true then <straight-line body> end` ->
     body, only when the body contains no block keywords
     (if/for/while/function/repeat/else/elseif/end) at all, so no
     nesting or else-branch can be mishandled.
  P6 negated-comparison flip: `if|elseif not (a <op> b) then` ->
     `if|elseif a <flipped-op> b then` for a single comparison
     whose operands are identifiers/dotted names or integer
     literals (no and/or, no calls). `not x` on a bare value is
     NOT flipped (boolean coercion differs from the value).

Deliberately NOT done (traps found in the 2026-10-24 audit):
  - `1/-0` is never rewritten: division by negative zero is -inf,
    and `/0` would give +inf. Any `-0` folding is out of scope.
  - nil-clearing assignments (`b,i,_=nil,nil,nil`) are never
    removed: proving one dead needs flow analysis (later reads,
    closure captures) this module does not do.
  - helper definitions are never removed: they are positional
    table elements; deleting one shifts the permutation.
  - no renaming: a conflicted slot (e.g. field `m`, `q`) is
    addressed by both linker phases, so renaming would break
    identity. Conflicts are reported by qa.py, not renamed here.

clean_source(src) -> (cleaned_src, stats) where stats counts each
pass and lists up to 20 pre-clean line locations per pass.
"""
import re

KEYWORDS = {
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
    'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
    'repeat', 'return', 'then', 'true', 'until', 'while',
}

_FLIP = {'==': '~=', '~=': '==', '<': '>=', '>': '<=',
         '<=': '>', '>=': '<'}


def _line_of(text, pos, start_line):
    return start_line + text[:pos].count('\n')


def _split_top_commas(s):
    """Split on top-level commas (depth over () [] {} only)."""
    parts, depth, cur = [], 0, []
    for ch in s:
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        if ch == ',' and depth == 0:
            parts.append(''.join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append(''.join(cur))
    return parts


def _clean_segment(seg, start_line, stats, locs):
    # P1: double parens around a bare integer literal, repeatedly
    # (handles triple+ parens too).
    pat1 = re.compile(r'\(\((\d+)\)\)')
    while True:
        m = pat1.search(seg)
        if not m:
            break
        locs['double_parens'].append(_line_of(seg, m.start(), start_line))
        seg = seg[:m.start()] + '(' + m.group(1) + ')' + seg[m.end():]
        stats['double_parens'] += 1

    # P2: safe single-paren collapse. Token-glue guard: collapsing
    # must never join two word characters across the removed
    # parens, so a keyword directly hugging the paren (e.g.
    # `or(232)` or `return(5)`, no whitespace) is KEPT — removing
    # the parens there would produce `or232` / `return5`.
    out, i = [], 0
    for m in re.finditer(r'\((\d+)\)', seg):
        # previous non-space token/char
        j = m.start() - 1
        while j >= 0 and seg[j] in ' \t\r\n':
            j -= 1
        prev_ok = False
        if j < 0:
            prev_ok = True
        elif seg[j] in ',;=<>~+-*/%^#(':
            prev_ok = True
        elif seg[j].isalnum() or seg[j] == '_':
            k = j
            while k >= 0 and (seg[k].isalnum() or seg[k] == '_'):
                k -= 1
            word = seg[k + 1:j + 1]
            # keyword hugging the paren with no whitespace glues
            prev_ok = word in KEYWORDS and (j + 1 < m.start())
        # next non-space token/char
        k = m.end()
        while k < len(seg) and seg[k] in ' \t\r\n':
            k += 1
        next_ok = False
        if k >= len(seg):
            next_ok = True
        elif seg[k] in ',);':
            next_ok = True
        elif seg[k] in '+-*/%^<>~=':
            next_ok = True
        elif seg[k].isalnum() or seg[k] == '_':
            e = k
            while e < len(seg) and (seg[e].isalnum() or seg[e] == '_'):
                e += 1
            # keyword hugging the paren with no whitespace glues
            next_ok = seg[k:e] in KEYWORDS and (m.end() < k)
        if prev_ok and next_ok:
            out.append(seg[i:m.start()])
            out.append(m.group(1))
            i = m.end()
            stats['single_parens'] += 1
            locs['single_parens'].append(
                _line_of(seg, m.start(), start_line))
        # else: kept, untouched
    out.append(seg[i:])
    seg = ''.join(out)

    # P3: `+-` before a digit or `(`.
    def _rep_pm(m):
        stats['plus_minus'] += 1
        locs['plus_minus'].append(_line_of(seg, m.start(), start_line))
        return '-' + m.group(1)
    seg = re.sub(r'\+-(\d|\()', _rep_pm, seg)

    # P4: local-decl trailing-nil drop.
    def _rep_local(m):
        names, rhs = m.group(1), m.group(2)
        if 'function' in rhs:
            return m.group(0)
        parts = _split_top_commas(rhs)
        stripped = [p.strip() for p in parts]
        kept = list(stripped)
        while kept and kept[-1] == 'nil':
            kept.pop()
        if len(kept) == len(stripped):
            return m.group(0)
        stats['local_nil_drop'] += 1
        locs['local_nil_drop'].append(
            _line_of(seg, m.start(), start_line))
        if not kept:
            return 'local ' + names
        return 'local ' + names + ' = ' + ', '.join(kept)
    seg = re.sub(r'local\s+([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)'
                 r'\s*=\s*([^\n;]+)', _rep_local, seg)

    # P5: `if true then <straight-line body> end` -> body.
    block_kw = r'(?:if|for|while|function|repeat|until|else|elseif|end)\b'
    pat5 = re.compile(
        r'if\s+true\s+then\s*((?:(?!\b' + block_kw + r').)*?)\s*end\b',
        re.S)
    def _rep_true(m):
        stats['if_true_unwrap'] += 1
        locs['if_true_unwrap'].append(
            _line_of(seg, m.start(), start_line))
        return m.group(1)
    seg = pat5.sub(_rep_true, seg)

    # P6: negated single comparison flip.
    pat6 = re.compile(
        r'((?:if|elseif)\s+)not\s*\('
        r'([\w.]+|-?\d+)\s*(==|~=|<=|>=|<|>)\s*([\w.]+|-?\d+)\)'
        r'(\s*then\b)')
    def _rep_not(m):
        stats['negated_flip'] += 1
        locs['negated_flip'].append(
            _line_of(seg, m.start(), start_line))
        return (m.group(1) + m.group(2) + ' ' + _FLIP[m.group(3)] +
                ' ' + m.group(4) + m.group(5))
    seg = pat6.sub(_rep_not, seg)
    return seg


def clean_source(src):
    """Return (cleaned_src, stats). stats['locations'] holds up to
    20 pre-clean line numbers per pass (for the audit trail)."""
    import fold as fold_mod
    stats = {'double_parens': 0, 'single_parens': 0, 'plus_minus': 0,
             'local_nil_drop': 0, 'if_true_unwrap': 0,
             'negated_flip': 0}
    locs = {k: [] for k in stats}
    parts, line = [], 1
    for kind, seg in fold_mod.split_segments(src):
        if kind == 'str':
            parts.append(seg)
        else:
            parts.append(_clean_segment(seg, line, stats, locs))
        line += seg.count('\n')
    stats['locations'] = {k: sorted(set(v))[:20] for k, v in locs.items()}
    stats['total_fixed'] = sum(stats[k] for k in
                                ('double_parens', 'single_parens',
                                 'plus_minus', 'local_nil_drop',
                                 'if_true_unwrap', 'negated_flip'))
    return ''.join(parts), stats
