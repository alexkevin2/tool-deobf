#!/usr/bin/env python3
"""Static deobfuscation pipeline for MoonVeil (moonveil.cc).

MoonVeil ships (at least) two compile types:
  - "vm" (vmType "fox"): a state-machine interpreter — one big
    `repeat ... until` dispatch over a numeric state variable, branches
    chosen by an if/elseif comparison tree; each leaf performs one
    operation and computes the next state arithmetically.
  - "safeEnv": source-level control-flow flattening — the same
    state-machine shape wrapped around the original statements, plus
    string encryption via a bit32.bxor helper.

This module is STATIC (no execution):
  1. detect   header version / VM fingerprint / CFF fingerprint
  2. fold     numeric normalisation + constant folding (shared fold.py)
  3. strings  inventory of every string literal (escapes decoded)
  4. states   extract the dispatch tree leaves: guard path, statements,
              next-state assignments, call/return flags -> states.json

Full devirtualisation of the fox VM is build-specific RE (like the
Luraph v15.1 engine was for its build) and, per community research,
MoonVeil's string decryption is environment-locked to a real Roblox
client, so dynamic dumping belongs in-game. This pipeline therefore
reports PARTIAL with complete static artifacts.

Usage: moonveil.py <input.lua> [-o outdir]
"""
import argparse, hashlib, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fold as fold_mod
import extract_vm

HEADER_RE = re.compile(r'generated using MoonVeil\s+([0-9][0-9.]*)')

def detect(src):
    m = HEADER_RE.search(src[:2000])
    head = src[:4000]
    # fox VM wrapper: return({{}, function(...) ...}) — keep this strict;
    # a loose `return({` + repeat + 0x test also matches Luraph builds.
    fox = bool(re.search(r'return\s*\(\s*\{\s*\{\s*\}\s*,\s*function', head))
    # safeEnv/CFF builds open by aliasing bit32.bxor & friends into locals
    # M1 (fingerprint audit P0): the old Luraph-only veto was not enough —
    # a header-stripped Luraph bootstrap build (setmetatable VM table,
    # MY blob, Fz builder) trips this shape. Veto all three Luraph
    # bootstrap markers; a genuine header-stripped MoonVeil CFF build
    # has none of them, so the shape fallback keeps its purpose.
    cff = ('bit32.bxor' in src[:1000] and 'repeat' in src and not m
           and 'Luraph' not in src[:1000]
           and 'setmetatable({' not in src[:4096]
           and 'MY=[==[' not in src
           and not re.search(r'\bFz\s*=\s*function', src))
    return {'version': m.group(1) if m else None,
            'header': bool(m), 'fox_vm_shape': fox, 'cff_shape': cff}

def is_moonveil(src):
    d = detect(src)
    return d['header'] or d['fox_vm_shape'] or d['cff_shape']

# ------------------------------------------------------------------ tokens
def block_span(toks, i):
    """toks[i] is an opener (function/if/for/while/repeat/do); return index
    just past its matching end/until."""
    depth, pending_do, j = 0, 0, i
    while j < len(toks):
        t = toks[j][1]
        if toks[j][0] == 'word':
            if t in ('for', 'while'):
                depth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: depth += 1
            elif t in ('function', 'if', 'repeat'):
                depth += 1
            elif t == 'until':
                depth -= 1
                if depth == 0: return j + 1
            elif t == 'end':
                depth -= 1
                if depth == 0: return j + 1
        j += 1
    return j

def find_dispatches(toks):
    """Locate every dispatch loop: this MoonVeil profile spreads the VM
    over many functions, each with its own small state machine written as
    `repeat ... until false` or `while true do ... end`, driven by an
    if/elseif comparison tree over one state variable.
    Return [(start, end, state_var, kind)]."""
    out = []
    for i, (kind, txt, s0, e0) in enumerate(toks):
        kind_loop = None
        if kind == 'word' and txt == 'repeat':
            kind_loop = 'repeat'
        elif kind == 'word' and txt == 'while':
            nxt = [t[1] for t in toks[i + 1:i + 6] if t[0] == 'word']
            if nxt[:1] == ['true']:
                kind_loop = 'while'
        if not kind_loop:
            continue
        end = block_span(toks, i)
        body = toks[i:end]
        if sum(1 for t in body if t[1] == 'if') < 2:
            continue
        counts = {}
        for a, b in zip(body, body[1:]):
            if a[0] == 'word' and b[1] in ('<', '>', '==', '~=', '<=', '>='):
                counts[a[1]] = counts.get(a[1], 0) + 1
            if b[0] == 'word' and a[1] in ('<', '>', '==', '~=', '<=', '>='):
                counts[b[1]] = counts.get(b[1], 0) + 1
        if not counts or max(counts.values()) < 3:
            continue
        out.append((i, end, max(counts, key=counts.get), kind_loop))
    return out

def split_branches(toks, i):
    """toks[i] is 'if'. Return (branches, next_i) where branches is a list of
    (cond_text, body_toks) including a final (None, body) for else."""
    branches = []
    j = i + 1
    cond_start = j
    depth = 0
    while j < len(toks):
        t = toks[j][1]
        if toks[j][0] == 'word' and t in ('function', 'for', 'while', 'repeat', 'if', 'do'):
            depth += 1
        elif toks[j][0] == 'word' and t in ('end', 'until'):
            depth -= 1
        if depth == 0 and toks[j][1] == 'then':
            break
        j += 1
    cond = toks[cond_start:j]
    body_start = j + 1
    k, depth, pending_do = body_start, 0, 0
    while k < len(toks):
        t = toks[k][1]
        if toks[k][0] == 'word':
            if t in ('for', 'while'):
                depth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: depth += 1
            elif t in ('function', 'repeat', 'if'):
                depth += 1
            elif t in ('end', 'until'):
                if depth == 0:
                    branches.append((cond, toks[body_start:k]))
                    return branches, k + 1
                depth -= 1
            elif t in ('elseif', 'else') and depth == 0:
                branches.append((cond, toks[body_start:k]))
                if t == 'else':
                    e = block_end_at(toks, k)
                    branches.append((None, toks[k + 1:e]))
                    return branches, e + 1
                sub, nxt = split_branches_elseif(toks, k)
                branches.extend(sub)
                return branches, nxt
        k += 1
    branches.append((cond, toks[body_start:k]))
    return branches, k

def block_end_at(toks, i):
    """Index of the 'end' closing the if that an else at i belongs to:
    scan forward with depth counting from 1."""
    depth, j, pending_do = 1, i + 1, 0
    while j < len(toks):
        t = toks[j][1]
        if toks[j][0] == 'word':
            if t in ('for', 'while'): depth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: depth += 1
            elif t in ('function', 'repeat', 'if'): depth += 1
            elif t in ('end', 'until'):
                depth -= 1
                if depth == 0: return j
        j += 1
    return j - 1

def split_branches_elseif(toks, i):
    """toks[i] is 'elseif' at the chain level: fabricate an if-token view."""
    branches = []
    j = i + 1
    cond_start = j
    depth = 0
    while j < len(toks):
        t = toks[j][1]
        if toks[j][0] == 'word' and t in ('function', 'for', 'while', 'repeat', 'if', 'do'):
            depth += 1
        elif toks[j][0] == 'word' and t in ('end', 'until'):
            depth -= 1
        if depth == 0 and toks[j][1] == 'then':
            break
        j += 1
    cond = toks[cond_start:j]
    body_start = j + 1
    k, depth, pending_do = body_start, 0, 0
    while k < len(toks):
        t = toks[k][1]
        if toks[k][0] == 'word':
            if t in ('for', 'while'):
                depth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: depth += 1
            elif t in ('function', 'repeat', 'if'):
                depth += 1
            elif t in ('end', 'until'):
                if depth == 0:
                    branches.append((cond, toks[body_start:k]))
                    return branches, k + 1
                depth -= 1
            elif t in ('elseif', 'else') and depth == 0:
                branches.append((cond, toks[body_start:k]))
                if t == 'else':
                    e = block_end_at(toks, k)
                    branches.append((None, toks[k + 1:e]))
                    return branches, e + 1
                sub, nxt = split_branches_elseif(toks, k)
                branches.extend(sub)
                return branches, nxt
        k += 1
    branches.append((cond, toks[body_start:k]))
    return branches, k

def text_of(src, toks):
    if not toks: return ''
    return src[toks[0][2]:toks[-1][3]]

def extract_states(src, toks, lo, hi, state_var):
    """Walk the dispatch region; every leaf statement-run becomes a state."""
    states = []
    def walk(region, guard):
        i = 0
        run = []
        def flush():
            if run:
                states.append((list(guard), list(run)))
                run.clear()
        while i < len(region):
            kind, txt = region[i][0], region[i][1]
            if kind == 'word' and txt == 'if':
                flush()
                branches, nxt = split_branches(region, i)
                for cond, body in branches:
                    g = guard + [text_of(src, cond).strip()] if cond is not None else guard + ['else']
                    walk(body, g)
                i = nxt
                continue
            if kind == 'word' and txt in ('for', 'while', 'function', 'repeat'):
                end = block_span(region, i)
                run.extend(region[i:end])
                i = end
                continue
            run.append(region[i])
            i += 1
        flush()
    walk(toks[lo:hi], [])
    out = []
    assign_re = re.compile(r'(?<![A-Za-z0-9_.])' + re.escape(state_var) + r'\s*=(?![=~])')
    for guard, rtoks in states:
        text = text_of(src, rtoks).strip()
        if not text:
            continue
        nxt = assign_re.findall(text)
        out.append({'guard': ' and '.join(g for g in guard if g) or '(entry)',
                    'statements': text[:600],
                    'next_state_assigns': len(nxt),
                    'has_call': '(' in text,
                    'has_return': bool(re.search(r'\breturn\b', text))})
    return out

def string_inventory(src):
    vals = []
    for kind, seg in fold_mod.split_segments(src):
        if kind == 'str' and seg[:1] in ('"', "'"):
            try:
                vals.append(extract_vm.luau_unescape(seg))
            except Exception:
                pass
    return vals

def main():
    ap = argparse.ArgumentParser(description='Static MoonVeil deobfuscation')
    ap.add_argument('input')
    ap.add_argument('-o', '--outdir', default=None)
    args = ap.parse_args()
    data = open(args.input, 'rb').read()
    src = data.decode('utf-8', errors='strict')
    sha = hashlib.sha256(data).hexdigest()
    outdir = args.outdir or os.path.splitext(os.path.basename(args.input))[0] + '-moonveil-deobf'
    os.makedirs(outdir, exist_ok=True)
    det = detect(src)
    print(f"[0] input {args.input}  {len(data)} bytes  sha256={sha[:16]}...")
    print(f"[1] detect: {det}")
    # M4 (fingerprint audit P2): record the version but never branch on
    # it; warn when it is not 2.1.0, the only version with a verified
    # linker pipeline — "header matched" must not be read as "linker
    # pipeline applies".
    if det['version'] and det['version'] != '2.1.0':
        print(f"    [!] header version {det['version']} is not 2.1.0 "
              f"(only 2.1.0 has a verified linker pipeline); "
              f"static extraction only")
    if not is_moonveil(src):
        print("    not a recognised MoonVeil build; aborting")
        return 2
    folded = fold_mod.fold_source(src)
    open(os.path.join(outdir, 'folded.luau'), 'w', encoding='utf-8').write(folded)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes")
    strings = string_inventory(src)
    with open(os.path.join(outdir, 'strings.txt'), 'w', encoding='utf-8') as f:
        for s in strings:
            f.write(repr(s) + '\n')
    print(f"[3] strings: {len(strings)} literals")
    toks = list(extract_vm._tokens(folded))
    disps = find_dispatches(toks)
    states = []
    for li, (lo, hi, var, kind_loop) in enumerate(disps):
        for st in extract_states(folded, toks, lo + 1, hi - 1, var):
            st['loop'] = li
            st['loop_kind'] = kind_loop
            st['state_var'] = var
            states.append(st)
    state_var = disps[0][2] if disps else None
    json.dump(states, open(os.path.join(outdir, 'states.json'), 'w'), indent=1)
    print(f"[4] states: {len(states)} leaf blocks across {len(disps)} dispatch loops")
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write("# moonveil-deobf report (static)\n\n")
        f.write(f"- input: `{os.path.basename(args.input)}` ({len(data)} bytes, sha256 `{sha}`)\n")
        f.write(f"- detect: {det}\n")
        f.write(f"- string literals: {len(strings)}\n")
        f.write(f"- dispatch loops found: {len(disps)}; leaf blocks extracted: {len(states)}\n")
        f.write("- status: **PARTIAL** — static pipeline (fold + strings + state graph).\n")
        f.write("  Full fox-VM devirtualisation is per-build RE; MoonVeil string\n")
        f.write("  decryption is environment-locked to a real Roblox client.\n")
    print(f"done (PARTIAL static) -> {outdir}")
    return 5

if __name__ == '__main__':
    sys.exit(main())
