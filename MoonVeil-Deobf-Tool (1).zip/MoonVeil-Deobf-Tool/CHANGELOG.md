# MoonVeil-Deobf-Tool changelog

## v1.2.0 (2026-10-24) — self-audit round: clean passes + baked-in QA

Self-audit of the v1.1.0 outputs (full defect list with file + line
+ snippet + count: `tests/qa-audit-2026-10-24.md`). The audit's
honest headline: v1.1.0 was already strong where rot was expected
(pure-numeric arithmetic 0, `if true` 0, `elseif not` 0, helper
call sites remaining 0, probe leaks 0). The real residue was
narrower, and this release fixes what is provable and reports the
rest on every run.

### New: clean.py (applied to decrypted AND linearized, each gated)

- Double-paren collapse `((N))` -> `(N)`; safe single-paren
  collapse `(N)` -> `N` (call/index contexts kept; keyword-hug
  guard: `or(232)` stays `or(232)`, never `or232` — a token-glue
  bug caught in the author's own first draft of the pass).
- `+-` spelling -> `-` for digit/`(` followers (`G+-77` -> `G-77`).
- Local-decl trailing-nil drop (`local a, b = 1, nil` ->
  `local a, b = 1`). Assignment trailing nils are NEVER dropped
  (`a, b = 1, nil` keeps `b`'s old value without the nil).
- `if true then <straight-line body> end` unwrap and
  negated-comparison flip (`elseif not (a < 5)` -> `elseif a >= 5`),
  both no-ops on the golden but synthetic-tested for future builds.
- Gates per stage: literal-multiset equivalence + luau-compile
  PASS, else revert to uncleaned output (recorded in qa_report).
  Golden result: decrypted 1,060 fixes (483 double-parens, 374
  single-parens, 203 plus-minus), linearized +1 reflow site
  (`e=(178)` standalone Tier B line); both files compile.
- Deliberately NOT done: `1/-0` (division by negative zero is
  -inf; `/0` would flip the sign); nil-clearing writes (need flow
  analysis); helper-definition removal (positional elements);
  slot renaming (shared slots); blob-chain evaluation (see below).

### New: qa.py + qa_report.json + report QA section (every run)

- Schema `moonveil-qa/1`, measured on the DELIVERED files:
  raw patterns (unfolded constants 0, `if true` 0, negated 0,
  double parens 0, plus-minus residue 3, nil-init decls 0,
  nil-clear statements 105), link residue (unresolved helper
  calls 0, cache-or sites 0, helper cache refs 10 = definitions,
  fragment string-call sites 1, probe leaks 0), structuring
  (tier-B blocks 752, KEPT loops 4 with reasons), names
  (INFERRED 0 / neutral 97), slot conflicts, and `residue` with
  locations + why-not-fixed for every unfixed class.
- Naming evidence (`naming_evidence.json`, all labels neutral):
  link `F` references 25 stdlib/metamethod string keys
  (`type`, `pcall`, `pairs`, …), link `ya` references `__call`,
  `__iter` — evidence the tool previously computed nowhere.
  Evidence is gathered span-aware from the substituted source, so
  a `["x"]`-shaped substring inside the encoded blob can never
  fake a key (a bug in the first draft: code-segment-only regex
  can never match `["key"]` at all, since the quotes live in a
  string segment).
- Slot/link-reuse detection: fields `m` (combiner + instantiated)
  and `q` (fragment field + instantiated + blob-chain head) are
  flagged as conflicts in qa_report; they are NOT renamed (same
  table slot, both linker phases — renaming breaks identity).

### Residue that stays residue (honest, counted per run)

- 105 nil-clear statements (flow analysis required).
- 4 KEPT loops: #6 (Pa) dynamic `E`@208, #57 (s) entry not found,
  #60 (S) unreachable leaves, #89 (F) dynamic `C`@58.
- 10 helper-definition lines (dead scaffolding, table-shape).
- 1 blob chain (`decrypted.luau` L1982:
  `a.F(a.t(a.q"<encoded blob>"))`) — terminal `F` unclassified;
  evaluating the chain would be payload-adjacent execution beyond
  the proven helper-shape scope, so it stays verbatim + flagged.
- 490 single parens kept by guard, 3 `+-` identifier followers.
- Router known gap (unchanged): header-stripped foreign files are
  not vetoed (veto window = first 4096 chars, header-dependent);
  no validated discriminator exists in the corpus, so none was
  invented.

### Golden re-pin (documented diff, tool-regenerated only)

- `sample/output/decrypted.luau`: sha256 `181646aa…` (was
  `2c68b99b…`); `linearized.luau`: `dd7229a4…` (was `c8936f6d…`).
  Diff per byte class: removed parens + `+-` -> `-` ONLY —
  verified mechanically: new decrypted == clean(old decrypted)
  byte-for-byte, new linearized == clean(old linearized)
  byte-for-byte. `cfg.md`, `constants.json`, `roles.json`,
  `states.json`, `strings.json` are byte-identical to v1.1.0.
  The published deliverable `MoonVeil-Loader-2.1.0-deobf/` is NOT
  overwritten by this release (it is the v1.1.0-era artifact;
  republishing it from v1.2.0 output is a separate decision).
- Regression suite extended (C1 clean unit checks incl. glue
  guards + traps, Q1 QA assertions pinned to the golden numbers,
  G2 QA-on-off-mode, G6 full-run determinism across
  PYTHONHASHSEED, S2 now also audits clean.py/qa.py for
  hardcoded IDs). M1–M5 fingerprint rules untouched and green;
  router.py untouched; spoof_engine byte-identity (S1) still
  holds; no hardcoded game IDs in production code (S2).

## v1.1.0 (2026-10-24) — fingerprint upgrades + shared spoof-engine port

Corpus at time of release: 12 samples
(`~/luau-deobf/corpus/`, INDEX.md + corpus.json). Golden:
MoonVeil 2.1.0 loader `57b458d4` (FULL/decrypted). Negatives:
plain ouroboros loader `d2d86e68` (must exit 2),
StealAnEggs `4c174a06` (must NOT route to MoonVeil).

### Fingerprint proposals applied (FINGERPRINT-REPORT.md §3.2)

- **M1 (P0)** — `moonveil.py:detect()` CFF shape: added vetoes for
  the Luraph bootstrap markers (`setmetatable({` VM table in first
  4096 chars, `MY=[==[` blob, `\bFz=function`) alongside the
  existing `Luraph` veto. Verified: header-stripped StealAnEggs
  went from CFF True (misroute) to False; no corpus golden changed.
- **M2 (P1)** — new `router.py`: unified router, precedence
  foreign-header reject -> linker-tail + cache-idiom + helper-shape
  -> moonveil2 -> static (header/fox/CFF) -> exit 2. CORRECTION to
  the audit: its "no other file has tail + cache" guard claim does
  NOT hold — the AntiLua unversioned loader (`db64db2b`) matches
  the tail regex AND the cache idiom (field `qd` x3222) AND the
  pos-element helper shapes (4 numeric + 1 string). The router
  therefore checks known foreign headers FIRST; without that veto
  the loader would misroute into moonveil2. Router result on all
  12 corpus samples: only the MoonVeil sample routes to moonveil2,
  the other 11 reject.
- **M3 (P1)** — `moonveil2.py`: tail-matched but zero permutation
  recovered, cache idiom not found, or no helpers classified now
  return **2** (not this profile) with the tail evidence printed,
  instead of 5. Exit 5 is kept for genuine partial decryption
  (helpers found, some sites unevaluated). Goldens unaffected
  (sample classifies helpers).
- **M4 (P2)** — `moonveil.py` main: header version is recorded but
  never branched on; a warning is printed when it is not `2.1.0`
  (the only version with a verified linker pipeline).
- **M5 (P2)** — fox shape: strict `return({{},function` regex kept
  exactly as-is (loosening it would match jjs's `return({`); no
  code change, covered by regression D1.
- Caveat (audit §3.3, unchanged): no fox-VM or safeEnv/CFF
  MoonVeil sample exists in the corpus — M1/M5 are conservative
  vetoes/preservations, NOT trained fox/CFF numeric thresholds.

### Spoof-engine port (SPOOF-SPEC §10, MoonVeil checklist)

- Vendored `spoof_engine.py` next to `moonveil2.py`, byte-identical
  to the Luraph v6 canonical copy (sha256 `d33daef8...`, verified
  by regression S1 on every run).
- `trace_template.luau`: game proxy `__index` now serves identity
  fields from a driver-injected seed table (seed-literal
  substitution, same pattern as Luraph's `runner_behavior.luau`),
  logs every identity read (`[IDREAD] field value seed|probe`),
  and serves `PROBE_VALUE` (imported from the engine, never
  retyped) for unseeded reads. When spoofing is off the hook is
  inert and the trace log is unchanged (modulo Luau runtime
  pointer addresses, which vary between any two runs).
- New AST gate scanner in `moonveil2.py` over the RECOVERED source
  (via bundled `luau-ast`; regex fallback if unavailable): `==` /
  `~=` / bound comparisons on `game.<field>` and set-membership
  (`table[game.<field>]` with keys recovered from assignments /
  constructors) feed `collect_events()`. The raw blob is never
  scanned. Extra (non-canonical) `game.*` fields are reported
  separately (`extra_field`).
- Driver: `run_trace()` runs `plan_forks()` (same caps as the
  engine) and emits unified `identity_report.json`
  (`spoof-engine/1`) + a report section; CLI `--spoof-id auto|off`
  (default `auto`; off = legacy behaviour, no identity artifacts).
  Auto runs without `--trace` emit a scan-only report
  (`forks: []`). Branch rule: real runs stay `unclassified` —
  no validated MoonVeil decoy signature exists, so no `gate-pass`
  label is inferred (a caller-supplied `is_pass` rule is required,
  as the synthetic test supplies).
- Validation: the MoonVeil 2.1.0 sample has no identity gate in its
  recovered source, so its report honestly says `gates: []`,
  `unknown_fields: []` (1 unclassified fork, HttpGet fired by the
  loader itself, not claimed as gate-pass). The synthetic fixture
  (`tests/fixtures/gate_fixture.luau`, invented test values only)
  proves the full path: eq-const + set-membership candidates,
  fork 0 seeds the eq value and takes the GATE-PASS-EQ branch,
  fork 1 seeds the set value and takes GATE-PASS-SET, report
  emitted, off-mode byte-identical with no identity artifacts.
- Audit (regression S2): 0 game-ID literals in production code;
  the only ID-shaped literal is the probe marker (documented, not
  a game ID). Nothing fetched on any spoof path.

### vs previous zip (`MoonVeil-Deobf-Tool.zip` sha256 `013968e7...`)

- Added: `spoof_engine.py`, `router.py`, `CHANGELOG.md`, `tests/`
  (regression suite + synthetic gate fixture).
- Changed: `moonveil.py` (M1, M4), `moonveil2.py` (M3, `--spoof-id`,
  gate scanner, fork driver, scan-only report),
  `trace_template.luau` (seed/probe game-proxy hook),
  `run_sample.sh` (also asserts the sample identity report),
  `README.md` (router + spoofing docs, package version).
- Unchanged (byte-identical under legacy/off modes): sample
  `decrypted.luau`, `linearized.luau`, `constants.json`,
  `roles.json`, `states.json`, `strings.json`, `cfg.md`.
