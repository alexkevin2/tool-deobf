# MoonVeil Deobf Tool (standalone) — package v1.2.0

Deobfuscator for **MoonVeil 2.x "linker" builds** — the profile where
the chunk returns a table of ~97 entries and calls a linker method on
it: `return({...}):l({names...}, "Entry", ...)`.

## How it works (everything is discovered from the file itself)

1. Parses the tail call -> names array, entry name, stripped chunk.
2. Folds literals (hex/binary/underscores -> decimal).
3. Links the table in a Luau harness with a bogus entry name and
   recovers the name->function permutation by function identity.
4. Classifies the context's decrypt helpers by body shape
   (`a.<cache>[k] = <expr>; return a.<cache>[k]`), finds the string
   combiner + fragment decoder field, and parses the entry's
   builder-instantiation list.
5. Evaluates every numeric-constant and string decrypt call site in
   the harness and substitutes the real values back into the source.

Because names/roles are discovered per file, other 2.x builds with
the same architecture (including older ones) work without changes.
Builds with a different architecture fall back to `moonveil.py`
(static fold + string inventory + state-graph extraction, PARTIAL).

## Usage

    python3 moonveil2.py <input.lua> [-o outdir] [--luau path]
    python3 router.py <input.lua>        # unified router (see below)
    python3 tests/check_moonveil.py      # full regression suite

Outputs: decrypted.luau (constants + strings substituted, clean
passes applied, compiles clean), linearized.luau (dispatch trees
rewritten as flat state-labelled blocks — per-function graphs in
cfg.md; loops that cannot be proven equivalent keep their original
form), constants.json, strings.json, roles.json, states.json,
report.md, qa_report.json (self-check QA, moonveil-qa/1 — see
below), naming_evidence.json (string-key evidence per link name,
all labelled neutral). With `--trace` the chunk is also
executed in a mocked Roblox environment (HttpGet/loadstring stubbed —

## Self-check QA (v1.2.0)

Every run writes `qa_report.json` and appends a QA section to
`report.md`, measured on the DELIVERED files: raw-pattern counts
(unfolded constants, `if true`, negated conditionals, double
parens, plus-minus residue, nil-init decls, nil-clear statements),
link residue (unresolved helper calls, cache-or sites, helper
cache refs, fragment string-call sites, probe leaks), structuring
(tier-B blocks, KEPT loops with reasons), name ratios (INFERRED 0
/ neutral 97 on the golden — this tool assigns no semantic names),
slot conflicts, and `residue`: every defect detected but NOT fixed,
with locations and the reason it was left alone. Clean passes
(`clean.py`: double-paren collapse, safe single-paren collapse,
`+-` spelling, local-decl trailing-nil drop, `if true` unwrap,
negated-comparison flip) run under two gates — literal-multiset
equivalence and luau-compile PASS — and revert to the uncleaned
output if either fails. Deliberately never done: removing
nil-clearing writes (needs flow analysis), removing helper
definitions (positional table elements), renaming conflicted slots
(same slot, both linker phases), evaluating the L1982 blob chain
(unclassified terminal closure), folding `1/-0` (sign of infinity).
See `tests/qa-audit-2026-10-24.md` for the full defect list that
drove this release.
remote code is never fetched) and trace.log records its behaviour.
Exit 0 = decrypted; 5 = PARTIAL; 2 = not this profile.

## Router (fingerprint audit M2)

`router.py` picks the entry point so the two MoonVeil profiles stop
being chosen by hand. Precedence, first match wins:

1. Foreign-family header (AntiLua / XHider / Luraph / luast) -> reject.
   This veto is load-bearing: the AntiLua unversioned loader matches
   the linker tail, the cache idiom and the helper shapes, so the
   tail+cache+helper check alone would misroute it into moonveil2.
2. Linker tail + cache idiom + helper shape -> `moonveil2`.
3. MoonVeil header / fox / CFF (M1-vetoed) -> `moonveil.py` (static).
4. Else -> reject (exit 2).

## Identity spoofing (shared spoof_engine port, SPOOF-SPEC §10)

`moonveil2.py --spoof-id auto|off` (default `auto`). The vendored
`spoof_engine.py` is byte-identical to the Luraph v6 canonical copy.
The gate scanner reads the **recovered** source (decrypted.luau) via
the bundled `luau-ast` (regex fallback if luau-ast fails) — never the
raw obfuscated blob. With `--trace`, the driver runs one mock trace
per fork from `plan_forks()` (game proxy `__index` serves fork seeds,
unseeded identity reads serve the probe marker and are logged) and
emits `identity_report.json` (unified `spoof-engine/1` schema) plus
an identity section in `report.md`. Without `--trace`, an auto run
still emits a scan-only report (`forks: []`).

Branch rule: there is **no validated MoonVeil decoy signature**, so
real-run forks are labelled `unclassified` by default; a `gate-pass`
label requires a caller-supplied `is_pass` rule (the synthetic test
in `tests/` supplies one). The bundled 2.1.0 sample has no identity
gate, so its report honestly says `gates: []`, `unknown_fields: []`.
`--spoof-id off` restores exact legacy behaviour: no identity
artifacts, primary outputs byte-identical to the pre-feature goldens.
No game ID literal exists in production code (audit in
`tests/check_moonveil.py` S2); test fixtures keep invented values
only as clearly-labelled test data. Nothing is ever fetched on any
spoof path; HttpGet stays an inert logged mock.

## Requirements

Python 3.10+. Luau CLI binaries bundled in `bin/` (Linux).

## Sample

`sample/Loader-MoonVeil-2.1.0.lua` — a real MoonVeil 2.1.0 loader
(StarCrow Hub): 790 numeric constants + 31 strings decrypted
(stdlib/metamethod names the VM hides). Run `./run_sample.sh`.
