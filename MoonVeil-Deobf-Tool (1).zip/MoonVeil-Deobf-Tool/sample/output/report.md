# MoonVeil 2.x linker-build deobfuscation (moonveil2)

- input: Loader-MoonVeil-2.1.0.lua (168970 bytes, sha256 57b458d441b9c93d433250fed562e2ca255897bc0991c053251d20fd4a363e3d)
- profile: linker `:l`, 97 named entries, entry `Ya`
- roles discovered: cache `Sa`; numeric helpers ['Ua', 'Va', 'Wa', 'Xa'];
  string helper `Ta` via combiner `m` + fragment field `q`
- decrypted: 790 numeric constants, 31 strings;
  899 call sites substituted; luau-compile: True
- state graph: 1481 leaf blocks (states.json)
- status: DECRYPTED (VM state machines remain as while-true dispatch with
  real constants/strings inline; run a mock-env trace to read behaviour)
- linearized.luau: {'loops': 45, 'tierA': 0, 'tierB': 41, 'kept': 4}, luau-compile: True (per-function graphs in cfg.md)

## self-check QA (moonveil-qa/1)

- luau-compile decrypted: True; literal-multiset equivalence after clean: True
- clean passes applied: double-parens 483, safe single-parens 374, plus-minus 203, local-nil-drop 0, if-true-unwrap 0, negated-flip 0
- raw patterns in decrypted: unfolded constants 0, `if true` 0, negated conditionals 0, double parens 0, plus-minus residue 3, nil-init decls 0, nil-clear statements 105
- link residue in decrypted: unresolved helper calls 0, cache-or sites 0, helper cache refs (definitions) 10, fragment string-call sites 1, probe leaks 0
- structuring: linearized tier-B blocks 752, KEPT loops 4 (#6 (Pa): dynamic transition in state 208: E; #57 (s): entry state not found; #60 (S): unreachable leaves remain; #89 (F): dynamic transition in state 58: C)
- names: INFERRED 0 / neutral 97; slot conflicts: ['m', 'q']; links with string-key evidence: ['F', 'ya']
- defects detected but NOT fixed (residue):
  - nil_clear_statements: 105 (locations [8, 8, 8, 15, 15, 15, 26, 26, 26, 35]) — needs flow analysis (later reads / closure captures); textual removal would be unsound
  - kept_loops: 4 (locations [6, 77, 79, 120]) — linearize proof failure (dynamic transition / missing entry / unreachable leaves); kept original loop is correct
  - helper_definitions_dead: 10 (locations [1000, 1001, 1899, 1900, 2342, 2343, 2501, 2502, 2533, 2534]) — positional table elements; deleting one shifts the permutation
  - frag_string_call_sites: 1 (locations [1982]) — blob chain through unclassified terminal closure; evaluating it would be payload-adjacent execution beyond the proven helper-shape scope
  - slot_conflicts: 2 (locations []) — same table slot addressed by both linker phases; renaming would break identity
  - plus_minus_residue: 3 (locations [2501, 2501, 2533]) — clean.py folds digit/(` followers only; identifier followers left alone
  - single_parens_kept: 490 (locations [31, 31, 56, 59, 59, 62, 62, 64, 64, 68]) — call/index contexts kept by the clean.py guard

## Identity spoofing (--spoof-id auto)

- no game-identity field reads found; no spoofing applied.
- note: gate scan: luau-ast over recovered source
- note: Gate scan over recovered source (decrypted.luau), never the raw blob.
- note: Trace not run; run with --trace for fork evidence (forks=[] here).
- full detail: identity_report.json
