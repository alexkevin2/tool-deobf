#!/usr/bin/env python3
"""Regression suite for MoonVeil-Deobf-Tool (package v1.2.0).

Covers: M1 CFF vetoes, M2 router precedence, M3 exit-2-on-no-helpers,
M5 strict fox regex (unchanged), spoof-engine port (byte-identity,
gate scan over recovered source, fork traces, off-mode byte-identity),
no-hardcode audit, determinism, v1.2.0 clean passes (clean.py) and
self-check QA (qa.py: raw-pattern counts, slot conflicts, name
ratios, residue). No payload is executed outside the
tool's own sandboxed trace runner; no remote fetch anywhere.

Usage: python3 tests/check_moonveil.py   (exit 0 = ALL CHECKS PASS)
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
import moonveil
import moonveil2
import router
import spoof_engine as se

CORPUS = '/home/hatch/luau-deobf/corpus/samples'
FAILURES = []


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] {name} {detail}")
    if not cond:
        FAILURES.append(name)


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def run_py(args, env=None):
    e = dict(os.environ)
    if env:
        e.update(env)
    return subprocess.run([sys.executable] + args, capture_output=True,
                          text=True, cwd=HERE, env=e, timeout=600)


# --- S1: vendored spoof engine byte-identical to canonical ---
CANON = '/home/hatch/luau-deobf/tools/Luraph-Deobf-Tool-v6/spoof_engine.py'
check('S1 spoof_engine byte-identical',
      sha(os.path.join(HERE, 'spoof_engine.py')) == sha(CANON),
      sha(os.path.join(HERE, 'spoof_engine.py'))[:16])

# --- S2: no-hardcode audit over production code ---
PROD = [f for f in ('moonveil.py', 'moonveil2.py', 'router.py', 'fold.py',
                    'extract_vm.py', 'linearize.py', 'clean.py', 'qa.py',
                    'trace_template.luau', 'spoof_engine.py')]
FIXTURE_IDS = {'123456789', '987654321'}
PROBE = '7777777777777'
hits, bad, probes = [], [], []
for f in PROD:
    text = open(os.path.join(HERE, f), encoding='utf-8').read()
    for m in re.finditer(r'\d{9,}', text):
        v = m.group(0)
        if v in FIXTURE_IDS:
            bad.append((f, v))
        elif v == PROBE:
            probes.append((f, v))
        else:
            hits.append((f, v))
check('S2 no fixture/test ID in production code', not bad, str(bad))
print(f"     probe-marker literals (allowed, NOT game IDs): {probes}")
print(f"     other 9+-digit literals (must be none): {hits}")
check('S2b other 9+-digit literals are probe-only',
      all(v == PROBE for _, v in hits), str(hits))

# --- D1: static detector over the corpus (import-only) ---
expected_detect = {}
for p in sorted(os.listdir(CORPUS)):
    src = open(os.path.join(CORPUS, p), encoding='utf-8',
               errors='replace').read()
    expected_detect[p] = moonveil.detect(src)
moon = [k for k, d in expected_detect.items() if d['header']]
check('D1 only MoonVeil sample has a MoonVeil header',
      len(moon) == 1 and moon[0].startswith('57b458d4'), str(moon))
check('D1 jjs fox shape stays False (M5 strict regex kept)',
      not expected_detect['54df32ac_jjs_khanhly_1878725522944274.luau']['fox_vm_shape'])
steal = open(os.path.join(CORPUS, '4c174a06_stealaneggs.luau'),
             encoding='utf-8', errors='replace').read()
stripped = re.sub(r'--[^\n]*Luraph[^\n]*\n', '', steal, count=1)
check('D1 header-stripped stealaneggs CFF False (M1)',
      not moonveil.detect(stripped)['cff_shape']
      and not moonveil.is_moonveil(stripped))

# --- D2: router precedence over the corpus ---
routes = {}
for p in sorted(os.listdir(CORPUS)):
    src = open(os.path.join(CORPUS, p), encoding='utf-8',
               errors='replace').read()
    routes[p] = router.route(src)[0]
check('D2 router: only MoonVeil sample -> moonveil2',
      routes['57b458d4_moonveil_loader_2.1.0.luau'] == 'moonveil2'
      and all(v == 'reject' for k, v in routes.items()
              if not k.startswith('57b458d4')), str(routes))
check('D2 router: plain ouroboros loader -> reject (exit 2)',
      routes['d2d86e68_ouroboros_loader.luau'] == 'reject')
check('D2 router: stealaneggs must NOT route to MoonVeil',
      routes['4c174a06_stealaneggs.luau'] == 'reject')

# --- D3: moonveil2 exit codes (M3 + negative control) ---
tmp = tempfile.mkdtemp(prefix='mv-check-')
try:
    plain = os.path.join(CORPUS, 'd2d86e68_ouroboros_loader.luau')
    r = run_py(['moonveil2.py', plain, '-o', os.path.join(tmp, 'plain'),
                '--spoof-id', 'off'])
    check('D3 plain loader -> exit 2', r.returncode == 2,
          f'rc={r.returncode}')
    m3src = ('return ({ l = function(self, names, entry) '
             'for i, n in ipairs(names) do self[n] = self[i] end end, '
             'function() return 42 end }):l({"a"}, "a", ...)\n')
    m3path = os.path.join(tmp, 'tail-nohelpers.lua')
    open(m3path, 'w').write(m3src)
    r = run_py(['moonveil2.py', m3path, '-o', os.path.join(tmp, 'm3'),
                '--spoof-id', 'off'])
    check('D3 tail-matched but no cache idiom -> exit 2 (M3)',
          r.returncode == 2, f'rc={r.returncode} out={r.stdout[-200:]}')
finally:
    pass

# --- C1: clean.py unit checks (semantics-preserving passes) ---
import clean as clean_mod
_clean_cases = [
    ("double paren chains", "x = ((42)) + ((7))", "x = 42 + 7"),
    ("or hug kept (no glue)", "G = a or((232))", "G = a or(232)"),
    ("or spaced collapses", "G = a or ((232))", "G = a or 232"),
    ("return hug kept", "return(5)", "return(5)"),
    ("return spaced collapses", "return (5)", "return 5"),
    ("next hug kept", "x = (5)and y", "x = (5)and y"),
    ("single safe", "e,n[b]=(105),i", "e,n[b]=105,i"),
    ("call args kept", "y = f(5)", "y = f(5)"),
    ("plus-minus", "G = G+-77 + x+-2*y", "G = G-77 + x-2*y"),
    ("plus-minus ident kept", "x = a+-b", "x = a+-b"),
    ("div-by-neg-zero trap kept", "G,M=(174),1/-0", "G,M=174,1/-0"),
    ("local nil drop", "local a, b = 1, nil\nlocal c = nil",
     "local a, b = 1\nlocal c"),
    ("assignment nil kept", "a, b = 1, nil", "a, b = 1, nil"),
    ("if true unwrap", "if true then x = 1 end", "x = 1"),
    ("if true nested kept", "if true then if a then x = 1 end end",
     "if true then if a then x = 1 end end"),
    ("negated flip lt", "elseif not (a < 5) then x = 1 end",
     "elseif a >= 5 then x = 1 end"),
    ("negated flip eq", "if not (a == b) then x = 1 end",
     "if a ~= b then x = 1 end"),
    ("string trap untouched", 's = "a+-5 ((9))" \nx = ((9))',
     's = "a+-5 ((9))" \nx = 9'),
    ("concat glue kept", 's = (5).."x"', 's = (5).."x"'),
]
for _name, _src, _exp in _clean_cases:
    _out, _st = clean_mod.clean_source(_src)
    check(f'C1 clean: {_name}', _out == _exp,
          f'got { _out!r} want {_exp!r}')

# --- G: sample runs (auto + off) ---
luau = moonveil2.find_luau(None)
SAMPLE = os.path.join(HERE, 'sample', 'Loader-MoonVeil-2.1.0.lua')
GOLD = os.path.join(HERE, 'sample', 'output')
if luau:
    out_auto = os.path.join(tmp, 'auto')
    r = run_py(['moonveil2.py', SAMPLE, '-o', out_auto, '--trace'])
    check('G1 sample auto run exit 0', r.returncode == 0,
          f'rc={r.returncode}')
    for f in ('decrypted.luau', 'linearized.luau', 'constants.json',
              'roles.json', 'states.json', 'strings.json', 'cfg.md'):
        check(f'G1 auto primary byte-identical: {f}',
              open(os.path.join(out_auto, f), 'rb').read()
              == open(os.path.join(GOLD, f), 'rb').read())
    rep = json.load(open(os.path.join(out_auto, 'identity_report.json')))
    check('G1 sample auto: no identity gate (honest empty report)',
          rep['schema_version'] == 'spoof-engine/1'
          and rep['gates'] == [] and rep['unknown_fields'] == []
          and rep['candidates'] == {} and rep['fields_seen'] == [],
          f"gates={rep['gates']}")
    # --- Q: v1.2.0 self-check QA on the auto run ---
    qa = json.load(open(os.path.join(out_auto, 'qa_report.json')))
    check('Q1 QA schema + gates pass',
          qa['schema'] == 'moonveil-qa/1' and qa['compile_ok'] is True
          and qa['equivalence_ok'] is True
          and qa['clean']['applied'] is True, str(qa['clean']))
    check('Q1 clean counts on golden (483/374/203, total 1060)',
          qa['clean']['double_parens'] == 483
          and qa['clean']['single_parens'] == 374
          and qa['clean']['plus_minus'] == 203
          and qa['clean']['total_fixed'] == 1060
          and qa['clean']['local_nil_drop'] == 0
          and qa['clean']['if_true_unwrap'] == 0
          and qa['clean']['negated_flip'] == 0, str(qa['clean']))
    d = qa['decrypted']
    check('Q1 decrypted raw patterns fixed (double/if-true/negated/'
          'unresolved/probe all 0)',
          d['double_parens'] == 0 and d['if_true'] == 0
          and d['negated_conditionals'] == 0
          and d['unfolded_pure_arith'] == 0
          and d['unresolved_helper_calls'] == 0
          and d['cache_or_sites'] == 0 and d['probe_leaks'] == 0,
          str(d))
    check('Q1 decrypted residue counted honestly (frag 1, helper '
          'defs 10, nil-clear 105, plus-minus 3, single-parens 490)',
          d['frag_string_call_sites'] == 1
          and d['helper_cache_refs'] == 10
          and d['nil_clear_statements'] == 105
          and d['plus_minus'] == 3 and d['single_parens'] == 490
          and d['nil_init_decls'] == 0, str(d))
    check('Q1 structuring: tierB 752, KEPT 4 with reasons',
          qa['linearized']['tierB_blocks'] == 752
          and qa['kept_loop_count'] == 4
          and sorted(k['function'] for k in qa['kept_loops'])
          == sorted(['#6 (Pa)', '#57 (s)', '#60 (S)', '#89 (F)']),
          str(qa['kept_loops']))
    check('Q1 names: INFERRED 0 / neutral 97, slot conflicts [m, q], '
          'evidence links [F, ya]',
          qa['names'] == {'inferred': 0, 'neutral': 97}
          and qa['slot_conflicts'] == ['m', 'q']
          and qa['multi_role_fields'] == ['m', 'q']
          and qa['naming_evidence_links'] == ['F', 'ya']
          and sorted(qa['naming_evidence']['F']['strings_referenced'])
          == sorted(['__mode', 'band', 'bit32', 'bor', 'btest', 'bxor',
                     'byte', 'char', 'create', 'error', 'getmetatable',
                     'gmatch', 'insert', 'lshift', 'move', 'pack',
                     'pairs', 'pcall', 'select', 'setmetatable',
                     'string', 'table', 'tonumber', 'type', 'unpack'])
          and qa['naming_evidence']['ya']['strings_referenced']
          == ['__call', '__iter']
          and qa['naming_evidence']['F']['label'] == 'neutral',
          str(qa['naming_evidence_links']))
    check('Q1 residue categories (nothing silently dropped)',
          sorted(r['category'] for r in qa['residue'])
          == sorted(['nil_clear_statements', 'kept_loops',
                     'helper_definitions_dead', 'frag_string_call_sites',
                     'slot_conflicts', 'plus_minus_residue',
                     'single_parens_kept']),
          str([r['category'] for r in qa['residue']]))
    check('Q1 QA section present in report.md',
          'self-check QA (moonveil-qa/1)' in open(
              os.path.join(out_auto, 'report.md')).read()
          and 'slot conflicts' in open(
              os.path.join(out_auto, 'report.md')).read())
    check('Q1 naming_evidence.json matches QA report',
          json.load(open(os.path.join(out_auto,
                                      'naming_evidence.json')))
          == qa['naming_evidence'])
    check('G1 sample auto: single unclassified fork (no gate-pass claim)',
          len(rep['forks']) == 1
          and rep['forks'][0]['branch'] == 'unclassified'
          and rep['forks'][0]['seeds'] == {})
    out_off = os.path.join(tmp, 'off')
    r = run_py(['moonveil2.py', SAMPLE, '-o', out_off, '--trace',
                '--spoof-id', 'off'])
    check('G2 sample off run exit 0', r.returncode == 0)
    for f in ('decrypted.luau', 'linearized.luau', 'constants.json',
              'roles.json', 'states.json', 'strings.json', 'cfg.md'):
        check(f'G2 off primary byte-identical: {f}',
              open(os.path.join(out_off, f), 'rb').read()
              == open(os.path.join(GOLD, f), 'rb').read())
    check('G2 off: no identity artifacts',
          not os.path.exists(os.path.join(out_off, 'identity_report.json'))
          and 'Identity spoofing' not in open(
              os.path.join(out_off, 'report.md')).read())
    check('G2 off: QA report still emitted (QA is not an identity '
          'artifact)',
          os.path.exists(os.path.join(out_off, 'qa_report.json'))
          and json.load(open(os.path.join(out_off, 'qa_report.json')))['schema']
          == 'moonveil-qa/1')
    # scan-only auto (no --trace): report present, forks empty
    out_scan = os.path.join(tmp, 'scan')
    r = run_py(['moonveil2.py', SAMPLE, '-o', out_scan,
                '--spoof-id', 'auto'])
    rep2 = json.load(open(os.path.join(out_scan, 'identity_report.json')))
    check('G3 scan-only auto: report with forks=[]',
          rep2['gates'] == [] and rep2['forks'] == [])
else:
    print('[SKIP] luau binary not found; sample runs skipped')

# --- G4: synthetic gate fixture (scan + fork traces + off) ---
FIX = os.path.join(HERE, 'tests', 'fixtures', 'gate_fixture.luau')
fx = open(FIX, encoding='utf-8').read()
cands, fread, extra, notes = moonveil2.scan_identity_gates(fx)
check('G4 fixture scan: eq-const + set-membership candidates',
      sorted((c['value'], c['kind']) for c in cands.get('PlaceId', []))
      == [(123456789, 'eq-const'), (987654321, 'set-membership')],
      str(cands))
check('G4 fixture scan: PlaceId read recorded',
      'PlaceId' in fread)
c2, _, _, _ = moonveil2._scan_regex(fx)
check('G4 regex fallback agrees on candidates',
      sorted((c['value'], c['kind']) for c in c2.get('PlaceId', []))
      == [(123456789, 'eq-const'), (987654321, 'set-membership')])
if luau:
    def is_pass(fork):
        tops = ' '.join(fork['prints_top'])
        return ('GATE-PASS' in tops) and ('GATE-DECOY' not in tops)

    fx_out = os.path.join(tmp, 'fixture')
    os.makedirs(fx_out, exist_ok=True)
    rep = moonveil2.run_trace(luau, fx, fx_out, recovered_source=fx,
                              spoof_mode='auto', is_pass=is_pass)
    forks = rep['forks']
    check('G4 fixture: 2 forks (primary + one-field variation)',
          len(forks) == 2, str([f['seeds'] for f in forks]))
    check('G4 fixture: fork 0 seeds eq value, takes GATE-PASS branch',
          forks[0]['seeds'] == {'PlaceId': {'value': 123456789,
                                            'source': 'static:eq-const'}}
          and forks[0]['branch'] == 'gate-pass'
          and any('GATE-PASS-EQ' in p for p in forks[0]['prints_top']),
          str(forks[0]))
    check('G4 fixture: fork 1 seeds set value, takes GATE-PASS-SET',
          forks[1]['seeds']['PlaceId']['value'] == 987654321
          and forks[1]['branch'] == 'gate-pass'
          and any('GATE-PASS-SET' in p for p in forks[1]['prints_top']),
          str(forks[1]))
    gates = {g['field']: g for g in rep['gates']}
    check('G4 fixture: PlaceId gate forked, primary spoofed value set',
          gates['PlaceId']['status'] == 'forked'
          and gates['PlaceId']['forked'] is True
          and gates['PlaceId']['spoofed_value'] == 123456789
          and rep['unknown_fields'] == [], str(gates))
    fx_off = os.path.join(tmp, 'fixture-off')
    os.makedirs(fx_off, exist_ok=True)
    check('G4 fixture off: no identity report returned',
          moonveil2.run_trace(luau, fx, fx_off, recovered_source=fx,
                              spoof_mode='off') is None
          and not os.path.exists(
              os.path.join(fx_off, 'identity_report.json')))

# --- G5: determinism (scan-only report across PYTHONHASHSEED) ---
if luau:
    dec = open(os.path.join(GOLD, 'decrypted.luau'), encoding='utf-8').read()
    hashes = []
    for seed_env in ('0', '12345'):
        d = os.path.join(tmp, 'det' + seed_env)
        os.makedirs(d, exist_ok=True)
        open(os.path.join(d, 'report.md'), 'w').write('# x\n')
        moonveil2.run_identity_scan(d, dec)
        hashes.append(sha(os.path.join(d, 'identity_report.json')))
    check('G5 identity report deterministic across PYTHONHASHSEED',
          hashes[0] == hashes[1], str(hashes))

# --- G6: determinism of full runs across PYTHONHASHSEED ---
if luau:
    _hashes = {}
    for _seed in ('0', '12345'):
        _d = os.path.join(tmp, 'fulldet' + _seed)
        _r = run_py(['moonveil2.py', SAMPLE, '-o', _d,
                     '--spoof-id', 'off'],
                    env={'PYTHONHASHSEED': _seed})
        _hashes[_seed] = tuple(
            sha(os.path.join(_d, f)) for f in
            ('decrypted.luau', 'linearized.luau', 'qa_report.json',
             'naming_evidence.json', 'cfg.md', 'constants.json',
             'roles.json', 'states.json', 'strings.json'))
        check(f'G6 full off run exit 0 (seed {_seed})',
              _r.returncode == 0, f'rc={_r.returncode}')
    check('G6 full outputs deterministic across PYTHONHASHSEED',
          _hashes['0'] == _hashes['12345'], str(_hashes))

shutil.rmtree(tmp, ignore_errors=True)
print()
if FAILURES:
    print(f'FAILURES ({len(FAILURES)}): {FAILURES}')
    sys.exit(1)
print('ALL CHECKS PASS')
