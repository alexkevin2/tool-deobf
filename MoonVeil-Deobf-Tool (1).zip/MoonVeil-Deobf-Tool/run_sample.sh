#!/bin/sh
# Runs the MoonVeil 2.x engine on the bundled Loader sample and diffs
# the decrypted + linearized outputs against the expected ones.
set -e
cd "$(dirname "$0")"
python3 moonveil2.py sample/Loader-MoonVeil-2.1.0.lua -o sample-run-out --trace
cmp -s sample-run-out/decrypted.luau sample/output/decrypted.luau || { echo "SAMPLE MISMATCH: decrypted.luau"; exit 1; }
cmp -s sample-run-out/linearized.luau sample/output/linearized.luau || { echo "SAMPLE MISMATCH: linearized.luau"; exit 1; }
python3 -c "
import json, sys
r = json.load(open('sample-run-out/identity_report.json'))
assert r['schema_version'] == 'spoof-engine/1' and r['gates'] == [] and r['unknown_fields'] == [], r
q = json.load(open('sample-run-out/qa_report.json'))
assert q['schema'] == 'moonveil-qa/1' and q['compile_ok'] is True and q['equivalence_ok'] is True, q
assert q['decrypted']['probe_leaks'] == 0 and q['decrypted']['unresolved_helper_calls'] == 0, q['decrypted']
assert q['slot_conflicts'] == ['m', 'q'] and q['kept_loop_count'] == 4, q
" || { echo "SAMPLE MISMATCH: identity_report.json or qa_report.json"; exit 1; }
echo "SAMPLE OK: decrypted.luau + linearized.luau match expected output; identity_report.json gates=[] as expected; qa_report.json schema ok, no probe leaks, slot conflicts [m, q], 4 KEPT loops"
