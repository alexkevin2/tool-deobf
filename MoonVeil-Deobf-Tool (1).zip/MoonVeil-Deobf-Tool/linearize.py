#!/usr/bin/env python3
"""linearize.py — turn MoonVeil's nested dispatch trees into flat,
state-labelled code.

Input is the DECRYPTED source (real state constants inline). For every
dispatch loop (`while true do` / `repeat ... until false` whose if-tree
branches only on `state <cmp> <int>`):

  1. walk the tree into leaves with structured guards (condition +
     polarity; an `else` contributes the negation of every condition
     of its if-chain),
  2. extract every state transition per leaf (constant, `cond and A
     or B`, or arithmetic in the state var),
  3. BFS the concrete state graph from the entry value,
  4. emit either
       Tier A — a straight-line statement sequence, when the graph is
                a simple path ending in `return` and every transition
                is a removable tail assignment, or
       Tier B — a flat `if state == v then ... elseif ... end` chain
                inside the same loop, blocks in BFS order, leaf bodies
                verbatim.
  Any doubt (a value matching != 1 leaf, an unreachable leaf, a
  dynamic transition, a missing entry value) leaves that loop's
  original text untouched. Correctness never depends on heuristics:
  Tier B reuses the original leaf bodies inside the original loop.

Usage: linearize.py <decrypted.luau> [-o linearized.luau] [--cfg cfg.md]
       [--roles roles.json]
"""
import argparse, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import extract_vm
import moonveil as mv

CMP_RE = re.compile(r'^\(?\s*(\w+)\s*(<=|>=|<|>|==|~=)\s*(-?\d+)\s*\)?$')
STMT_KW = ('if', 'for', 'while', 'return', 'local', 'end', 'elseif',
           'else', 'until', 'do', 'then', 'break', 'repeat', 'function')

# ------------------------------------------------------------------ table
def split_elements(src, toks):
    """All top-level elements of the returned table with char spans."""
    start = next(i for i, t in enumerate(toks) if t[1] == '{')
    spans, bdepth, kdepth, cur, pending_do = [], 0, 0, start + 1, 0
    i = start + 1
    while i < len(toks):
        kind, t = toks[i][0], toks[i][1]
        if kind == 'word':
            if t in ('for', 'while'):
                kdepth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: kdepth += 1
            elif t in ('function', 'if', 'repeat'):
                kdepth += 1
            elif t in ('end', 'until'):
                if kdepth == 0 and bdepth == 0: break
                kdepth -= 1
        elif t in ('{', '(', '['): bdepth += 1
        elif t in ('}', ')', ']'):
            if kdepth == 0 and bdepth == 0: break
            bdepth -= 1
        elif t == ',' and kdepth == 0 and bdepth == 0:
            spans.append((cur, i)); cur = i + 1
        i += 1
    spans.append((cur, i))
    out = []
    pos_idx = 0
    for a, b in spans:
        if b <= a: continue
        c0, c1 = toks[a][2], toks[b - 1][3]
        tx = src[c0:c1]
        m = re.match(r'\s*([A-Za-z_]\w*)\s*=', tx)
        if m and not tx.lstrip().startswith('function'):
            out.append({'kind': 'keyed', 'name': m.group(1), 'c0': c0, 'c1': c1})
        else:
            pos_idx += 1
            out.append({'kind': 'pos', 'index': pos_idx, 'c0': c0, 'c1': c1})
    return out

# ------------------------------------------------------------------ leaves
def walk_leaves(src, toks, lo, hi, var):
    leaves = []
    def walk(region, guard):
        i, run = 0, []
        def flush():
            if run and mv.text_of(src, run).strip():
                leaves.append({'guard': list(guard), 'toks': list(run)})
            run.clear()
        while i < len(region):
            kind, txt = region[i][0], region[i][1]
            if kind == 'word' and txt == 'if':
                branches, nxt = mv.split_branches(region, i)
                infos, ok = [], True
                for cond, body in branches:
                    if cond is None:
                        infos.append(None); continue
                    t = mv.text_of(src, cond).strip()
                    m = CMP_RE.match(t)
                    if not m or m.group(1) != var:
                        ok = False; break
                    infos.append((t, m.group(2), int(m.group(3))))
                if ok:
                    flush()
                    negs = []
                    for (cond, body), info in zip(branches, infos):
                        if info is None:
                            g = guard + negs
                        else:
                            g = guard + negs + [(info[0], True)]
                            negs = negs + [(info[0], False)]
                        walk(body, g)
                    i = nxt
                    continue
                end = mv.block_span(region, i)
                run.extend(region[i:end]); i = end; continue
            if kind == 'word' and txt in ('for', 'while', 'function', 'repeat'):
                end = mv.block_span(region, i)
                run.extend(region[i:end]); i = end; continue
            run.append(region[i]); i += 1
        flush()
    walk(toks[lo:hi], [])
    for lf in leaves:
        lf['text'] = mv.text_of(src, lf['toks']).strip()
        lf['has_return'] = leaf_has_return(lf['toks'])
    return leaves

def leaf_has_return(toks):
    depth = 0
    for kind, txt, *_ in toks:
        if kind == 'word':
            if txt == 'function': depth += 1
            elif txt == 'end' and depth: depth -= 1
            elif txt == 'return' and depth == 0: return True
    return False

# ------------------------------------------------------------------ transitions
def _is_assign_start(toks, k):
    j = k
    while j < len(toks):
        if toks[j][0] != 'word': return False
        j += 1
        if j < len(toks) and toks[j][1] == ',':
            j += 1; continue
        break
    return j < len(toks) and toks[j][1] == '='

def _split_top(toks):
    parts, depth, cur = [], 0, []
    for t in toks:
        if t[1] in ('(', '[', '{'): depth += 1
        elif t[1] in (')', ']', '}'): depth -= 1
        if t[1] == ',' and depth == 0:
            parts.append(cur); cur = []
        else:
            cur.append(t)
    parts.append(cur)
    return parts

def find_transitions(src, toks, var):
    """Find every assignment whose target list contains the bare state
    variable (targets may be index expressions like r[t])."""
    out = []
    i = 0
    while i < len(toks):
        if toks[i][0] == 'word' and toks[i][1] not in STMT_KW \
                and (i == 0 or toks[i - 1][1] not in ('.', ':', 'for')):
            # scan for a top-level '=' (assignment) within a small window
            j, depth, lhs_toks, found = i, 0, [], False
            while j < len(toks) and j - i <= 60:
                t = toks[j][1]
                if t in ('(', '[', '{'): depth += 1
                elif t in (')', ']', '}'):
                    depth -= 1
                    if depth < 0: break
                if depth == 0 and t == '=':
                    found = True; break
                if depth == 0 and toks[j][0] == 'word' and t in STMT_KW:
                    break
                lhs_toks.append(toks[j]); j += 1
            if found:
                lhs_text = mv.text_of(src, lhs_toks).strip() if lhs_toks else ''
                # the LHS must be a pure target list (ident / a.b / a[..]
                # separated by commas) — otherwise the scan ran across a
                # statement boundary (e.g. a local declaration list)
                if not re.fullmatch(r'\w+(?:\s*\.\s*\w+|\s*\[[^\[\]]*\])?'
                                    r'(?:\s*,\s*\w+(?:\s*\.\s*\w+|\s*\[[^\[\]]*\])?)*',
                                    lhs_text):
                    found = False
            if found:
                targets = [mv.text_of(src, part).strip()
                           for part in _split_top(lhs_toks) if part]
                if var in targets:
                    k, depth, rhs = j + 1, 0, []
                    while k < len(toks):
                        t, kd = toks[k][1], toks[k][0]
                        if t in ('(', '[', '{'): depth += 1
                        elif t in (')', ']', '}'): depth -= 1
                        if depth == 0 and rhs:
                            if kd == 'word' and t in STMT_KW: break
                            if kd == 'word' and _is_assign_start(toks, k): break
                            prev = rhs[-1][1]
                            prev_end = (rhs[-1][0] == 'str' or prev in (')', ']', '}')
                                        or prev.isdigit()
                                        or (rhs[-1][0] == 'word' and prev not in ('and', 'or', 'not')))
                            if prev_end and kd == 'word' and t not in ('and', 'or'):
                                break
                        rhs.append(toks[k]); k += 1
                    exprs = _split_top(rhs)
                    idx = targets.index(var)
                    if idx < len(exprs) and exprs[idx]:
                        etoks = exprs[idx]
                        out.append({'lhs': targets,
                                    'expr': mv.text_of(src, etoks).strip(),
                                    'c0': toks[i][2], 'c1': etoks[-1][3]})
                    i = max(k, i + 1)
                    continue
        i += 1
    return out

def _strip_parens(e):
    e = e.strip()
    while len(e) > 1 and e[0] == '(' and e[-1] == ')':
        depth = 0
        wraps = True
        for n, ch in enumerate(e):
            if ch == '(': depth += 1
            elif ch == ')': depth -= 1
            if depth == 0 and n < len(e) - 1:
                wraps = False; break
        if not wraps: break
        e = e[1:-1].strip()
    return e

def _top_level_find(e, keyword, last=False):
    """Find `and`/`or` as a top-level keyword (it may hug parentheses,
    e.g. `a==l and((170))or((138))`). Returns the match span start."""
    hits = []
    for m in re.finditer(r'\b' + keyword + r'\b', e):
        depth = 0
        for ch in e[:m.start()]:
            if ch in '([{': depth += 1
            elif ch in ')]}': depth -= 1
        if depth == 0:
            hits.append((m.start(), m.end()))
    if not hits: return (-1, -1)
    return hits[-1] if last else hits[0]

def classify_value(e, var):
    e = _strip_parens(e)
    if re.fullmatch(r'-?\d+', e):
        return ('const', int(e))
    if re.search(r'(?<![\w.])' + re.escape(var) + r'(?![\w])', e):
        sub = re.sub(r'(?<![\w.])' + re.escape(var) + r'(?![\w])', 'v', e)
        if re.fullmatch(r'[\d\s\+\-\*/%\(\)\.v]+', sub):
            return ('arith', sub)
    return ('dynamic', e)

def classify_transition(tr, var):
    e = _strip_parens(tr['expr'])
    base = classify_value(e, var)
    if base[0] != 'dynamic':
        return base
    # cond and X or Y, where X/Y are const or arithmetic in the state var
    po, po_end = _top_level_find(e, 'or', last=True)
    if po > 0:
        head, side_b = e[:po], e[po_end:]
        pa, pa_end = _top_level_find(head, 'and', last=True)
        if pa > 0:
            side_a = head[pa_end:]
            ca, cb = classify_value(side_a, var), classify_value(side_b, var)
            if ca[0] != 'dynamic' and cb[0] != 'dynamic':
                return ('branch2', (ca, cb))
    return ('dynamic', e)

def _eval_side(cls, v):
    kind, val = cls
    if kind == 'const': return val
    if kind == 'arith':
        try:
            r = eval(val, {'__builtins__': {}}, {'v': v})
        except Exception:
            return None
        if isinstance(r, float) and r == int(r): r = int(r)
        return r
    return None

def tr_successors(tr, v):
    kind, val = tr['cls']
    if kind in ('const', 'arith'):
        r = _eval_side(tr['cls'], v)
        return None if r is None else [r]
    if kind == 'branch2':
        a = _eval_side(val[0], v)
        b = _eval_side(val[1], v)
        if a is None or b is None: return None
        return [a, b]
    return None

def eval_cmp(v, op, num):
    return {'<': v < num, '<=': v <= num, '>': v > num, '>=': v >= num,
            '==': v == num, '~=': v != num}[op]

# ------------------------------------------------------------------ graph
def build_graph(src, elem_toks, lo, hi, var):
    # region = loop body without wrapper tokens: for `while` skip
    # while/true/do and drop the final end; for `repeat` skip repeat and
    # drop from the matching until.
    body_lo = lo + 1
    if elem_toks[lo][1] == 'while':
        while body_lo < hi and elem_toks[body_lo][1] != 'do':
            body_lo += 1
        body_lo += 1
        body_hi = hi - 1                      # final 'end'
    else:                                     # repeat
        body_hi = hi
        for k in range(hi - 1, lo, -1):
            if elem_toks[k][1] == 'until':
                body_hi = k
                break
    leaves = walk_leaves(src, elem_toks, body_lo, body_hi, var)
    if not leaves:
        return None, 'no leaves'
    for lf in leaves:
        lf['transitions'] = find_transitions(src, lf['toks'], var)
        for tr in lf['transitions']:
            tr['cls'] = classify_transition(tr, var)
    # entry value: last const transition to var before the loop
    entry = None
    for tr in find_transitions(src, elem_toks[:lo], var):
        c = classify_transition(tr, var)
        if c[0] == 'const':
            entry = c[1]
    if entry is None:
        return None, 'entry state not found'
    def matches(lf, v):
        for text, pol in lf['guard']:
            m = CMP_RE.match(text)
            if eval_cmp(v, m.group(2), int(m.group(3))) != pol:
                return False
        return True
    order, leaf_of, seen = [], {}, set()
    frontier = [entry]
    seen.add(entry)
    while frontier:
        if len(seen) > 10000:
            return None, 'state explosion (>10000 states)'
        v = frontier.pop(0)
        ms = [lf for lf in leaves if matches(lf, v)]
        if len(ms) != 1:
            return None, f'state {v} matched {len(ms)} leaves'
        leaf_of[v] = ms[0]
        order.append(v)
        for tr in ms[0]['transitions']:
            succ = tr_successors(tr, v)
            if succ is None:
                return None, f'dynamic transition in state {v}: {tr["expr"][:40]}'
            for nv in succ:
                if nv not in seen:
                    seen.add(nv); frontier.append(nv)
    if len({id(l) for l in leaf_of.values()}) != len(leaves):
        return None, 'unreachable leaves remain'
    return {'entry': entry, 'order': order, 'leaf_of': leaf_of, 'leaves': leaves}, None

# ------------------------------------------------------------------ emission
def fmtv(v):
    return str(int(v)) if isinstance(v, float) and v == int(v) else str(v)

def emit(src, g, var, kind):
    order, leaf_of = g['order'], g['leaf_of']
    # Tier A: simple path?
    path_ok = True
    for n, v in enumerate(order):
        lf = leaf_of[v]
        succ = []
        for tr in lf['transitions']:
            s = tr_successors(tr, v)
            if s is None or len(s) != 1:
                path_ok = False; break
            succ += s
        if not path_ok: break
        if n < len(order) - 1:
            if succ != [order[n + 1]] or lf['has_return']: path_ok = False; break
            if len(lf['transitions']) != 1: path_ok = False; break
            tr = lf['transitions'][0]
            if tr['lhs'] != [var] or tr['cls'][0] != 'const': path_ok = False; break
            tail = lf['text'][tr['c0'] - lf['toks'][0][2]:]
            if lf['text'][tr['c1'] - lf['toks'][0][2]:].strip(' \t\r\n;'):
                path_ok = False; break
        else:
            if not lf['has_return']: path_ok = False; break
    if path_ok:
        parts = []
        for n, v in enumerate(order):
            lf = leaf_of[v]
            if n < len(order) - 1:
                tr = lf['transitions'][0]
                base = lf['toks'][0][2]
                parts.append((lf['text'][:tr['c0'] - base]).rstrip())
            else:
                parts.append(lf['text'])
        return ('A', '\n'.join(p for p in parts if p))
    # Tier B: flat dispatch in the same loop wrapper
    lines = []
    lines.append('while true do' if kind == 'while' else 'repeat')
    for n, v in enumerate(order):
        kw = 'if' if n == 0 else 'elseif'
        lines.append(f"{kw} {var} == {fmtv(v)} then -- state {fmtv(v)}")
        lines.append(leaf_of[v]['text'])
    lines.append('end')
    if kind == 'while':
        lines.append('end')
    else:
        lines.append('until false')
    return ('B', '\n'.join(lines))

# ------------------------------------------------------------------ driver
def _merge_numbers(toks):
    """The tokenizer emits digits one char at a time; merge adjacent
    digit tokens back into number tokens (char spans stay exact)."""
    out = []
    for t in toks:
        if (out and out[-1][3] == t[2] and t[1].isdigit()
                and out[-1][1].isdigit()):
            k, txt, s, _ = out[-1]
            out[-1] = (k, txt + t[1], s, t[3])
        else:
            out.append(t)
    return out

def linearize_source(src, roles=None):
    # drop pure-whitespace tokens (the tokenizer emits them; every
    # consumer here works on char spans, so this is safe)
    toks = _merge_numbers([t for t in extract_vm._tokens(src) if t[1].strip()])
    elements = split_elements(src, toks)
    elem_of_tok = {}
    for ei, el in enumerate(elements):
        pass
    disps = mv.find_dispatches(toks)
    # outermost loops only
    outer = []
    for d in disps:
        if any(o is not d and o[0] <= d[0] and d[1] <= o[1] for o in disps):
            continue
        outer.append(d)
    inv_perm = {}
    if roles and roles.get('permutation'):
        inv_perm = {v: k for k, v in roles['permutation'].items()}
    def elem_label(c0):
        for el in elements:
            if el['c0'] <= c0 < el['c1']:
                if el['kind'] == 'keyed': return f"keyed '{el['name']}'"
                return f"#{el['index']} ({inv_perm.get(el['index'], '?')})"
        return '?'
    replacements = []   # (c0, c1, new_text)
    cfg = ['# MoonVeil state graphs (from linearized run)', '']
    stats = {'loops': len(outer), 'tierA': 0, 'tierB': 0, 'kept': 0}
    def true_hi(lo, hi):
        # block_span stops just past `until` for repeat loops, before its
        # condition; extend over the (short) condition expression.
        if hi - 1 > lo and toks[hi - 1][1] == 'until':
            j, depth = hi, 0
            while j < len(toks) and j < hi + 8:
                t = toks[j][1]
                if t in ('(', '[', '{'): depth += 1
                elif t in (')', ']', '}'): depth -= 1
                if depth == 0 and (t == ',' or toks[j][0] == 'word' and t == 'end'):
                    break
                j += 1
            return j
        return hi
    for (lo, hi0, var, kind) in outer:
        hi = true_hi(lo, hi0)
        lc0, lc1 = toks[lo][2], toks[hi - 1][3]
        label = elem_label(lc0)
        # element-local token window: tokens before lo within same element
        el = next(el for el in elements if el['c0'] <= lc0 < el['c1'])
        etoks = [t for t in toks if el['c0'] <= t[2] < el['c1']]
        elo = next(i for i, t in enumerate(etoks) if t[2] == lc0)
        ehi = elo + (hi - lo)
        g, err = build_graph(src, etoks, elo, ehi, var)
        if g is None:
            stats['kept'] += 1
            cfg.append(f"## function {label}: KEPT original loop ({err})")
            cfg.append('')
            continue
        tier, text = emit(src, g, var, kind)
        stats['tierA' if tier == 'A' else 'tierB'] += 1
        replacements.append((lc0, lc1, text))
        flow = ' -> '.join(fmtv(v) for v in g['order'])
        cfg.append(f"## function {label}: tier {tier}, {len(g['order'])} states, var `{var}`")
        cfg.append(f"flow (BFS): {flow}")
        cfg.append('')
    out = src
    for c0, c1, text in sorted(replacements, reverse=True):
        out = out[:c0] + text + out[c1:]
    return out, stats, '\n'.join(cfg)

def main():
    ap = argparse.ArgumentParser(description='Linearize MoonVeil dispatch loops')
    ap.add_argument('input')
    ap.add_argument('-o', '--output', default=None)
    ap.add_argument('--cfg', default=None)
    ap.add_argument('--roles', default=None)
    args = ap.parse_args()
    src = open(args.input, encoding='utf-8').read()
    roles = json.load(open(args.roles)) if args.roles else None
    out, stats, cfg = linearize_source(src, roles)
    outpath = args.output or (os.path.splitext(args.input)[0] + '.linearized.luau')
    open(outpath, 'w', encoding='utf-8').write(out)
    if args.cfg:
        open(args.cfg, 'w', encoding='utf-8').write(cfg)
    print(f"loops: {stats['loops']}  tierA: {stats['tierA']}  tierB: {stats['tierB']}  kept: {stats['kept']}")
    print(f"-> {outpath}")
    return 0

if __name__ == '__main__':
    sys.exit(main())
