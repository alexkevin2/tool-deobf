#!/usr/bin/env python3
"""moonveil2.py — dynamic-link deobfuscator for MoonVeil 2.x "linker" builds.

Profile (verified on MoonVeil 2.1.0): the chunk returns a table of ~97
entries (builder functions + raw helpers) and calls a linker method on
it:  return({...}):l({names...}, "EntryName", ...)
The linker renames entries into a context table; the entry instantiates
runtime closures from builders, then runs the main function. Constants
are encrypted behind cache-backed helpers on the context:

  numeric:  function(a,b,c,d) a.<cache>[d] = <arith>; return a.<cache>[d] end
  strings:  function(a,b,c,d) a.<cache>[d] = a.<m>(b, c); return ... end
            called as h:Str(h.<q>"frag1", h.<q>"frag2", key)

Everything (names, permutation, roles) is DISCOVERED from the file
itself, so other builds with the same architecture work unchanged:
  1. parse the tail call -> names array + entry name + stripped chunk
  2. fold (shared fold.py)
  3. harness: link with a bogus entry; recover the name->index map by
     function identity; classify helpers by body shape
  4. parse the entry's instantiation list; harness: instantiate, then
     evaluate every numeric / string decrypt call site
  5. substitute values back -> decrypted.luau (+ states.json, report)

Exit: 0 = constants+strings decrypted & compile OK; 5 = PARTIAL;
2 = not this profile (caller should fall back to static moonveil.py).
"""
import argparse, hashlib, json, os, re, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fold as fold_mod
import extract_vm
import moonveil as mv_static

# Package version of the MoonVeil-Deobf-Tool distribution (distinct
# from the obfuscator version it targets, MoonVeil 2.1.0).
TOOL_VERSION = '1.2.0'
try:
    import spoof_engine as se
except Exception:  # vendored copy missing -> spoof features degrade
    se = None

TAIL_RE = re.compile(r'\}\s*\)\s*:\s*([A-Za-z_]\w*)\s*\(')
ARGS_NUM = r'(-?\d+(?:\s*,\s*-?\d+)*)'
STR_LIT = r'"((?:[^"\\]|\\.)*)"'

# ------------------------------------------------------------ tail parse
def find_tail(src):
    last = None
    for m in TAIL_RE.finditer(src):
        last = m
    if not last:
        return None
    tail = src[last.start():]
    m = re.match(r'\}\s*\)\s*:\s*([A-Za-z_]\w*)\s*\(\s*\{((?:"(?:[^"\\]|\\.)*",?\s*)+)\}\s*,\s*"([^"]+)"\s*,\s*\.\.\.\s*\)\s*$', tail)
    if not m:
        return None
    names = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(2))
    stripped = src[:last.start() + 1] + ')\n'
    return {'link': m.group(1), 'names': names, 'entry': m.group(3),
            'stripped': stripped}

# ------------------------------------------------------------ table split
def split_table(folded):
    """Split the outer returned table into positional element sources and
    keyed elements (name -> source)."""
    toks = list(extract_vm._tokens(folded))
    start = next(i for i, t in enumerate(toks) if t[1] == '{')
    spans, bdepth, kdepth, cur, pending_do = [], 0, 0, start + 1, 0
    i = start + 1
    while i < len(toks):
        kind, t = toks[i][0], toks[i][1]
        if kind == 'word':
            if t in ('for', 'while'):
                kdepth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: kdepth += 1
            elif t in ('function', 'if', 'repeat'):
                kdepth += 1
            elif t in ('end', 'until'):
                if kdepth == 0 and bdepth == 0: break
                kdepth -= 1
        elif t in ('{', '(', '['): bdepth += 1
        elif t in ('}', ')', ']'):
            if kdepth == 0 and bdepth == 0: break
            bdepth -= 1
        elif t == ',' and kdepth == 0 and bdepth == 0:
            spans.append((cur, i)); cur = i + 1
        i += 1
    spans.append((cur, i))
    pos, keyed = [], {}
    for a, b in spans:
        if b <= a: continue
        tx = folded[toks[a][2]:toks[b - 1][3]]
        m = re.match(r'\s*([A-Za-z_]\w*)\s*=', tx)
        if m and not tx.lstrip().startswith('function'):
            keyed[m.group(1)] = tx
        else:
            pos.append(tx)
    return pos, keyed

# ------------------------------------------------------------ harness
def find_luau(arg):
    if arg: return arg
    for cand in (os.path.join(HERE, 'bin', 'luau'),
                 os.path.expanduser('~/workspace/roblox_deobf/bin/luau'),
                 os.environ.get('LUAU_BIN', '')):
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    return None

def run_luau(luau, code, tag, timeout=600):
    import tempfile
    fd, path = tempfile.mkstemp(suffix=f'-{tag}.luau')
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(code)
        return subprocess.run([luau, path], capture_output=True, text=True,
                              timeout=timeout)
    finally:
        os.unlink(path)

def harness_base(stripped, names, link):
    esc = ''.join('\\%03d' % b for b in stripped.encode())
    names_lua = '{' + ','.join('"%s"' % n.replace('\\', '\\\\').replace('"', '\\"') for n in names) + '}'
    return ('local src = "' + esc + '"\n'
            'local t = assert(loadstring(src))()\n'
            f'local names = {names_lua}\n'
            f'pcall(t.{link}, t, names, "ZZZ_no_entry")\n')

def lua_bytes(raw):
    return '"' + ''.join('\\%03d' % b for b in raw) + '"'

# ------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description='Deobfuscate MoonVeil 2.x linker builds')
    ap.add_argument('input')
    ap.add_argument('-o', '--outdir', default=None)
    ap.add_argument('--luau', default=None)
    ap.add_argument('--trace', action='store_true',
                    help='also run the chunk in a mocked Roblox environment '
                         'and log its behaviour (HttpGet/loadstring stubbed)')
    ap.add_argument('--spoof-id', choices=('auto', 'off'), default='auto',
                    help='dynamic game-ID spoofing (shared spoof_engine): '
                         'auto scans the RECOVERED source for identity '
                         'gates, runs one mock trace per fork from '
                         'plan_forks() and emits identity_report.json; '
                         'off restores exact legacy behaviour (no '
                         'identity artifacts)')
    args = ap.parse_args()

    data = open(args.input, 'rb').read()
    src = data.decode('utf-8', errors='strict')
    sha = hashlib.sha256(data).hexdigest()
    outdir = args.outdir or os.path.splitext(os.path.basename(args.input))[0] + '-moonveil-deobf'
    os.makedirs(outdir, exist_ok=True)
    print(f"[0] input {args.input}  {len(data)} bytes  sha256={sha[:16]}...")

    tail = find_tail(src)
    if not tail:
        print("[1] no linker tail call found -> not the 2.x linker profile")
        return 2
    names, entry, link = tail['names'], tail['entry'], tail['link']
    print(f"[1] linker profile: link=:{link}  names={len(names)}  entry={entry!r}")

    folded = fold_mod.fold_source(src)
    open(os.path.join(outdir, 'folded.luau'), 'w', encoding='utf-8').write(folded)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes")

    luau = find_luau(args.luau)
    if not luau:
        print("[!] luau binary not found"); return 5

    # phase 1: recover name -> positional index by function identity
    code = harness_base(tail['stripped'], names, link) + '''
for _, n in ipairs(names) do
    local idx = 0
    if t[n] ~= nil then
        for i = 1, #t do
            if t[i] == t[n] then idx = i break end
        end
    end
    print("PERM|" .. n .. "|" .. idx)
end
'''
    r = run_luau(luau, code, 'perm')
    if r.returncode != 0:
        print("[!] link harness failed:", r.stderr[-400:]); return 5
    perm = {}
    for line in r.stdout.splitlines():
        p = line.split('|')
        if len(p) == 3 and p[0] == 'PERM':
            perm[p[1]] = int(p[2])
    inv = {v: k for k, v in perm.items() if v}
    print(f"[3] permutation recovered: {len(inv)}/{len(names)} positional names")
    if not inv:
        # M3: tail matched but the link harness recovered no name
        # mapping at all -> not this profile, not a partial result.
        print(f"[!] zero permutation recovered (linker tail :{link} "
              f"with {len(names)} names, entry {entry!r}) "
              f"-> not this profile")
        return 2

    pos, keyed = split_table(folded)
    print(f"    table elements: {len(pos)} positional, keyed={sorted(keyed)}")

    # cache field: most common `.<name>[k] or` idiom target
    from collections import Counter
    cache_votes = Counter(re.findall(r'\.(\w+)\[\s*-?\d+\s*\]\s*or\s*\w+:', folded))
    if not cache_votes:
        # M3: tail matched but no cache idiom -> this is not the linker
        # profile (a tail-shape false positive), not a partial
        # decryption. Exit 2 with the tail evidence, not 5.
        print(f"[!] cache idiom not found (linker tail :{link} with "
              f"{len(names)} names, entry {entry!r} matched, but no "
              f"cache-idiom/helper classification) -> not this profile")
        return 2
    CACHE = cache_votes.most_common(1)[0][0]
    print(f"    cache field: {CACHE}")

    # classify raw helpers by body shape:
    # function(self, p2, ..., pN) self.CACHE[pN] = rhs return self.CACHE[pN] end
    shape = re.compile(r'function\s*\(\s*(\w+)((?:\s*,\s*\w+)+)\s*\)\s*\1\.' + CACHE +
                       r'\[(\w+)\]\s*=\s*(.+?)\s*return\s+\1\.' + CACHE + r'\[\3\]\s*end', re.S)
    num_methods, str_method, str_m = set(), None, None
    for idx, tx in enumerate(pos, 1):
        m = shape.search(tx)
        if not m: continue
        params = [m.group(1)] + [p.strip() for p in m.group(2).split(',') if p.strip()]
        if m.group(3) != params[-1] or len(params) < 3: continue
        rhs = m.group(4).strip()
        nm = inv.get(idx)
        if nm is None: continue
        ms = re.fullmatch(re.escape(m.group(1)) + r'\.(\w+)\(\s*' +
                          re.escape(params[1]) + r'\s*,\s*' + re.escape(params[2]) + r'\s*\)', rhs)
        if ms:
            str_method, str_m = nm, ms.group(1)
        else:
            num_methods.add(nm)
    print(f"    numeric helpers: {sorted(num_methods)}  string helper: {str_method} (combiner {str_m})")
    if not num_methods and not str_method:
        # M3: same as the cache-idiom case — no helpers classified
        # means nothing was decrypted, so "not this profile" (2) is
        # more honest than PARTIAL (5). Exit 5 is kept for genuine
        # partial decryption (helpers found, some sites unevaluated).
        print(f"[!] no decrypt helpers classified (linker tail :{link} "
              f"with {len(names)} names, entry {entry!r} matched, "
              f"cache field {CACHE}) -> not this profile")
        return 2

    # entry instantiation list
    eidx = perm.get(entry, 0)
    entry_src = pos[eidx - 1] if eidx else keyed.get(entry, '')
    pairs_inst = []
    for m in re.finditer(r'((?:\w+\.\w+\s*,\s*)*\w+\.\w+)\s*=\s*((?:\w+:\w+\(\)\s*,\s*)*\w+:\w+\(\))', entry_src):
        lhs = [x.strip().split('.')[-1] for x in m.group(1).split(',')]
        rhs = re.findall(r':(\w+)\(\)', m.group(2))
        if len(lhs) == len(rhs):
            pairs_inst += list(zip(lhs, rhs))
    print(f"    entry instantiation: {pairs_inst}")

    # harvest call sites
    num_alt = '|'.join(sorted(num_methods)) if num_methods else None
    num_sites, str_sites = {}, {}
    QF = None
    if num_alt:
        for m in re.finditer(r'\w+:(' + num_alt + r')\(' + ARGS_NUM + r'\)', folded):
            num_sites[(m.group(1), tuple(int(x) for x in m.group(2).split(',')))] = None
    if str_method:
        sm = re.search(r'\w+:(' + str_method + r')\(\s*\w+\.(\w+)"', folded)
        if sm: QF = sm.group(2)
        if QF:
            pat = (r'\w+:(' + str_method + r')\(\s*\w+\.' + QF + STR_LIT +
                   r'\s*,\s*\w+\.' + QF + STR_LIT + r'\s*,\s*(-?\d+)\s*\)')
            def _raw(u):
                return u if isinstance(u, bytes) else u.encode('latin-1', 'replace')
            for m in re.finditer(pat, folded):
                f1 = _raw(extract_vm.luau_unescape(m.group(2)))
                f2 = _raw(extract_vm.luau_unescape(m.group(3)))
                str_sites[(f1, f2, int(m.group(4)))] = None
    print(f"[4] call sites: {len(num_sites)} numeric, {len(str_sites)} string (frag field {QF})")

    # phase 2 harness: instantiate + evaluate
    lines = [harness_base(tail['stripped'], names, link)]
    if pairs_inst:
        # NOTE: instantiate SEQUENTIALLY in entry order. The entry writes
        # it as one multiple assignment, but in the harness (raw linked
        # table) builders read sibling fields, so one-at-a-time it is.
        lines += [f't.{fld} = t:{meth}()' for fld, meth in pairs_inst]
    for (meth, a) in num_sites:
        argstr = ', '.join(map(str, a))
        lines.append(f'print("DEC|{meth}|{argstr}|" .. tostring(t:{meth}({argstr})))')
    for (f1, f2, key) in str_sites:
        lines.append(f'print("STR|{key}|" .. (t:{str_method}(t.{QF}({lua_bytes(f1)}), t.{QF}({lua_bytes(f2)}), {key}):gsub(".", function(ch) return string.format("\\\\%03d", string.byte(ch)) end)))')
    r = run_luau(luau, '\n'.join(lines) + '\n', 'eval')
    if r.returncode != 0:
        print("[!] eval harness failed:", r.stderr[-400:]); return 5
    values, strings = {}, {}
    def dec_ddd(s):
        out, i = bytearray(), 0
        while i < len(s):
            if s[i] == '\\' and s[i + 1:i + 4].isdigit():
                out.append(int(s[i + 1:i + 4])); i += 4
            else:
                out += s[i].encode('latin-1'); i += 1
        return bytes(out)
    for line in r.stdout.splitlines():
        p = line.split('|')
        if len(p) == 4 and p[0] == 'DEC':
            a = tuple(int(x) for x in p[2].split(', '))
            v = float(p[3]) if ('.' in p[3] or 'e' in p[3]) else int(p[3])
            values[(p[1], a)] = v
        elif len(p) == 3 and p[0] == 'STR':
            strings[int(p[1])] = dec_ddd(p[2])
    print(f"[5] evaluated: {len(values)} numeric constants, {len(strings)} strings")

    # substitute
    def fmt(v):
        s = str(int(v)) if isinstance(v, float) and v == int(v) else repr(v)
        return f"({s})"
    def lua_lit(raw):
        out = []
        for b in raw:
            if b == 34: out.append('\\"')
            elif b == 92: out.append('\\\\')
            elif 32 <= b < 127: out.append(chr(b))
            else: out.append('\\%03d' % b)
        return '"' + ''.join(out) + '"'
    out = folded
    n_sub = 0
    if num_alt:
        sa_num = re.compile(r'\w+\.' + CACHE + r'\[(-?\d+)\]\s*or\s*\w+:(' + num_alt + r')\(' + ARGS_NUM + r'\)')
        def rep_sa_num(m):
            nonlocal n_sub
            a = tuple(int(x) for x in m.group(3).split(','))
            v = values.get((m.group(2), a))
            if v is None: return m.group(0)
            n_sub += 1; return fmt(v)
        out = sa_num.sub(rep_sa_num, out)
        bare_num = re.compile(r'\w+:(' + num_alt + r')\(' + ARGS_NUM + r'\)')
        def rep_num(m):
            nonlocal n_sub
            a = tuple(int(x) for x in m.group(2).split(','))
            v = values.get((m.group(1), a))
            if v is None: return m.group(0)
            n_sub += 1; return fmt(v)
        out = bare_num.sub(rep_num, out)
    if str_method and QF:
        pat = (r'\w+:(' + str_method + r')\(\s*\w+\.' + QF + STR_LIT +
               r'\s*,\s*\w+\.' + QF + STR_LIT + r'\s*,\s*(-?\d+)\s*\)')
        sa_str = re.compile(r'\w+\.' + CACHE + r'\[(-?\d+)\]\s*or\s*(' + pat + r')')
        def rep_sa_str(m):
            nonlocal n_sub
            v = strings.get(int(m.group(1)))   # the Sa[k] key == the Ta key
            if v is None: return m.group(0)
            n_sub += 1; return lua_lit(v)
        out = sa_str.sub(rep_sa_str, out)
        bare_str = re.compile(pat)
        def rep_str(m):
            nonlocal n_sub
            v = strings.get(int(m.group(4)))
            if v is None: return m.group(0)
            n_sub += 1; return lua_lit(v)
        out = bare_str.sub(rep_str, out)
    dec_path = os.path.join(outdir, 'decrypted.luau')
    comp = os.path.join(os.path.dirname(luau), 'luau-compile')
    # stage 7: semantics-preserving clean passes (clean.py) with two
    # gates — literal-multiset equivalence and luau-compile PASS on
    # the cleaned text. If either gate fails, the uncleaned output
    # is delivered instead and the revert is recorded in qa_report.
    import clean as clean_mod
    cleaned, cstats = clean_mod.clean_source(out)
    def _lit_multiset(text):
        from collections import Counter
        nums, strs = [], []
        for kind, seg in fold_mod.split_segments(text):
            if kind == 'code':
                nums += re.findall(r'(?<![\w.])\d+', seg)
            elif seg.startswith(('"', "'")):
                strs.append(seg)
        return Counter(nums), Counter(strs)
    _equiv = _lit_multiset(out) == _lit_multiset(cleaned)
    _clean_compile = None
    if os.path.isfile(comp):
        import tempfile
        fd, _tmp = tempfile.mkstemp(suffix='-cleancheck.luau')
        try:
            with os.fdopen(fd, 'w') as f:
                f.write(cleaned)
            _clean_compile = subprocess.run(
                [comp, _tmp], capture_output=True).returncode == 0
        finally:
            os.unlink(_tmp)
    clean_applied = bool(_equiv and _clean_compile)
    cstats['applied'] = clean_applied
    cstats['equivalence_ok'] = _equiv
    cstats['clean_compile_ok'] = _clean_compile
    final = cleaned if clean_applied else out
    if not clean_applied:
        print(f"[7] clean passes REVERTED (equivalence={_equiv}, "
              f"clean_compile={_clean_compile}); delivering uncleaned")
    else:
        print(f"[7] clean passes applied: {cstats}")
    open(dec_path, 'w', encoding='utf-8').write(final)
    print(f"[6] substituted {n_sub} sites -> decrypted.luau")

    comp = os.path.join(os.path.dirname(luau), 'luau-compile')
    compile_ok = None
    if os.path.isfile(comp):
        rr = subprocess.run([comp, dec_path], capture_output=True)
        compile_ok = rr.returncode == 0
    print(f"    luau-compile: {compile_ok}")

    states = []
    try:
        toks = list(extract_vm._tokens(out))
        for li, (lo, hi, var, kind_loop) in enumerate(mv_static.find_dispatches(toks)):
            for st in mv_static.extract_states(out, toks, lo + 1, hi - 1, var):
                st['loop'] = li; st['loop_kind'] = kind_loop; st['state_var'] = var
                states.append(st)
        print(f"    states: {len(states)} leaf blocks")
    except Exception as e:
        print("    states extraction failed:", e)
    json.dump(states, open(os.path.join(outdir, 'states.json'), 'w'), indent=0)
    json.dump({f"{m}|{','.join(map(str, a))}": v for (m, a), v in values.items()},
              open(os.path.join(outdir, 'constants.json'), 'w'), indent=0)
    json.dump({str(k): v.decode('utf-8', 'replace') for k, v in strings.items()},
              open(os.path.join(outdir, 'strings.json'), 'w'), ensure_ascii=False, indent=0)
    roles = {'cache': CACHE, 'numeric_helpers': sorted(num_methods),
             'string_helper': str_method, 'string_combiner': str_m,
             'fragment_field': QF, 'entry': entry, 'instantiation': pairs_inst,
             'permutation': {k: v for k, v in perm.items() if v}}
    json.dump(roles, open(os.path.join(outdir, 'roles.json'), 'w'), indent=0)
    # Naming evidence + slot-reuse conflicts (v1.2.0 self-audit).
    # No renaming happens here: a conflicted slot is addressed by
    # both linker phases, so renaming would break identity. The
    # resolution is detection + neutral labelling + QA flagging.
    # Evidence is gathered from CODE segments only, so string
    # contents (e.g. the encoded blob) can never fake a key.
    field_roles = {}
    def _add_role(f, r):
        if f:
            field_roles.setdefault(f, set()).add(r)
    for _nm in num_methods:
        _add_role(_nm, 'helper-numeric')
    _add_role(str_method, 'helper-string')
    _add_role(str_m, 'combiner')
    _add_role(QF, 'fragment-field')
    _add_role(CACHE, 'cache-field')
    for _fld, _meth in pairs_inst:
        _add_role(_fld, 'instantiated-field')
    naming_evidence = {}
    # NOTE: evidence is gathered from the SUBSTITUTED source (out),
    # not the folded table: the string keys (e.g. "type") only
    # appear literally after Ta call sites are replaced by their
    # decoded values. Element order is unchanged by substitution.
    # A `["key"]` pattern straddles segment boundaries (brackets
    # in code, content in a string segment), so matches are kept
    # only when the `[` itself is in code — a `["x"]`-shaped
    # substring INSIDE a string literal (e.g. the encoded blob)
    # is never counted as evidence.
    def _code_index_keys(tx):
        str_spans, off = [], 0
        for _kind, _seg in fold_mod.split_segments(tx):
            if _kind == 'str':
                str_spans.append((off, off + len(_seg)))
            off += len(_seg)
        keys = set()
        for _m in re.finditer(r'\["([^"]+)"\]', tx):
            if any(s <= _m.start() < e for s, e in str_spans):
                continue
            keys.add(_m.group(1))
        return sorted(keys)
    pos_dec, _keyed_dec = split_table(out)
    for _idx, _tx in enumerate(pos_dec, 1):
        _nm = inv.get(_idx)
        if _nm is None:
            continue
        _keys = _code_index_keys(_tx)
        if _keys:
            naming_evidence[_nm] = {'strings_referenced': _keys,
                                    'label': 'neutral'}
        # String-call targets: a quoted/long-bracket string segment
        # whose preceding code segment ends in `.<field>` means the
        # field is called with a string argument (e.g. `a.q"blob"`).
        # Segment order is used (not a raw regex) so a `.q"`-shaped
        # substring INSIDE a string literal can never fake a role.
        _prev_code = ''
        for _kind, _seg in fold_mod.split_segments(_tx):
            if _kind == 'code':
                _prev_code = _seg
            elif _seg[:1] in ('"', "'", '['):
                _m = re.search(r'\.(\w+)\s*$', _prev_code.rstrip())
                if _m:
                    _add_role(_m.group(1), 'string-call-target')
    slot_conflicts = sorted(
        f for f, rs in field_roles.items()
        if 'instantiated-field' in rs and rs & {'combiner', 'fragment-field'})
    multi_role_fields = sorted(
        f for f, rs in field_roles.items() if len(rs) >= 2)
    json.dump(naming_evidence,
              open(os.path.join(outdir, 'naming_evidence.json'), 'w'),
              indent=0, sort_keys=True)
    print(f"    naming evidence: {sorted(naming_evidence)}; "
          f"slot conflicts: {slot_conflicts}")
    status = 'DECRYPTED' if (compile_ok and len(values) == len(num_sites)) else 'PARTIAL'
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write(f"""# MoonVeil 2.x linker-build deobfuscation (moonveil2)

- input: {os.path.basename(args.input)} ({len(data)} bytes, sha256 {sha})
- profile: linker `:{link}`, {len(names)} named entries, entry `{entry}`
- roles discovered: cache `{CACHE}`; numeric helpers {sorted(num_methods)};
  string helper `{str_method}` via combiner `{str_m}` + fragment field `{QF}`
- decrypted: {len(values)} numeric constants, {len(strings)} strings;
  {n_sub} call sites substituted; luau-compile: {compile_ok}
- state graph: {len(states)} leaf blocks (states.json)
- status: {status} (VM state machines remain as while-true dispatch with
  real constants/strings inline; run a mock-env trace to read behaviour)
""")
    # stage 8: linearize the dispatch loops of the delivered
    # (cleaned) decrypted source; states.json above is extracted
    # from the pre-clean text (graph data is clean-invariant:
    # clean changes no state numbers, transitions or literals).
    lin_src, cfg_text = final, ''
    try:
        import linearize as lin_mod
        lin_src, lstats, cfg_text = lin_mod.linearize_source(final, roles)
        # Clean the linearized text too (same gates): linearize
        # reflows leaf bodies onto their own lines, which changes
        # paren-adjacency — e.g. `e=(178)end` in decrypted stays
        # guarded, but as a standalone Tier B line `e=(178)` it is
        # safely collapsible. Without this second pass the two
        # stages would disagree by exactly that class of site.
        lin_cleaned, lin_cstats = clean_mod.clean_source(lin_src)
        _lin_equiv = _lit_multiset(lin_src) == _lit_multiset(lin_cleaned)
        _lin_compile = None
        if os.path.isfile(comp):
            import tempfile as _tf
            _fd, _tmp = _tf.mkstemp(suffix='-linclean.luau')
            try:
                with os.fdopen(_fd, 'w') as f:
                    f.write(lin_cleaned)
                _lin_compile = subprocess.run(
                    [comp, _tmp], capture_output=True).returncode == 0
            finally:
                os.unlink(_tmp)
        if _lin_equiv and _lin_compile:
            lin_src = lin_cleaned
            print(f"[8b] linearized clean applied: {lin_cstats}")
        else:
            print(f"[8b] linearized clean REVERTED "
                  f"(equivalence={_lin_equiv}, compile={_lin_compile})")
        lin_path = os.path.join(outdir, 'linearized.luau')
        open(lin_path, 'w', encoding='utf-8').write(lin_src)
        open(os.path.join(outdir, 'cfg.md'), 'w', encoding='utf-8').write(cfg_text)
        lin_ok = None
        if os.path.isfile(comp):
            rr = subprocess.run([comp, lin_path], capture_output=True)
            lin_ok = rr.returncode == 0
        print(f"[8] linearize: {lstats} compile={lin_ok}")
        with open(os.path.join(outdir, 'report.md'), 'a', encoding='utf-8') as f:
            f.write(f"- linearized.luau: {lstats}, luau-compile: {lin_ok} "
                    f"(per-function graphs in cfg.md)\n")
    except Exception as e:
        print(f"[8] linearize skipped: {e}")
    # stage 9: self-check QA over the DELIVERED files.
    try:
        import qa as qa_mod
        _probe = se.PROBE_VALUE if se is not None else None
        qa_rep = qa_mod.build_qa(final, lin_src, roles, cfg_text,
                                 slot_conflicts, multi_role_fields,
                                 naming_evidence, cstats, compile_ok,
                                 bool(cstats.get('equivalence_ok')),
                                 probe_value=_probe)
        with open(os.path.join(outdir, 'qa_report.json'), 'w',
                  encoding='utf-8') as f:
            json.dump(qa_rep, f, indent=1, sort_keys=True)
            f.write('\n')
        with open(os.path.join(outdir, 'report.md'), 'a',
                  encoding='utf-8') as f:
            f.write(qa_mod.report_section(qa_rep))
        print(f"[9] QA: kept={qa_rep['kept_loop_count']} "
              f"slot_conflicts={slot_conflicts} "
              f"residue={[r['category'] for r in qa_rep['residue']]}")
    except Exception as e:
        print(f"[9] QA skipped: {e}")
    if args.trace:
        run_trace(luau, src, outdir, recovered_source=final,
                  spoof_mode=args.spoof_id)
    elif args.spoof_id == 'auto':
        # Scan-only identity report (no execution): the gate scan
        # itself is static, so every auto run gets a report even
        # without --trace; forks need --trace.
        try:
            run_identity_scan(outdir, final)
            print("[7b] identity: scan-only report -> identity_report.json")
        except Exception as e:
            print(f"[!] identity scan skipped: {e}")
    print(f"[7] status: {status}")
    return 0 if status == 'DECRYPTED' else 5

# ------------------------------------------------------------ spoofing
# Shared dynamic game-ID spoof engine port (SPOOF-SPEC §10).
# Branch rule for this tool: there is NO validated MoonVeil decoy
# signature, so real runs leave every fork 'unclassified' (is_pass
# None) — a gate-pass label requires a caller-supplied is_pass rule,
# as the synthetic test supplies. Never infer gate-pass from raw
# signals (e.g. an HttpGet alone proves nothing about which gate
# branch ran when no gate was found).
#
# Gate model: the scanner reads the RECOVERED source (decrypted /
# linearized output) — never the raw obfuscated blob, whose
# string-encrypted names would false-positive. Primary scan is the
# bundled luau-ast JSON AST; a regex scan over the recovered text
# is the fallback when luau-ast is unavailable (noted in the
# report). Luau-side sentinel capture is impossible (== between a
# table and a number never fires __eq), so forks use static seeds
# + probe serving only.

def _ast_nodes(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _ast_nodes(v)
    elif isinstance(o, list):
        for v in o:
            yield from _ast_nodes(v)


def _game_field(node):
    """AstExprIndexName `game.<field>` -> field name, else None."""
    if not isinstance(node, dict) or node.get('type') != 'AstExprIndexName':
        return None
    e = node.get('expr') or {}
    if e.get('type') == 'AstExprGlobal' and e.get('global') == 'game':
        idx = node.get('index')
        if isinstance(idx, str) and node.get('op') == '.':
            return idx
    return None


def _const_value(node):
    if not isinstance(node, dict):
        return None
    if node.get('type') == 'AstExprConstantNumber':
        v = node.get('value')
        if isinstance(v, float) and v == int(v):
            return int(v)
        return v
    if node.get('type') == 'AstExprConstantString':
        return node.get('value')
    return None


def _node_line(node):
    try:
        return int(str(node.get('location', '0,0')).split(' ')[0].split(',')[0]) + 1
    except Exception:
        return 0


def _scan_ast(source_text):
    """AST gate scan via bundled luau-ast. Returns
    (candidates, fields_read, extra_fields, notes). Raises on any
    failure so the caller can fall back to the regex scan."""
    ast_bin = os.path.join(HERE, 'bin', 'luau-ast')
    if not (os.path.isfile(ast_bin) and os.access(ast_bin, os.X_OK)):
        raise RuntimeError('luau-ast binary not found')
    import tempfile
    fd, path = tempfile.mkstemp(suffix='-gatescan.luau')
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(source_text)
        r = subprocess.run([ast_bin, path], capture_output=True, text=True,
                           timeout=120)
        if r.returncode != 0:
            raise RuntimeError('luau-ast failed: ' + r.stderr[-200:])
        doc = json.loads(r.stdout)
    finally:
        os.unlink(path)
    nodes = list(_ast_nodes(doc))
    fields_read = {}
    all_fields = set()
    for n in nodes:
        f = _game_field(n)
        if f:
            all_fields.add(f)
            loc = f"recovered:{_node_line(n)}"
            fields_read.setdefault(f, [])
            if loc not in fields_read[f]:
                fields_read[f].append(loc)
    extra = sorted(f for f in all_fields if f not in se.IDENTITY_FIELDS)
    # Set tables: local name -> constant keys (constructor items and
    # `name[const] = ...` assignments).
    sets = {}
    for n in nodes:
        if n.get('type') == 'AstStatLocal':
            for var, val in zip(n.get('vars') or [], n.get('values') or []):
                if isinstance(val, dict) and val.get('type') == 'AstExprTable':
                    keys = set()
                    for it in val.get('items') or []:
                        if isinstance(it, dict):
                            kv = _const_value(it.get('key'))
                            if kv is not None:
                                keys.add(kv)
                    if keys:
                        sets.setdefault(var.get('name'), set()).update(keys)
        elif n.get('type') == 'AstStatAssign':
            for tgt in n.get('vars') or []:
                if isinstance(tgt, dict) and tgt.get('type') == 'AstExprIndexExpr':
                    e = tgt.get('expr') or {}
                    name = None
                    if e.get('type') == 'AstExprLocal':
                        name = (e.get('local') or {}).get('name')
                    kv = _const_value(tgt.get('index'))
                    if name and kv is not None:
                        sets.setdefault(name, set()).add(kv)
    events = []
    binmap_field_left = {'CompareEq': 'eq', 'CompareNe': 'ne',
                         'CompareLt': 'gt', 'CompareGt': 'lt',
                         'CompareLe': 'ge', 'CompareGe': 'le'}
    binmap_const_left = {'CompareEq': 'eq', 'CompareNe': 'ne',
                         'CompareLt': 'lt', 'CompareGt': 'gt',
                         'CompareLe': 'le', 'CompareGe': 'ge'}
    for n in nodes:
        if n.get('type') == 'AstExprBinary':
            op = n.get('op')
            lf, rf = _game_field(n.get('left')), _game_field(n.get('right'))
            lv, rv = _const_value(n.get('left')), _const_value(n.get('right'))
            if lf and rv is not None and op in binmap_field_left:
                events.append({'field': lf, 'op': binmap_field_left[op],
                               'value': rv, 'proto': 'recovered',
                               'pc': _node_line(n),
                               'pattern': f'game.{lf} {op} {rv!r}'})
            elif rf and lv is not None and op in binmap_const_left:
                events.append({'field': rf, 'op': binmap_const_left[op],
                               'value': lv, 'proto': 'recovered',
                               'pc': _node_line(n),
                               'pattern': f'{lv!r} {op} game.{rf}'})
        elif n.get('type') == 'AstExprIndexExpr':
            f = _game_field(n.get('index'))
            if not f:
                continue
            keys = None
            e = n.get('expr') or {}
            if e.get('type') == 'AstExprLocal':
                keys = sets.get((e.get('local') or {}).get('name'))
            elif e.get('type') == 'AstExprTable':
                keys = set()
                for it in e.get('items') or []:
                    if isinstance(it, dict):
                        kv = _const_value(it.get('key'))
                        if kv is not None:
                            keys.add(kv)
            if keys:
                for k in sorted(keys, key=str):
                    events.append({'field': f, 'op': 'in-set', 'value': k,
                                   'proto': 'recovered',
                                   'pc': _node_line(n),
                                   'pattern': f'set-membership via game.{f}'})
    candidates = {}
    se.collect_events(candidates, events, fields=extra)
    se.sort_candidates(candidates)
    return candidates, fields_read, extra, ['gate scan: luau-ast over recovered source']


def _num_lit(s):
    try:
        f = float(s)
        return int(f) if f == int(f) else f
    except Exception:
        return None


def _scan_regex(source_text):
    """Fallback textual scan over recovered source (same gate shapes
    as the AST scan, approximated). Used only when luau-ast fails."""
    fields_read = {}
    compared = set()
    events = []

    def note_field(f, line):
        compared.add(f)
        loc = f"recovered:{line}"
        fields_read.setdefault(f, [])
        if loc not in fields_read[f]:
            fields_read[f].append(loc)

    for i, line in enumerate(source_text.splitlines(), 1):
        for m in re.finditer(r'game\.(\w+)\s*(==|~=|<|>|<=|>=)\s*(-?\d+(?:\.\d+)?)', line):
            f, op, v = m.group(1), m.group(2), _num_lit(m.group(3))
            if v is None:
                continue
            note_field(f, i)
            mp = {'==': 'eq', '~=': 'ne', '<': 'gt', '>': 'lt',
                  '<=': 'ge', '>=': 'le'}[op]
            events.append({'field': f, 'op': mp, 'value': v,
                           'proto': 'recovered', 'pc': i,
                           'pattern': f'game.{f} {op} {v!r}'})
        for m in re.finditer(r'(-?\d+(?:\.\d+)?)\s*(==|~=|<|>|<=|>=)\s*game\.(\w+)', line):
            v, op, f = _num_lit(m.group(1)), m.group(2), m.group(3)
            if v is None:
                continue
            note_field(f, i)
            mp = {'==': 'eq', '~=': 'ne', '<': 'lt', '>': 'gt',
                  '<=': 'le', '>=': 'ge'}[op]
            events.append({'field': f, 'op': mp, 'value': v,
                           'proto': 'recovered', 'pc': i,
                           'pattern': f'{v!r} {op} game.{f}'})
        for m in re.finditer(r'game\.(\w+)', line):
            note_field(m.group(1), i)
    sets = {}
    for m in re.finditer(r'(\w+)\[(-?\d+)\]\s*=', source_text):
        sets.setdefault(m.group(1), set()).add(_num_lit(m.group(2)))
    for m in re.finditer(r'(\w+)\[game\.(\w+)\]', source_text):
        for k in sorted(sets.get(m.group(1), set()), key=str):
            events.append({'field': m.group(2), 'op': 'in-set', 'value': k,
                           'proto': 'recovered', 'pc': 0,
                           'pattern': f'set-membership via {m.group(1)}'})
    extra = sorted(f for f in compared if f not in se.IDENTITY_FIELDS)
    candidates = {}
    se.collect_events(candidates, events, fields=extra)
    se.sort_candidates(candidates)
    return candidates, fields_read, extra, \
        ['gate scan: regex fallback over recovered source (luau-ast unavailable)']


def scan_identity_gates(source_text):
    """Scan RECOVERED source for identity gates. Returns
    (candidates, fields_read, extra_fields, notes). Never scans the
    raw obfuscated blob."""
    if se is None:
        raise RuntimeError('spoof_engine not available')
    try:
        return _scan_ast(source_text)
    except Exception as e:
        notes_fallback = [f'luau-ast scan failed ({e}); regex fallback used']
        c, fr, ex, notes = _scan_regex(source_text)
        return c, fr, ex, notes_fallback + notes


def _lua_str(s):
    out = []
    for ch in s:
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif ch == '\t':
            out.append('\\t')
        elif 32 <= ord(ch) < 127:
            out.append(ch)
        else:
            for b in ch.encode('utf-8'):
                out.append('\\%03d' % b)
    return '"' + ''.join(out) + '"'


def lua_seed_literal(seeds):
    if not seeds:
        return '{}'
    parts = []
    for f in sorted(seeds):
        v = seeds[f]
        if isinstance(v, bool):
            lit = 'true' if v else 'false'
        elif isinstance(v, (int, float)):
            lit = str(int(v)) if float(v) == int(v) else repr(v)
        else:
            lit = _lua_str(str(v))
        parts.append(f'["{f}"] = {lit}')
    return '{' + ', '.join(parts) + '}'


def _trace_code(tpl, src, enabled, seeds):
    esc = ''.join('\\%03d' % b for b in src.encode())
    code = tpl.replace('"__SRC__"', '"' + esc + '"')
    code = code.replace('__IDENTITY_SPOOF_ENABLED__',
                        'true' if enabled else 'false')
    code = code.replace('__IDENTITY_SEEDS__', lua_seed_literal(seeds))
    probe = str(se.PROBE_VALUE) if se is not None else '7777777777777'
    code = code.replace('__PROBE_VALUE__', probe)
    return code


def _run_one_trace(luau, code, tag, timeout=180):
    import tempfile
    fd, path = tempfile.mkstemp(suffix=f'-{tag}.luau')
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(code)
        r = subprocess.run([luau, path], capture_output=True, text=True,
                           timeout=timeout, errors='replace')
        return r.returncode, r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return None, '(trace timed out after 180s)\n'
    finally:
        os.unlink(path)


def parse_trace_log(log):
    reads = []
    for m in re.finditer(r'\[IDREAD\] (\w+) (.+) (seed|probe)$', log, re.M):
        reads.append({'field': m.group(1), 'value': m.group(2),
                      'source': m.group(3)})
    prints = re.findall(r'^\[print\] (.*)$', log, re.M)
    http_calls = re.findall(r'\[HTTPGET\] (\S+)', log)
    return {'identity_reads': reads,
            'prints_total': len(prints),
            'prints_top': prints[:8],
            'mock_calls': len(re.findall(r'^\[proxy\]', log, re.M)),
            'http_attempts': len(http_calls),
            'http_calls': http_calls,
            'finished': '[chunk finished] ok:\ttrue' in log}


def run_trace(luau, src, outdir, recovered_source=None, spoof_mode='auto',
              is_pass=None):
    """Execute the original chunk under the mock-environment template
    (trace_template.luau): Roblox globals are logging proxies, HttpGet
    and loadstring are stubbed — remote code is never fetched or run.

    spoof_mode 'off' (or a missing spoof_engine) reproduces the exact
    legacy behaviour: one trace, trace.log, behaviour section, no
    identity artifacts. spoof_mode 'auto' scans the recovered source
    for identity gates, runs one trace per fork from plan_forks(),
    and emits identity_report.json (unified spoof-engine/1) plus an
    identity section in report.md. trace.log is fork 0's log."""
    tpl_path = os.path.join(HERE, 'trace_template.luau')
    if not os.path.isfile(tpl_path):
        print("[trace] template missing, skipped"); return None
    tpl = open(tpl_path, encoding='utf-8').read()
    if spoof_mode == 'off' or se is None:
        code = _trace_code(tpl, src, False, {})
        _rc, log = _run_one_trace(luau, code, 'trace')
        open(os.path.join(outdir, 'trace.log'), 'w', encoding='utf-8').write(log)
        parsed = parse_trace_log(log)
        httpgets = parsed['http_calls']
        instances = re.findall(r'\[Instance\.new\] (\w+)', log)
        texts = re.findall(r'\.Text = "([^"]*)"', log)
        finished = parsed['finished']
        print(f"[trace] finished_ok={finished} instances={len(instances)} "
              f"httpgets={httpgets} texts={texts[:6]}")
        with open(os.path.join(outdir, 'report.md'), 'a', encoding='utf-8') as f:
            f.write(f"\n## behaviour trace (mock env, remote code stubbed)\n\n")
            f.write(f"- ran to completion: {finished}\n")
            f.write(f"- Instance.new: {instances}\n")
            f.write(f"- GUI texts seen: {texts}\n")
            f.write(f"- HttpGet URLs: {httpgets}\n")
            f.write(f"- full log: trace.log\n")
        return None
    # --- auto: scan recovered source, then fork traces ---
    if recovered_source is None:
        dec = os.path.join(outdir, 'decrypted.luau')
        recovered_source = open(dec, encoding='utf-8').read() if os.path.isfile(dec) else ''
    if recovered_source:
        candidates, fields_read, extra, notes = scan_identity_gates(recovered_source)
    else:
        candidates, fields_read, extra = {}, {}, []
        notes = ['gate scan skipped: no recovered source available; '
                 'raw blob is never scanned for field names']
    forks, _primary = se.plan_forks(candidates)
    seed = se.build_seed(candidates)
    fork_records, all_reads = [], []
    for fi, seeds in enumerate(forks):
        code = _trace_code(tpl, src, True, seeds)
        rc, log = _run_one_trace(luau, code, f'trace-fork{fi}')
        open(os.path.join(outdir, f'trace-fork-{fi}.log'), 'w',
             encoding='utf-8').write(log)
        if fi == 0:
            open(os.path.join(outdir, 'trace.log'), 'w',
                 encoding='utf-8').write(log)
        parsed = parse_trace_log(log)
        reads = parsed.pop('identity_reads')
        for r in reads:
            all_reads.append({'fork': fi, **r})
        fork_records.append({
            'fork': fi, 'exit': rc if rc is not None else -1,
            'seeds': {f: {'value': v,
                          'source': se.candidate_source(candidates, f, v)}
                      for f, v in sorted(seeds.items())},
            'identity_reads': reads,
            'prints_total': parsed['prints_total'],
            'prints_top': parsed['prints_top'],
            'mock_calls': parsed['mock_calls'],
            'http_attempts': parsed['http_attempts'],
            'http_calls': parsed['http_calls'],
            'chunk': ''})
        print(f"[trace] fork {fi}: seeds={seeds} finished={parsed['finished']} "
              f"prints={parsed['prints_total']} http={parsed['http_attempts']} "
              f"idreads={len(reads)}")
    notes = notes + [
        'Gate scan over recovered source (decrypted.luau), never the raw blob.',
        'Luau == between a table and a number never fires __eq: no '
        'sentinel capture; forks use static seeds + probe serving.',
    ]
    if is_pass is None:
        notes.append('Branch labels unclassified by default: no validated '
                     'MoonVeil decoy signature exists; a caller-supplied '
                     'is_pass rule is required for any gate-pass label.')
    rep = se.build_report(
        route='moonveil', candidates=candidates, fields_read=fields_read,
        forks=fork_records,
        seed=[{'field': f, 'value': v, 'source': 'static'}
              for f, v in sorted(seed.items())],
        identity_reads=all_reads, notes=notes,
        extra_fields=sorted(extra), is_pass=is_pass)
    with open(os.path.join(outdir, 'identity_report.json'), 'w',
              encoding='utf-8') as f:
        json.dump(rep, f, indent=1, ensure_ascii=False)
        f.write('\n')
    with open(os.path.join(outdir, 'report.md'), 'a', encoding='utf-8') as f:
        f.write("\n## behaviour trace (mock env, remote code stubbed)\n\n")
        f.write(f"- forks run: {len(fork_records)} (spoof-id auto; "
                f"per-fork logs trace-fork-N.log, trace.log = fork 0)\n")
        for fr in fork_records:
            f.write(f"- fork {fr['fork']}: seeds={fr['seeds']} "
                    f"branch={fr.get('branch', 'unclassified')} "
                    f"prints={fr['prints_total']} "
                    f"http_attempts={fr['http_attempts']}\n")
        f.write(se.report_section(rep))
    print(f"[trace] identity: gates={len(rep['gates'])} "
          f"unknown={rep['unknown_fields']} forks={len(fork_records)} "
          f"-> identity_report.json")
    return rep


def run_identity_scan(outdir, recovered_source):
    """Static-only identity report (no trace): scan the recovered
    source, emit identity_report.json + report section with
    forks=[] (fork evidence needs --trace)."""
    if se is None:
        raise RuntimeError('spoof_engine not available')
    candidates, fields_read, extra, notes = scan_identity_gates(recovered_source)
    seed = se.build_seed(candidates)
    notes = notes + [
        'Gate scan over recovered source (decrypted.luau), never the raw blob.',
        'Trace not run; run with --trace for fork evidence (forks=[] here).',
    ]
    rep = se.build_report(
        route='moonveil', candidates=candidates, fields_read=fields_read,
        forks=[],
        seed=[{'field': f, 'value': v, 'source': 'static'}
              for f, v in sorted(seed.items())],
        identity_reads=[], notes=notes, extra_fields=sorted(extra))
    with open(os.path.join(outdir, 'identity_report.json'), 'w',
              encoding='utf-8') as f:
        json.dump(rep, f, indent=1, ensure_ascii=False)
        f.write('\n')
    with open(os.path.join(outdir, 'report.md'), 'a', encoding='utf-8') as f:
        f.write(se.report_section(rep))
    return rep

if __name__ == '__main__':
    sys.exit(main())
