# Sample output — StealAnEggs.luau (bootstrap route)

These files are the **outputs of Luraph-Deobf-Tool-v6** (bootstrap
route, engine BootstrapVM v2.1) on the reference sample
`StealAnEggs.luau` (Luraph v15.1, virtualized-bootstrap
sub-variant; 1,693,989 bytes, sha256
`4c174a0606465436ac5409d23e504145a11e5eb28fb5850ab761c11c556f8d98`),
produced by the isolated regression run in `tests/` (tool copied
to a temp dir, fake HOME, scrubbed environment).

The obfuscated target file itself is **not** included in this
package.

Contents: `full_clean.luau` (**headline deliverable** — the
cleaned source: root + all recovered child protos rendered as
idiomatic Luau with restructured control flow (v6.1 clean2
stage; 525/796 instructions structured, dispatch scoped to two
irreducible kernels), 2,038 lines, 796 instructions,
luau-compile PASS,
sha256 `d50a955d55b33e2bcf47e5dc4c99abb673e19b0756d632a7e8fb4b4561197f47`),
`clean_map.json` (796/796 instructions mapped, per-proto form +
reasons) and `clean_stats.json` (equivalence audit),
`full.luau` (the raw lift the cleaned source is rendered from —
ground truth, compile-validated, 796 instructions),
`lifted.luau` (root proto, static route, compile-validated),
`children_recovered.json` (the authoritative 20-child set),
`sweep_state.json` / `sweepE_state.json` (executor accounting and
evidence), `children.json` (root materialization + the
47-descriptor static census, cross-check only), `protos.json`,
`proto_structs.json`, `root_disasm.txt`, `lift_stats.json`,
`stage1/` (gsub/src/dst bins), `report.md`, `manifest.json`.

Verdict for this sample: **PARTIAL (exit 5)** — root fully
lifted; 19/20 real children recovered (15 dz walked, 4 bz
constant artifacts; child18 proven phantom); 164/434 referenced
constants resolved in context; 6 protos keep a cleaned dispatch
form with proven reasons (see the tool README's Known limits).
