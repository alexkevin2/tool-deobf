# Luraph-BootstrapVM-Deobf — run report

- input: `stealaneggs_raw.luau` (1693989 bytes, sha256 `4c174a0606465436ac5409d23e504145a11e5eb28fb5850ab761c11c556f8d98`)
- family: Luraph v15.1, virtualized-bootstrap sub-variant (numeric-keyed VM table, blob field `MY`, FSM entry `vY`)
- verdict: **PARTIAL** (exit 5)
- total runtime: 584.8s

## Stages

| stage | result | seconds |
|---|---|---|
| stage1_decode | ok | 3.6 |
| table_parse | ok | 2.8 |
| e_fields | ok | 3.1 |
| streams | ok | 4.7 |
| eager_t0 | ok | 33.9 |
| eager_t1 | ok | 40.5 |
| eager_t2 | ok | 116.1 |
| eager_t3 | ok | 119.4 |
| eager_merge | ok | 0.4 |
| gen_disasm2 | ok | 0.1 |
| root_disasm | ok | 0.8 |
| census178 | ok | 98.2 |
| children | ok | 11.4 |
| lift | ok | 0.2 |
| factory_ast | ok | 1.7 |
| executor_sweep | ok | 140.4 |
| liftE | ok | 0.3 |
| build_cfg2 | ok | 0.2 |
| clean2 | ok | 7.0 |

## Stage 1 — static blob decode

- gsub.bin: 617190 bytes, sha256 `8329f34db797e20c6861db7c90427c68bbd036dedf39ead7796e1035c9e05231`
- src.bin: 617190 bytes, sha256 `dc507e26a9c79bf35e4c982aa96ed8f0d170a135051172662a91d83f9a40980a`
- dst.bin: 149176 bytes, sha256 `6fcda6f98b5c41288c3a6a516ba98c67de2c73532dcf6ffe3046e34c8d696835`

Method: gsub alphabet repair (`YY="[ -' }~]"` class -> `_Y` table) -> vY FSM Ascii85 decode in place -> structure table E -> payload chunk slice. The algorithm was verified byte-identically against live VM buffer captures in the original case.

## Root proto

- instructions visited by the disassembly walk: 304 (by mode: {'A': 70, 'B': 31, 'C': 203})
- access-order constants: 794 materialized, 434 unresolved (of 1228 attempted)
- lift: 271 of 304 visited instructions translated with bodies; 1 UNIMPL
- DECRYPTSTR strings still ENCRYPTED (dynamic seed or unresolved header): 9 — left marked in the output, never guessed
- luau-compile validation of lifted.luau: PASS

## Child protos — executor sweep (source of truth)

- real child protos (in-context sweep): 20
- dz children walked + lifted: 15
- bz children (constant artifacts — single-table group + verbatim slot utility closure, no instruction stream exists): 4
- unrecovered children: 1 (child18: descriptor proven phantom — its build reads slot 753511, not a function slot, and its captured factory args are incoherent in every explored state; see sweep_state.json walk_infos)
- referenced constants resolved in context: 164/434 — the remainder are placeholders: coverage ends at a capture/register fidelity wall inside proto5 (mode C pc 35, nil-index write with an unpopulated base register) under both mock policies tried
- dynamic DECRYPTSTRs decrypted in context: 7/9 (contents are binary blobs, no readable text; the unreached sites stay ENCRYPTED)
- full.luau (root + children): 796 instructions, luau-compile PASS

Method: the slot-15209 payload interpreter is executed by a Python AST interpreter over the live fz_sim objects, so materializer calls fire with their real captures and streams/fields decrypt in place (out-of-context builds, by contrast, cycle forever in the _z/v walker pair). Requires EXEC_ACT_BUDGET=2000000 (set by the driver) for deterministic execution.

## Child descriptors — static census (cross-check only)

- eager-error keyspace scanned: 11319 keys
- child descriptors censused (state-178): 47
- child protos recovered by the static route: 0

The static census is PHANTOM-PRONE and is kept only as a cross-check: of its 47 descriptors, the in-context sweep showed only 2 are real children — 34 are plain constants and 11 are garbage subtrees. Never use the census as the child set; the executor sweep above is authoritative.

## Cleaned source (headline deliverable)

- `full_clean.luau` — the same 796 walked instructions rendered as idiomatic Luau (2036 lines): structured control flow where the jump graph is safely structurable (the remaining protos keep a cleaned dispatch form — per-proto reasons in clean_map.json), promoted/renamed registers, CONFIRMED stdlib names for factory aliases, `CONST_UNRESOLVED_*` placeholders for unresolved constants (never invented values)
- instruction mapping: 796/796 in clean_map.json; equivalence audit: {'checked': 796, 'problems': [], 'problem_count': 0}
- luau-compile validation of full_clean.luau: PASS
- full_clean.luau sha256: `d50a955d55b33e2bcf47e5dc4c99abb673e19b0756d632a7e8fb4b4561197f47`

## Outputs

- `full_clean.luau` — cleaned source (headline deliverable; see section above)
- `clean_map.json` / `clean_stats.json` — cleaning pass mapping + equivalence audit
- `full.luau` — lifted root + all recovered child protos (executor route; compile-validated; ground truth for the cleaned source)
- `lifted.luau` — lifted root proto only (static route; compile-validated)
- `children_recovered.json` — executor-harvested child protos (the authoritative child set)
- `sweep_state.json` — executor sweep accounting (constants, walks, dynamic strings)
- `sweepE_state.json` — executor evidence (factory-arg captures, bz build log, child18 attempts)
- `children.json` — root materialization results + static child descriptor census (cross-check only)
- `protos.json` — eager materialization of the root operand tables
- `proto_structs.json` — per-proto structured walk records, root + children (the lifter input)
- `root_disasm.txt` — root proto disassembly (C1 walk)
- `stage1/` — gsub.bin / src.bin / dst.bin
- `manifest.json` — machine-readable run manifest
- `.work/` — full pipeline workdir (logs in `.work/logs`)
