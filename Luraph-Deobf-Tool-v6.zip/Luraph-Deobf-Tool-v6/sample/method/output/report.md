# luraph-v151-deobf report

- input: `input_v151.lua` (35760 bytes, sha256 `54df32acd80487567595a15db3b07f3cc6b24ef1a95cabdf6387980004213ab6`)
- detect: {'header_v15.1': True, 'string.unpack deserializer': True, 'ascii85+lz blob': True, 'method entry .t(': True, 'structural_v15.1': True}
- protos: 5, instructions: 604, unpack reads consumed: 3164/3164
- opcodes classified: 40/40 (unknown: none)
- lifted protos structured: 5/5; pc-loop fallback: none
- xor key used: [167, 229, 252, 19, 5, 111, 231, 18, 18, 106, 166, 245, 119] (string score 0.900)
- luau-compile: folded=True, lifted=True; luau-analyze: folded=(1, 0), lifted=(1, 0)
- source-cleaned: cleaned.luau — 4/5 protos register-promoted (1 CONFIRMED, 1 INFERRED, 35 neutral names); luau-compile cleaned=True; literal multiset preserved=True; see clean_map.json

## Identity spoofing (--spoof-id auto)

- `PlaceId` candidates: 9391468976 (set-membership)
- fork 0: seeds {PlaceId=9391468976} -> prints=1, http_attempts=1, mock_calls=1, identity_reads=1
- note: Luau == never fires __eq for table-vs-number (verified with the bundled CLI), so no Luau sentinel can capture the compared value in this sandbox; candidates are extracted statically, pre-seeded at read time, and resolved across differential forks. HttpGet & co are logged mock interactions; nothing is fetched.
- full detail: identity_report.json

Outputs: folded.luau, protos.json, opnames.json, handlers.json, ops.json,
disasm.txt, lifted.luau, lift_report.json, cleaned.luau, clean_map.json, unpack.log, runner.luau, identity_report.json
