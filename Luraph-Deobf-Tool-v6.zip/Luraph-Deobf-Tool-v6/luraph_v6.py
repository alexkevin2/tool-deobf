#!/usr/bin/env python3
"""luraph_v6.py — Luraph-Deobf-Tool-v6: one CLI for every Luraph
family this project handles, with automatic variant routing.

v6 is the merge of the two previous standalone tools (kept verbatim
as route engines under routes/):

  * Luraph-Deobf-Tool-v5 (routes/method/luraph151.py) — the
    method-based Luraph v15.1 pipeline (fold -> string.unpack dump
    in the sandboxed Luau CLI -> exact-consumption proto parse ->
    signature-based opcode classification -> structured lift),
    plus its sub-routes: upstream Deobfuscator-Luraph-V15 for
    v15.0/v14.x headers, and the buffer-variant route (dump +
    constant pool + varint body-grammar parse, PARTIAL).
  * Luraph-BootstrapVM-Deobf v2.1 (routes/bootstrap/luraph_bvm.py)
    — the v15.1 "virtualized bootstrap" sub-variant (StealAnEggs
    family): static stage-1 blob decode -> Fz builder simulation
    -> in-context executor sweep -> dz/bz walks -> lift -> source
    cleaning pass. Headline deliverable: full_clean.luau.

Routing (--route auto, the default):
  1. bootstrap fingerprint (LPH& blob field MY + numeric-keyed VM
     table + setmetatable literal + `):vY()(` entry + Fz builder +
     extractable VM fields)  -> bootstrap route
  2. any other Luraph evidence (version header of any version,
     structural v15.1 fingerprint, or buffer-variant fingerprint)
     -> method route (which itself sub-routes v15.0/v14.x to the
     upstream engine and buffer builds to the buffer pipeline)
  3. neither -> rejected, exit 2, with the detected-evidence
     summary printed. The tool never emits garbage for a family it
     does not recognise.

  Fingerprint upgrades (2026-10-24, corpus FINGERPRINT-REPORT
  L1-L7; see README Changelog):
  * L1 (P0): a foreign-family header in the first 4096 chars
    vetoes *buffer-variant evidence only* — version-header and
    structural evidence still route. This stops the estate's
    clearest live misroute (AntiLua mos_hub tripped bufvar and
    was routed method->buffer); the veto never rejects a file
    on a mere mention of another obfuscator outside the header
    window, and it is v6-local (luraph151.main() untouched).
  * L2 (P0): the buffer screen itself vetoes bootstrap cheap
    markers and Luraph version headers (see luraph151.py).
  * L3 (P1): buffer body-grammar failure -> exit 2, not 5.
  * L4 (conservative): the bootstrap entry-tail *shape* is an
    additional conjunct; the literal `:vY()(` gate is retained
    (not demoted) pending a second bootstrap sample.
  * L5 (documented, not relaxed): bootstrap thresholds
    (numeric slots >= 5, `_Y={` offset >= 1,000,000) are fragile
    on the single bootstrap sample — kept as hard gates.
  * L6 (P2): version-header scan widened 400 -> 2000 chars,
    comment-line anchored (all golden headers are `--` lines).
  * L7 (documented precedence): bootstrap -> version-header
    (upstream for != 15.1) -> method sub-routes; inside the
    method route, headerless files check buffer before
    structural (pre-existing order, preserved deliberately —
    see luraph151.py main(); the report's "structural -> buffer"
    shorthand is NOT implemented as a reorder, because no
    golden distinguishes the two and reordering would change
    headerless both-evidence behaviour without a sample).

QA upgrade (2026-10-24, self-audit round; see
  tests/qa-audit-2026-10-24.md): v6.2.0 adds qa_clean.py (vendored
  byte-identical into both routes) + qa_report.json on every run.
  Passes, all provable-only: isolated literal folding, if-true /
  if-false cleanup, kind-conflict downgrade to neutral, trailing-
  nil compaction, self-assign / unused-T removal, straight-line
  dead-write elimination. Verbatim lines (bzClosure / proto_child)
  are never modified; lshift(x, 0), q+N-M arithmetic, __descriptor
  ids, empty while-true loops and the 2 proven kernels are counted
  as residue, not rewritten. --qa-clean off restores exact v6.1.0
  bytes for cleaned.luau / buffer lifted.luau / full_clean.luau;
  lifted.luau (method) and upstream output are never modified.

Exit codes (route semantics preserved from the merged tools):
  0  full recovery (method route success; bootstrap FULL_RECOVERY)
     -- the v20 route NEVER exits 0 (see routes/v20/luraph_v20.py)
  5  PARTIAL (bootstrap route's expected verdict today; method
     buffer route; a route stage failed after a fingerprint match;
     v20 route with or without a trace-bundle lift -- a lifted
     v20 run is PARTIAL-with-assumption, never FULL)
  2  not a recognised Luraph family (v6-level rejection), input
     missing, or the method route's own rejection
  3/4 method-route internals, preserved from v5 (upstream clone
     unavailable / proto-parse mismatch)

Usage: python3 luraph_v6.py <file.luau> [-o outdir]
       [--route auto|bootstrap|method] [--luau path] [--force]
       [--clean-work] [--spoof-id auto|off]

--spoof-id auto (default): automatic game-ID spoofing for identity
gates (game.PlaceId / JobId / ...).  Static candidate extraction
from the recovered protos feeds seeded mock environments (method
route: differential behavior forks; bootstrap route: seeded +
comparison-calibrated executor mocks); every run emits
identity_report.json and a report section.  --spoof-id off restores
the exact legacy behaviour (no identity artifacts).
"""
import argparse
import hashlib
import importlib.util
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
METHOD_DIR = os.path.join(ROOT, 'routes', 'method')
BOOTSTRAP_DIR = os.path.join(ROOT, 'routes', 'bootstrap')
V20_DIR = os.path.join(ROOT, 'routes', 'v20')
BIN = os.path.join(ROOT, 'bin')
VERSION = '6.6.0'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


# ---------------------------------------------------------------- detect
def bootstrap_detect(text_se):
    """Reuse the bootstrap route's own fingerprint verbatim."""
    static_dir = os.path.join(BOOTSTRAP_DIR, 'modules', 'static')
    sys.path.insert(0, static_dir)
    try:
        dec = load_module('bvm_decode_stage1',
                          os.path.join(static_dir, 'decode_stage1.py'))
        bvm = load_module('luraph_bvm_driver',
                          os.path.join(BOOTSTRAP_DIR, 'luraph_bvm.py'))
        return bvm.detect(text_se, dec)
    finally:
        sys.path.remove(static_dir)


# L1: foreign-family headers, tested only in the first 4096 chars
# (matching the existing header windows). The veto applies to
# buffer-variant evidence only — never to version/structural
# evidence, and never to a mere mention deeper in the file.
FOREIGN_HEADERS = (
    'AntiLua Obfuscator v',
    'generated by [https://obf.antilua.xyz/]',
    'created by XHider v',
    'generated by luast v',
    'generated using MoonVeil',
)


def foreign_header_in(text):
    """Return the foreign-family header found in the first 4096
    chars, or None. L1 veto input (v6 auto-routing only)."""
    head = text[:4096]
    for h in FOREIGN_HEADERS:
        if h in head:
            return h
    return None


def version_header(src):
    """L6: Luraph version header in a `--` comment line within the
    first 2000 chars (golden headers sit at offset 33; the wider
    window tolerates a loader-env preamble, the comment anchor
    stops a payload-embedded header string from version-routing)."""
    m = re.search(r'(?m)^[ \t]*--.*Luraph Obfuscator v([0-9.]+)',
                  src[:2000])
    return m.group(1) if m else None


def method_detect(src):
    """Reuse the method route's detectors verbatim (import only;
    its main() is never called in-process)."""
    m = load_module('luraph151_engine',
                    os.path.join(METHOD_DIR, 'luraph151.py'))
    markers = m.detect(src)
    version = version_header(src)
    return m, markers, m.is_buffer_variant(src), version


def v20_detect(src):
    """v20.0 fingerprint (routes/v20/fingerprint.py). Returns
    (matched, evidence). Imported lazily so a missing/corrupt
    v20 module can never break bootstrap/method routing."""
    try:
        fp = load_module('v20_fingerprint',
                         os.path.join(V20_DIR, 'fingerprint.py'))
        return fp.detect_v20(src)
    except Exception as e:
        return False, {'fingerprint_error': repr(e)}


def run_v20(raw, outdir, luau, spoof_id='auto', qa_clean='on',
            trace_bundle=None):
    argv = [sys.executable, os.path.join(V20_DIR, 'luraph_v20.py'),
            raw, '-o', outdir, '--luau', luau,
            '--spoof-id', spoof_id, '--qa-clean', qa_clean]
    if trace_bundle:
        argv += ['--trace-bundle', trace_bundle]
    print(f'[route] v20 -> {" ".join(argv[1:])}', flush=True)
    return subprocess.run(argv).returncode


# ---------------------------------------------------------------- routes
def run_bootstrap(raw, outdir, clean_work, spoof_id='auto', qa_clean='on'):
    argv = [sys.executable, os.path.join(BOOTSTRAP_DIR, 'luraph_bvm.py'),
            raw, '-o', outdir, '--spoof-id', spoof_id,
            '--qa-clean', qa_clean]
    if clean_work:
        argv.append('--clean-work')
    print(f'[route] bootstrap -> {" ".join(argv[1:])}', flush=True)
    return subprocess.run(argv).returncode


def find_upstream_env():
    if os.environ.get('LURAPH_UPSTREAM_DIR'):
        return None
    for cand in (os.path.join(ROOT, '..', 'Deobfuscator-Luraph-V15'),
                 os.path.expanduser('~/luau-deobf/tools/'
                                    'Deobfuscator-Luraph-V15')):
        if os.path.isfile(os.path.join(cand, 'deob.js')):
            return os.path.abspath(cand)
    return None


def run_method(raw, outdir, luau, force, spoof_id='auto', qa_clean='on'):
    argv = [sys.executable, os.path.join(METHOD_DIR, 'luraph151.py'),
            raw, '-o', outdir, '--luau', luau,
            '--spoof-id', spoof_id, '--qa-clean', qa_clean]
    if force:
        argv.append('--force')
    env = dict(os.environ)
    up = find_upstream_env()
    if up:
        env['LURAPH_UPSTREAM_DIR'] = up
        print(f'[route] LURAPH_UPSTREAM_DIR={up}', flush=True)
    print(f'[route] method -> {" ".join(argv[1:])}', flush=True)
    return subprocess.run(argv, env=env).returncode


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(
        description='Luraph-Deobf-Tool-v6 — unified Luraph '
                    'deobfuscator with automatic variant routing')
    ap.add_argument('input', help='obfuscated .luau/.lua file')
    ap.add_argument('-o', '--outdir', default=None,
                    help='output directory (default: '
                         '<input-stem>-deobf-v6)')
    ap.add_argument('--route', choices=('auto', 'bootstrap', 'method',
                                        'v20'),
                    default='auto', help='routing override '
                                         '(default: auto)')
    ap.add_argument('--luau', default=None,
                    help='Luau CLI for the method route '
                         '(default: bundled bin/luau)')
    ap.add_argument('--force', action='store_true',
                    help='method route: continue even if the v15.1 '
                         'header is missing (v5 semantics)')
    ap.add_argument('--clean-work', action='store_true',
                    help='bootstrap route: delete the .work '
                         'directory at the end')
    ap.add_argument('--spoof-id', choices=('auto', 'off'),
                    default='auto',
                    help='automatic game-ID spoofing for identity '
                         'gates (game.PlaceId & friends): static '
                         'candidate extraction + seeded/calibrated '
                         'mock environments + identity_report.json '
                         '(default: auto; off = legacy behaviour, '
                         'no identity artifacts)')
    ap.add_argument('--qa-clean', choices=('on', 'off'), default='on',
                    help='v6.2.0 QA passes on cleaned/lifted outputs; '
                         'off restores exact v6.1.0 bytes for those files')
    ap.add_argument('--v20-trace-bundle', default=None,
                    help='v20 route: trace bundle directory for the '
                         'stage-5 lift (covered path only, emitted '
                         'as PARTIAL-with-assumption, exit 5). '
                         'Without it the v20 route emits no source.')
    args = ap.parse_args()

    raw = os.path.abspath(args.input)
    if not os.path.isfile(raw):
        print(f'error: input not found: {raw}', file=sys.stderr)
        return 2
    outdir = os.path.abspath(args.outdir) if args.outdir else \
        os.path.splitext(os.path.basename(raw))[0] + '-deobf-v6'
    print(f'[v6] Luraph-Deobf-Tool v{VERSION}')
    print(f'[v6] input: {raw} ({os.path.getsize(raw)} bytes, '
          f'sha256 {sha256_file(raw)})')

    data = open(raw, 'rb').read()
    text_se = data.decode('utf-8', errors='surrogateescape')
    try:
        src = data.decode('utf-8', errors='strict')
    except UnicodeDecodeError:
        src = None

    boot_ok, boot_checks = bootstrap_detect(text_se)
    print(f'[detect] bootstrap fingerprint: {boot_ok}')
    for k, v in boot_checks.items():
        print(f'    {k}: {v}')

    markers, bufvar, version = {}, False, None
    m151 = None
    v20_ok, v20_ev = False, {}
    if src is not None:
        m151, markers, bufvar, version = method_detect(src)
        v20_ok, v20_ev = v20_detect(src)
    print(f'[detect] method markers: {markers}')
    print(f'[detect] method version header: {version}; '
          f'buffer variant: {bufvar}')
    print(f'[detect] v20 fingerprint: {v20_ok}')
    for k, v in v20_ev.items():
        print(f'    {k}: {v}')
    # L1: foreign header vetoes bufvar evidence only.
    foreign = foreign_header_in(text_se)
    print(f'[detect] foreign-family header (first 4096): {foreign}')
    if foreign and bufvar:
        print('[detect] L1 veto: buffer-variant evidence ignored '
              f'(foreign header: {foreign})')

    method_evidence = bool(
        version or markers.get('structural_v15.1')
        or (bufvar and not foreign))

    # P0 (2026-10-24): upstream is allowlisted to 15.0/14.x only.
    # A version header outside the allowlist is NOT method
    # evidence on its own -- otherwise v20.0 (and any future
    # version) would again be sent to the upstream engine.
    upstream_allowed = bool(
        version and re.match(r'^(15\.0|14\.[0-9]+)$', version))

    route = args.route
    if route == 'auto':
        if boot_ok:
            route = 'bootstrap'
        elif v20_ok:
            route = 'v20'
        elif v20_ev.get('conflict'):
            print('REJECTED: v20.0 shape matched but a negative '
                  'conjunct failed (conflicting family markers); '
                  'refusing to fall through to upstream.',
                  file=sys.stderr)
            return 2
        elif version and version != '15.1' and not upstream_allowed:
            print(f'REJECTED: Luraph v{version} is not a supported '
                  'layout (upstream allowlist: 15.0 / 14.x only; '
                  'no v20 route matched). No output was produced.',
                  file=sys.stderr)
            return 2
        elif method_evidence:
            route = 'method'
        else:
            print('REJECTED: no recognised Luraph fingerprint '
                  '(neither the virtualized-bootstrap family nor '
                  'any method/upstream/buffer Luraph evidence). '
                  'No output was produced.', file=sys.stderr)
            return 2
    elif route == 'bootstrap' and not boot_ok:
        print('REJECTED: --route bootstrap given but the bootstrap '
              'fingerprint does not match (see checks above).',
              file=sys.stderr)
        return 2
    elif route == 'v20' and not v20_ok:
        print('REJECTED: --route v20 given but the v20 fingerprint '
              'does not match (see checks above).',
              file=sys.stderr)
        return 2
    elif route == 'method' and src is None:
        print('REJECTED: --route method given but the input is '
              'not valid UTF-8 text.', file=sys.stderr)
        return 2

    print(f'[v6] route selected: {route} '
          f'({"auto" if args.route == "auto" else "forced"})')
    os.makedirs(outdir, exist_ok=True)
    if route == 'bootstrap':
        return run_bootstrap(raw, outdir, args.clean_work,
                             args.spoof_id, args.qa_clean)
    luau = args.luau or os.path.join(BIN, 'luau')
    if route == 'v20':
        return run_v20(raw, outdir, luau, args.spoof_id,
                       args.qa_clean, args.v20_trace_bundle)
    return run_method(raw, outdir, luau, args.force, args.spoof_id,
                      args.qa_clean)


if __name__ == '__main__':
    sys.exit(main())
