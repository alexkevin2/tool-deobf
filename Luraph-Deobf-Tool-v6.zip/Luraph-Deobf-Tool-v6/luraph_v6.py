#!/usr/bin/env python3
"""luraph_v6.py — Luraph-Deobf-Tool-v6: one CLI for every Luraph
family this project handles, with automatic variant routing.

v6 is the merge of the two previous standalone tools (kept verbatim
as route engines under routes/):

  * Luraph-Deobf-Tool-v5 (routes/method/luraph151.py) — the
    method-based Luraph v15.1 pipeline (fold -> string.unpack dump
    in the sandboxed Luau CLI -> exact-consumption proto parse ->
    signature-based opcode classification -> structured lift),
    plus its sub-routes: upstream Deobfuscator-Luraph-V15 for
    v15.0/v14.x headers, and the buffer-variant route (dump +
    constant pool + varint body-grammar parse, PARTIAL).
  * Luraph-BootstrapVM-Deobf v2.1 (routes/bootstrap/luraph_bvm.py)
    — the v15.1 "virtualized bootstrap" sub-variant (StealAnEggs
    family): static stage-1 blob decode -> Fz builder simulation
    -> in-context executor sweep -> dz/bz walks -> lift -> source
    cleaning pass. Headline deliverable: full_clean.luau.

Routing (--route auto, the default):
  1. bootstrap fingerprint (LPH& blob field MY + numeric-keyed VM
     table + setmetatable literal + `):vY()(` entry + Fz builder +
     extractable VM fields)  -> bootstrap route
  2. any other Luraph evidence (version header of any version,
     structural v15.1 fingerprint, or buffer-variant fingerprint)
     -> method route (which itself sub-routes v15.0/v14.x to the
     upstream engine and buffer builds to the buffer pipeline)
  3. neither -> rejected, exit 2, with the detected-evidence
     summary printed. The tool never emits garbage for a family it
     does not recognise.

Exit codes (route semantics preserved from the merged tools):
  0  full recovery (method route success; bootstrap FULL_RECOVERY)
  5  PARTIAL (bootstrap route's expected verdict today; method
     buffer route; a route stage failed after a fingerprint match)
  2  not a recognised Luraph family (v6-level rejection), input
     missing, or the method route's own rejection
  3/4 method-route internals, preserved from v5 (upstream clone
     unavailable / proto-parse mismatch)

Usage: python3 luraph_v6.py <file.luau> [-o outdir]
       [--route auto|bootstrap|method] [--luau path] [--force]
       [--clean-work] [--spoof-id auto|off]

--spoof-id auto (default): automatic game-ID spoofing for identity
gates (game.PlaceId / JobId / ...).  Static candidate extraction
from the recovered protos feeds seeded mock environments (method
route: differential behavior forks; bootstrap route: seeded +
comparison-calibrated executor mocks); every run emits
identity_report.json and a report section.  --spoof-id off restores
the exact legacy behaviour (no identity artifacts).
"""
import argparse
import hashlib
import importlib.util
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
METHOD_DIR = os.path.join(ROOT, 'routes', 'method')
BOOTSTRAP_DIR = os.path.join(ROOT, 'routes', 'bootstrap')
BIN = os.path.join(ROOT, 'bin')
VERSION = '6.0.0'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


# ---------------------------------------------------------------- detect
def bootstrap_detect(text_se):
    """Reuse the bootstrap route's own fingerprint verbatim."""
    static_dir = os.path.join(BOOTSTRAP_DIR, 'modules', 'static')
    sys.path.insert(0, static_dir)
    try:
        dec = load_module('bvm_decode_stage1',
                          os.path.join(static_dir, 'decode_stage1.py'))
        bvm = load_module('luraph_bvm_driver',
                          os.path.join(BOOTSTRAP_DIR, 'luraph_bvm.py'))
        return bvm.detect(text_se, dec)
    finally:
        sys.path.remove(static_dir)


def method_detect(src):
    """Reuse the method route's detectors verbatim (import only;
    its main() is never called in-process)."""
    m = load_module('luraph151_engine',
                    os.path.join(METHOD_DIR, 'luraph151.py'))
    markers = m.detect(src)
    version = None
    vm = re.search(r'Luraph Obfuscator v([0-9.]+)', src[:400])
    if vm:
        version = vm.group(1)
    return m, markers, m.is_buffer_variant(src), version


# ---------------------------------------------------------------- routes
def run_bootstrap(raw, outdir, clean_work, spoof_id='auto'):
    argv = [sys.executable, os.path.join(BOOTSTRAP_DIR, 'luraph_bvm.py'),
            raw, '-o', outdir, '--spoof-id', spoof_id]
    if clean_work:
        argv.append('--clean-work')
    print(f'[route] bootstrap -> {" ".join(argv[1:])}', flush=True)
    return subprocess.run(argv).returncode


def find_upstream_env():
    if os.environ.get('LURAPH_UPSTREAM_DIR'):
        return None
    for cand in (os.path.join(ROOT, '..', 'Deobfuscator-Luraph-V15'),
                 os.path.expanduser('~/luau-deobf/tools/'
                                    'Deobfuscator-Luraph-V15')):
        if os.path.isfile(os.path.join(cand, 'deob.js')):
            return os.path.abspath(cand)
    return None


def run_method(raw, outdir, luau, force, spoof_id='auto'):
    argv = [sys.executable, os.path.join(METHOD_DIR, 'luraph151.py'),
            raw, '-o', outdir, '--luau', luau,
            '--spoof-id', spoof_id]
    if force:
        argv.append('--force')
    env = dict(os.environ)
    up = find_upstream_env()
    if up:
        env['LURAPH_UPSTREAM_DIR'] = up
        print(f'[route] LURAPH_UPSTREAM_DIR={up}', flush=True)
    print(f'[route] method -> {" ".join(argv[1:])}', flush=True)
    return subprocess.run(argv, env=env).returncode


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(
        description='Luraph-Deobf-Tool-v6 — unified Luraph '
                    'deobfuscator with automatic variant routing')
    ap.add_argument('input', help='obfuscated .luau/.lua file')
    ap.add_argument('-o', '--outdir', default=None,
                    help='output directory (default: '
                         '<input-stem>-deobf-v6)')
    ap.add_argument('--route', choices=('auto', 'bootstrap', 'method'),
                    default='auto', help='routing override '
                                         '(default: auto)')
    ap.add_argument('--luau', default=None,
                    help='Luau CLI for the method route '
                         '(default: bundled bin/luau)')
    ap.add_argument('--force', action='store_true',
                    help='method route: continue even if the v15.1 '
                         'header is missing (v5 semantics)')
    ap.add_argument('--clean-work', action='store_true',
                    help='bootstrap route: delete the .work '
                         'directory at the end')
    ap.add_argument('--spoof-id', choices=('auto', 'off'),
                    default='auto',
                    help='automatic game-ID spoofing for identity '
                         'gates (game.PlaceId & friends): static '
                         'candidate extraction + seeded/calibrated '
                         'mock environments + identity_report.json '
                         '(default: auto; off = legacy behaviour, '
                         'no identity artifacts)')
    args = ap.parse_args()

    raw = os.path.abspath(args.input)
    if not os.path.isfile(raw):
        print(f'error: input not found: {raw}', file=sys.stderr)
        return 2
    outdir = os.path.abspath(args.outdir) if args.outdir else \
        os.path.splitext(os.path.basename(raw))[0] + '-deobf-v6'
    print(f'[v6] Luraph-Deobf-Tool v{VERSION}')
    print(f'[v6] input: {raw} ({os.path.getsize(raw)} bytes, '
          f'sha256 {sha256_file(raw)})')

    data = open(raw, 'rb').read()
    text_se = data.decode('utf-8', errors='surrogateescape')
    try:
        src = data.decode('utf-8', errors='strict')
    except UnicodeDecodeError:
        src = None

    boot_ok, boot_checks = bootstrap_detect(text_se)
    print(f'[detect] bootstrap fingerprint: {boot_ok}')
    for k, v in boot_checks.items():
        print(f'    {k}: {v}')

    markers, bufvar, version = {}, False, None
    m151 = None
    if src is not None:
        m151, markers, bufvar, version = method_detect(src)
    print(f'[detect] method markers: {markers}')
    print(f'[detect] method version header: {version}; '
          f'buffer variant: {bufvar}')

    method_evidence = bool(
        version or markers.get('structural_v15.1') or bufvar)

    route = args.route
    if route == 'auto':
        if boot_ok:
            route = 'bootstrap'
        elif method_evidence:
            route = 'method'
        else:
            print('REJECTED: no recognised Luraph fingerprint '
                  '(neither the virtualized-bootstrap family nor '
                  'any method/upstream/buffer Luraph evidence). '
                  'No output was produced.', file=sys.stderr)
            return 2
    elif route == 'bootstrap' and not boot_ok:
        print('REJECTED: --route bootstrap given but the bootstrap '
              'fingerprint does not match (see checks above).',
              file=sys.stderr)
        return 2
    elif route == 'method' and src is None:
        print('REJECTED: --route method given but the input is '
              'not valid UTF-8 text.', file=sys.stderr)
        return 2

    print(f'[v6] route selected: {route} '
          f'({"auto" if args.route == "auto" else "forced"})')
    os.makedirs(outdir, exist_ok=True)
    if route == 'bootstrap':
        return run_bootstrap(raw, outdir, args.clean_work,
                             args.spoof_id)
    luau = args.luau or os.path.join(BIN, 'luau')
    return run_method(raw, outdir, luau, args.force, args.spoof_id)


if __name__ == '__main__':
    sys.exit(main())
