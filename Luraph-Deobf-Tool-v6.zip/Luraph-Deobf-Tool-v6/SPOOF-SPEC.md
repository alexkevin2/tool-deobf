# SPOOF-SPEC — Shared Dynamic Game-ID Spoof Engine (spoof_engine.py v1.0.0)

**Status:** implemented in Luraph v6 (canonical copy:
`Luraph-Deobf-Tool-v6/spoof_engine.py`, sha256
`d33daef82bd5c0ffb086daef4978fd0423fa30dfd0024741507b080d35230d6b`
at delivery; vendored byte-identical copies in
`routes/method/spoof_engine.py`,
`routes/bootstrap/modules/stageE/spoof_engine.py`, and the
distribution mirror `~/luau-deobf/tools-shared/spoof_engine.py`).
Sibling tools (MoonVeil, Luast, Luau-Deobf-Tool) port FROM this
spec + module without re-deriving the semantics.

**One-line rule (Kevin's requirement):** spoofing is DYNAMIC and
NEVER hardcoded — per script, at analysis time, the tool detects
that script's identity gates and spoofs the local environment view
so the gate-PASS branch is taken. No game ID may appear as a
literal, default, or fallback in tool code. Test fixtures may retain
real IDs only as clearly-labelled test data, never as defaults
(see §8 for the audit).

## 1. What spoofing is (and is not)

A Luraph-style payload commonly hides its real body behind an
identity gate and serves a decoy branch to any environment whose
ID does not match. Spoofing configures the **local mock
environments the analysing tool itself runs** (a Luau-CLI runner's
fabricated `game` table, or a Python executor's game mock) so the
gate-PASS branch executes during analysis. It is analysis-side
only:

- It never contacts a server, never fetches a URL, never executes
  a remote payload. Remote-load calls (HttpGet/HttpPost/GetAsync
  and friends) stay **logged mock interactions answered with
  inert values** by the tool's own mock layer.
- IDs checked **server-side cannot be spoofed locally** and are
  out of scope by construction. A gate whose expected value is
  only ever compared on a server is reported, not spoofed.
- Payloads are never executed outside the tool's existing
  sandbox/executor policy. Spoofing changes *what the mock
  answers*, not *whether the payload runs*.

## 2. Gate model

### 2.1 Identity fields

Canonical fields (exact member names on the `game` object):

| field | notes |
|---|---|
| `PlaceId` | the common gate (numeric) |
| `JobId` | usually a string (server instance id) — values may be strings |
| `CreatorId` | numeric |
| `PlaceVersion` | numeric |
| `GameId` | numeric |

**Extension rule:** any other `game.*` member compared against a
constant or a set counts as an identity field too. A tool passes
such names via `extra_fields` to the engine helpers; the report
lists them separately (`extra_field: true` on the gate record) so
a reader can tell the standard set from tool-specific extensions.
Field-name matching is exact and case-sensitive.

### 2.2 Gate shapes (candidate kinds)

A *gate* is a comparison site where an identity-field value flows
into a test against a constant or a set. The engine's pattern
vocabulary (`OP_KIND` / `KIND_RANK`):

| kind | shape | strength | gate-PASS value? |
|---|---|---|---|
| `eq-const` | `game.PlaceId == <const>` (or `~= ` inverted, `==` with operands swapped) | strong (rank 0) | the constant itself |
| `set-membership` | a table built with numeric keys, later indexed by the identity-field value (`t[game.PlaceId]`) | strong (rank 0) | any key of the set |
| `ne-const` | `game.PlaceId ~= <const>` | weak (rank 1) | **NO** — seeding the constant guarantees the decoy branch; fork with a different probe |
| `lt-bound` | `<const> < game.PlaceId` (bound) | weak (rank 1) | **NO, not directly** — the bound, not an equality target; see §4.3 |
| `gt-bound` | `game.PlaceId < <const>` | weak (rank 1) | bound only, see §4.3 |
| `le-bound` / `ge-bound` | `<=` / `>=` variants | weak (rank 1) | bound only, see §4.3 |
| `same-instruction` | an instruction whose constants co-refer to a field name and a number (bootstrap walk records) | weak (rank 2) | unproven — co-occurrence, not a comparison |
| `proto-consts` | a proto referencing a field name also references a number (buffer-variant pool scan) | weak (rank 2) | unproven |
| `pool` | numeric constants of a proto that reads the field, with no gate site found (method fallback) | weakest (rank 3) | unproven |

Worked examples (Luau source shape → engine event):

```
game.PlaceId == 9391468976
  -> {field: 'PlaceId', op: 'eq', value: 9391468976}  => eq-const
local allowed = {}; allowed[9391468976] = true
if allowed[game.PlaceId] then ... end
  -> {field: 'PlaceId', op: 'in-set', value: 9391468976} => set-membership
if 100 < game.PlaceId then ... end
  -> {field: 'PlaceId', op: 'lt', value: 100} => lt-bound (PASS needs >100, not 100)
if game.PlaceId ~= 12345 then <decoy> else <real> end
  -> {field: 'PlaceId', op: 'ne', value: 12345} => ne-const (PASS needs anything but 12345)
```

(The numeric literals above are illustrative shapes, not tool
defaults. The validated real example is the JjsKhanhly
set-membership gate at root pc 5; see §9.)

### 2.3 Candidate records

A candidate is `{value, kind, evidence: [{proto, pc, pattern}]}`.
Dedupe key is **(value, kind)**: the same value from two gate
shapes is two candidates (the shapes disagree about what "pass"
means). Evidence entries accumulate per site; a candidate with no
evidence is invalid and must not be emitted. Candidate values are
numbers or strings only (booleans, tables, nil are never
candidates). Candidate ordering is deterministic: kind rank, then
`str(value)` — the "best" candidate (fork 0's seed) is the first
after this sort.

## 3. Static extraction patterns

Tools feed the engine by ONE of these routes (in preference order):

1. **Proven gate scan (preferred).** The tool's own IR/provenance
   pass finds field reads flowing into comparisons and emits
   comparison events via `collect_events()` (see §2.2 table for
   the op mapping). Luraph v6 method route does this with a
   register-provenance pass (`GETGLOBAL game` → `GETTABLE_K`
   field → `EQ_K_SKIP` / set-table `GETTABLE_R` / `LT_K_SKIP`,
   through `MOVE` / `SELF` / `CALL` chains and `CLOSURE`
   captures into child upvalues).
2. **Co-occurrence scan.** Where no dataflow model exists,
   `extract_cooccurrence()` scans instruction constant lists for
   a field name + numbers in one instruction (bootstrap route's
   `proto_structs.json` walk records). Weak by design.
3. **Pool / presence scan.** `extract_buffer()`-style pool scans
   (buffer variant) and `extract_field_presence()` (materializer
   output). Presence alone is NEVER candidacy: a field name seen
   with no gate site yields `fields_seen` / `fields_read` entries
   and an UNKNOWN gate, not a candidate.

A tool MUST report every field it saw (`fields_seen` /
`fields_read`) even when it found no candidate for it. Hiding an
unresolved field is a spec violation.

## 4. Multi-gate + multi-candidate semantics

### 4.1 Seed resolution

`build_seed()` seeds **only exactly-one-distinct-candidate
fields**. Ambiguous fields (0 or ≥2 distinct values) stay
unseeded: a Python executor serves them as sentinels (§5) and a
Luau runner serves them from the fork plan (§4.2). Seeding an
ambiguous field with an arbitrary pick is forbidden.

### 4.2 Fork / seed strategy (`plan_forks`)

- **Fork 0 (primary):** every field seeded with its best
  candidate (first after the §2.3 sort). If a field has no
  candidate it is left unseeded in every fork (Luau runners serve
  the probe value for it, logged `source: probe`).
- **Further forks:** vary ONE field at a time over its remaining
  candidates, fields visited in sorted order, duplicates dropped.
- **Caps:** ≤ 4 values per field, ≤ 9 forks total
  (`MAX_FORKS_PER_FIELD`, `MAX_FORKS_TOTAL`). These caps are part
  of the validated behaviour; changing them changes fork counts
  and every golden that records forks.
- **Deterministic ordering:** fields sorted alphabetically;
  candidates in §2.3 order; forks in plan order. No timestamps,
  no paths, no hash-order in any fork record.
- **Documented limit:** one-field-at-a-time forking does NOT
  cover interacting multi-gate combinations (a gate-PASS path
  needing two non-primary values at once). Full cartesian forking
  is exponential and deliberately not attempted. When no fork
  shows gate-PASS evidence, the report's unresolved/UNKNOWN
  fields name the gap; the bootstrap route's contradiction log
  (§5) is the complementary signal for interacting gates.

### 4.3 Bounds and negations (non-pass kinds)

`lt/gt/le/ge-bound` and `ne-const` candidates are kept in the
candidate list (legacy compatibility, weak rank) but flagged
(`non_pass_kinds` on the gate record). Ports SHOULD NOT seed a
bound value expecting a pass:

- `lt-bound`/`le-bound` value `B`: a passing value is `B+1`
  (or greater); `gt-bound`/`ge-bound`: `B-1` (or smaller).
  The engine provides `expand_bound_candidates()` for this
  (opt-in; Luraph v6's legacy fork plan seeds bound values
  verbatim to keep its goldens byte-identical — see §6).
- `ne-const` value `V`: any value except `V` passes; fork with
  the probe or another field's candidate, never with `V`.

### 4.4 The probe value

`PROBE_VALUE = 7777777777777` is a distinctive marker served for
unseeded identity reads (Luau runners; Python executors use a
sentinel object instead). It is NOT a game ID, NOT a candidate,
and NEVER a default seed. Reads served from the probe are logged
`source: probe`. A branch taken under probe serving is a
probe-branch, not a gate-PASS branch, and must not be reported
as one. (Collision note: if a real gate's expected value ever
equalled the probe, probe-served reads would false-pass; the
probe is chosen far outside the observed PlaceId range and every
probe-served read is logged, so such a collision is detectable
in the report.)

## 5. Sentinel / comparison-capture model (Python executors)

For tools whose executor equality hook sees both operands
(Luraph v6 bootstrap route: `executor.Runtime.decide('cmpeq')`),
the engine's `SpoofState` defines the policy the mock layer
implements:

1. `enabled=False` → legacy behaviour: no identity logging, no
   sentinel (the mock serves an ordinary child mock).
2. Field seeded → serve the seed; log
   `('read', field, value, 'static-seed')`. Seed entries are
   logged at setup as `('seed', field, value, 'static')`.
3. Field adopted via capture → serve the adopted value; log
   `('read', field, value, 'adopted')`.
4. Otherwise → serve a per-field sentinel object (identity-stable:
   repeated reads return the same sentinel); log
   `('read', field, None, 'sentinel')`.
5. First scalar the sentinel is compared against → **adopt** it
   (that comparison answers true); log
   `('capture', field, value, site)` where site is
   `(proto, mode, pc)`.
6. A later comparison demanding a different value → answer
   consistently with the adopted value (false), keep the adopted
   value, and log `('contradiction', field, adopted, compared,
   site)`. Contradictions are evidence of interacting/multiple
   gates, not errors to paper over.
7. Only numeric/str scalars are capturable; other types are
   ignored (no adoption, no log).

`SpoofState.to_state()` / `log_to_state()` produce the sweep
state shape `{seeded, reads, captures, contradictions}`.

**Luau-side limitation (why there is no Luau sentinel):**
verified against the bundled Luau CLI, `==` between a table and a
number NEVER fires `__eq` (false by type). A Luau-side sentinel
therefore cannot capture the compared value; Luau runners must
use static candidates + forks (§4.2), never `__eq` capture.

## 6. identity_report.json schema

### 6.1 Unified schema (`schema_version: "spoof-engine/1"`)

Emitted by `spoof_engine.build_report()`. Sibling ports SHOULD
emit this shape. Fields:

```json
{
  "schema_version": "spoof-engine/1",
  "feature": "spoof-id",
  "mode": "auto",
  "route": "<tool route name, e.g. 'method' | 'bootstrap' | 'moonveil' | 'luast' | 'luau-deobf'>",
  "fields_seen": ["<field>", "..."] ,
  "fields_read": {"<field>": ["<proto path>", "..."]},
  "candidates": {"<field>": [{"value": 0, "kind": "eq-const",
                              "evidence": [{"proto": "root", "pc": 5,
                                            "pattern": "..."}]}]},
  "gates": [{"field": "PlaceId", "status": "seeded|forked|captured|contradicted|unknown",
             "candidates": ["<same as candidates[field]>"],
             "spoofed_value": 0,
             "forked": false,
             "non_pass_kinds": ["lt-bound"],
             "extra_field": false}],
  "unknown_fields": ["<field with status unknown>"],
  "seed": [{"field": "PlaceId", "value": 0, "source": "static"}],
  "captures": [{"field": "PlaceId", "value": 0, "site": ["root", "C", 35]}],
  "contradictions": [{"field": "PlaceId", "adopted": 0, "compared": 1,
                      "site": ["root", "C", 40]}],
  "forks": [{"fork": 0, "exit": 0,
             "seeds": {"PlaceId": {"value": 0, "source": "static:eq-const"}},
             "identity_reads": [{"field": "PlaceId", "value": "0", "source": "seed"}],
             "prints_total": 1, "prints_top": [],
             "mock_calls": 1, "http_attempts": 1, "http_calls": [],
             "branch": "gate-pass|other-branch|unclassified", "chunk": ""}],
  "identity_reads_total": 0,
  "identity_reads": ["<first 200 reads, fork-tagged for fork reports>"],
  "scope": "local-analysis-only: mock environments run by this tool; nothing fetched; server-checked IDs out of scope.",
  "notes": ["<tool notes, incl. the Luau __eq limitation where applicable>"]
}
```

Rules:

- `gates[].status` is derived, never guessed (§5 / §4.1):
  `seeded` (exactly one candidate), `forked` (>1 candidate),
  `captured` (no static candidate, capture adopted a value),
  `contradicted` (contradiction logged for the field),
  `unknown` (read/seen, no candidate, no capture).
  `spoofed_value` is set only for seeded/captured fields (for
  forked fields: the primary fork's value, with `forked: true`);
  for unknown fields it is **null**.
- `unknown_fields` lists every `unknown` gate. A run with a
  non-empty `unknown_fields` MUST NOT claim full gate coverage.
- `forks[].branch` is `gate-pass` / `other-branch` ONLY under a
  caller-supplied evidence rule (`is_pass(fork)`); without one it
  is `unclassified`. The engine never infers gate-PASS from raw
  signals. The validated JjsKhanhly rule is an EXAMPLE of such a
  caller rule (inert HttpGet mock fired + decoy print signature
  absent — the mismatch control shows exactly 161 insult prints
  and no HttpGet), not an engine default.
- `identity_reads` is capped at 200 entries; the total is kept
  separately in `identity_reads_total`. Reads from probe serving
  carry `source: probe` and are never candidates.
- The report is deterministic: no timestamps, no absolute paths,
  sorted fields, plan-order forks. (This is what makes the v6
  golden sha256 stable.)

### 6.2 Legacy shapes (Luraph v6 only, golden compatibility)

Luraph v6 keeps emitting its two pre-engine shapes until its
goldens are regenerated, via `build_report_legacy_method()` and
`build_report_legacy_bootstrap()` (same key order and value
shapes as the original `identity.py` builders):

- method / method-buffer: `{feature, mode, route, fields_seen
  (sorted list), fields_read, candidates, forks,
  identity_reads_total, identity_reads (fork-tagged, ≤200),
  notes}` — no `gates[]`, no `branch` labels.
- bootstrap: `{feature, mode, route, fields_seen (merged dict),
  candidates, seed, captures, contradictions,
  identity_reads_total, identity_reads (≤200), notes}` — no
  forks (single canonical sweep run).

Migration note for a future v6 major: switch both routes to §6.1
in one change, regenerate `tests/golden/spoof_sha256.json` from
the new output, and record the old sha in the changelog. Do NOT
mix shapes within one route.

### 6.3 Report section + off mode

Every auto run also appends a short `## Identity spoofing`
section to the route's `report.md` (legacy sections preserved
verbatim for v6; `report_section()` for unified reports).
`--spoof-id off` restores exact legacy behaviour: NO
`identity_report.json`, NO report section, and primary outputs
byte-identical to pre-feature goldens (regression Part E proves
this for the method route).

## 7. Porting contract (per tool)

A port MUST do all of the following (checklist in §10 gives the
per-tool file map):

1. Vendor `spoof_engine.py` unchanged (byte-identical to the
   canonical copy) into the tool tree; import it — do not fork
   its constants. If the tool's module path cannot see the
   canonical copy, vendor a copy next to the importing module
   (the v6 pattern: one copy per import root) and add a
   byte-identity check to the tool's tests.
2. Keep the CLI flag spelling `--spoof-id auto|off`
   (default `auto`); `off` must produce byte-identical legacy
   outputs and no identity artifacts.
3. Feed the engine ONLY from extraction over the analysed script
   or from comparison capture. No literals, no defaults, no
   "common ID" lists, no environment-variable overrides that
   inject an ID. (A seed file passed between a tool's own stages
   is allowed only if its contents were produced by step 3's
   extraction in the same run.)
4. Emit `identity_report.json` per auto run (unified §6.1 for new
   ports; legacy §6.2 only for v6's existing routes) + a report
   section. Report UNKNOWN fields; never guess.
5. Keep remote-load calls as inert logged mocks. Nothing fetched,
   ever, on any fork or capture path.
6. Add regression coverage mirroring v6 Part E: a gate-PASS
   control (seeded run takes the pass branch), a mismatch control
   (decoy branch signature), an off-mode byte-identity check,
   a no-identity negative, and a no-hardcode audit (the tool's
   production code contains no game-ID literal from its
   fixtures).
7. Document the tool's executor hook (§5-style capture vs Luau
   fork-only) and its branch-evidence rule for `branch` labels.

## 8. No-hardcode audit (v6, at delivery)

Method: `grep` for the fixture game ID over production code
(`luraph_v6.py` + `routes/**/*.py|luau`, excluding `sample/` and
`tests/`), plus a 9+-digit-literal triage over the same tree, plus
the engine's own literal scan. Result:

- **Fixture ID hits in production code: 0.** The ID appears only
  in labelled test data: `tests/check_spoof.py` (controls +
  assertions, header-commented as test data),
  `sample/method/behavior-test/*.luau` (hand-written v5-era
  fixtures), `sample/method/output/*` (tool outputs on the
  sample), and `tests/golden/spoof_sha256.json` (a hash, not a
  value). No production default, fallback, or "common ID" list
  exists; none was removed because none existed — the audit is
  recorded here and enforced by `tests/check_spoof_engine.py`
  (S2) on every future run.
- **Other 9+-digit literals in production code: triaged, none
  are game IDs.** `PROBE_VALUE = 7777777777777` (method route +
  both behavior runners: the §4.4 probe marker, not an ID);
  VM arithmetic constants (`4294967296`, `2^63`-range masks,
  hash/xor keys in the transcribed Fz/sim code); executor
  scaffolding (`987654321` RNG seed, `1700000000.0` virtual
  clock). The engine file itself contains exactly one ID-shaped
  literal: `PROBE_VALUE`.
- **Removed in this change: none** (nothing to remove). The two
  pre-existing `identity.py` modules were refactored into thin
  adapters; their behaviour and report bytes are unchanged
  (proved by the unchanged Part E golden, §9).

## 9. Validation evidence (Luraph v6, this change)

- New engine unit suite `tests/check_spoof_engine.py`: ALL PASS
  (vendored-copy identity, no-hardcode audit, negative/UNKNOWN,
  event kinds + sort, fork caps + determinism, seed rules,
  SpoofState adopt/contradiction/disabled, legacy key orders,
  unified gates/branches, bound expansion, co-occurrence
  evidence shape).
- Existing spoof regression `tests/check_spoof.py` (Part E):
  re-run after the refactor — see `tests/spoof_engine_validation.log`
  for commands + outputs. Headline invariants: E1 behavior-test
  controls (match → HttpGet + remote-payload-run; mismatch →
  exactly 161 insult prints, no HttpGet); E2 auto run on the
  bundled method sample → `identity_report.json` sha256 equals
  the golden `155b89f2…c5a`, candidate PlaceId set-membership at
  root pc 5, exactly one fork, fork 0 gate-PASS (http_attempts 1,
  prints_total 1, PlaceId read from static seed); E3 off-mode →
  no identity artifacts, primaries byte-identical to v5 goldens;
  E4 synthetic units (negative, eq-const, bootstrap static +
  sentinel flow) unchanged.
- Bootstrap full-route note: the bootstrap adapter preserves the
  legacy report shape and the sample static behaviour (0 gate
  candidates, PlaceId seen in materialized constants); the full
  StealAnEggs sweep is covered by regression Part A, unchanged
  by this refactor (no sweep code touched except the
  `IDENTITY_FIELDS` import in `mocks.py`).

## 10. Porting checklist (sibling workers)

### MoonVeil (`~/luau-deobf/tools/MoonVeil-Deobf-Tool/`)

- [ ] Vendor `spoof_engine.py` next to `moonveil2.py` (its
  import root) — byte-identical; add a copy-identity check.
- [ ] Mock-env owner: `trace_template.luau` (`env.game =
  mkproxy("game")`, HttpGet already stubbed, remote code never
  fetched). Hook: make the game proxy's `__index` serve
  identity fields from a seed table injected by the driver
  (seed literal substitution, same pattern as Luraph's
  `runner_behavior.luau` `__IDENTITY_SEEDS__`), logging every
  identity read; unseeded reads serve `PROBE_VALUE` (import the
  constant from the engine; do not retype it).
- [ ] Gate scanner (new): MoonVeil recovers source text, not
  protos — scan the recovered source AST (via the bundled
  `luau-ast`) for `game.<field>` reads flowing into `==` /
  set-index tests and feed `collect_events()`; fall back to a
  co-occurrence scan over the decrypted constants when no gate
  site matches. Do NOT scan the raw obfuscated blob for field
  names (string-encrypted names would false-positive).
- [ ] Driver owner: `run_trace()` in `moonveil2.py` (line ~398)
  — run one trace per fork from `plan_forks()` (same caps),
  collect per-fork print/mock logs, emit `identity_report.json`
  (unified §6.1) + a report section into the outdir, and add
  `--spoof-id auto|off` to the CLI (off = today's behaviour,
  no identity artifacts, no extra traces).
- [ ] Branch rule: define and document the tool's `is_pass`
  rule before labelling any fork `gate-pass` (e.g. stubbed
  HttpGet fired + decoy signature absent); default is
  `unclassified`.

### Luast (`~/luau-deobf/tools/Luast-Deobf-Tool/`)

- [ ] Vendor `spoof_engine.py` next to `luast_deobf.py`.
- [ ] **Static-only port (no execution):** Luast never executes
  the payload (luau-ast parse + luau-compile check only) and
  this port MUST NOT change that. The port is: gate detection
  over the deflattened AST (pool-resolved `game.<field>`
  comparisons in structured code + flattened-machine guards),
  fed to `collect_events()`; emit `identity_report.json`
  (unified §6.1) with `gates[]`/`unknown_fields` and annotate
  gate sites in the cleaned output's comments. There is no fork
  and no mock env in this port — `forks: []`, and any branch
  claim stays `unclassified` unless the sibling adds an
  explicitly opt-in, separately-gated behavior harness (out of
  scope for the first port; do not smuggle execution in).
- [ ] CLI: add `--spoof-id auto|off` (off = today's outputs
  byte-identical, no identity artifacts). Report owner:
  `luast_deobf.py`'s report/manifest emission (the `Gates:`
  lines) — append the identity section there and write
  `identity_report.json` next to the deflattened/cleaned
  outputs.
- [ ] Gate-note: flattened machines dispatch on state numbers,
  not on identity values — a gate inside a machine leaf is a
  normal comparison once deflattened; gates that ARE the machine
  dispatch (state == const) are NOT identity gates and must not
  be reported as such.

### Luau-Deobf-Tool (`~/luau-deobf/tools/Luau-Deobf-Tool/`)

- [ ] Vendor `spoof_engine.py` next to `luau_deobf.py` (its
  import root covers `modules/` via the existing `sys.path`
  inserts; verify the import resolves from every route entry
  point, or vendor a second copy next to the importing module
  as v6 does).
- [ ] Mock-env owners (per route): route C's decoder-only
  harness `modules/xhider/build_harness.py` (the existing
  mock-env harness — extend its game mock with seed/probe
  serving + identity-read logging; keep it decoder-only, no
  payload-logic execution); routes A/B's `gen-runner` in
  `modules/antilua_devirt.py` (instrumented runner: same
  seed/probe game mock + logging forwarders; HttpGet stays a
  logging stub). Each route keeps its own runner template;
  only the seed/probe/capture semantics come from the engine.
- [ ] Gate scanners (per route, new): route B string-layer
  (decrypted literals + CPS factories — scan the recovered
  payload AST for `game.<field>` comparisons); route C (146
  lifted protos / structured states — scan lifted protos for
  field reads into comparisons, same provenance idea as v6
  method); route A (full-virtualization — static gate scan is
  blocked until the FT/proto lift lands; report gates as
  UNKNOWN with the blocker noted, do not guess).
- [ ] Report owner: `luau_deobf.py`'s per-run emission
  (`report.md` + `manifest.json` in the outdir) — add the
  identity section + `identity_report.json` (unified §6.1) and
  a `spoof` block in the manifest; add `--spoof-id auto|off`
  to the CLI (off = today's outputs byte-identical).
- [ ] Branch rule per route, documented before any `gate-pass`
  label; route C's decoder-only harness cannot show branch
  outcomes, so its forks stay `unclassified` until a behavior
  runner exists for that route.

### Shared rules for all three ports

- [ ] No game-ID literal anywhere in production code (add the
  S2-style audit to each tool's tests, pointed at that tool's
  own fixtures).
- [ ] `off` byte-identity proven against the tool's existing
  goldens before the port ships.
- [ ] Nothing fetched on any path; HttpGet-class calls stay
  inert logged mocks; server-checked IDs reported, not spoofed.
