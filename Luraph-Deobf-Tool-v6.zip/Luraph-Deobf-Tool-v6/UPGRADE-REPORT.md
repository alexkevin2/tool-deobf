# Upgrade report — regular-Luraph strengthening (2026-10-23)

Scope per Kevin: "nâng cấp để deobf Luraph THƯỜNG" — the method
route family (v15.1 method-based, v15.0/v14.x upstream, buffer
variant). The bootstrap route is untouched except as regression
protection; the v5 tool dir is untouched; all changes are additive
(new stages append outputs; established outputs are byte-identical
under the full regression).

## Track 1 — buffer-variant opcode semantics: CRACKED

The buffer variant's protos run on a **stage-1 VM**: the payload's
own interpreter closure, installed by its `Vj` method at state
slot 55. (A second, stage-2 VM exists for protos the loader builds
at runtime; it is not part of the static body and is out of scope.)
Method, per the established playbook: signature classification +
handler bodies as ground truth, with dynamic executor evidence for
the instruction decoder.

- **Decoder** (`buffer_lifter.decode_proto`): each packed
  instruction (op, v2, v3, v4) expands into the VM's operand
  streams (J opcodes, D/Q/b numeric streams, A/u/W sparse constant
  streams) via digit fields of v2/v3/v4 (divmod 8) and the
  header pool. Rules reverse-engineered from the deserializer
  methods (`n8` + helpers) in the folded source and **proven
  dynamically**: the deserializer was instrumented and run in the
  Luau sandbox over the reference sample; the static decoder
  reproduces its output **exactly — dense streams 43,496/43,496,
  sparse streams 3,812/3,812, 54 descriptor markers, 0 link
  records in this sample**.
- **Pool parser** (`parse_pool`): header tagged stream parsed
  from the reconstructed binary; validated against the case
  oracle — **1,156/1,156 entries (offsets + values) exact**.
- **Op table** (`optable_buffer.json`, handler bodies in
  `bodies_buffer.json`): **162/162 dispatch opcodes classified**
  from their handler bodies (evidence type: handler-body for
  every entry). 158 distinct packed op words occur in the
  reference sample, including the sentinel 2^52−1 (stub-proto
  marker, not an opcode); ops 3, 101, 124, 128, 137 have handlers
  but never occur. Census: 140 fall-through, 13 conditional
  jumps, 5 returns, op 9 = unconditional jump (2,954 occurrences
  — blocks are jump-chained), numeric-for pair (95/12), generic-
  for pair (58/13), 4 NOP variants, 4 self-patching "mangled FSM"
  decrypt ops (101/124/127/132, emitted as faithful transcriptions
  including their `J[P]` self-writes).
- **Lifter** (`buffer_lifter.lift_buffer`): CFG structuring
  (dominator/post-dominator region analysis, for-pair recognition
  over scattered blocks, return-tail duplication) with a chunked
  dispatch-kernel fallback rendering the same semantic statements.
  Reference sample: **57 protos, 10,874 instructions accounted;
  35 structured + 22 kernel; 42 instructions unreachable (dead);
  luau-compile PASS.** Spot-check: payload logic reads in place —
  the stage-1 loader builds its wrapper from the payload's known
  constants (`"GetAsync"`, `"ScreenGui"`, `setmetatable`,
  `"__index"`, the setfenv wrapper format string).
- **Integration**: `luraph151.buffer_route` stage [3c] appends
  `lifted.luau` and updates the report verdict (bytecode listing
  kept as ground truth). Route exit stays **5 (PARTIAL)** for the
  named residues below.

### Track 1 residues (honest)
- **CLOSURE child identity** (ops 72/47, 65 instructions in the
  sample): binds through the deserializer's deferred link
  registry; static id→proto resolution is not established, so
  closures render as `__descriptor(<id>)` placeholders (54
  descriptor references). The closure bodies themselves (captures
  spec from H[2], state-slot-55 factory, env fixup) are rendered
  faithfully.
- **X field**: carried per proto and printed in comments; its
  exact role (frame-constructor argument) is **unconfirmed**.
- **Kernel protos (22/57)**: irreducible CFGs (multi-entry SCCs,
  shared join blocks) emitted as exact pc-dispatched
  transcriptions — semantically complete, not structured.
- The **stage-2 VM** (runtime-built protos) is untouched: it is
  not present in the static body.

## Track 2 — source-clean stage for the method route

New stage 6b (`routes/method/clean.py`), additive: consumes
`lifted.luau` + `lift_report.json`, emits `cleaned.luau` +
`clean_map.json`. Register-table promotion to real locals,
provable-only:

- Gates per proto: register table must not escape (e.g.
  `table.unpack(R, ...)`), no dynamic register indexing (the
  multret-spill idiom disqualifies), literal indices only.
  Failing protos are copied verbatim and mapped with the reason.
- Naming from the lifted text's own evidence: **CONFIRMED** =
  exactly one definition, a bare known-global, first access is
  that definition, global never bare-assigned; such locals are
  initialised at declaration from the outer global (Luau RHS
  scope rule), which is what makes the shadowing safe.
  **INFERRED** = global-rooted self-refining chains (final member
  name, e.g. `placeId`) and closures (`closure_<child id>`).
  **NEUTRAL** = kind names from the first definition's shape.
- Equivalence: per-proto instr/dispatched accounting anchored to
  `lift_report.json` in `clean_map.json`; the whole-file
  string-literal multiset is verified unchanged; cleaned output
  is luau-compile checked. Idiom conversion beyond renaming:
  **0 by design** where unprovable (matching the bootstrap
  route's precedent).

### JjsKhanhly validation (method-route flagship)
- 5 protos / 604 instructions (case ground truth); route lift:
  5/5 structured (lift_report), `lifted.luau` byte-identical to
  the pristine-v5 golden.
- Clean: **4/5 protos promoted, 37 registers renamed: 1
  CONFIRMED (`warn`), 1 INFERRED (`closure_root_1`), 35 neutral;
  1 proto skipped** (root.1: dynamic register index — the
  vararg `table.unpack(R, ...)` tail-call shape). The low
  semantic-name count is honest: this payload reuses most
  registers as generic temps (the root register that holds
  `game` is later `print` for the 161 unrolled insult prints);
  the payload's constants stay inlined and readable — the
  PlaceId gate reads directly (`t0[9391468976] = true`,
  `r1 = r1["PlaceId"]`).
- `cleaned.luau`: **luau-compile PASS**, string-literal multiset
  preserved exactly.

## Regression + packaging

- New goldens: `tests/golden/upgrade_sha256.json` (buffer
  `lifted.luau` sha256 `13023dfe…`, op coverage 162 classified /
  158 occurring incl. sentinel; JjsKhanhly `cleaned.luau` sha256
  `6feebab4…` + clean_map totals), checked by new Part D of
  `tests/run_regression.sh` (`tests/check_upgrade.py`).
- All pre-existing goldens unchanged: bootstrap route outputs
  byte-identical (StealAnEggs `full_clean.luau` sha256
  `d50a955d…7f47`), method corpus 6/6 vs pristine v5 (the buffer
  corpus goldens cover `constant_pool.txt`/`protos.json`, which
  the new stage does not touch; the buffer `report.md` text
  change is the sanctioned verdict update for this route).
- Full isolated regression from the repackaged zip: **PASS ALL
  PARTS** (A bootstrap, B corpus, D upgrade, C negatives) — see
  `tests/regression_results.log` in the package.
