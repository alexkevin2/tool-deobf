# FEATURE REPORT — automatic game-ID spoofing (`--spoof-id`)

Date: 2026-10-23 (evening). Scope: Luraph-Deobf-Tool-v6, both
routes. All changes additive; `--spoof-id off` reproduces the
pre-feature behaviour byte-identically (proven below and by
regression Part E).

## Problem

Luraph payloads gate their real body on the game identity —
`game.PlaceId == <expected>` and friends — and serve a decoy
branch otherwise. The tool's mock environments were generic, so
every mock execution took the decoy unless a human hand-wrote
the expected ID (the v5-era fixtures in
`sample/method/behavior-test/` do exactly that by hand).

## What shipped

### Method route (`routes/method/identity.py`, stage 7 + buffer
stage 3d)

- **Static extraction** — symbolic provenance over the expanded
  proto tree (game provenance tracked through GETGLOBAL / MOVE /
  GETTABLE_K / SELF / CALL(gamedesc) / CLOSURE→GETUPVAL):
  equality-against-constant, **set-membership** (a
  `set[PlaceId]`-style table test), and less-than bound patterns
  yield strong candidates with (proto, pc) evidence; identity
  fields merely *read* contribute a weak "pool" candidate class
  harvested from the proto's own numeric constants. Buffer
  sub-route: the decoded constant pool is scanned (weak
  `proto-consts` evidence — the buffer VM's instruction stream
  is not dataflow-modelled).
- **Behavior forks** — the lifted source runs in a Luau sandbox
  (`runner_behavior.luau` / `runner_buffer_behavior.luau`) whose
  mock `game.__index` serves identity fields from a seed
  document and logs every identity read, print, and mock call.
  Fork 0 serves the primary candidate for every field; further
  forks vary one field at a time (≤ 4 per field, ≤ 9 total).
  Remote loads stay inert logged mocks (`HttpGet` → `""`).

### Bootstrap route (`routes/bootstrap/modules/stageE/identity.py`)

- **Static extraction** over the stage-2 walk records: an
  instruction whose constants co-refer to an identity field name
  and a number yields a `same-instruction` candidate; the
  materializer output contributes presence-only `fields_seen`.
  Exactly-one-candidate fields are written to
  `identity_seed.json` for the sweep.
- **Self-calibrating executor mocks** — the sweep's game mock
  serves seeded fields directly; unseeded identity fields are
  served as a per-field `IdSentinel`. The executor's equality
  hook (`Runtime.decide('cmpeq', …)`) sees both operands: the
  first scalar a sentinel is compared against is **captured and
  adopted**; later comparisons against a different value are
  logged as **contradictions**. The sweep harvests the identity
  log into `sweepE_state.json`; the driver assembles
  `identity_report.json` (static half + sweep half) and adds a
  manifest summary + report section. The canonical sweep stays a
  single deterministic run — no forking on this route.

## Mechanism substitution (documented per design)

The design called for a Luau-side sentinel whose `__eq`
metamethod captures the compared value. **That does not work in
Luau**: `__eq` fires only when *both* operands are tables
sharing a metatable; `sentinel == 9391468976` evaluates to
`false` silently. Verified empirically against the bundled
`bin/luau` with a minimal probe (table-vs-number `__eq` never
invoked; table-vs-table with a shared metatable invokes it).
The method route therefore captures at **read time** (static
candidates pre-seeded through the mock's `__index`) and resolves
ambiguity by **forking**, which demonstrably reaches the
gate-pass branch. The bootstrap route's Python executor is not
bound by Luau metamethod rules, so it implements the original
capture-at-comparison design exactly.

## Validation

### JjsKhanhly (bundled method sample) — end to end

- Static extraction: **PlaceId candidate 9391468976**,
  kind `set-membership`, evidence root pc 5, pattern
  `set[PlaceId] membership` — the case's known gate value.
- Behavior fork 0 (seed 9391468976, no hand-written game table):
  gate **PASS** — 1 print (`or run start`), 1 `HttpGet` mock
  attempt (the remote load stays a logged mock; nothing is
  fetched), chunk completes.
- Control fork (seed 12345, the mismatch-fixture value):
  **exactly 161** decoy insult prints, 0 HTTP attempts — the
  case ground truth for the wrong-ID branch.
- No-seed run: probe value served, decoy branch taken, the read
  logged with `source=probe`.
- The v5 fixtures agree as controls: match fixture → `HTTPGET`
  + remote payload executed; mismatch fixture → 161 insults +
  `DONE`, no HTTP (regression Part E1 re-runs both).
- Pipeline outputs with the feature on AND off are
  **byte-identical** to the pre-feature baseline
  (`lifted.luau` d0b89ff2…, `ops.json` dc9f46e7…,
  `protos.json` 3a28763e…, `cleaned.luau` 4a152419…); `off`
  additionally emits no `identity_report.json` and no report
  section.

### Buffer sub-route (corpus payload)

Exit 5 unchanged; stage 3d emits an identity report with
`fields_seen = []` — this payload's constant pool contains no
identity field names at all. Its behavior chunk stops at the
same environment gap as the stock dump runner
(`attempt to index nil with 'new'`), so zero identity reads are
recorded: an honest empty result, no behaviour change.

### Bootstrap route (StealAnEggs sample data)

- Static: 0 gate candidates from the walk records (no walked
  instruction co-refers to an identity field and a number);
  `fields_seen = {PlaceId}` from the materialized constants at
  `/proto_groups/0/tables/2/materialized/5251/other`; seed `{}`.
  The sweep therefore serves PlaceId as a sentinel and would log
  any read/capture — none is forced or invented.
- Mock layer unit-verified: sentinel identity-stable across
  reads, adoption switches served values, seeded reads log
  `static-seed`, and with the feature off the game mock returns
  the exact legacy child mock with an empty identity log.

### Synthetic units (regression Part E4)

- Proto tree with no identity constants → zero candidates,
  zero field reads.
- Hand-built EQ gate (`R(game.PlaceId) == 12345`) → candidate
  recovered as kind `eq-const` with the comparing pc.

### Regression

- Part E (`tests/check_spoof.py`, 34 checks): **ALL PASS**,
  including the golden hash of the bundled sample's
  `identity_report.json` (sha256 `155b89f2…c5a`).
- Full isolated regression from the repackaged zip (2026-10-23,
  ~11 min): **REGRESSION PASS — ALL PARTS (A, B, D, E, C)**.
  Part A re-proves the StealAnEggs golden byte-identically with
  the feature enabled in the canonical sweep, and the Part A
  bootstrap output contains the route's own
  `identity_report.json` (fields_seen PlaceId, 0 candidates —
  the honest empty result for this payload) plus the manifest
  identity summary and the report section.

## Limits

- IDs computed from non-constant expressions are caught only
  where an execution compares them (bootstrap capture; method
  forks over pool-harvested candidates).
- Server-checked IDs are out of scope: this spoofs the local
  environment view for analysis only.
- Self-calibration needs the gate to actually execute; a gate
  behind an unexecuted branch stays a static candidate only.
