#!/usr/bin/env python3
"""qa_report.py — self-check QA report for Luraph-Deobf-Tool-v6 (v6.2.0).

Phase 3 of the self-audit upgrade: every run emits ``qa_report.json``
plus a short section appended to ``report.md``. The report counts
raw patterns (string-aware, so literals never count), name ratios,
unstructured residue, and defects detected but NOT fixed, with
locations. It never modifies a cleaned/lifted file — that is
qa_clean.py's job; this module only measures.

Counts (all on masked code: strings replaced, comments stripped):
  if_true / if_false / elseif_not / while_true / empty_while_true
  descriptor (callsites, with ids) / link (callsites)
  nil_decl_all / nil_decl_mixed / trailing_nil_lines
  lshift_zero / self_assign / const_unresolved
  unfolded_arith (``+ N - M``-style non-isolated constant residues)
  kind_changes (per-function strong-kind changes, with the name;
    kind-lettered ones should be 0 after qa_clean renames them)
For buffer lifts, proto header lines give structured/kernel counts.
"""
import json
import re

try:
    import qa_clean as QC
except Exception:  # vendored copies live next to the driver
    QC = None


def _mask_line(line):
    if QC is not None:
        return QC.mask(line)
    out = []
    i = 0
    while i < len(line):
        c = line[i]
        if c in '"\'':
            j = i + 1
            while j < len(line):
                if line[j] == '\\':
                    j += 2
                    continue
                if line[j] == c:
                    break
                j += 1
            out.append('""')
            i = j + 1
        elif line.startswith('--', i):
            break
        else:
            out.append(c)
            i += 1
    return ''.join(out)


def audit_text(text):
    lines = text.split('\n')
    code = [_mask_line(l) for l in lines]
    a = {}

    def hits(pat):
        out = []
        for i, l in enumerate(code):
            if re.search(pat, l):
                out.append(i + 1)
        return out

    a['lines'] = len(text.splitlines())
    a['if_true'] = hits(r'\bif true then\b')
    a['if_false'] = hits(r'\bif false then\b')
    a['elseif_not'] = hits(r'\belseif not\b')
    a['while_true'] = hits(r'\bwhile true do\b')
    a['empty_while_true'] = [i + 1 for i, l in enumerate(code)
                             if re.match(r'^\s*while true do\s*$', l)
                             and i + 1 < len(code)
                             and code[i + 1].strip() == 'end']
    desc = []
    for i, l in enumerate(code):
        for m in re.finditer(r'__descriptor\(([^)]+)\)', l):
            if 'local function __descriptor' in l:
                continue
            desc.append({'line': i + 1, 'id': m.group(1)})
    a['descriptor'] = desc
    a['link_calls'] = [i + 1 for i, l in enumerate(code)
                       if re.search(r'(?<![\w.])__link\(', l)
                       and 'local function __link' not in l]
    a['lshift_zero'] = hits(r'bit32\.lshift\([^,]+,\s*0\s*\)')
    a['const_unresolved'] = hits(r'CONST_UNRESOLVED')
    a['self_assign'] = []
    for i, l in enumerate(code):
        m = re.match(r'^\s*([A-Za-z_][\w]*)\s*=\s*([A-Za-z_][\w]*)\s*;?\s*$', l)
        if m and m.group(1) == m.group(2):
            a['self_assign'].append(i + 1)
    # nil declarations: all-nil vs mixed, and trailing-nil lines
    alln, mixed, trail = [], [], []
    for i, l in enumerate(code):
        m = re.match(r'^\s*local\s+[\w,\s]+?\s*=\s*(.+?)\s*$', l)
        if not m:
            continue
        raw = lines[i]
        # values from the raw line (mask would corrupt strings);
        # strip a trailing comment outside strings first.
        code_part, _c = (QC.split_comment(raw) if QC is not None
                         else (raw, ''))
        m2 = re.match(r'^(\s*local\s+[\w,\s]+?)\s*=\s*(.+?)\s*$', code_part)
        vals = None
        if m2 and QC is not None:
            vals = QC.split_top_commas(m2.group(2))
        elif m2:
            vals = [v.strip() for v in m2.group(2).split(',')]
        if vals is None:
            continue
        if all(v == 'nil' for v in vals):
            alln.append(i + 1)
        elif 'nil' in vals:
            mixed.append(i + 1)
        if vals and vals[-1] == 'nil':
            trail.append(i + 1)
    a['nil_decl_all'] = alln
    a['nil_decl_mixed'] = mixed
    a['trailing_nil_lines'] = trail
    a['unfolded_arith'] = hits(r'\+\s*\d+\s*-\s*\d+|\-\s*\d+\s*\+\s*\d+')
    # buffer proto headers
    a['proto_structured'] = len(re.findall(r'mode=structured', text))
    a['proto_kernel'] = len(re.findall(r'mode=kernel', text))
    a['proto_kernel_ids'] = [m.group(1) for m in
                             re.finditer(r'-- proto (\d+): \d+ instructions, X=\S+, mode=kernel', text)]
    a['kind_changes'] = kind_changes(text)
    return a


def kind_changes(text):
    """Per-function strong-kind changes (qa_clean block tracking).
    Returns [{line, function, name, kinds: [k1, k2]}]."""
    if QC is None:
        return []
    lines = text.split('\n')
    blocks = QC.find_blocks(lines)
    out = []
    for (s, e, bname, _p) in blocks:
        seen = {}
        for k in range(s + 1, e):
            code = _mask_line(lines[k])
            m = QC.SINGLE_ASSIGN.match(code)
            if not m:
                continue
            kk = QC.kind_of(m.group(2))
            if not kk:
                continue
            prev = seen.get(m.group(1))
            if prev and prev != kk:
                out.append({'line': k + 1, 'function': bname,
                            'name': m.group(1), 'kinds': [prev, kk]})
                seen[m.group(1)] = kk
            else:
                seen.setdefault(m.group(1), kk)
    return out


def summarize(audit):
    """Compact count-only view for the report section."""
    keys = ('if_true', 'if_false', 'elseif_not', 'while_true',
            'empty_while_true', 'descriptor', 'link_calls',
            'lshift_zero', 'const_unresolved', 'self_assign',
            'nil_decl_all', 'nil_decl_mixed', 'trailing_nil_lines',
            'unfolded_arith', 'kind_changes')
    return {k: len(audit.get(k, [])) for k in keys}


def build_report(version, route, files, qa_stats, name_ratio,
                 unstructured, defects_not_fixed, qa_enabled=True):
    """files: {filename: {'before': audit, 'after': audit}}."""
    return {
        'tool': 'Luraph-Deobf-Tool-v6',
        'version': version,
        'route': route,
        'qa_clean': {'enabled': qa_enabled, 'passes': qa_stats},
        'files': {fn: {'lines_before': v['before']['lines'],
                       'lines_after': v['after']['lines'],
                       'counts_before': summarize(v['before']),
                       'counts_after': summarize(v['after'])}
                  for fn, v in files.items()},
        'name_ratio': name_ratio,
        'unstructured': unstructured,
        'defects_not_fixed': defects_not_fixed,
        'notes': [
            'Counts are string-aware (literals/comments excluded).',
            'empty_while_true loops are faithful infinite loops, '
            'never removed (hang -> return would change semantics).',
            'lshift(x, 0) is not folded: it errors on nil/non-number '
            'where a plain copy would not.',
            'Non-isolated constant arithmetic (q + 4 - 1) is not '
            'folded: double rounding is not associative.',
            '__descriptor ids are runtime deferred-link keys and '
            'are not recoverable from static artefacts.',
        ],
    }


def section(report):
    """Markdown lines for appending to report.md."""
    L = []
    L.append('')
    L.append('## QA self-check (v%s)' % report['version'])
    qc = report['qa_clean']
    L.append('- qa_clean: %s' % ('enabled' if qc['enabled'] else 'off (legacy bytes)'))
    if qc['enabled']:
        for name, st in qc['passes'].items():
            L.append('- qa_clean %s: %d changed' % (name, st.get('changed', 0)))
    for fn, v in report['files'].items():
        cb, ca = v['counts_before'], v['counts_after']
        L.append('- %s: %d -> %d lines; if_true %d->%d, elseif_not %d->%d, '
                 'descriptor %d->%d, trailing_nil %d->%d, kind_changes %d->%d'
                 % (fn, v['lines_before'], v['lines_after'],
                    cb['if_true'], ca['if_true'], cb['elseif_not'],
                    ca['elseif_not'], cb['descriptor'], ca['descriptor'],
                    cb['trailing_nil_lines'], ca['trailing_nil_lines'],
                    cb['kind_changes'], ca['kind_changes']))
    if report.get('name_ratio'):
        L.append('- name_ratio: %s' % json.dumps(report['name_ratio']))
    u = report.get('unstructured') or {}
    if u:
        L.append('- unstructured residue: %s' % json.dumps(u))
    dnf = report.get('defects_not_fixed') or []
    L.append('- defects detected but NOT fixed: %d' % len(dnf))
    for d in dnf[:20]:
        L.append('  - %s:%s %s — %s' % (d.get('file'), d.get('line'),
                                        d.get('category'), d.get('detail')))
    if len(dnf) > 20:
        L.append('  - … +%d more (see qa_report.json)' % (len(dnf) - 20))
    return L
