#!/usr/bin/env python3
"""qa_clean.py — post-clean QA passes for Luraph-Deobf-Tool-v6 (v6.2.0).

Applied AFTER the route's own clean stage, to the cleaned/lifted
text only. `lifted.luau` (method route) and upstream-engine output
are never modified by this module.

Every pass is provable-only and conservative:
  * verbatim lines (``bzClosure…`` / ``proto_child…`` constant
    artifacts) are never modified;
  * a construct the pass cannot prove safe is left untouched and
    reported as residue by qa_report.py, never silently rewritten;
  * string literals and comments are never touched (all rewrites
    operate on code segments only, long ``[[ ]]`` strings excluded);
  * dead-write elimination runs only inside one straight-line
    segment (reset at every control line, ``local`` decl, inline
    ``function``, verbatim line, or function boundary) and only for
    names that are declared locals of the enclosing function.

Passes (in application order):
  1. literal folding — isolated literal-only expressions only:
     integer ``a + b`` / ``a - b`` / ``a * b`` (result < 2**53),
     ``not true`` / ``not false``. Non-isolated arithmetic such as
     ``q + 4 - 1`` is deliberately NOT folded: double rounding is
     not associative, so ``q+4-1`` and ``q+3`` can differ.
  2. ``if true`` unwrap / ``if false`` delete-or-else (simple
     blocks only: no elseif/else for unwrap, matching ``end`` found
     by nesting scan, all body lines dedentable, no verbatim lines
     inside; anything else is left alone).
  3. kind-conflict downgrade (method/bootstrap-clean only): a
     kind-lettered local (``s<n>``/``n<n>``/``b<n>``/``t<n>``/``f<n>``)
     whose assignments carry two different strong value kinds is
     alpha-renamed to neutral ``r<n>`` throughout its function
     block, iff ``r<n>`` is free there. Split-per-live-range was
     rejected: the conflicting ranges share one declaration.
  4. nil-init compaction — strip TRAILING ``nil`` values from a
     local declaration value list only (Luau pads missing values
     with nil, so this is exact). Positional nils are never moved:
     ``local … = nil, warn, nil`` keeps ``warn`` in place.
  5. junk simplification — exact self-assigns (``x = x`` for a
     declared bare local) and unused ``local T = -1`` in a
     method/bootstrap-clean function block (T referenced nowhere
     else in the block).
  6. dead-assignment elimination — see the rule above. RHS must
     be pure: literal, bare local, or an operator chain over
     literals/bare locals only (no calls, no indexing, no table
     or function literals). The overwriting assignment may be any
     single-target assignment whose RHS does not read the target.

``clean_text(text, style)`` returns ``(new_text, stats, removed)``:
  stats: {pass: {'changed': int, 'locations': [(orig_line, before, after)]}}
  removed: sorted list of ORIGINAL line numbers that no longer
    exist in the output (for clean_map line-number adjustment).

Styles: 'method-clean', 'bootstrap-clean', 'buffer-lift'.
'buffer-lift' disables passes 3 and 5 (VM register variables are
not promoted names; the T convention does not apply there).
"""
import re

# ------------------------------------------------------------------ utils

def split_comment(line):
    """Split a line into (code, comment) with '--' outside strings."""
    i = 0
    n = len(line)
    while i < n:
        c = line[i]
        if c in '"\'':
            j = i + 1
            while j < n:
                if line[j] == '\\':
                    j += 2
                    continue
                if line[j] == c:
                    break
                j += 1
            i = j + 1
        elif line.startswith('--', i):
            return line[:i], line[i:]
        else:
            i += 1
    return line, ''


def segments(line):
    """Split a line into (is_string, text) parts (short strings only)."""
    out = []
    i = 0
    n = len(line)
    buf = ''
    while i < n:
        c = line[i]
        if c in '"\'':
            if buf:
                out.append((False, buf))
                buf = ''
            j = i + 1
            while j < n:
                if line[j] == '\\':
                    j += 2
                    continue
                if line[j] == c:
                    break
                j += 1
            out.append((True, line[i:j + 1]))
            i = j + 1
        else:
            buf += c
            i += 1
    if buf:
        out.append((False, buf))
    return out


def mask(line):
    """Code-only view of a line: strings replaced by '""'."""
    return ''.join('""' if s else t for s, t in segments(line))


def split_statements(code):
    """Split code (no comment) by ';' outside strings -> raw pieces."""
    pieces = []
    buf = ''
    i = 0
    n = len(code)
    while i < n:
        c = code[i]
        if c in '"\'':
            j = i + 1
            while j < n:
                if code[j] == '\\':
                    j += 2
                    continue
                if code[j] == c:
                    break
                j += 1
            buf += code[i:j + 1]
            i = j + 1
        elif c == ';':
            pieces.append(buf)
            buf = ''
            i += 1
        else:
            buf += c
            i += 1
    pieces.append(buf)
    return pieces


def is_verbatim(line):
    return 'bzClosure' in line or line.startswith('local proto_child')


def split_top_commas(s):
    """Split a value list on top-level commas (strings/parens aware)."""
    parts = []
    buf = ''
    i = 0
    n = len(s)
    depth = 0
    while i < n:
        c = s[i]
        if c in '"\'':
            j = i + 1
            while j < n:
                if s[j] == '\\':
                    j += 2
                    continue
                if s[j] == c:
                    break
                j += 1
            buf += s[i:j + 1]
            i = j + 1
            continue
        if c in '({[':
            depth += 1
        elif c in ')}]':
            depth -= 1
        if c == ',' and depth == 0:
            parts.append(buf)
            buf = ''
            i += 1
            continue
        buf += c
        i += 1
    parts.append(buf)
    return [p.strip() for p in parts]


# ------------------------------------------------------------------ blocks

FN_HEAD = re.compile(r'^\s*local function\s+([A-Za-z_][\w]*)\s*\((.*?)\)\s*$')
FN_END = re.compile(r'^end\s*$')
LOCAL_DECL = re.compile(r'^\s*local\s+([A-Za-z_][\w\s,]*?)\s*(?:=|$)')
FOR_VARS = re.compile(r'\bfor\s+([A-Za-z_][\w\s,]*?)\s+in\b|\bfor\s+([A-Za-z_][\w]*)\s*=')


def find_blocks(lines):
    """Return list of (start_idx, end_idx, name, params) for top-level
    `local function … end` blocks (end at column 0)."""
    blocks = []
    i = 0
    while i < len(lines):
        m = FN_HEAD.match(mask(lines[i]))
        if m and not lines[i].startswith((' ', '\t')):
            params = [p.strip() for p in m.group(2).split(',') if p.strip() and p.strip() != '...']
            j = i + 1
            while j < len(lines) and not FN_END.match(mask(lines[j])):
                j += 1
            blocks.append((i, j if j < len(lines) else len(lines) - 1,
                           m.group(1), params))
            i = (j + 1) if j < len(lines) else len(lines)
        else:
            i += 1
    return blocks


def block_locals(lines, start, end, params):
    """Declared locals of a block: header params + `local …` decls,
    minus for-loop variables (excluded from dead-elim targets)."""
    names = set(params)
    for k in range(start + 1, end):
        m = LOCAL_DECL.match(mask(lines[k]))
        if m:
            for nm in m.group(1).split(','):
                nm = nm.strip()
                if nm:
                    names.add(nm)
    for k in range(start, end + 1):
        for mm in FOR_VARS.finditer(mask(lines[k])):
            for g in mm.groups():
                if g:
                    for nm in g.split(','):
                        names.discard(nm.strip())
    return names


# ------------------------------------------------------------------ pass 1: fold

INT_BIN = re.compile(r'(?<![\w\d.])(-?\d+)\s*([+\-*])\s*(-?\d+)(?![\w\d.])')


def _fold_code(code):
    """Fold isolated integer binary expressions only. A match is
    isolated iff the nearest non-space character on EITHER side is
    not an operator (so ``q + 4 - 1`` and ``4 - 1 + q`` are never
    folded — double rounding is not associative) and not the start
    of a concat, and a leading ``-`` on the first operand is only
    accepted where it is unambiguously unary (start, ``=``, ``(``,
    ``,``). Unsafe matches are skipped, never folded."""
    changed = False
    out = code
    for _ in range(8):
        folded = False
        for m in INT_BIN.finditer(out):
            prev = out[:m.start()].rstrip()
            nxt = out[m.end():].lstrip()
            prev_ch = prev[-1] if prev else ''
            if prev_ch in '+-*/%^':
                continue
            if nxt[:1] in ('+', '-', '*', '/', '%', '^') or nxt.startswith('..'):
                continue
            if m.group(1).startswith('-') and prev_ch not in ('', '=', '(', ','):
                continue
            a, op, b = int(m.group(1)), m.group(2), int(m.group(3))
            v = a + b if op == '+' else a - b if op == '-' else a * b
            if abs(v) >= 2 ** 53:
                continue
            out = out[:m.start()] + str(v) + out[m.end():]
            changed = True
            folded = True
            break
        if not folded:
            break
    out2 = re.sub(r'\bnot\s+true\b', 'false', out)
    out2 = re.sub(r'\bnot\s+false\b', 'true', out2)
    if out2 != out:
        changed = True
    return out2, changed


def pass_fold(entries):
    """entries: list of [orig_lineno, text]. Returns changed count."""
    n = 0
    for e in entries:
        line = e[1]
        if is_verbatim(line):
            continue
        code, comment = split_comment(line)
        parts = []
        changed = False
        for is_str, t in segments(code):
            if is_str:
                parts.append(t)
            else:
                t2, ch = _fold_code(t)
                changed = changed or ch
                parts.append(t2)
        if changed:
            e[1] = ''.join(parts) + comment
            n += 1
    return n


# ------------------------------------------------------------------ pass 2: if true / if false

CTRL_OPEN = re.compile(r'\b(if|while|for|function|do|repeat)\b')
CTRL_CLOSE = re.compile(r'\b(end|until)\b')


def _block_end(entries, idx):
    """Find matching `end` for the `if` at entries[idx]; return
    (end_idx, else_idx_or_None, elseif_bool) or None if not simple."""
    depth = 0
    else_idx = None
    for j in range(idx, len(entries)):
        code = mask(entries[j][1]).strip()
        if j == idx:
            depth = 1
            continue
        if re.match(r'^(elseif|else)\b', code):
            if depth == 1:
                if code.startswith('elseif'):
                    return None
                if else_idx is not None:
                    return None
                else_idx = j
            continue
        opens = len(CTRL_OPEN.findall(code))
        closes = len(CTRL_CLOSE.findall(code))
        # `if` on a line that also closes something is rare in these
        # outputs; be conservative and bail on mixed lines.
        if opens and closes:
            return None
        depth += opens - closes
        if depth == 0:
            return (j, else_idx)
        if depth < 0:
            return None
    return None


def _indent_of(line):
    return line[:len(line) - len(line.lstrip())]


def _dedentable(entries, a, b):
    """Body lines a..b: all blank or sharing one indent prefix."""
    indents = {_indent_of(entries[k][1]) for k in range(a, b + 1)
               if entries[k][1].strip()}
    if len(indents) != 1:
        return None
    ind = indents.pop()
    if ind == '':
        return None
    return ind


def pass_iftrue(entries):
    """entries mutated in place (removed lines -> text None).
    Returns (removed_orig_linenos, changed_blocks)."""
    removed = []
    blocks = 0
    i = 0
    while i < len(entries):
        if entries[i][1] is None:
            i += 1
            continue
        code, comment = split_comment(entries[i][1])
        if comment.strip() or is_verbatim(entries[i][1]):
            i += 1
            continue
        m = re.match(r'^\s*if (true|false) then\s*$', mask(code))
        if not m:
            i += 1
            continue
        found = _block_end(entries, i)
        if not found:
            i += 1
            continue
        end_idx, else_idx = found
        body = entries[i + 1:end_idx if else_idx is None else else_idx]
        if any(e[1] is None or is_verbatim(e[1]) for e in body):
            i += 1
            continue
        if m.group(1) == 'true':
            if else_idx is not None:
                i += 1
                continue
            ind = _dedentable(entries, i + 1, end_idx - 1)
            if ind is None and end_idx - i > 1:
                i += 1
                continue
            if ind:
                for k in range(i + 1, end_idx):
                    if entries[k][1].startswith(ind):
                        entries[k][1] = entries[k][1][len(ind):]
            removed.append(entries[i][0])
            removed.append(entries[end_idx][0])
            entries[i][1] = None
            entries[end_idx][1] = None
            blocks += 1
            i = end_idx + 1
        else:  # if false
            if else_idx is None:
                for k in range(i, end_idx + 1):
                    removed.append(entries[k][0])
                    entries[k][1] = None
                blocks += 1
                i = end_idx + 1
            else:
                else_body = entries[else_idx + 1:end_idx]
                if any(e[1] is None or is_verbatim(e[1]) for e in else_body):
                    i += 1
                    continue
                ind = _dedentable(entries, else_idx + 1, end_idx - 1)
                if ind is None and end_idx - else_idx > 1:
                    i += 1
                    continue
                if ind:
                    for k in range(else_idx + 1, end_idx):
                        if entries[k][1].startswith(ind):
                            entries[k][1] = entries[k][1][len(ind):]
                for k in list(range(i, else_idx + 1)) + [end_idx]:
                    removed.append(entries[k][0])
                    entries[k][1] = None
                blocks += 1
                i = end_idx + 1
    return removed, blocks


# ------------------------------------------------------------------ pass 3: kind downgrade

KIND_LETTER = re.compile(r'^([snbtf])(\d+)$')


def kind_of(rhs):
    r = rhs.strip()
    if r.startswith('"') or r.startswith("'"):
        return 'string'
    if re.match(r'^-?\d', r):
        return 'number'
    if r in ('true', 'false'):
        return 'boolean'
    if r.startswith('{'):
        return 'table'
    if r.startswith('function'):
        return 'function'
    if r.startswith('tonumber'):
        return 'number'
    if r.startswith('tostring'):
        return 'string'
    if '..' in r and '(' not in r:
        return 'string'
    if re.search(r'\s*(?:\+|-|\*|/|%|\^)\s*', r) and '(' not in r:
        return 'number'
    if re.search(r'\s*(?:==|~=|<|>|<=|>=)\s*', r):
        return 'boolean'
    if r.startswith('#'):
        return 'number'
    return None


SINGLE_ASSIGN = re.compile(r'^\s*([A-Za-z_][\w]*)\s*=\s*(.+?);?\s*$')


def pass_rename(entries, blocks):
    """Alpha-rename kind-lettered locals with conflicting strong
    kinds to neutral r<n> within their block. Returns renames list
    of (block_name, old, new, [orig_linenos])."""
    renames = []
    # entries are indexed by position; blocks are (start, end, name, params)
    # over the ORIGINAL line list, but entries list is mutated only by
    # pass 2 (None entries) before this pass runs — positions are
    # preserved (None entries keep their slot), so block indices stay
    # valid as long as this pass runs before any line-removing pass
    # other than pass 2. (Driver order: fold, iftrue, rename, nil,
    # junk, dead — dead removes lines last, via entries slots.)
    for (s, e, bname, _params) in blocks:
        kinds = {}
        for k in range(s + 1, e):
            if entries[k][1] is None:
                continue
            code = mask(entries[k][1])
            m = SINGLE_ASSIGN.match(code)
            if not m:
                continue
            kk = kind_of(m.group(2))
            if kk:
                kinds.setdefault(m.group(1), set()).add(kk)
        used = set()
        for k in range(s, e + 1):
            if entries[k][1] is None:
                continue
            used.update(re.findall(r'(?<![\w.])[A-Za-z_][\w]*',
                                   mask(entries[k][1])))
        for name, ks in kinds.items():
            if len(ks) < 2:
                continue
            m = KIND_LETTER.match(name)
            if not m:
                continue
            new = 'r' + m.group(2)
            if new in used:
                continue
            # string-aware rename over the block's code segments
            touched = []
            for k in range(s, e + 1):
                if entries[k][1] is None:
                    continue
                code, comment = split_comment(entries[k][1])
                parts = []
                hit = False
                for is_str, t in segments(code):
                    if is_str:
                        parts.append(t)
                    else:
                        t2 = re.sub(r'(?<![\w.])' + re.escape(name) + r'\b',
                                    new, t)
                        if t2 != t:
                            hit = True
                        parts.append(t2)
                if hit:
                    entries[k][1] = ''.join(parts) + comment
                    touched.append(entries[k][0])
            if touched:
                renames.append((bname, name, new, touched))
                used.discard(name)
                used.add(new)
    return renames


# ------------------------------------------------------------------ pass 4: nil compaction

def pass_nil(entries):
    n = 0
    locs = []
    for e in entries:
        if e[1] is None or is_verbatim(e[1]):
            continue
        code, comment = split_comment(e[1])
        m = re.match(r'^(\s*local\s+[\w,\s]+?)\s*=\s*(.+?)\s*$', mask(code))
        if not m:
            continue
        # re-extract values from the RAW code (mask keeps lengths for
        # strings as '""', which would corrupt values) — instead parse
        # the raw code with the same regex.
        m2 = re.match(r'^(\s*local\s+[\w,\s]+?)\s*=\s*(.+?)\s*$', code)
        if not m2 or 'function' in m2.group(2):
            continue
        vals = split_top_commas(m2.group(2))
        stripped = list(vals)
        while stripped and stripped[-1] == 'nil':
            stripped.pop()
        if len(stripped) == len(vals):
            continue
        join = (' ' + comment) if comment else ''
        if stripped:
            e[1] = m2.group(1) + ' = ' + ', '.join(stripped) + join
        else:
            e[1] = m2.group(1) + join
        n += 1
        locs.append(e[0])
    return n, locs


# ------------------------------------------------------------------ pass 5: junk (self-assign, unused T)

def pass_junk(entries, blocks, style):
    self_n = 0
    self_locs = []
    # self-assigns: whole-line, declared-local only (checked per block)
    block_of = {}
    for (s, e, bname, params) in blocks:
        locs = block_locals([x[1] if x[1] is not None else '' for x in entries], s, e, params)
        for k in range(s, e + 1):
            block_of[k] = locs
    for idx, e in enumerate(entries):
        if e[1] is None or is_verbatim(e[1]):
            continue
        code, comment = split_comment(e[1])
        m = re.match(r'^\s*([A-Za-z_][\w]*)\s*=\s*([A-Za-z_][\w]*)\s*;?\s*$', mask(code))
        if m and m.group(1) == m.group(2) and m.group(1) in block_of.get(idx, set()):
            if comment.strip():
                e[1] = _indent_of(e[1]) + comment.strip()
            else:
                e[1] = None
            self_n += 1
            self_locs.append(e[0])
    # unused T (method/bootstrap-clean only)
    t_n = 0
    t_locs = []
    if style in ('method-clean', 'bootstrap-clean'):
        for (s, e, bname, _params) in blocks:
            decl_idx = None
            for k in range(s + 1, e):
                if entries[k][1] is None:
                    continue
                if re.match(r'^\s*local T = -1\s*;?\s*$', mask(entries[k][1])):
                    decl_idx = k
                    break
            if decl_idx is None:
                continue
            used_elsewhere = False
            for k in range(s, e + 1):
                if k == decl_idx or entries[k][1] is None:
                    continue
                if re.search(r'(?<![\w.])T(?![\w])', mask(entries[k][1])):
                    used_elsewhere = True
                    break
            if not used_elsewhere:
                entries[decl_idx][1] = None
                t_n += 1
                t_locs.append(entries[decl_idx][0])
    return (self_n, self_locs), (t_n, t_locs)


# ------------------------------------------------------------------ pass 6: dead elimination

CTRL_START = re.compile(r'^\s*(if|elseif|else|while|for|repeat|until|return|break|do|end|local function|function)\b')
PURE = re.compile(r'^\s*(?:-?\d+(?:\.\d+)?|true|false|nil|"[^"]*"|\'[^\']*\'|[A-Za-z_][\w]*(?:\s*(?:\+|-|\*|/|%|\^|\.\.|==|~=|<|>|<=|>=|and|or)\s*(?:-?\d+(?:\.\d+)?|true|false|nil|"[^"]*"|[A-Za-z_][\w]*))*)\s*$')


def _drop_piece(entries, pidx, name):
    """Remove the single-target assignment to `name` from the entry
    at pidx (which currently holds exactly that statement, possibly
    among other ';'-separated statements)."""
    e = entries[pidx]
    if e[1] is None:
        return
    code, comment = split_comment(e[1])
    pieces = split_statements(code)
    kept = []
    dropped = False
    for piece in pieces:
        m = re.match(r'^\s*([A-Za-z_][\w]*)\s*=\s*(.+?)\s*$', mask(piece).strip())
        if not dropped and m and m.group(1) == name:
            dropped = True
            continue
        kept.append(piece)
    if not dropped:
        return
    if not kept or all(p.strip() == '' for p in kept):
        if comment.strip():
            e[1] = _indent_of(e[1]) + comment.strip()
        else:
            e[1] = None
    else:
        e[1] = ';'.join(kept) + comment


def pass_dead2(entries, blocks):
    """Working dead-elimination (see pass_dead docstring). Returns
    (removed_orig_linenos, shortened_orig_linenos)."""
    decl = {}
    for (s, e, bname, params) in blocks:
        locs = block_locals([x[1] if x[1] is not None else '' for x in entries], s, e, params)
        for k in range(s, e + 1):
            decl[k] = locs
    pending = {}
    before = {e[0]: (e[1] if e[1] is not None else None) for e in entries}

    def reset():
        pending.clear()

    for idx, e in enumerate(entries):
        if e[1] is None:
            reset()
            continue
        line = e[1]
        if FN_HEAD.match(mask(line)) and not line.startswith((' ', '\t')):
            reset()
            continue
        if FN_END.match(mask(line)):
            reset()
            continue
        if is_verbatim(line):
            reset()
            continue
        allowed = decl.get(idx)
        if allowed is None:
            reset()
            continue
        code, comment = split_comment(line)
        pieces = split_statements(code)
        for piece in pieces:
            s = piece.strip()
            if not s:
                continue
            masked = mask(piece).strip()
            if CTRL_START.match(masked):
                reset()
                continue
            if 'function' in masked and not masked.startswith('local function'):
                reset()
                continue
            m = re.match(r'^([A-Za-z_][\w]*)\s*=\s*(.+?)\s*$', masked)
            if m:
                name, rhs = m.group(1), m.group(2).strip()
                for nm in list(pending):
                    if nm != name and re.search(r'(?<![\w.])' + re.escape(nm) + r'\b', rhs):
                        del pending[nm]
                if name in pending and name in allowed and \
                        not re.search(r'(?<![\w.])' + re.escape(name) + r'\b', rhs):
                    pidx = pending.pop(name)
                    _drop_piece(entries, pidx, name)
                if PURE.match(rhs) and name in allowed and \
                        not re.search(r'\b' + re.escape(name) + r'\b', rhs):
                    pending[name] = idx
                else:
                    pending.pop(name, None)
                continue
            if masked.startswith('local '):
                reset()
                continue
            if '=' in masked and ',' in masked.split('=')[0]:
                lhs = masked.split('=')[0]
                for nm in re.findall(r'[A-Za-z_][\w]*', lhs):
                    pending.pop(nm, None)
                rhs = masked.split('=', 1)[1]
                for nm in list(pending):
                    if re.search(r'(?<![\w.])' + re.escape(nm) + r'\b', rhs):
                        del pending[nm]
                continue
            for nm in list(pending):
                if re.search(r'(?<![\w.])' + re.escape(nm) + r'\b', masked):
                    del pending[nm]
    removed = []
    shortened = []
    for e in entries:
        orig = e[0]
        old = before[orig]
        new = e[1]
        if old is not None and new is None:
            removed.append(orig)
        elif old is not None and new is not None and new != old:
            shortened.append(orig)
    return removed, shortened


# ------------------------------------------------------------------ driver

def clean_text(text, style):
    """Apply qa_clean passes. Returns (new_text, stats, removed)."""
    lines = text.split('\n')
    entries = [[i + 1, ln] for i, ln in enumerate(lines)]
    blocks = find_blocks(lines)
    stats = {}

    stats['fold'] = {'changed': pass_fold(entries), 'locations': []}
    removed_if, blocks_if = pass_iftrue(entries)
    stats['iftrue'] = {'changed': blocks_if, 'locations': removed_if}
    renames = []
    if style in ('method-clean', 'bootstrap-clean'):
        renames = pass_rename(entries, blocks)
    stats['rename'] = {'changed': len(renames), 'locations': renames}
    nil_n, nil_locs = pass_nil(entries)
    stats['nil'] = {'changed': nil_n, 'locations': nil_locs}
    (self_n, self_locs), (t_n, t_locs) = pass_junk(entries, blocks, style)
    stats['self_assign'] = {'changed': self_n, 'locations': self_locs}
    stats['unused_T'] = {'changed': t_n, 'locations': t_locs}
    dead_removed, dead_short = pass_dead2(entries, blocks)
    stats['dead'] = {'changed': len(dead_removed) + len(dead_short),
                     'locations': dead_removed,
                     'shortened': dead_short}

    out_lines = [e[1] for e in entries if e[1] is not None]
    removed = sorted(e[0] for e in entries if e[1] is None
                     and lines[e[0] - 1] != '')
    # entries whose original line was blank and stayed blank are not
    # "removed"; the check above excludes blank originals. Lines that
    # became None from a non-blank original are genuine removals.
    new_text = '\n'.join(out_lines)
    return new_text, stats, removed
