#!/usr/bin/env python3
"""check_v20_lift.py -- Part V-lift of the v6 regression: the v20.0
trace-verified lifter (tool v6.4.0).

Unlike check_v20.py (stages 1-4 fixture, no bundle, no source),
this fixture runs the v20 route WITH a trace bundle and pins
the covered-path lift:
  L1  exit 5 (PARTIAL-with-assumption, never 0) + route v20 +
      lifted.luau + lift_report.json + literal_equation.json
  L2  luau-compile exit 0 on lifted.luau
  L3  literal equation ok: no missing, no invented
  L4  the assumption text (read from the bundle) appears
      verbatim in all four places: lifted.luau header,
      qa_report.json, report.md, lift_report.json; verdict
      PARTIAL-with-assumption in qa + report, never bare FULL
  L5  determinism: a second run under a different PYTHONHASHSEED
      produces byte-identical lifted.luau + protos.json
  L6  no bundle-derived sensitive literal in lift.py (grep gate
      over bundle ints > 1000 and digest/sha/key strings)
  L7  negative control: the same run WITHOUT a bundle still
      exits 5 and emits no lifted.luau (check_v20 V4 shape)

Usage: check_v20_lift.py <tool-dir> <workdir> [sample] [bundle]
  Sample default: ~/luau-deobf/work/animedice-20261024/AnimeDice.lua
  Bundle default: ~/luau-deobf/work/animedice-20261024/stage6/
    lifter/bundle (env V20_LIFT_BUNDLE overrides).
Exit 0 = all checks pass, else 1 (prints FAIL lines).
"""
import hashlib
import json
import os
import re
import subprocess
import sys

FAIL = []


def check(name, ok, detail=''):
    print(('PASS ' if ok else 'FAIL ') + name
          + ('' if ok else f' -- {detail}'))
    if not ok:
        FAIL.append(name)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


def run(tool, sample, out, bundle=None, seed=None):
    env = dict(os.environ)
    if seed is not None:
        env['PYTHONHASHSEED'] = seed
    argv = [sys.executable, os.path.join(tool, 'luraph_v6.py'),
            sample, '-o', out]
    if bundle:
        argv += ['--v20-trace-bundle', bundle]
    return subprocess.run(argv, capture_output=True, text=True,
                          env=env, timeout=600)


def bundle_sensitive(bundle):
    vals = set()

    def walk(o):
        if isinstance(o, bool):
            return
        if isinstance(o, int):
            if abs(o) > 1000:
                vals.add(str(o))
        elif isinstance(o, str):
            if re.fullmatch(r'[0-9a-f]{32,}', o) \
                    or re.fullmatch(r'[0-9]+(:[0-9]+)+', o) \
                    or len(o) >= 32:
                vals.add(o)
        elif isinstance(o, dict):
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    for fn in os.listdir(bundle):
        p = os.path.join(bundle, fn)
        if fn.endswith('.json'):
            walk(json.load(open(p)))
        elif fn.endswith('.jsonl'):
            for line in open(p):
                if line.strip():
                    walk(json.loads(line))
    vals.discard('')
    return vals


def main():
    tool = sys.argv[1]
    work = sys.argv[2]
    sample = (sys.argv[3] if len(sys.argv) > 3 else os.environ.get(
        'V20_SAMPLE',
        '/home/hatch/luau-deobf/work/animedice-20261024/AnimeDice.lua'))
    bundle = (sys.argv[4] if len(sys.argv) > 4 else os.environ.get(
        'V20_LIFT_BUNDLE',
        '/home/hatch/luau-deobf/work/animedice-20261024/stage6/'
        'lifter/bundle'))
    os.makedirs(work, exist_ok=True)
    if not os.path.isfile(sample):
        print(f'v20-lift fixture sample not found: {sample}')
        return 2
    if not os.path.isdir(bundle):
        print(f'v20-lift fixture bundle not found: {bundle}')
        return 2
    merged = json.load(open(os.path.join(
        bundle, 'merged_entry_trace.json')))
    assumption = merged.get('assumption') or ''

    out = os.path.join(work, 'v20-lift-out')
    r = run(tool, sample, out, bundle=bundle, seed='1')
    lifted = os.path.join(out, 'lifted.luau')
    check('L1 exit 5 + route v20 + lift artifacts',
          r.returncode == 5
          and '[v6] route selected: v20' in r.stdout
          and os.path.isfile(lifted)
          and os.path.isfile(os.path.join(out, 'lift_report.json'))
          and os.path.isfile(os.path.join(
              out, 'literal_equation.json')),
          f'exit={r.returncode} tail={r.stdout[-200:]!r}')
    src = open(lifted).read() if os.path.isfile(lifted) else ''
    luau = os.path.join(tool, 'bin', 'luau-compile')
    cc = subprocess.run([luau, lifted], capture_output=True,
                        timeout=120) if src else None
    check('L2 luau-compile exit 0 on lifted.luau',
          cc is not None and cc.returncode == 0,
          f'exit={None if cc is None else cc.returncode}')
    eq = {}
    eqp = os.path.join(out, 'literal_equation.json')
    if os.path.isfile(eqp):
        eq = json.load(open(eqp))
    check('L3 literal equation ok (no missing, no invented)',
          eq.get('ok') is True
          and not eq.get('missing_numbers')
          and not eq.get('missing_strings')
          and not eq.get('invented_numbers')
          and not eq.get('invented_strings'),
          f'got {eq}')
    qa = {}
    qap = os.path.join(out, 'qa_report.json')
    if os.path.isfile(qap):
        qa = json.load(open(qap))
    rep = ''
    repp = os.path.join(out, 'report.md')
    if os.path.isfile(repp):
        rep = open(repp).read()
    lift_rep = {}
    lrp = os.path.join(out, 'lift_report.json')
    if os.path.isfile(lrp):
        lift_rep = json.load(open(lrp))
    check('L4 assumption verbatim in all four places + '
          'PARTIAL-with-assumption verdict',
          bool(assumption)
          and assumption in src
          and qa.get('assumption') == assumption
          and assumption in rep
          and lift_rep.get('assumption') == assumption
          and qa.get('verdict') == 'PARTIAL-with-assumption'
          and 'PARTIAL-with-assumption' in rep
          and 'PARTIAL-with-assumption' in src
          and lift_rep.get('verdict') == 'PARTIAL-with-assumption',
          f'qa_verdict={qa.get("verdict")} '
          f'lift_verdict={lift_rep.get("verdict")}')
    out2 = os.path.join(work, 'v20-lift-out-det')
    r2 = run(tool, sample, out2, bundle=bundle, seed='99')
    det = r2.returncode == 5 \
        and os.path.isfile(os.path.join(out2, 'lifted.luau')) \
        and sha256_file(os.path.join(out2, 'lifted.luau')) == \
        sha256_file(lifted) \
        and sha256_file(os.path.join(out2, 'protos.json')) == \
        sha256_file(os.path.join(out, 'protos.json'))
    check('L5 determinism across PYTHONHASHSEED', det,
          f'exit2={r2.returncode}')
    lift_py = os.path.join(tool, 'routes', 'v20', 'lift.py')
    code = open(lift_py).read() if os.path.isfile(lift_py) else ''
    sens = bundle_sensitive(bundle)
    hits = [v for v in sens if v and v in code]
    check('L6 no bundle sensitive literal in lift.py',
          not hits, f'hits={hits[:5]}')
    out3 = os.path.join(work, 'v20-lift-out-nobundle')
    r3 = run(tool, sample, out3, bundle=None, seed='1')
    check('L7 no-bundle control: exit 5, no lifted.luau',
          r3.returncode == 5
          and not os.path.isfile(os.path.join(out3, 'lifted.luau')),
          f'exit={r3.returncode}')
    print(f'v20-lift: {len(FAIL)} failures')
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
