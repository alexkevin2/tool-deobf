#!/usr/bin/env python3
"""check_outputs.py — verify a Luraph-Deobf-Tool-v6 BOOTSTRAP-route
run on the StealAnEggs regression sample against the golden numbers
(checks 1-9 inherited from Luraph-BootstrapVM-Deobf v2.0.0; checks
10-12 are the v6 clean-stage checks).

Usage: python3 check_outputs.py <outdir> <golden_dir> <tool_exit_code>

Checks (each prints PASS/FAIL; exit 0 iff all pass):
  1. tool exit code == 5 (PARTIAL — the expected verdict today)
  2. manifest.json verdict == PARTIAL and luau_compile_ok is true
  3. stage-1 bins byte-identical to the case's oracle-verified
     outputs (sha256 vs golden/stage1_sha256.json)
  4. root walk visited set == golden 304 (mode, pc) pairs
     (from proto_structs.json)
  5. static child census == golden 47 (table, key) pairs
     (cross-check artifact only — phantom-prone, see README)
  6. root constants summary == 794 materialized / 434 errors /
     1228 attempted (static access-order pass)
  7. [v2] executor child set == golden 20 real children
     (pid/kind/M/parent/table/key from children_recovered.json —
     the authoritative child set from the in-context sweep)
  8. [v2] executor accounting: 15 dz walked, 4 bz constant
     artifacts, 1 unrecovered (child18, proven phantom);
     referenced constants 164/434; full.luau = 796 instructions
     and manifest full_compile_ok is true
  9. [v2] bz slots == {child14: 41, child16: 41, child19: 41,
     child20: 67} (from proto_structs.json bz-constant records)

Golden history: checks 1-6 are the v1 goldens (unchanged values).
Checks 7-9 were added in v2.0.0 with the executor route; their
values are the case's Phase E final numbers (STAGEE-REPORT.md).
The v1 check "all censused descriptors marked blocked" was
REMOVED: the census is no longer the child truth source, so its
per-descriptor outcome labels are not a correctness gate anymore.
"""
import hashlib
import json
import os
import sys

outdir, golden, tool_exit = sys.argv[1], sys.argv[2], int(sys.argv[3])
fails = []


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] {name}"
          + (f' — {detail}' if detail else ''))
    if not cond:
        fails.append(name)


def jload(p, default=None):
    try:
        with open(p) as f:
            return json.load(f)
    except Exception:
        return default


check('tool exit code == 5 (PARTIAL)', tool_exit == 5, f'got {tool_exit}')

man = jload(os.path.join(outdir, 'manifest.json'), {}) or {}
check('manifest verdict == PARTIAL', man.get('verdict') == 'PARTIAL',
      f"got {man.get('verdict')}")
check('manifest luau_compile_ok', man.get('luau_compile_ok') is True)

golden_sha = jload(os.path.join(golden, 'stage1_sha256.json'), {})
for n in ('gsub', 'src', 'dst'):
    p = os.path.join(outdir, 'stage1', n + '.bin')
    got = None
    if os.path.isfile(p):
        got = hashlib.sha256(open(p, 'rb').read()).hexdigest()
    check(f'stage1 {n}.bin sha256 == golden', got == golden_sha.get(n),
          f'got {got}')

ps = jload(os.path.join(outdir, 'proto_structs.json'), {}) or {}
visited = sorted([i['mode'], i['pc']]
                 for i in ps.get('root', {}).get('instructions', []))
golden_visited = jload(os.path.join(golden, 'visited_set.json'), [])
check('root visited set == golden (304 pairs)',
      visited == golden_visited,
      f'got {len(visited)} pairs, golden {len(golden_visited)}')

cj = jload(os.path.join(outdir, 'children.json'), {}) or {}
census = sorted([c['table'], c['key']]
                for c in cj.get('child_descriptor_census', []))
golden_census = jload(os.path.join(golden, 'census_set.json'), [])
check('child census == golden (47 descriptors, cross-check)',
      census == golden_census,
      f'got {len(census)}, golden {len(golden_census)}')

cs = cj.get('root', {}).get('constants_summary', {})
check('root constants 794/434/1228',
      (cs.get('materialized'), cs.get('errors'), cs.get('attempted'))
      == (794, 434, 1228),
      f"got {cs.get('materialized')}/{cs.get('errors')}/"
      f"{cs.get('attempted')}")

# ---- v2: executor route (source of truth) ----
recs = jload(os.path.join(outdir, 'children_recovered.json'), []) or []
got_children = []
for r in recs:
    acc = r.get('access') or {}
    got_children.append({'pid': r['pid'], 'kind': r['kind'],
                         'M': r.get('descriptor_M'),
                         'parent': acc.get('proto'),
                         'table': acc.get('table'),
                         'key': acc.get('key')})
got_children.sort(key=lambda x: int(x['pid'][5:]))
golden_children = jload(os.path.join(golden, 'executor_children.json'),
                        [])
check('executor child set == golden (20 real children)',
      got_children == golden_children,
      f'got {len(got_children)}, golden {len(golden_children)}')

ex = man.get('executor', {}) or {}
check('executor dz walked == 15', ex.get('dz_walked') == 15,
      f"got {ex.get('dz_walked')}")
check('executor bz artifacts == 4',
      ex.get('bz_constant_artifacts') == 4,
      f"got {ex.get('bz_constant_artifacts')}")
check('executor unrecovered == 1 (child18 phantom)',
      ex.get('unrecovered') == 1, f"got {ex.get('unrecovered')}")
rc = ex.get('referenced_constants', {}) or {}
check('executor constants 164/434',
      (rc.get('resolved'), rc.get('total')) == (164, 434),
      f"got {rc.get('resolved')}/{rc.get('total')}")
check('full.luau instructions == 796',
      ex.get('full_instructions') == 796,
      f"got {ex.get('full_instructions')}")
check('manifest full_compile_ok', ex.get('full_compile_ok') is True)

bz = {pid: st.get('slot') for pid, st in ps.items()
      if isinstance(st, dict) and st.get('kind') == 'bz-constant'}
check('bz slots == golden {14:41, 16:41, 19:41, 20:67}',
      bz == {'child14': 41, 'child16': 41, 'child19': 41,
             'child20': 67},
      f'got {bz}')

# ---- v6: clean stage ----
CLEAN_SHA = 'd50a955d55b33e2bcf47e5dc4c99abb673e19b0756d632a7e8fb4b' \
            '4561197f47'
cp_ = os.path.join(outdir, 'full_clean.luau')
got_clean = None
if os.path.isfile(cp_):
    got_clean = hashlib.sha256(open(cp_, 'rb').read()).hexdigest()
check('full_clean.luau sha256 == case golden (byte-identical)',
      got_clean == CLEAN_SHA, f'got {got_clean}')
cmap = jload(os.path.join(outdir, 'clean_map.json'), {}) or {}
check('clean_map mapped/total == 796/796',
      (cmap.get('mapped'), cmap.get('total_instructions'))
      == (796, 796),
      f"got {cmap.get('mapped')}/{cmap.get('total_instructions')}")
cl = man.get('clean', {}) or {}
check('manifest clean.ok + clean.compile_ok',
      cl.get('ok') is True and cl.get('compile_ok') is True,
      f"got ok={cl.get('ok')} compile_ok={cl.get('compile_ok')}")

print('REGRESSION: ' + ('ALL CHECKS PASS' if not fails
                        else f'{len(fails)} CHECK(S) FAILED: {fails}'))
sys.exit(0 if not fails else 1)
