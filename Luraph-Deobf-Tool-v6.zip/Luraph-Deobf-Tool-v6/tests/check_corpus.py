#!/usr/bin/env python3
"""check_corpus.py — run the v6 CLI (AUTO route) over the method
corpus and verify exit codes + primary-output sha256 against
tests/golden/corpus_sha256.json (goldens generated from the
pristine Luraph-Deobf-Tool-v5 on 2026-10-23; see that file's
"about" note, incl. the two duplicate-content case pairs).

Usage: python3 check_corpus.py <v6_tool_dir> <work_root>
Env: CORPUS_<NAME> overrides per-entry input paths;
     LURAPH_UPSTREAM_DIR is passed through to the tool.
Exit 0 iff every entry passes.
"""
import hashlib
import json
import os
import subprocess
import sys

tool_dir, work_root = sys.argv[1], sys.argv[2]
golden_path = os.path.join(tool_dir, 'tests', 'golden',
                           'corpus_sha256.json')
with open(golden_path) as f:
    golden = json.load(f)

fails = []


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] corpus {name}"
          + (f' — {detail}' if detail else ''), flush=True)
    if not cond:
        fails.append(name)


os.makedirs(work_root, exist_ok=True)
for entry in golden['entries']:
    name = entry['name']
    inp = os.environ.get(entry['input_env']) or \
        entry.get('input_default') or \
        os.path.join(tool_dir, entry['input_default_in_package'])
    if not os.path.isfile(inp):
        check(name, False, f'input not found: {inp}')
        continue
    outdir = os.path.join(work_root, name)
    argv = [sys.executable, os.path.join(tool_dir, 'luraph_v6.py'),
            inp, '-o', outdir]
    print(f'--- corpus {name}: {inp} (expect route '
          f"{entry['route']}, exit {entry['exit']})", flush=True)
    p = subprocess.run(argv, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, text=True,
                       timeout=3600)
    tail = '\n'.join(p.stdout.splitlines()[-3:])
    check(f'{name} exit == {entry["exit"]}', p.returncode ==
          entry['exit'], f'got {p.returncode}; tail: {tail!r}')
    for rel, want in entry['files'].items():
        got = None
        fp = os.path.join(outdir, rel)
        if os.path.isfile(fp):
            got = sha(fp)
        check(f'{name} {rel} sha256 == v5 golden', got == want,
              f'got {got}')

print('CORPUS: ' + ('ALL CHECKS PASS (6/6 entries)' if not fails
                    else f'{len(fails)} CHECK(S) FAILED: {fails}'))
sys.exit(0 if not fails else 1)
