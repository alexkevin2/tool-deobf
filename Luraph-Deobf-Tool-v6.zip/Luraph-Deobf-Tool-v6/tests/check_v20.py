#!/usr/bin/env python3
"""check_v20.py — Part V of the v6 regression: the v20.0 route
(PARTIAL fixture, 2026-10-24).

The v20 route does not yet lift to source (stage 5 blocker), so
this fixture pins the PROVEN stages instead of a cleaned output:
  V1  auto-routing selects v20 (not method/upstream) and exits 5
  V2  pool framing closes exactly (741 / 1218153 / 1219515) and
      pool.bin is byte-identical to the Phase-1 baseline artifact
  V3  stage 3/4 metrics in protos.json: entry proto 87 constants,
      22 protos visited, 0 errors, 111 printable strings
  V4  no source file is emitted and no upstream fragment exists
      (the v6.2.0 misroute shape must never recur)
  V5  determinism: a second run under a different PYTHONHASHSEED
      produces a byte-identical protos.json
  V6  negative controls: the v20 fingerprint is False on every
      v15.x golden + buffer golden + bootstrap sample (routed
      correctly by the full regression, checked here at the
      fingerprint level only)

Usage: check_v20.py <tool-dir> <workdir> [sample]
  Sample default: ~/luau-deobf/work/animedice-20261024/AnimeDice.lua
  (env V20_SAMPLE overrides).  Baseline pool.bin default:
  ~/luau-deobf/work/animedice-20261024/baseline-v620/pool.bin
  (env V20_BASELINE_POOL overrides).
Exit 0 = all checks pass, else 1 (prints FAIL lines).
"""
import hashlib
import json
import os
import subprocess
import sys

FAIL = []


def check(name, ok, detail=''):
    print(('PASS ' if ok else 'FAIL ') + name
          + ('' if ok else f' -- {detail}'))
    if not ok:
        FAIL.append(name)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


def run(tool, sample, out, seed=None):
    env = dict(os.environ)
    if seed is not None:
        env['PYTHONHASHSEED'] = seed
    r = subprocess.run([sys.executable,
                        os.path.join(tool, 'luraph_v6.py'),
                        sample, '-o', out],
                       capture_output=True, text=True, env=env,
                       timeout=600)
    return r


def main():
    tool = sys.argv[1]
    work = sys.argv[2]
    sample = (sys.argv[3] if len(sys.argv) > 3 else os.environ.get(
        'V20_SAMPLE',
        '/home/hatch/luau-deobf/work/animedice-20261024/AnimeDice.lua'))
    baseline_pool = os.environ.get(
        'V20_BASELINE_POOL',
        '/home/hatch/luau-deobf/work/animedice-20261024/'
        'baseline-v620/pool.bin')
    os.makedirs(work, exist_ok=True)
    if not os.path.isfile(sample):
        print(f'v20 fixture sample not found: {sample}')
        return 2
    out = os.path.join(work, 'v20-out')
    r = run(tool, sample, out, seed='1')
    check('V1 route v20 + exit 5',
          r.returncode == 5 and '[v6] route selected: v20' in r.stdout,
          f'exit={r.returncode} tail={r.stdout[-200:]!r}')
    pool_stats = {}
    if os.path.isfile(os.path.join(out, 'pool_stats.json')):
        pool_stats = json.load(open(os.path.join(out, 'pool_stats.json')))
    check('V2 pool framing 741/1218153/1219515',
          pool_stats == {'xO': 741, 'BL': 1218153,
                         'sum_len': 1218153, 'decoded_len': 1219515},
          f'got {pool_stats}')
    pool_ok = os.path.isfile(os.path.join(out, 'pool.bin')) \
        and os.path.isfile(baseline_pool) \
        and sha256_file(os.path.join(out, 'pool.bin')) == \
        sha256_file(baseline_pool)
    check('V2 pool.bin byte-identical to Phase-1 baseline', pool_ok)
    protos = {}
    if os.path.isfile(os.path.join(out, 'protos.json')):
        protos = json.load(open(os.path.join(out, 'protos.json')))
    check('V3 entry 87 constants / 22 protos / 0 errors / 111 strings',
          protos.get('entry_constants') == 87
          and protos.get('protos_visited') == 22
          and protos.get('errors') == 0
          and (protos.get('totals') or {}).get('string_printable') == 111,
          f"got entry={protos.get('entry_constants')} "
          f"protos={protos.get('protos_visited')} "
          f"errors={protos.get('errors')} "
          f"totals={protos.get('totals')}")
    check('V4 no source file, no upstream fragment',
          not os.path.isfile(os.path.join(out, 'deobfuscated_upstream.lua'))
          and not os.path.isfile(os.path.join(
              out, 'deobfuscated_upstream_REJECTED.lua'))
          and not os.path.isfile(os.path.join(out, 'lifted.luau'))
          and not os.path.isfile(os.path.join(out, 'cleaned.luau')))
    out2 = os.path.join(work, 'v20-out-det')
    r2 = run(tool, sample, out2, seed='99')
    det = r2.returncode == 5 \
        and os.path.isfile(os.path.join(out2, 'protos.json')) \
        and sha256_file(os.path.join(out2, 'protos.json')) == \
        sha256_file(os.path.join(out, 'protos.json'))
    check('V5 determinism across PYTHONHASHSEED', det,
          f'exit2={r2.returncode}')
    # V6: fingerprint negatives (import only, no runs).
    sys.path.insert(0, os.path.join(tool, 'routes', 'v20'))
    try:
        import fingerprint as fp
        negs = {
            'v151': os.path.join(tool, 'sample', 'method',
                                 'input_v151.lua'),
            'bf_tester': os.environ.get(
                'CORPUS_BF',
                '/home/hatch/luau-deobf/work/bf-tester-20261022-180054/'
                'muse-luau/input/BF-Tester.luau'),
            'buffer': os.environ.get(
                'CORPUS_PAYLOAD',
                '/home/hatch/luau-deobf/work/luraph-payload-20261021-165455/'
                'muse-luau/input/luraph_payload.lua'),
            'steal': os.environ.get(
                'BVM_SAMPLE_RAW',
                '/home/hatch/luau-deobf/work/stealaneggs/'
                'stealaneggs_raw.luau'),
        }
        for name, path in negs.items():
            if not os.path.isfile(path):
                print(f'V6 skip {name}: file not found')
                continue
            ok, _ev = fp.detect_v20(open(path, encoding='utf-8').read())
            check(f'V6 fingerprint False on {name}', not ok)
        ok, _ev = fp.detect_v20(open(sample, encoding='utf-8').read())
        check('V6 fingerprint True on AnimeDice', ok)
    finally:
        sys.path.remove(os.path.join(tool, 'routes', 'v20'))
    print('V20 FIXTURE ' + ('PASS' if not FAIL else f'FAIL {FAIL}'))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
