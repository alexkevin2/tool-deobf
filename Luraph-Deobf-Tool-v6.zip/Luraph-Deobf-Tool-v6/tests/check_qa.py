#!/usr/bin/env python3
"""check_qa.py — Part Q of the v6 regression: the v6.2.0 QA upgrade.

Checks (exit 0 iff all pass):
  Q1  vendored qa_clean.py / qa_report.py copies are byte-identical
      to the tool-root canonical copies (same discipline as the
      spoof-engine S1 check).
  Q2  --qa-clean off restores exact v6.1.0 bytes: method cleaned.luau
      == 6feebab4… and buffer lifted.luau == 13023dfe… (the v6.1.0
      goldens), while qa_report.json is still emitted with
      qa_clean.enabled == false.
  Q3  --qa-clean on (default) method run: cleaned.luau sha == the
      v6.2.0 golden, qa passes nil==4 / self_assign==1 / unused_T==4 /
      rename==2 / dead==0, clean_map names root.0.0:8 == r8 and
      root:2 == r2, totals unchanged (1/1/35), literal multiset
      preserved, luau-compile true; lifted.luau and
      identity_report.json still == their v6.1.0 goldens.
  Q4  --qa-clean on buffer run: lifted.luau sha == the v6.2.0 golden,
      qa passes nil==172 / dead==22 / fold==0, qa_report descriptor
      sites == 54, kernel protos == 22, and the report.md QA section
      is present.
  Q5  no hardcoded game IDs in production code: qa_clean.py and
      qa_report.py (all copies) contain no 10-digit PlaceId-like
      literal (the S2 rule, applied to the new modules).

Usage: python3 check_qa.py <v6_tool_dir> <work_root>
Env: CORPUS_JJS / CORPUS_PAYLOAD override the two inputs (same
convention as check_corpus.py).
"""
import hashlib
import json
import os
import re
import subprocess
import sys

tool_dir, work_root = sys.argv[1], sys.argv[2]
fails = []


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] qa {name}"
          + (f' — {detail}' if detail else ''), flush=True)
    if not cond:
        fails.append(name)


os.makedirs(work_root, exist_ok=True)
luau_compile = os.path.join(tool_dir, 'bin', 'luau-compile')


def compiles(path):
    return subprocess.run([luau_compile, path],
                          stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL).returncode == 0


# ---------------------------------------------------------------- Q1
for mod in ('qa_clean.py', 'qa_report.py'):
    root = open(os.path.join(tool_dir, mod), 'rb').read()
    for copy in (os.path.join(tool_dir, 'routes', 'method', mod),
                 os.path.join(tool_dir, 'routes', 'bootstrap',
                              'modules', 'stageE', mod)):
        check(f'Q1 {mod} vendored copy identical: {copy}',
              os.path.isfile(copy)
              and open(copy, 'rb').read() == root)

# ---------------------------------------------------------------- inputs
jjs = os.environ.get('CORPUS_JJS') or os.path.join(
    tool_dir, 'sample', 'method', 'input_v151.lua')
buf = os.environ.get('CORPUS_PAYLOAD') or os.path.join(
    '/home/hatch/luau-deobf/work/luraph-payload-20261021-165455',
    'muse-luau', 'input', 'luraph_payload.lua')
GOLDEN_CLEAN_V61 = '6feebab4b76835419bc4a817018c303a73dab6d9b41eed0933dc23e316c0c60a'
GOLDEN_CLEAN_V62 = '5fdafc866d3c95f3886e831cc3d267acba08d34cb1664038c076280ae53708d8'
GOLDEN_LIFT_V61 = '13023dfe4a67c6fc0f4395a9cebfc78e38af2a07965f40931243d9958be74edf'
GOLDEN_LIFT_V62 = 'ed9b8ba3d92340f7ae2e18c6929116544da54211f0221dfd570645639acdef8d'
GOLDEN_JJS_LIFTED = 'd0b89ff26e1496ba63d8249f242848498873d08cba7d0956a927e2bde53597d1'
GOLDEN_JJS_IDREP = '155b89f2f263682c58507906aeeeb951f3dcf2ae01a6344e12dbce892d256c5a'


def run(inp, out, extra=()):
    p = subprocess.run([sys.executable, os.path.join(tool_dir, 'luraph_v6.py'),
                        inp, '-o', out, *extra],
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=1800)
    return p


# ---------------------------------------------------------------- Q2 (off)
out_off = os.path.join(work_root, 'jjs-off')
p = run(jjs, out_off, ('--qa-clean', 'off'))
check('Q2 jjs --qa-clean off exit 0', p.returncode == 0,
      f'got {p.returncode}')
check('Q2 jjs off cleaned == v6.1.0 golden',
      os.path.isfile(os.path.join(out_off, 'cleaned.luau'))
      and sha(os.path.join(out_off, 'cleaned.luau')) == GOLDEN_CLEAN_V61)
q = json.load(open(os.path.join(out_off, 'qa_report.json'))) \
    if os.path.isfile(os.path.join(out_off, 'qa_report.json')) else {}
check('Q2 jjs off qa_report emitted, qa_clean disabled',
      q.get('qa_clean', {}).get('enabled') is False)
out_boff = os.path.join(work_root, 'buffer-off')
p = run(buf, out_boff, ('--qa-clean', 'off'))
check('Q2 buffer --qa-clean off exit 5', p.returncode == 5,
      f'got {p.returncode}')
check('Q2 buffer off lifted == v6.1.0 golden',
      os.path.isfile(os.path.join(out_boff, 'lifted.luau'))
      and sha(os.path.join(out_boff, 'lifted.luau')) == GOLDEN_LIFT_V61)

# ---------------------------------------------------------------- Q3 (on, method)
out_on = os.path.join(work_root, 'jjs-on')
p = run(jjs, out_on)
check('Q3 jjs on exit 0', p.returncode == 0, f'got {p.returncode}')
check('Q3 jjs on cleaned == v6.2.0 golden',
      os.path.isfile(os.path.join(out_on, 'cleaned.luau'))
      and sha(os.path.join(out_on, 'cleaned.luau')) == GOLDEN_CLEAN_V62)
check('Q3 jjs on cleaned compiles',
      os.path.isfile(os.path.join(out_on, 'cleaned.luau'))
      and compiles(os.path.join(out_on, 'cleaned.luau')))
check('Q3 jjs on lifted == v6.1.0 golden (never modified)',
      os.path.isfile(os.path.join(out_on, 'lifted.luau'))
      and sha(os.path.join(out_on, 'lifted.luau')) == GOLDEN_JJS_LIFTED)
check('Q3 jjs on identity_report == golden (unchanged)',
      os.path.isfile(os.path.join(out_on, 'identity_report.json'))
      and sha(os.path.join(out_on, 'identity_report.json')) == GOLDEN_JJS_IDREP)
q = json.load(open(os.path.join(out_on, 'qa_report.json'))) \
    if os.path.isfile(os.path.join(out_on, 'qa_report.json')) else {}
passes = q.get('qa_clean', {}).get('passes', {})
check('Q3 qa passes nil/self/T/rename/dead == 4/1/4/2/0',
      (passes.get('nil', {}).get('changed'),
       passes.get('self_assign', {}).get('changed'),
       passes.get('unused_T', {}).get('changed'),
       passes.get('rename', {}).get('changed'),
       passes.get('dead', {}).get('changed')) == (4, 1, 4, 2, 0),
      json.dumps({k: v.get('changed') for k, v in passes.items()}))
cmap = json.load(open(os.path.join(out_on, 'clean_map.json'))) \
    if os.path.isfile(os.path.join(out_on, 'clean_map.json')) else {}
check('Q3 clean_map names r8/r2 patched, totals unchanged',
      cmap.get('protos', {}).get('root.0.0', {}).get('names', {}).get('8')
      == ['r8', 'neutral']
      and cmap.get('protos', {}).get('root', {}).get('names', {}).get('2')
      == ['r2', 'neutral']
      and cmap.get('totals') == {'protos': 5, 'promoted': 4, 'skipped': 1,
                                 'names_confirmed': 1, 'names_inferred': 1,
                                 'names_neutral': 35}
      and cmap.get('literal_multiset_equal') is True
      and cmap.get('luau_compile') is True,
      json.dumps(cmap.get('totals')))

# ---------------------------------------------------------------- Q4 (on, buffer)
out_bon = os.path.join(work_root, 'buffer-on')
p = run(buf, out_bon)
check('Q4 buffer on exit 5', p.returncode == 5, f'got {p.returncode}')
check('Q4 buffer on lifted == v6.2.0 golden',
      os.path.isfile(os.path.join(out_bon, 'lifted.luau'))
      and sha(os.path.join(out_bon, 'lifted.luau')) == GOLDEN_LIFT_V62)
check('Q4 buffer on lifted compiles',
      os.path.isfile(os.path.join(out_bon, 'lifted.luau'))
      and compiles(os.path.join(out_bon, 'lifted.luau')))
q = json.load(open(os.path.join(out_bon, 'qa_report.json'))) \
    if os.path.isfile(os.path.join(out_bon, 'qa_report.json')) else {}
passes = q.get('qa_clean', {}).get('passes', {})
check('Q4 qa passes nil/dead/fold == 172/22/0',
      (passes.get('nil', {}).get('changed'),
       passes.get('dead', {}).get('changed'),
       passes.get('fold', {}).get('changed')) == (172, 22, 0),
      json.dumps({k: v.get('changed') for k, v in passes.items()}))
check('Q4 qa descriptor sites == 54, kernel protos == 22',
      q.get('files', {}).get('lifted.luau', {}).get('counts_after', {})
      .get('descriptor') == 54
      and len(q.get('unstructured', {}).get('kernel_protos', [])) == 22,
      json.dumps(q.get('unstructured', {}))[:200])
rep = open(os.path.join(out_bon, 'report.md'), encoding='utf-8').read() \
    if os.path.isfile(os.path.join(out_bon, 'report.md')) else ''
check('Q4 report.md QA section present', '## QA self-check' in rep)

# ---------------------------------------------------------------- Q5
for mod in ('qa_clean.py', 'qa_report.py'):
    for base in (tool_dir,
                 os.path.join(tool_dir, 'routes', 'method'),
                 os.path.join(tool_dir, 'routes', 'bootstrap',
                              'modules', 'stageE')):
        path = os.path.join(base, mod)
        txt = open(path, encoding='utf-8', errors='replace').read() \
            if os.path.isfile(path) else ''
        hits = re.findall(r'\b\d{10}\b', txt)
        check(f'Q5 no 10-digit game-ID literal in {path}', not hits,
              f'found {hits[:3]}')

print('QA CHECKS: ' + ('ALL PASS' if not fails
                        else f'{len(fails)} CHECK(S) FAILED: {fails}'))
sys.exit(0 if not fails else 1)
