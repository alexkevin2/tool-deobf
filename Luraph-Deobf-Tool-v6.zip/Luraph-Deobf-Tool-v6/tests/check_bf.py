#!/usr/bin/env python3
"""check_bf.py -- Part BF of the v6 regression: the buffer-bf
route (tool v6.6.0).

Checks (spec section 6):
  BF1 routing + exit: BF-Main via AUTO routing -> method at v6
      level, then the buffer-bf stage at method level; exit 5;
      stdout contains `verdict: PARTIAL`; v6 print line reads
      `buffer variant: True`; `v20 fingerprint: False`.
      Direct luraph151.py invocation gives the same exit/stage.
  BF2 artifact metrics vs proof: bf_protos.json protos equal
      the fixture metrics (13 protos, per-proto entry/nconsts/
      S/r/p/T lengths, proto 12 body null, proto 45 T=789 vs
      X-factory-786 flagged); total S 15683; main S>=80 5738;
      all-proto S>=80 8238; op17 total 80 (main 39);
      bf_annotated.luau luau-compile exit 0; qa_report.json
      verdict PARTIAL with hub_strings_recovered false,
      structured_lift false and the full gap list present.
  BF3 literal spot checks (no entry-count golden until the
      count delta is reconciled): main _/X complete-key
      presence (10146 each, contiguous 1..10146); main g 371 /
      f 2300 harvested with hangs g372/f2301 listed in
      qa_report, not present as values; sub-proto per-pool
      counts per the section-3 table; distinct strings 231
      with sole hub-pattern hit HttpService; non-ASCII
      distinct values exactly 2; _721 rendered as
      entry-10110 self-reference, never as a named function
      (and the harvest-log address string never appears in
      the annotated file).
  BF4 determinism across PYTHONHASHSEED: runs with seed 0
      and 12345 produce byte-identical bf_protos.json,
      bf_annotated.luau, qa_report.json.
  BF5 no-sample-literals grep over route CODE (data/ files
      are data, not code, and are excluded): no harvested
      string of length >= 12, no keystream word, and no
      8-consecutive-int proto array fragment appears in
      routes/buffer_bf/*.py or routes/method/luraph151.py.
      (The proven-input sha gate string is an input
      identifier, not harvested content, and is excluded by
      construction: the grep targets harvested strings,
      keystream words and array fragments only.)
  BF6 old goldens green (unit level; the full Parts A-E/Q/V/
      V-lift/C still run in run_regression.sh): buffer_body.py
      and buffer_lifter.py byte-identical to the v6.4.0
      baseline; buffer_route() function text byte-identical;
      is_buffer_variant(steal) == False; old buffer golden
      still True; bf-tester True but harmless (upstream-first).
  BF7 grammar-failure fail-close: a synthetic headered file
      with buffer evidence but no body/descriptor (static
      evidence alone) exits 2 via runner-capture failure with
      a REJECTED report.md and NO lifted file and NO PARTIAL
      qa_report; a corrupted synthetic body (bad header
      varint, trailer desync) is rejected by the grammar
      parser.
  BF9 runner capture (v6.6.0): a grammar-valid unseen
      synthetic control routes to buffer-bf and exits 5 with
      artifacts derived from its captured body (proto arrays
      equal to the body the control wrote), determinism
      across two runs, and no invented literals.
  BF10 harvest isolation (v6.6.0): chunked harvest with
      binary-split isolation recovers every non-hang key and
      isolates exactly the planted hang keys.
  BF11 op-leaf trace (v6.6.0): trace parsing gives per-mode
      coverage and loop-A decrypt seeds from each event's own
      M/q via the formula module.
  BF8 no forbidden imports / no old-route mutation / no case
      mutation: no import of buffer_body or buffer_lifter in
      the new stage; old files byte-identical (see BF6); the
      BF-Main case input sha is unchanged after the runs.

Plus unit checks U1-U4: VM varint (worked example +
round-trips), grammar round-trip + corruption rejection,
fill-transform properties + decrypt-region involution, and
loop/pool table constants vs fixture key counts.

Usage: check_bf.py <tool-dir> <workdir> [bf-sample]
    [steal-sample] [old-buffer-sample] [bf-tester-sample]
Exit 0 = all checks pass, else 1 (prints FAIL lines).
"""

import ast
import hashlib
import json
import os
import re
import subprocess
import sys

FAIL = []

BF_MAIN_SHA = ('f0e390463cff5025002311d475b643ded9497eb5b4e70b3d09e8bd4bc4de702c')
BUFFER_BODY_SHA = ('153dbb489542cf3377884c42ba8f86c08d6fbe28e0cc191badeaefd154575cc4')
BUFFER_LIFTER_SHA = ('08e22d3e03bbe0e9917d9b24405db0af7c91ba9ac35d78afd3bab46b1133a205')
BUFFER_ROUTE_SHA = ('f732fb557095e325341badfbc5e01d8034a0aec4473972aa6aa168e10d561188')

EXPECTED_PROTOS = [
    (0, 10110, 180, 'buf4', 10147, 10145, 10146, 10146),
    (1, 44, 33, 'buf23', 92, 94, 92, 95),
    (2, 49, 40, 'buf25', 143, 143, 144, 144),
    (3, 492, 26, 'buf27', 2117, 2117, 2113, 2116),
    (4, 402, 44, 'buf29', 733, 733, 733, 735),
    (5, 28, 14, 'buf36', 64, 66, 65, 63),
    (6, 4, 10, 'buf38', 34, 35, 34, 34),
    (7, 12, 14, 'buf40', 202, 202, 200, 201),
    (8, 152, 18, 'buf42', 248, 251, 250, 251),
    (9, 128, 31, 'buf44', 246, 244, 245, 245),
    (10, 3, 34, 'buf46', 53, 53, 56, 56),
    (11, 45, 47, 'buf64', 786, 785, 786, 789),
    (12, 6, 44, None, 818, 818, 816, 816),
]

# Per-proto harvested counts (pool order _, g, f, X) per the
# section-3 harvest table. X total for proto 45 is 789 (T
# length); harvested X is the factory count 786.
EXPECTED_HARVEST = {
    10110: (10146, 371, 2300, 10146),
    44: (92, 94, 92, 95),
    49: (144, 143, 143, 144),
    492: (2113, 692, 2117, 2116),
    402: (733, 731, 732, 735),
    28: (65, 66, 64, 63),
    4: (34, 35, 34, 34),
    12: (200, 202, 202, 201),
    152: (250, 251, 248, 251),
    128: (245, 244, 246, 245),
    3: (56, 53, 53, 56),
    45: (785, 56, 785, 786),
    6: (816, 818, 373, 419),
}

EXPECTED_GAPS = {
    'buf3_section_grammar', 'proto12_body', 'proto45_x_discrepancy',
    'nested_f319_and_unresolved_f', 'mq_seeds_live_coverage',
    'sub_proto_completion', 'structured_lift',
    'section_suffix_header_trailer_semantics',
    'sub_proto_table_constants', 'function_constant_mapping',
    'count_delta_str_entries', 'hub_strings',
    'loop_d_live_verification',
}

HUB_PATTERN = re.compile(
    r'http|discord|github|raw\.|\.com|\.gg|\.dev|webhook|api', re.I)


def check(name, ok, detail=''):
    print(('PASS ' if ok else 'FAIL ') + name
          + ('' if ok else f' -- {detail}'))
    if not ok:
        FAIL.append(name)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


def run(argv, seed=None):
    env = dict(os.environ)
    if seed is not None:
        env['PYTHONHASHSEED'] = seed
    return subprocess.run(argv, capture_output=True, text=True,
                          env=env, timeout=900)


def load_json(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    tool = os.path.abspath(sys.argv[1])
    work = os.path.abspath(sys.argv[2])
    bf = sys.argv[3] if len(sys.argv) > 3 else (
        os.path.expanduser('~/luau-deobf/work/bf-main-20261024-222521/'
                           'muse-luau/input/BF-Main.luau'))
    steal = sys.argv[4] if len(sys.argv) > 4 else (
        os.path.expanduser('~/luau-deobf/work/stealaneggs/'
                           'stealaneggs_raw.luau'))
    oldbuf = sys.argv[5] if len(sys.argv) > 5 else (
        os.path.expanduser('~/luau-deobf/work/luraph-payload-20261021-'
                           '165455/muse-luau/input/luraph_payload.lua'))
    bftester = sys.argv[6] if len(sys.argv) > 6 else (
        os.path.expanduser('~/luau-deobf/work/bf-tester-20261022-180054/'
                           'muse-luau/input/BF-Tester.luau'))
    os.makedirs(work, exist_ok=True)
    for p, label in ((bf, 'BF-Main'), (steal, 'StealAnEggs'),
                     (oldbuf, 'old-buffer golden'),
                     (bftester, 'bf-tester')):
        if not os.path.isfile(p):
            print(f'FAIL setup: {label} sample missing: {p}')
            return 1
    bf_sha_before = sha256_file(bf)
    check('setup BF-Main input sha matches proven input',
          bf_sha_before == BF_MAIN_SHA, bf_sha_before[:16])

    # ---- import tool modules for unit checks ----
    routes_dir = os.path.join(tool, 'routes')
    method_dir = os.path.join(routes_dir, 'method')
    sys.path.insert(0, routes_dir)
    sys.path.insert(0, method_dir)
    import buffer_bf.varint as varint_mod
    import buffer_bf.grammar as grammar_mod
    import buffer_bf.tables as tables_mod
    import buffer_bf.formulas as formulas_mod
    import buffer_bf.runner as runner_mod
    import luraph151 as m151

    # ---- U1: VM varint ----
    try:
        v, nxt = varint_mod.decode_varint(
            bytes([215, 222, 171, 146]), 0)
        ok_u1 = (v, nxt) == (306899934, 4)
        for val in (0, 1, 127, 128, 16383, 16384, 2097151,
                    2097152, 306899934, 1 << 28):
            enc = varint_mod.encode_varint(val)
            dec, nxt = varint_mod.decode_varint(enc, 0)
            if dec != val or nxt != len(enc):
                ok_u1 = False
        check('U1 VM varint worked example + round-trips', ok_u1)
    except Exception as e:
        check('U1 VM varint worked example + round-trips', False, repr(e))

    # ---- U2: grammar round-trip + corruption rejection ----
    try:
        sections = {'p': [0, 127, 128, 306899934, 5],
                    'r': [1, 2, 3], 'S': [80, 17, 0, 999999],
                    'T': [7, 8]}
        body = grammar_mod.build_bf_body(
            9, 2466785157, 1794036372, sections, 10110,
            trailer=b'\x02\xb1\xa6\x03\x9d')
        parsed = grammar_mod.parse_bf_body(
            body, {'p': 5, 'r': 3, 'S': 4, 'T': 2}, 5)
        ok_u2 = (parsed['sections'] == sections
                 and parsed['entry_pc'] == 10110
                 and parsed['nconsts'] == 9)
        bad = bytearray(body)
        bad[0] = 3  # header first varint != 2
        try:
            grammar_mod.parse_bf_body(
                bytes(bad), {'p': 5, 'r': 3, 'S': 4, 'T': 2}, 5)
            ok_u2 = False
        except grammar_mod.BFBodyError:
            pass
        try:
            grammar_mod.parse_bf_body(
                body, {'p': 5, 'r': 3, 'S': 4, 'T': 2}, 4)
            ok_u2 = False
        except grammar_mod.BFBodyError:
            pass
        check('U2 grammar round-trip + corruption rejection', ok_u2)
    except Exception as e:
        check('U2 grammar round-trip + corruption rejection',
              False, repr(e))

    # ---- U3: fill transform + decrypt involution + mixes ----
    try:
        fill = load_json(os.path.join(tool, 'routes', 'buffer_bf',
                                      'data', 'fill_keystream.json'))
        K = fill['keystream30']
        ok_u3 = len(K) == 64
        for w in (0, 3, 4, 0xFFFFFFFF, 123456789, 1 << 30):
            for k in (K[0], K[63]):
                fw = formulas_mod.fill_word(w, k)
                if fw & 3 != w & 3:
                    ok_u3 = False
                back = ((((fw >> 2) ^ (k & 0x3FFFFFFF)) << 2)
                        | (fw & 3)) & 0xFFFFFFFF
                if back != w:
                    ok_u3 = False
        buf = bytearray(b'hello world, this is a test buffer!')
        orig = bytes(buf)
        formulas_mod.decrypt_region(buf, 5, 20, 99)
        if bytes(buf) == orig:
            ok_u3 = False
        formulas_mod.decrypt_region(buf, 5, 20, 99)
        if bytes(buf) != orig:
            ok_u3 = False
        if formulas_mod.mix29(0, 0) != 0 \
                or formulas_mod.hash_chain_step(0) != 0:
            ok_u3 = False
        check('U3 fill transform + decrypt involution + mixes',
              ok_u3)
    except Exception as e:
        check('U3 fill transform + decrypt involution + mixes',
              False, repr(e))

    # ---- U4: loop/pool tables vs fixtures ----
    try:
        ok_u4 = (len(tables_mod.LOOP_A_OPS) == 80
                 and tables_mod.LOOP_A_OPS[15] == 'handler-load'
                 and tables_mod.LOOP_A_OPS[16] == 'decrypt'
                 and tables_mod.LOOP_A_OPS[61] == 'load-imm'
                 and tables_mod.LOOP_A_OPS[17] == 'PHASE-SWITCH'
                 and tables_mod.loop_a_op(80) == 'INDEX'
                 and tables_mod.loop_a_op(79) == 'mul-imm'
                 and tables_mod.POOL_ENTRY_STATE == 164
                 and tables_mod.POOL_DEFAULT_STATE == 54
                 and tables_mod.POOL_CACHE_WRITE_STATE == 59
                 and tables_mod.POOL_CACHE_RETURN_STATE == 110)
        for name, want in (('pool_states.json', 181),
                           ('loop2_states.json', 91),
                           ('loop81_states.json', 159),
                           ('loop131_states.json', 74)):
            got = load_json(os.path.join(
                tool, 'routes', 'buffer_bf', 'data', name))
            if len(got) != want:
                ok_u4 = False
        check('U4 loop/pool tables + fixture key counts', ok_u4)
    except Exception as e:
        check('U4 loop/pool tables + fixture key counts', False,
              repr(e))

    # ---- BF6 (unit part): predicate + old-route bytes ----
    try:
        bf_src = open(bf, encoding='utf-8').read()
        steal_src = open(steal, encoding='utf-8').read()
        old_src = open(oldbuf, encoding='utf-8').read()
        tester_src = open(bftester, encoding='utf-8').read()
        check('BF6 is_buffer_variant(steal) == False',
              m151.is_buffer_variant(steal_src) is False)
        check('BF6 is_buffer_variant(old buffer golden) == True',
              m151.is_buffer_variant(old_src) is True)
        check('BF6 is_buffer_variant(BF-Main) == True',
              m151.is_buffer_variant(bf_src) is True)
        check('BF6 is_buffer_variant(bf-tester) == True '
              '(expected, harmless: upstream-first)',
              m151.is_buffer_variant(tester_src) is True)
        check('BF6 buffer_body.py byte-identical to v6.4.0',
              sha256_file(os.path.join(method_dir,
                                       'buffer_body.py'))
              == BUFFER_BODY_SHA)
        check('BF6 buffer_lifter.py byte-identical to v6.4.0',
              sha256_file(os.path.join(method_dir,
                                       'buffer_lifter.py'))
              == BUFFER_LIFTER_SHA)
        src151 = open(os.path.join(method_dir, 'luraph151.py'),
                      encoding='utf-8').read()
        tree = ast.parse(src151)
        lines = src151.splitlines(keepends=True)
        route_txt = None
        for n in tree.body:
            if isinstance(n, ast.FunctionDef) \
                    and n.name == 'buffer_route':
                route_txt = ''.join(
                    lines[n.lineno - 1:n.end_lineno])
        route_sha = hashlib.sha256(
            route_txt.encode()).hexdigest() if route_txt else None
        check('BF6 buffer_route() function byte-identical',
              route_sha == BUFFER_ROUTE_SHA, str(route_sha))
    except Exception as e:
        check('BF6 predicate + old-route bytes', False, repr(e))

    # ---- BF1: auto routing + direct routing ----
    out_auto = os.path.join(work, 'out-auto')
    r = run([sys.executable, os.path.join(tool, 'luraph_v6.py'),
             bf, '-o', out_auto])
    out = r.stdout + r.stderr
    check('BF1 auto route exit 5', r.returncode == 5,
          f'exit={r.returncode}')
    check('BF1 auto stdout verdict: PARTIAL',
          'verdict: PARTIAL' in out)
    check('BF1 auto route selected: method',
          'route selected: method' in out)
    check('BF1 auto buffer variant: True',
          'buffer variant: True' in out)
    check('BF1 auto v20 fingerprint: False',
          'v20 fingerprint: False' in out)
    check('BF1 auto no cleaned.luau',
          not os.path.isfile(os.path.join(out_auto, 'cleaned.luau')))
    out_direct = os.path.join(work, 'out-direct')
    r2 = run([sys.executable, os.path.join(method_dir, 'luraph151.py'),
              bf, '-o', out_direct, '--luau',
              os.path.join(tool, 'bin', 'luau')])
    out2 = r2.stdout + r2.stderr
    check('BF1 direct route exit 5', r2.returncode == 5,
          f'exit={r2.returncode}')
    check('BF1 direct route buffer-bf stage',
          'buffer-bf route' in out2 and 'verdict: PARTIAL' in out2)

    # ---- BF2: artifact metrics vs proof ----
    try:
        bfp = load_json(os.path.join(out_auto, 'bf_protos.json'))
        protos = bfp['protos']
        ok_bf2 = len(protos) == 13
        for (idx, entry, nconsts, body, ns, nr, np_, nt) \
                in EXPECTED_PROTOS:
            p = protos[idx]
            if (p['index'], p['entry'], p['nconsts'], p['body'],
                    len(p['S']), len(p['r']), len(p['p']),
                    len(p['T'])) != (idx, entry, nconsts, body,
                                     ns, nr, np_, nt):
                ok_bf2 = False
        total_s = sum(len(p['S']) for p in protos)
        s_ge80 = sum(1 for p in protos for v in p['S'] if v >= 80)
        main_ge80 = sum(1 for v in protos[0]['S'] if v >= 80)
        op17 = sum(1 for p in protos for v in p['S'] if v == 17)
        main_op17 = sum(1 for v in protos[0]['S'] if v == 17)
        ok_bf2 = ok_bf2 and total_s == 15683 and s_ge80 == 8238 \
            and main_ge80 == 5738 and op17 == 80 and main_op17 == 39 \
            and protos[12]['body'] is None
        check('BF2 bf_protos.json metrics vs proof', ok_bf2,
              f'total_s={total_s} s_ge80={s_ge80} op17={op17}')
        qa = load_json(os.path.join(out_auto, 'qa_report.json'))
        m = re.search(r"VERSION = '([^']+)'",
                      open(os.path.join(tool, 'luraph_v6.py'),
                           encoding='utf-8').read())
        tool_ver = m.group(1) if m else None
        gap_ids = {g['id'] for g in qa.get('gaps', [])}
        check('BF2 qa verdict PARTIAL + flags + gaps + version',
              qa.get('verdict') == 'PARTIAL'
              and qa.get('exit') == 5
              and qa.get('route') == 'buffer-bf'
              and qa.get('hub_strings_recovered') is False
              and qa.get('structured_lift') is False
              and qa.get('tool_version') == tool_ver
              and EXPECTED_GAPS <= gap_ids,
              f"version={qa.get('tool_version')} vs tool={tool_ver} "
              f"missing_gaps={sorted(EXPECTED_GAPS - gap_ids)}")
        check('BF2 proto45 T=789 vs X-factory-786 flagged',
              len(protos[11]['T']) == 789
              and 'proto45_x_discrepancy' in gap_ids)
        comp = os.path.join(tool, 'bin', 'luau-compile')
        rc = subprocess.run([comp, os.path.join(
            out_auto, 'bf_annotated.luau')],
            capture_output=True, timeout=300).returncode
        check('BF2 bf_annotated.luau luau-compile exit 0', rc == 0,
              f'exit={rc}')
        rep = open(os.path.join(out_auto, 'report.md'),
                   encoding='utf-8').read()
        check('BF2 report.md PARTIAL + hub-negative + no FULL',
              '**PARTIAL**' in rep
              and 'NOT recovered' in rep
              and 'FULL' not in rep)
        check('BF2 no FULL string in BF artifacts',
              all('FULL' not in open(os.path.join(out_auto, fn),
                                      encoding='utf-8',
                                      errors='replace').read()
                  for fn in ('bf_protos.json', 'bf_annotated.luau',
                             'qa_report.json', 'report.md',
                             'fill_keystream.json')))
    except Exception as e:
        check('BF2 artifact metrics vs proof', False, repr(e))

    # ---- BF3: literal spot checks ----
    try:
        bfp = load_json(os.path.join(out_auto, 'bf_protos.json'))
        protos = bfp['protos']
        qa = load_json(os.path.join(out_auto, 'qa_report.json'))
        main_lit = protos[0]['literals_main']
        ok_bf3 = True
        for pool in ('_', 'X'):
            keys = {int(k.split('[')[1].rstrip(']'))
                    for k in main_lit if k.startswith(pool + '[')}
            if keys != set(range(1, 10147)):
                ok_bf3 = False
        for pool, want in (('g', 371), ('f', 2300)):
            n = sum(1 for k in main_lit if k.startswith(pool + '['))
            if n != want:
                ok_bf3 = False
        if 'g[372]' in main_lit or 'f[2301]' in main_lit:
            ok_bf3 = False
        hangs = qa.get('hangs_confirmed', [])
        if 'main g372' not in hangs or 'main f2301' not in hangs:
            ok_bf3 = False
        for p in protos[1:]:
            lit = p['literals_sub']
            want = EXPECTED_HARVEST[p['entry']]
            got = tuple(sum(1 for k in lit
                            if k.startswith(pool + '['))
                        for pool in ('_', 'g', 'f', 'X'))
            if got != want:
                ok_bf3 = False
        check('BF3 per-pool harvested counts + hangs', ok_bf3)
        distinct = set()
        str_entries = 0
        for p in protos:
            lit = (p['literals_main'] if p['index'] == 0
                   else p['literals_sub'])
            for ent in lit.values():
                if isinstance(ent, dict) and ent.get('type') == 'str':
                    str_entries += 1
                    if isinstance(ent.get('value'), str):
                        distinct.add(ent['value'])
        hub_hits = sorted(v for v in distinct if HUB_PATTERN.search(v))
        nonascii = [v for v in distinct
                    if any(ord(ch) > 127 for ch in v)]
        check('BF3 distinct strings 231 + hub hit + non-ASCII 2',
              len(distinct) == 231 and hub_hits == ['HttpService']
              and len(nonascii) == 2,
              f'distinct={len(distinct)} hub={hub_hits} '
              f'nonascii={len(nonascii)} str_entries={str_entries}')
        ent721 = main_lit.get('_[721]')
        ann = open(os.path.join(out_auto, 'bf_annotated.luau'),
                   encoding='utf-8').read()
        addr = ent721.get('value') if isinstance(ent721, dict) else None
        check('BF3 _721 self-reference, address not in annotated',
              isinstance(ent721, dict)
              and ent721.get('type') == 'function'
              and 'entry-10110 self-reference' in ann
              and (addr is None or addr not in ann),
              f'_721={ent721}')
    except Exception as e:
        check('BF3 literal spot checks', False, repr(e))

    # ---- BF4: determinism across PYTHONHASHSEED ----
    try:
        outs = []
        for seed, name in (('0', 'det0'), ('12345', 'det12345')):
            o = os.path.join(work, name)
            rr = run([sys.executable,
                      os.path.join(method_dir, 'luraph151.py'),
                      bf, '-o', o, '--luau',
                      os.path.join(tool, 'bin', 'luau')],
                     seed=seed)
            if rr.returncode != 5:
                raise RuntimeError(f'det run {name} exit '
                                   f'{rr.returncode}')
            outs.append(o)
        ok_bf4 = all(
            sha256_file(os.path.join(outs[0], fn))
            == sha256_file(os.path.join(outs[1], fn))
            for fn in ('bf_protos.json', 'bf_annotated.luau',
                       'qa_report.json'))
        check('BF4 determinism PYTHONHASHSEED 0 vs 12345', ok_bf4)
    except Exception as e:
        check('BF4 determinism', False, repr(e))

    # ---- BF5: no-sample-literals grep over route CODE ----
    try:
        code_files = []
        bf_pkg = os.path.join(routes_dir, 'buffer_bf')
        for fn in sorted(os.listdir(bf_pkg)):
            if fn.endswith('.py'):
                code_files.append(os.path.join(bf_pkg, fn))
        code_files.append(os.path.join(method_dir, 'luraph151.py'))
        code = '\n'.join(open(p, encoding='utf-8').read()
                         for p in code_files)
        bfp = load_json(os.path.join(out_auto, 'bf_protos.json'))
        distinct = set()
        for p in bfp['protos']:
            lit = (p['literals_main'] if p['index'] == 0
                   else p['literals_sub'])
            for ent in lit.values():
                if isinstance(ent, dict) and ent.get('type') == 'str':
                    v = ent.get('value')
                    if isinstance(v, str) and len(v) >= 12:
                        distinct.add(v)
        bad_strings = sorted(v for v in distinct if v in code)
        fill = load_json(os.path.join(bf_pkg, 'data',
                                      'fill_keystream.json'))
        bad_keys = [str(w) for w in fill['keystream30']
                    if re.search(r'\b' + re.escape(str(w)) + r'\b',
                                 code)]
        grams = set()
        for p in bfp['protos']:
            for arr in ('S', 'r', 'p', 'T'):
                vals = p[arr]
                for i in range(len(vals) - 7):
                    grams.add(tuple(vals[i:i + 8]))
        code_ints = [int(t) for t in re.findall(
            r'(?<![\w.])\d+(?![\w.])', code)]
        bad_grams = [tuple(code_ints[i:i + 8])
                     for i in range(len(code_ints) - 7)
                     if tuple(code_ints[i:i + 8]) in grams]
        check('BF5 no harvested string (len>=12) in route code',
              not bad_strings, f'{bad_strings[:5]}')
        check('BF5 no keystream word in route code',
              not bad_keys, f'{bad_keys[:5]}')
        check('BF5 no 8-int proto array fragment in route code',
              not bad_grams, f'{bad_grams[:3]}')
    except Exception as e:
        check('BF5 no-sample-literals grep', False, repr(e))

    # ---- BF7: fail-close controls ----
    try:
        ctrl = os.path.join(work, 'control.luau')
        reads = ' '.join(f'buffer.read{n}' for n in (
            'u8', 'u16', 'i16', 'u32', 'i32', 'f32', 'f64', 'string',
            'bits', 'u8'))
        writes = ' '.join(f'buffer.write{n}' for n in (
            'u8', 'u16', 'i16', 'u32', 'i32', 'f32', 'f64', 'string',
            'bits', 'u8'))
        with open(ctrl, 'w', encoding='utf-8') as f:
            f.write('-- Luraph Obfuscator v15.1\n')
            f.write('local _buf = buffer.create(16)\n')
            f.write(f'-- handler table: {reads} {writes}\n')
            f.write('local x = 1\nprint(x)\n')
        o = os.path.join(work, 'out-control')
        rr = run([sys.executable,
                  os.path.join(method_dir, 'luraph151.py'),
                  ctrl, '-o', o, '--luau',
                  os.path.join(tool, 'bin', 'luau')])
        rep = ''
        if os.path.isfile(os.path.join(o, 'report.md')):
            rep = open(os.path.join(o, 'report.md'),
                       encoding='utf-8').read()
        check('BF7 synthetic control exit 2 + REJECTED, no '
              'lifted file, no PARTIAL qa',
              rr.returncode == 2
              and 'REJECTED' in rep
              and not os.path.isfile(os.path.join(
                  o, 'bf_annotated.luau'))
              and not os.path.isfile(os.path.join(o, 'bf_protos.json'))
              and not os.path.isfile(os.path.join(o, 'qa_report.json')),
              f'exit={rr.returncode}')
    except Exception as e:
        check('BF7 fail-close controls', False, repr(e))

    # ---- BF8: forbidden imports + case untouched ----
    try:
        import_lines = []
        bf_pkg = os.path.join(routes_dir, 'buffer_bf')
        for fn in sorted(os.listdir(bf_pkg)):
            if not fn.endswith('.py'):
                continue
            txt = open(os.path.join(bf_pkg, fn),
                       encoding='utf-8').read()
            for line in txt.splitlines():
                if re.match(r'\s*(import|from)\s+\S*buffer_(body|lifter)\b',
                            line):
                    import_lines.append(f'{fn}: {line}')
        check('BF8 no buffer_body/lifter imports in new stage',
              not import_lines, f'{import_lines[:3]}')
        check('BF8 BF-Main case input sha unchanged',
              sha256_file(bf) == bf_sha_before)
    except Exception as e:
        check('BF8 forbidden imports / case mutation', False, repr(e))

    # ---- BF9: runner capture, grammar-valid unseen control ----
    try:
        sections = {'p': [5, 6], 'r': [7, 8, 9],
                    'S': [0, 17, 85, 200, 3], 'T': [4, 5]}
        body = grammar_mod.build_bf_body(
            3, 11, 22, sections, 7, trailer=b'\x01\x02\x03\x04')
        reads = ' '.join(f'buffer.read{n}' for n in (
            'u8', 'u16', 'i16', 'u32', 'i32', 'f32', 'f64',
            'string', 'bits', 'u8'))
        writes = ' '.join(f'buffer.write{n}' for n in (
            'u8', 'u16', 'i16', 'u32', 'i32', 'f32', 'f64',
            'string', 'bits', 'u8'))
        ctrl_lines = [
            '-- Luraph Obfuscator v15.1',
            f'-- handler table: {reads} {writes}',
            'local junk = buffer.create(4)',
            'buffer.writeu8(junk, 0, 255)',
            'local bytes = {' + ','.join(str(b) for b in body)
            + '}',
            'local b = buffer.create(#bytes)',
            'for i, v in ipairs(bytes) do '
            'buffer.writeu8(b, i - 1, v) end',
            'print("BFPROTO", 7, 3, 2, 3, 5, 2, 4)',
        ]
        ctrl = os.path.join(work, 'control_valid.luau')
        with open(ctrl, 'w', encoding='utf-8') as f:
            f.write('\n'.join(ctrl_lines) + '\n')
        luau_bin = os.path.join(tool, 'bin', 'luau')
        out_r = os.path.join(work, 'out-runner')
        rr = run([sys.executable, os.path.join(tool, 'luraph_v6.py'),
                  ctrl, '-o', out_r])
        rep_r = ''
        if os.path.isfile(os.path.join(out_r, 'report.md')):
            rep_r = open(os.path.join(out_r, 'report.md'),
                         encoding='utf-8').read()
        ok_r9 = rr.returncode == 5 and 'verdict: PARTIAL' in (
            rr.stdout + rr.stderr)
        bfp_r = None
        qa_r = None
        if os.path.isfile(os.path.join(out_r, 'bf_protos.json')):
            bfp_r = load_json(os.path.join(out_r, 'bf_protos.json'))
            pr = bfp_r['protos'][0]
            ok_r9 = ok_r9 and pr['entry'] == 7 \
                and pr['nconsts'] == 3 and pr['body'] == 'captured' \
                and pr['S'] == sections['S'] \
                and pr['r'] == sections['r'] \
                and pr['p'] == sections['p'] \
                and pr['T'] == sections['T'] \
                and len(bfp_r['protos']) == 1
        else:
            ok_r9 = False
        if os.path.isfile(os.path.join(out_r, 'qa_report.json')):
            qa_r = load_json(os.path.join(out_r, 'qa_report.json'))
            ok_r9 = ok_r9 and qa_r.get('verdict') == 'PARTIAL' \
                and qa_r.get('hub_strings_recovered') is False \
                and qa_r.get('structured_lift') is False \
                and qa_r.get('runner_capture', {}).get(
                    'chunk_ok') is True \
                and qa_r.get('runner_capture', {}).get(
                    'timed_out') is False \
                and 'runner_gate_generalization' in {
                    g['id'] for g in qa_r.get('gaps', [])}
        else:
            ok_r9 = False
        check('BF9 runner valid control exit 5 + captured arrays',
              ok_r9, f'exit={rr.returncode}')
        check('BF9 runner report PARTIAL, no lifted-as-clean file',
              '**PARTIAL**' in rep_r
              and not os.path.isfile(os.path.join(out_r,
                                                  'cleaned.luau')),
              f'exit={rr.returncode}')
        comp = subprocess.run(
            [os.path.join(tool, 'bin', 'luau-compile'),
             os.path.join(out_r, 'bf_annotated.luau')],
            capture_output=True, timeout=300).returncode
        check('BF9 runner annotated luau-compile exit 0', comp == 0,
              f'exit={comp}')
        fill_r = load_json(os.path.join(out_r, 'fill_keystream.json'))
        check('BF9 runner fill note: no fill captured, no K copy',
              fill_r.get('fill_captured') is False,
              str(fill_r)[:80])
        out_r2 = os.path.join(work, 'out-runner2')
        rr2 = run([sys.executable, os.path.join(tool, 'luraph_v6.py'),
                   ctrl, '-o', out_r2])
        same = rr2.returncode == 5 and all(
            open(os.path.join(out_r, fn), 'rb').read()
            == open(os.path.join(out_r2, fn), 'rb').read()
            for fn in ('bf_protos.json', 'bf_annotated.luau',
                       'qa_report.json'))
        check('BF9 runner determinism across two runs', same,
              f'exit2={rr2.returncode}')
        # Corrupted captured body: descriptor/body mismatch -> 2.
        bad_lines = list(ctrl_lines)
        bad_lines[-1] = 'print("BFPROTO", 7, 3, 2, 3, 5, 2, 5)'
        ctrl_bad = os.path.join(work, 'control_bad.luau')
        with open(ctrl_bad, 'w', encoding='utf-8') as f:
            f.write('\n'.join(bad_lines) + '\n')
        out_bad = os.path.join(work, 'out-runner-bad')
        rb = run([sys.executable, os.path.join(tool, 'luraph_v6.py'),
                  ctrl_bad, '-o', out_bad])
        rep_bad = ''
        if os.path.isfile(os.path.join(out_bad, 'report.md')):
            rep_bad = open(os.path.join(out_bad, 'report.md'),
                           encoding='utf-8').read()
        check('BF9 runner descriptor mismatch exit 2 + REJECTED',
              rb.returncode == 2 and 'REJECTED' in rep_bad
              and not os.path.isfile(os.path.join(
                  out_bad, 'bf_protos.json'))
              and not os.path.isfile(os.path.join(
                  out_bad, 'qa_report.json')),
              f'exit={rb.returncode}')
    except Exception as e:
        check('BF9 runner capture controls', False, repr(e))

    # ---- BF10: harvest with hang isolation ----
    try:
        harv = ('function HARVEST_KEY(k)\n'
                '  if k == 5 or k == 10 then '
                'while true do end end\n'
                '  return k * 3\n'
                'end\n')
        vals, hangs = runner_mod.harvest_with_isolation(
            harv, list(range(1, 13)), os.path.join(tool, 'bin',
                                                  'luau'),
            os.path.join(work, 'harv'), chunk_size=4, timeout=3)
        check('BF10 harvest isolation: values + hang keys',
              hangs == [5, 10]
              and vals == {k: str(k * 3) for k in range(1, 13)
                           if k not in (5, 10)},
              f'hangs={hangs} vals={len(vals)}')
    except Exception as e:
        check('BF10 harvest isolation', False, repr(e))

    # ---- BF11: clean op-leaf trace parsing ----
    try:
        log = ('OPH|7|A|0|31|9|4|6|100|200\n'
               'OPH|7|A|1|60|9|4|6|100|200\n'
               'OPH|7|A|2|16|9|4|6|100|200\n'
               'OPH|7|B|0|5|9|4|6|0|0\n'
               'OPH|7|A|bad|1|2|3|4|5|6\n')
        res = runner_mod.parse_op_trace(log)
        ev = res['events']
        ok_t = (len(ev) == 4 and res['skipped'] == 1
                and res['coverage'] == {'A': 3, 'B': 1}
                and res['per_entry'] == {7: 4}
                and ev[0]['decrypt_seed']
                == formulas_mod.mix29(6, 100)
                and ev[1]['decrypt_seed']
                == formulas_mod.mix29(6, 200)
                and ev[2]['decrypt_seed'] == 9
                and ev[0]['loop_a_op'] == 'decrypt')
        check('BF11 op trace coverage + per-event M/q seeds', ok_t,
              f"events={len(ev)} skipped={res['skipped']}")
    except Exception as e:
        check('BF11 op trace parsing', False, repr(e))

    if FAIL:
        print(f'REGRESSION: {len(FAIL)} CHECK(S) FAILED: {FAIL}')
        return 1
    print('REGRESSION: ALL CHECKS PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())
