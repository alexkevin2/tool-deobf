#!/usr/bin/env python3
"""check_upgrade.py — Part D of the v6 regression: verify the
2026-10-23 regular-Luraph upgrade outputs inside the Part B corpus
output dirs (buffer route lifted source + method route cleaned
source) against tests/golden/upgrade_sha256.json.

Usage: python3 check_upgrade.py <tool_dir> <corpus_work_root>
Exit 0 iff every check passes.
"""
import hashlib
import json
import os
import subprocess
import sys

tool_dir, work_root = sys.argv[1], sys.argv[2]
golden = json.load(open(os.path.join(
    tool_dir, 'tests', 'golden', 'upgrade_sha256.json')))
luau_compile = os.path.join(tool_dir, 'bin', 'luau-compile')
fails = []


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] upgrade {name}"
          + (f' — {detail}' if detail else ''), flush=True)
    if not cond:
        fails.append(name)


def compiles(path):
    return subprocess.run([luau_compile, path],
                          stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL).returncode == 0


# ---- buffer route: lifted source (both duplicate-content entries)
for entry in ('luraph_payload_buffer', 'nnvn_cache_buffer'):
    out = os.path.join(work_root, entry)
    lifted = os.path.join(out, 'lifted.luau')
    check(f'{entry} lifted.luau exists', os.path.isfile(lifted))
    if os.path.isfile(lifted):
        check(f'{entry} lifted.luau sha256',
              sha(lifted) == golden['buffer']['lifted.luau_sha256'],
              sha(lifted))
        check(f'{entry} lifted.luau compiles', compiles(lifted))
    rep_path = os.path.join(out, 'report.md')
    if os.path.isfile(rep_path):
        rep = open(rep_path, encoding='utf-8').read()
        check(f'{entry} report states cracked semantics + counts',
              'opcode semantics: **cracked**' in rep
              and f"{golden['buffer']['structured']} structured" in rep
              and f"{golden['buffer']['kernel']} dispatch-kernel" in rep)

# ---- method route: cleaned source (both JjsKhanhly-content entries)
for entry in ('sample_v151_bundled', 'jjs_khanhly_case'):
    out = os.path.join(work_root, entry)
    cleaned = os.path.join(out, 'cleaned.luau')
    check(f'{entry} cleaned.luau exists', os.path.isfile(cleaned))
    if os.path.isfile(cleaned):
        check(f'{entry} cleaned.luau sha256',
              sha(cleaned) == golden['jjs_clean']['cleaned.luau_sha256'],
              sha(cleaned))
        check(f'{entry} cleaned.luau compiles', compiles(cleaned))
    map_path = os.path.join(out, 'clean_map.json')
    if os.path.isfile(map_path):
        cmap = json.load(open(map_path))
        t = cmap['totals']
        g = golden['jjs_clean']
        check(f'{entry} clean_map totals',
              t['protos'] == g['protos']
              and t['promoted'] == g['promoted']
              and t['skipped'] == g['skipped']
              and t['names_confirmed'] == g['names_confirmed']
              and t['names_inferred'] == g['names_inferred']
              and t['names_neutral'] == g['names_neutral'],
              json.dumps(t))
        check(f'{entry} clean literals preserved + compiled',
              cmap['literal_multiset_equal'] is True
              and cmap.get('luau_compile') is True)

print('UPGRADE CHECKS:', 'FAIL ' + str(fails) if fails else 'ALL PASS')
sys.exit(1 if fails else 0)
