#!/usr/bin/env python3
"""check_spoof_engine.py — unit checks for the shared spoof engine
(spoof_engine.py) and its v6 adapters.  Pure Python, no Luau
execution, no network, no payload runs.

Checks:
  S1  all vendored engine copies are byte-identical to the
      canonical v6-root copy (root, routes/method, stageE,
      tools-shared mirror).
  S2  no-hardcode audit: the literal game ID used by the v6 test
      fixtures appears NOWHERE in production code (luraph_v6.py +
      routes/**/*.py|luau, excluding sample/ and tests/); the
      engine file contains no game-ID literal at all (its only
      ID-shaped constant is the documented PROBE_VALUE marker).
  S3  negative case: no candidates -> empty seed, single empty
      fork, gates report UNKNOWN, never a guessed value.
  S4  collect_events: eq/in-set/lt/ne map to the right kinds,
      non-identity fields and non-scalar values are ignored,
      dedupe is by (value, kind).
  S5  multi-gate fork plan: deterministic, primary-first, one
      field varied at a time, capped (<=4/field, <=9 total).
  S6  seed resolution: exactly-one-candidate seeds; ambiguous
      fields stay unseeded.
  S7  SpoofState: seeded read, sentinel read, first-scalar adopt,
      contradiction keeps the adopted value, disabled mode logs
      nothing; log_to_state shape matches the bootstrap sweep.
  S8  legacy report shapes: method + bootstrap key order and
      value shapes (golden compatibility).
  S9  unified report: gates statuses, unknown_fields, branch
      labels default to 'unclassified' and follow a caller rule
      when one is supplied; bound expansion helper.

Usage: python3 check_spoof_engine.py <v6_tool_dir>
Exit 0 iff every check passes.
"""
import hashlib
import importlib.util
import os
import re
import sys

tool_dir = sys.argv[1]
fails = []


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] spoof-engine {name}"
          + (f' — {detail}' if detail else ''), flush=True)
    if not cond:
        fails.append(name)


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


root_engine = os.path.join(tool_dir, 'spoof_engine.py')
e = load('spoof_engine_test', root_engine)

# ---------------------------------------------------------------- S1
copies = [
    os.path.join(tool_dir, 'routes', 'method', 'spoof_engine.py'),
    os.path.join(tool_dir, 'routes', 'bootstrap', 'modules',
                 'stageE', 'spoof_engine.py'),
    os.path.expanduser('~/luau-deobf/tools-shared/spoof_engine.py'),
]
for p in copies:
    check(f'S1 vendored copy identical: {p}',
          os.path.isfile(p) and sha(p) == sha(root_engine),
          sha(p) if os.path.isfile(p) else 'missing')

# ---------------------------------------------------------------- S2
# TEST-DATA NOTE: the literal below is the JjsKhanhly fixture ID
# used by tests/check_spoof.py and sample/method/behavior-test/
# as labelled test data.  It must NOT appear in production code;
# this check enforces that (production = CLI + routes code, not
# sample/ or tests/).
TEST_ID = '9391468976'
prod_hits = []
for base, _dirs, files in os.walk(tool_dir):
    rel = os.path.relpath(base, tool_dir)
    if rel.split(os.sep)[0] in ('sample', 'tests'):
        continue
    if '__pycache__' in base:
        continue
    for fn in files:
        if fn.endswith(('.py', '.luau')):
            fp = os.path.join(base, fn)
            if TEST_ID in open(fp, encoding='utf-8',
                               errors='replace').read():
                prod_hits.append(os.path.relpath(fp, tool_dir))
check('S2 no fixture game ID in production code', not prod_hits,
      str(prod_hits))
eng_src = open(root_engine, encoding='utf-8').read()
big_nums = set(re.findall(r'\b\d{9,}\b', eng_src))
check('S2 engine: only PROBE_VALUE is ID-shaped',
      big_nums == {str(e.PROBE_VALUE)}, str(big_nums))
check('S2 engine: no TEST_ID literal', TEST_ID not in eng_src)

# ---------------------------------------------------------------- S3
cands = {}
check('S3 empty seed', e.build_seed(cands) == {})
forks, primary = e.plan_forks(cands)
check('S3 empty fork plan == [{}]', forks == [{}] and primary == {})
rep = e.build_report('test', {}, {'PlaceId': ['root']}, notes=[])
check('S3 unknown gate, spoofed null',
      rep['gates'] == [{'field': 'PlaceId', 'status': 'unknown',
                        'candidates': [], 'spoofed_value': None,
                        'forked': False, 'non_pass_kinds': [],
                        'extra_field': False}]
      and rep['unknown_fields'] == ['PlaceId'])

# ---------------------------------------------------------------- S4
c2 = {}
e.collect_events(c2, [
    {'field': 'PlaceId', 'op': 'eq', 'value': 100,
     'proto': 'root', 'pc': 1, 'pattern': 'PlaceId == const'},
    {'field': 'PlaceId', 'op': 'eq', 'value': 100,
     'proto': 'root', 'pc': 1, 'pattern': 'PlaceId == const'},
    {'field': 'PlaceId', 'op': 'in-set', 'value': 100,
     'proto': 'root', 'pc': 2, 'pattern': 'set membership'},
    {'field': 'PlaceId', 'op': 'lt', 'value': 50,
     'proto': 'root', 'pc': 3, 'pattern': 'const < PlaceId'},
    {'field': 'PlaceId', 'op': 'ne', 'value': 7,
     'proto': 'root', 'pc': 4, 'pattern': 'PlaceId ~= const'},
    {'field': 'Workspace', 'op': 'eq', 'value': 1,
     'proto': 'root', 'pc': 5, 'pattern': 'ignored field'},
    {'field': 'PlaceId', 'op': 'eq', 'value': [1],
     'proto': 'root', 'pc': 6, 'pattern': 'ignored value'},
    {'field': 'PlaceId', 'op': 'bogus', 'value': 1,
     'proto': 'root', 'pc': 7, 'pattern': 'ignored op'},
])
got = [(c['value'], c['kind']) for c in c2.get('PlaceId', [])]
check('S4 event kinds + dedupe',
      got == [(100, 'eq-const'), (100, 'set-membership'),
              (50, 'lt-bound'), (7, 'ne-const')], str(got))
e.sort_candidates(c2)
got_s = [(c['value'], c['kind']) for c in c2['PlaceId']]
check('S4 sort: strong first, then str(value)',
      got_s == [(100, 'eq-const'), (100, 'set-membership'),
                (50, 'lt-bound'), (7, 'ne-const')], str(got_s))

# ---------------------------------------------------------------- S5
c3 = {}
for v in (10, 20, 30, 40, 50):
    e.add_candidate(c3, 'PlaceId', v, 'eq-const', 'root', 1, 'eq')
for v in (1, 2):
    e.add_candidate(c3, 'JobId', v, 'eq-const', 'root', 2, 'eq')
e.sort_candidates(c3)
forks, primary = e.plan_forks(c3)
check('S5 primary = best per field',
      primary == {'JobId': 1, 'PlaceId': 10}, str(primary))
check('S5 fork count capped (1 + 3 + 1 = 5)',
      len(forks) == 5, str(len(forks)))
check('S5 forks vary one field at a time',
      all(sum(1 for f in fk if fk[f] != primary[f]) <= 1
          for fk in forks))
check('S5 fork plan deterministic (repeat identical)',
      e.plan_forks(c3)[0] == forks)
c_big = {}
for f in ('PlaceId', 'JobId', 'CreatorId'):
    for v in range(10):
        e.add_candidate(c_big, f, v, 'eq-const', 'root', 1, 'eq')
    e.sort_candidates(c_big)
forks_big, _ = e.plan_forks(c_big)
check('S5 total cap 9', len(forks_big) == 9, str(len(forks_big)))

# ---------------------------------------------------------------- S6
check('S6 ambiguous fields not seeded (exact)',
      e.build_seed(c3) == {}, str(e.build_seed(c3)))
check('S6 single-candidate field seeds',
      e.build_seed({'GameId': [{'value': 5, 'kind': 'eq-const',
                               'evidence': []}]}) == {'GameId': 5})

# ---------------------------------------------------------------- S7
st = e.SpoofState(True, {'PlaceId': 42})
check('S7 seeded read', st.read('PlaceId') == (42, 'static-seed'))
check('S7 sentinel read', st.read('JobId') == ('sentinel', 'sentinel'))
check('S7 first capture adopts',
      st.capture('JobId', 7, ('root', 'C', 1)) == ('adopted', 7))
check('S7 adopted read served',
      st.read('JobId') == (7, 'adopted'))
check('S7 contradiction keeps adopted',
      st.capture('JobId', 8, ('root', 'C', 2))
      == ('contradiction', 7))
check('S7 non-scalar capture ignored',
      st.capture('JobId', [1], ('root', 'C', 3)) == ('ignored', None))
state = st.to_state()
check('S7 log_to_state shape',
      state['seeded'] == [{'field': 'PlaceId', 'value': 42,
                           'source': 'static'}]
      and state['captures'][0]['value'] == 7
      and state['contradictions'][0]['compared'] == 8)
off = e.SpoofState(False, {'PlaceId': 42})
check('S7 disabled logs nothing + read disabled',
      off.read('PlaceId') == (None, 'disabled') and off.log == [])

# ---------------------------------------------------------------- S8
mrep = e.build_report_legacy_method(
    'method', {'PlaceId': [{'value': 1, 'kind': 'eq-const',
                            'evidence': []}]},
    {'PlaceId': ['root']}, [], ['note'])
check('S8 method legacy key order',
      list(mrep.keys()) == ['feature', 'mode', 'route', 'fields_seen',
                            'fields_read', 'candidates', 'forks',
                            'identity_reads_total', 'identity_reads',
                            'notes'])
brep = e.build_report_legacy_bootstrap(
    {}, {'PlaceId': ['root C:5']}, {}, {'seeded': [], 'reads': [],
                                        'captures': [],
                                        'contradictions': []}, [])
check('S8 bootstrap legacy key order',
      list(brep.keys()) == ['feature', 'mode', 'route', 'fields_seen',
                            'candidates', 'seed', 'captures',
                            'contradictions', 'identity_reads_total',
                            'identity_reads', 'notes'])
check('S8 bootstrap fields_seen merge preserves order',
      brep['fields_seen'] == {'PlaceId': ['root C:5']})
sec = e.report_section_legacy_method(mrep)
check('S8 method section header', '## Identity spoofing' in sec)

# ---------------------------------------------------------------- S9
urep = e.build_report('test', c3, {'PlaceId': ['root'],
                                   'JobId': ['root']},
                      forks=[{'fork': 0, 'seeds': {},
                              'identity_reads': [], 'prints_total': 1,
                              'http_attempts': 1, 'mock_calls': 1}],
                      notes=[])
statuses = {g['field']: g['status'] for g in urep['gates']}
check('S9 unified gate statuses (forked)',
      statuses == {'JobId': 'forked', 'PlaceId': 'forked'},
      str(statuses))
check('S9 branch defaults unclassified',
      urep['forks'][0]['branch'] == 'unclassified')
urep2 = e.build_report('test', c3, {}, forks=[
    {'fork': 0, 'seeds': {}, 'identity_reads': [], 'prints_total': 1,
     'http_attempts': 1, 'mock_calls': 1}], notes=[],
    is_pass=lambda fk: fk['http_attempts'] >= 1)
check('S9 branch follows caller rule',
      urep2['forks'][0]['branch'] == 'gate-pass')
check('S9 bound expansion lt',
      e.expand_bound_candidates(100, 'lt-bound') == [100, 101])
check('S9 bound expansion gt',
      e.expand_bound_candidates(100, 'gt-bound') == [100, 99])
check('S9 eq expansion identity',
      e.expand_bound_candidates(100, 'eq-const') == [100])

# co-occurrence evidence shape (bootstrap legacy verbatim)
co, seen = e.extract_cooccurrence(
    {'root': {'instructions': [{'mode': 'C', 'pc': 5, 'name': 'X',
                                'K': ["b'PlaceId'", 42]}]}})
check('S9 co-occurrence evidence shape',
      co == {'PlaceId': [{'value': 42, 'kind': 'same-instruction',
                          'evidence': [{'proto': 'root', 'mode': 'C',
                                        'pc': 5, 'op': 'X'}]}]}
      and seen == {'PlaceId': ['root C:5']}, str(co))

print('SPOOF ENGINE CHECKS:',
      'FAIL ' + str(fails) if fails else 'ALL PASS')
sys.exit(1 if fails else 0)
