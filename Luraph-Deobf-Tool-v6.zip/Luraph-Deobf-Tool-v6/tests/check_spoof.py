#!/usr/bin/env python3
"""check_spoof.py — Part E of the v6 regression: the --spoof-id
automatic game-ID spoofing feature (2026-10-23).

Checks:
  E1  behavior-test fixtures as CONTROLS (v5-era, hand-written game
      tables; the feature must agree with them, not use them):
      match fixture (PlaceId = 9391468976) -> HTTPGET logged and
      REMOTE_PAYLOAD_RAN executed; mismatch fixture (12345) ->
      exactly 161 insult prints + DONE, no HTTPGET.
  E2  v6 AUTO on the bundled method sample: exit 0;
      identity_report.json present, sha256 == golden
      (tests/golden/spoof_sha256.json), and semantically: PlaceId
      candidate 9391468976 (kind set-membership, evidence root pc 5);
      fork 0 shows the gate-PASS path taken with NO hand-written
      game table (http_attempts == 1, prints_total == 1, PlaceId
      read served from a static seed).
  E3  v6 --spoof-id OFF on the same input: exit 0, NO
      identity_report.json, report.md has no identity section, and
      lifted.luau / ops.json / protos.json sha256 == the pristine
      Part B corpus goldens (legacy behaviour byte-identical).
  E4  synthetic units (in-process):
      - a proto tree with no identity constants -> zero candidates
        and zero field reads (the negative case);
      - a synthetic EQ gate -> candidate recovered as 'eq-const';
      - bootstrap stageE identity: extraction over the bundled
        bootstrap sample (no gate candidates; PlaceId seen in the
        materialized constants), and the mocks sentinel flow
        (sentinel -> adopt -> served value; seeded read; off ==
        legacy child mock, no identity log).

Usage: python3 check_spoof.py <v6_tool_dir> <work_root>
Exit 0 iff every check passes.
"""
import hashlib
import json
import os
import subprocess
import sys

tool_dir, work_root = sys.argv[1], sys.argv[2]
luau = os.path.join(tool_dir, 'bin', 'luau')
fails = []


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def check(name, cond, detail=''):
    print(f"[{'PASS' if cond else 'FAIL'}] spoof {name}"
          + (f' — {detail}' if detail else ''), flush=True)
    if not cond:
        fails.append(name)


os.makedirs(work_root, exist_ok=True)
sample_input = os.path.join(tool_dir, 'sample', 'method',
                            'input_v151.lua')

# ---------------------------------------------------------------- E1
fx_dir = os.path.join(tool_dir, 'sample', 'method', 'behavior-test')
for name, want_http, want_remote, want_insult in (
        ('mock_placeid_match.luau', 1, 1, 0),
        ('mock_placeid_mismatch.luau', 0, 0, 161)):
    p = subprocess.run([luau, os.path.join(fx_dir, name)],
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=300)
    out = p.stdout
    check(f'E1 {name} exit 0', p.returncode == 0,
          f'got {p.returncode}')
    check(f'E1 {name} HTTPGET count == {want_http}',
          out.count('HTTPGET') == want_http,
          f"got {out.count('HTTPGET')}")
    check(f'E1 {name} REMOTE_PAYLOAD_RAN == {want_remote}',
          out.count('REMOTE_PAYLOAD_RAN') == want_remote)
    check(f'E1 {name} insult prints == {want_insult}',
          out.count('đã ngu') == want_insult,
          f"got {out.count('đã ngu')}")

# ---------------------------------------------------------------- E2
auto_out = os.path.join(work_root, 'auto')
p = subprocess.run([sys.executable,
                    os.path.join(tool_dir, 'luraph_v6.py'),
                    sample_input, '-o', auto_out],
                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                   text=True, timeout=1800)
check('E2 v6 auto exit 0', p.returncode == 0,
      f"got {p.returncode}; tail: {p.stdout.splitlines()[-2:]}")
irep_path = os.path.join(auto_out, 'identity_report.json')
check('E2 identity_report.json exists', os.path.isfile(irep_path))
if os.path.isfile(irep_path):
    golden = json.load(open(os.path.join(
        tool_dir, 'tests', 'golden', 'spoof_sha256.json')))
    check('E2 identity_report.json sha256 == golden',
          sha(irep_path) == golden['identity_report.json_sha256'],
          sha(irep_path))
    rep = json.load(open(irep_path))
    cands = rep.get('candidates', {}).get('PlaceId', [])
    check('E2 PlaceId candidate == 9391468976 (set-membership)',
          len(cands) == 1 and cands[0]['value'] == 9391468976
          and cands[0]['kind'] == 'set-membership',
          json.dumps(cands)[:200])
    check('E2 candidate evidence root pc 5',
          bool(cands) and cands[0]['evidence'][0]['proto'] == 'root'
          and cands[0]['evidence'][0]['pc'] == 5,
          json.dumps(cands[0]['evidence'])[:160] if cands else 'none')
    forks = rep.get('forks', [])
    check('E2 exactly one fork (single candidate)', len(forks) == 1,
          f'got {len(forks)}')
    if forks:
        f0 = forks[0]
        check('E2 fork0 gate-PASS evidence (http_attempts == 1)',
              f0['http_attempts'] == 1, f"got {f0['http_attempts']}")
        check('E2 fork0 prints_total == 1 (no insult loop)',
              f0['prints_total'] == 1, f"got {f0['prints_total']}")
        check('E2 fork0 PlaceId read served from static seed',
              any(r['field'] == 'PlaceId' and r['source'] == 'seed'
                  and r['value'] == '9391468976'
                  for r in f0['identity_reads']),
              json.dumps(f0['identity_reads'])[:200])
    rep_md = open(os.path.join(auto_out, 'report.md'),
                  encoding='utf-8').read()
    check('E2 report.md has the identity section',
          '## Identity spoofing' in rep_md)

# ---------------------------------------------------------------- E3
off_out = os.path.join(work_root, 'off')
p = subprocess.run([sys.executable,
                    os.path.join(tool_dir, 'luraph_v6.py'),
                    sample_input, '-o', off_out,
                    '--spoof-id', 'off'],
                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                   text=True, timeout=1800)
check('E3 v6 --spoof-id off exit 0', p.returncode == 0,
      f'got {p.returncode}')
check('E3 off: no identity_report.json',
      not os.path.exists(os.path.join(off_out, 'identity_report.json')))
rep_off = open(os.path.join(off_out, 'report.md'),
               encoding='utf-8').read()
check('E3 off: report.md has no identity section',
      'Identity spoofing' not in rep_off)
corpus_golden = json.load(open(os.path.join(
    tool_dir, 'tests', 'golden', 'corpus_sha256.json')))
entry = next(e for e in corpus_golden['entries']
             if e['name'] == 'sample_v151_bundled')
for rel, want in entry['files'].items():
    fp = os.path.join(off_out, rel)
    check(f'E3 off: {rel} sha256 == v5 golden',
          os.path.isfile(fp) and sha(fp) == want)

# ---------------------------------------------------------------- E4
sys.path.insert(0, os.path.join(tool_dir, 'routes', 'method'))
import lift as lift_mod          # noqa: E402
import identity as mid           # noqa: E402

# negative: proto tree without identity constants
neg_node = {'a': 0, 'b': 0,
            'code': {'A': [0], 'B': [0], 'C': [0], 'D': [0]},
            'consts': ['game', 'Workspace'],
            'children': []}
neg = lift_mod.Proto(neg_node, 'root')
lift_mod.expand(neg, {'0': 'CM'}, {'CM': 'GETGLOBAL'})
cands, fread = mid.extract_from_protos(neg)
check('E4 negative proto: zero candidates', cands == {},
      json.dumps(cands))
check('E4 negative proto: zero field reads', fread == {})

# synthetic EQ gate: R0 = game; R1 = R0["PlaceId"]; EQ R1 == 12345
eq_node = {'a': 0, 'b': 0,
           'code': {'A': [0, 1, 2], 'B': [0, 1, 0], 'C': [0, 0, 1],
                    'D': [0, 1, 2]},
           'consts': ['game', 'PlaceId', 12345],
           'children': []}
eqp = lift_mod.Proto(eq_node, 'root')
lift_mod.expand(eqp, {'0': 'CM', '1': 'a', '2': 'M'},
                {'CM': 'GETGLOBAL', 'a': 'GETTABLE_K',
                 'M': 'EQ_K_SKIP'})
cands, fread = mid.extract_from_protos(eqp)
pc = cands.get('PlaceId', [])
check('E4 synthetic EQ gate -> eq-const candidate 12345',
      len(pc) == 1 and pc[0]['value'] == 12345
      and pc[0]['kind'] == 'eq-const',
      json.dumps(pc)[:200])

# bootstrap stageE identity: static extraction + mocks sentinel flow
# (loaded by file path under distinct names: routes/method/identity.py
# already owns the plain module name 'identity' in this process)
import importlib.util           # noqa: E402


def _load(modname, path):
    spec = importlib.util.spec_from_file_location(modname, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_sE = os.path.join(tool_dir, 'routes', 'bootstrap', 'modules',
                   'stageE')
bid = _load('bid_identity', os.path.join(_sE, 'identity.py'))
bmocks = _load('bmocks', os.path.join(_sE, 'mocks.py'))

structs = json.load(open(os.path.join(
    tool_dir, 'sample', 'bootstrap', 'proto_structs.json')))
bcands, bseen = bid.extract_structs(structs)
check('E4 bootstrap structs: no gate candidates (sample)',
      bcands == {}, json.dumps(bcands)[:120])
mat = json.load(open(os.path.join(
    tool_dir, 'sample', 'bootstrap', 'protos.json')))
mseen = bid.extract_materialized(mat)
check('E4 bootstrap materialized: PlaceId seen',
      'PlaceId' in mseen, json.dumps(list(mseen))[:120])

n0 = len(bmocks.IDENTITYLOG)
bmocks.configure_identity(True, {})
g = bmocks.Mock('game')
g._is_game = True
g._sentinels = {}
s = g.get('PlaceId')
check('E4 mocks: unseeded read serves IdSentinel',
      isinstance(s, bmocks.IdSentinel))
check('E4 mocks: sentinel identity-stable', g.get('PlaceId') is s)
s.adopt(9391468976, ('root', 'C', 35))
check('E4 mocks: adopted value served after capture',
      g.get('PlaceId') == 9391468976)
check('E4 mocks: capture logged',
      any(e[0] == 'capture' and e[1] == 'PlaceId'
          and e[2] == 9391468976
          for e in bmocks.IDENTITYLOG[n0:]))
bmocks.configure_identity(False, {})
g3 = bmocks.Mock('game')
g3._is_game = True
g3._sentinels = {}
n1 = len(bmocks.IDENTITYLOG)
v = g3.get('PlaceId')
check('E4 mocks: off == legacy child mock, no identity log',
      type(v) is bmocks.Mock
      and not isinstance(v, bmocks.IdSentinel)
      and len(bmocks.IDENTITYLOG) == n1)

print('SPOOF CHECKS:', 'FAIL ' + str(fails) if fails else 'ALL PASS')
sys.exit(1 if fails else 0)
