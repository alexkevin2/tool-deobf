"""VM varint codec for the BF body grammar (spec section 2a).

This is NOT standard LEB128 for 4-byte values: the low and middle
7-bit groups are swapped. Rules, proven empirically and by the
interpreter's own decrypt-op formulas:

  1 byte:  b0 < 128 -> b0
  2 bytes: (b0 & 127) + (b1 << 7)
  3 bytes: (b0 & 127) + ((b1 & 127) << 7) + (b2 << 14)
  4 bytes: (b1 & 127) + ((b0 & 127) << 7) + ((b2 & 127) << 14)
           + (b3 << 21)   (swapped; b3 is taken whole)

Length is determined by continuation bits: bytes are consumed
while the high bit is set, up to a fixed width of 4. A 4-byte
value therefore always consumes exactly 4 bytes even when the
4th byte itself has its high bit set.

Worked example (must stay in the regression): bytes
[215, 222, 171, 146] decode to 306899934. Standard LEB128 would
give 306900823, which is wrong.
"""


class VarintError(ValueError):
    pass


def decode_varint(data, pos=0):
    """Decode one VM varint at data[pos]; return (value, next_pos)."""
    if pos >= len(data):
        raise VarintError('varint read past end of buffer')
    b0 = data[pos]
    if b0 < 128:
        return b0, pos + 1
    if pos + 1 >= len(data):
        raise VarintError('truncated 2-byte varint')
    b1 = data[pos + 1]
    if b1 < 128:
        return (b0 & 127) + (b1 << 7), pos + 2
    if pos + 2 >= len(data):
        raise VarintError('truncated 3-byte varint')
    b2 = data[pos + 2]
    if b2 < 128:
        return (b0 & 127) + ((b1 & 127) << 7) + (b2 << 14), pos + 3
    if pos + 3 >= len(data):
        raise VarintError('truncated 4-byte varint')
    b3 = data[pos + 3]
    return ((b1 & 127) + ((b0 & 127) << 7) + ((b2 & 127) << 14)
            + (b3 << 21)), pos + 4


def encode_varint(value):
    """Encode a non-negative int (< 2**29) as a VM varint."""
    if value < 0:
        raise VarintError('varint value must be non-negative')
    if value < 128:
        return bytes([value])
    if value < 16384:
        return bytes([(value & 127) | 128, value >> 7])
    if value < 2097152:
        return bytes([(value & 127) | 128,
                      ((value >> 7) & 127) | 128, value >> 14])
    if value >= (1 << 29):
        raise VarintError('varint value too large for 4-byte form')
    return bytes([((value >> 7) & 127) | 128,
                  (value & 127) | 128,
                  ((value >> 14) & 127) | 128,
                  value >> 21])


def decode_varint_list(data, pos, count):
    """Decode exactly count varints; return (values, next_pos)."""
    out = []
    for _ in range(count):
        v, pos = decode_varint(data, pos)
        out.append(v)
    return out, pos
