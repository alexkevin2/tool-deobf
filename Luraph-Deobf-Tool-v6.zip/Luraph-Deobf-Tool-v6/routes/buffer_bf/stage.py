#!/usr/bin/env python3
"""buffer_bf stage -- headered-buffer (BF-family) route, v6.6.0.

Entry point: buffer_bf_route(src, data, outdir, luau, sha, ...),
called ONLY from the three-way dispatch in
routes/method/luraph151.py main() (headered + buffer + not
structural). Exit semantics (spec section 4d):

  * 5 PARTIAL -- input validated AND proven-fixture gate passed.
    Writes report.md, bf_protos.json, bf_annotated.luau,
    qa_report.json, folded.luau, fill_keystream.json. Prints a
    `verdict: PARTIAL` line plus the gap list. NEVER exits 0.
  * 2 REJECTED -- static validation fails, write-family
    validation fails, fixture validation fails, or the input
    is not the proven BF-Main input (fail-closed gate). Writes
    ONLY report.md (REJECTED + reason). No lifted file, no
    bf_protos.json presented as recovered, no PARTIAL qa_report.

No file named cleaned.luau is ever written here, and no
verdict string other than PARTIAL/REJECTED is ever printed:
the ceiling for this route is PARTIAL by design.

MECHANISM (read before extending): two paths, one ceiling.

  * Proven-input transcription (BF-Main): BF bodies are
    runtime-constructed buffers, so the input file contains no
    body bytes to parse. The stage validates the input
    statically and transcribes the phase-3/phase-4 proven
    harvest bundled under data/ (every data file's sha256 is
    verified against the fixture manifest at load; any
    mismatch rejects). The proven-input list lives in fixture
    data (data/proven_inputs.json), NOT in route code.
  * Runner capture (unseen BF-family files): the input is run
    under the mock-env Luau CLI proxy runner in runner.py,
    which captures buffer snapshots + factory descriptors;
    captured bodies are parsed by the real grammar module with
    exact consumption and descriptor cross-checks. Artifacts
    are derived from the capture, never invented. Static
    evidence alone, without a proven input or a successful
    capture, exits 2.

Both paths exit 5 PARTIAL at most, never 0. Raw body-byte
parsing from a live BF-Main capture is NOT claimed: BF-Main
itself is not executed in this version (it spins in its hub
loop under a mock env per phase-3/4 evidence), so BF-Main
stays on the transcription path.

This stage never imports buffer_body or buffer_lifter.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, 'data')
METHOD_DIR = os.path.join(os.path.dirname(HERE), 'method')
if METHOD_DIR not in sys.path:
    sys.path.insert(0, METHOD_DIR)

from . import formulas as formulas_mod  # noqa: E402
from . import grammar as grammar_mod  # noqa: E402
from . import runner as runner_mod  # noqa: E402
from . import tables as tables_mod  # noqa: E402
from . import varint as varint_mod  # noqa: E402

TOOL_VERSION = '6.6.0'
ROUTE = 'buffer-bf'

# Proven-input gate, data-driven: the input identifiers for
# which transcription is proven live in data/proven_inputs.json
# (fixture data, sha-verified at load like every other fixture
# below). NO input sha literal appears in route code: an input
# not listed there takes the runner-capture path, and if that
# fails it exits 2 instead of emitting an unverified PARTIAL.

# Fixture manifest shas (case outputs, verified at copy time).
FIXTURE_SHAS = {
    'protos_v3.json':
        '489fd6797b54a2591603e31efc295b12cffc36ca2631d4687679891742254430',
    'fill_keystream.json':
        'b1248a2fd740be814e787c7097494c1907551c4eeaf6f76669ceab1577a61b30',
    'hangs_p4.json':
        '68517221ebd03ddab960e8b2d41b863985a22580677ca327ae71b6eca8fd7ec0',
    'seeds_p4.json':
        'c2b4fc47b495b8470bfbebfc7dfb4331454c1a3c7277f6481d65933752f65f9d',
    'pool_states.json':
        'a9b21b56906aab68336021604395d484a57f209483fe7c9faec466e0d1d24b7c',
    'loop2_states.json':
        '93488c1b3466cd3ba1aac8ec89356089bb622edce95f3cd5d5cdf0e542a1b573',
    'loop81_states.json':
        '99e70ca66850eb9519a70d4c3d0982dbeabae8444dcaceb97f12d08aa1e95a8b',
    'loop131_states.json':
        'f76128ac81bd83fdb5c9db0fc817cc8cf43ba05947fc68d6d329cf8f9a64d461',
    'proven_inputs.json':
        '18a1c5de76b1fe19602585479d0a3bc642213079b8136db95f07fc8d0dc34ac5',
}

# Expected proto table (spec section 2): index, entry, nconsts,
# body label, S, r, p, T lengths. Body None = proto 12, whose
# body bytes were never captured (arrays only).
EXPECTED_PROTOS = [
    (0, 10110, 180, 'buf4', 10147, 10145, 10146, 10146),
    (1, 44, 33, 'buf23', 92, 94, 92, 95),
    (2, 49, 40, 'buf25', 143, 143, 144, 144),
    (3, 492, 26, 'buf27', 2117, 2117, 2113, 2116),
    (4, 402, 44, 'buf29', 733, 733, 733, 735),
    (5, 28, 14, 'buf36', 64, 66, 65, 63),
    (6, 4, 10, 'buf38', 34, 35, 34, 34),
    (7, 12, 14, 'buf40', 202, 202, 200, 201),
    (8, 152, 18, 'buf42', 248, 251, 250, 251),
    (9, 128, 31, 'buf44', 246, 244, 245, 245),
    (10, 3, 34, 'buf46', 53, 53, 56, 56),
    (11, 45, 47, 'buf64', 786, 785, 786, 789),
    (12, 6, 44, None, 818, 818, 816, 816),
]

# Pool name -> array name (spec section 2a mapping).
POOL_ARRAY = {'_': 'p', 'g': 'r', 'f': 'S', 'X': 'T'}

# Reconciled gap list (spec section 3, verbatim in substance).
# Statuses: OPEN / PARTLY-CLOSED / BLOCKED -- never softened.
GAPS = [
    {'id': 'buf3_section_grammar', 'status': 'OPEN',
     'detail': 'Buf3 section grammar not decoded; 38125 bytes of '
               'buf3 unread (phase-1 coverage 109976/148101); the '
               'mapping from an encoded buf3 section to a decoded '
               'body is not decoded. This is the key to coverage '
               'of never-loaded protos.'},
    {'id': 'proto12_body', 'status': 'OPEN',
     'detail': 'Proto 12 (entry 6, 818 slots) arrays only; its body '
               'bytes were not found in the buffer log or as plain '
               'varints in buf3. Marked body: null / unvalidated.'},
    {'id': 'proto45_x_discrepancy', 'status': 'OPEN',
     'detail': 'Proto 45 X: factory pool [-1] length 786 vs '
               'phase-1 T length 789 -- 3 excess slots. Either the '
               'T parse over-counted by 3 or 3 T slots have no '
               'backing pool key. Flagged, not reconciled.'},
    {'id': 'nested_f319_and_unresolved_f', 'status': 'OPEN',
     'detail': 'NESTED F=319 proto-vs-helper unresolved (deferred '
               'by choice in phase 4); 9 unresolved F values: 1, 7, '
               '11, 14, 15, 36, 121, 319, 957. Do NOT claim 9 new '
               'protos.'},
    {'id': 'mq_seeds_live_coverage', 'status': 'PARTLY-CLOSED',
     'detail': 'Decrypt/expand FORMULAS proven (decrypt segments '
               '60/60; forward simulation 284 matched of 287 '
               'scored, 3 trace-attribution mismatches, 22 skips); '
               'live coverage partial: decrypt sites A16, B90, '
               'C50 never fired (source-only), several expands '
               'never fired, loop-D target ops 0 events in 240 s, '
               'and per-instance live M/q still require an op-leaf '
               'trace at lift time.'},
    {'id': 'sub_proto_completion', 'status': 'PARTLY-CLOSED',
     'detail': '8/12 sub-protos COMPLETE; 4 PARTIAL (hang-bounded); '
               'main g/f continuations never attempted in phase '
               '3/4. Exact per-pool table is in qa_report.json.'},
    {'id': 'structured_lift', 'status': 'BLOCKED',
     'detail': 'No structured executable lift: data-dependent '
               'jumps, phase-switches to three other loops, and '
               'expand/decrypt rewrites mean static structuring '
               'without M/Q seeds plus an execution trace would '
               'render pre-expansion code as if final. Ceiling '
               'is the annotated listing (comments over data '
               'tables, NOT executable code). Requires a verified '
               'post-expand model as oracle, stack-aware '
               'attribution for nested-call returns, and a '
               'per-instance array model for multi-call protos.'},
    {'id': 'section_suffix_header_trailer_semantics', 'status': 'OPEN',
     'detail': 'Section-suffix / header-u32 / trailer semantics '
               'opaque in the parser. The header-u32 = M/q '
               'numerical match is a testable hypothesis only, '
               'never used as a seed source.'},
    {'id': 'sub_proto_table_constants', 'status': 'OPEN',
     'detail': 'Sub-proto table constants NOT dumped (only main _ '
               'was in scope: 346 tables, 3066 pairs, 100% '
               'number-to-number).'},
    {'id': 'function_constant_mapping', 'status': 'PARTLY-CLOSED',
     'detail': 'Function-constant mapping partial: 32 NESTED '
               'mappings observed of 59 sub function constants; '
               '27 unmapped (likely cache hits or paths that did '
               'not emit NESTED).'},
    {'id': 'count_delta_str_entries', 'status': 'OPEN',
     'detail': 'Count delta unreconciled: 19218 typed-str entries '
               'in protos_v3.json as stored vs 19135 quoted in '
               'the case report section 11.6 (delta 83). The '
               'substantive results reproduce exactly (231 '
               'distinct strings; sole hub-pattern hit '
               'HttpService; 2 non-ASCII distinct values), so '
               'the hub-negative conclusion does not depend on '
               'the delta -- but neither entry count is used as '
               'a golden until reconciled.'},
    {'id': 'hub_strings', 'status': 'OPEN',
     'detail': 'Hub-specific strings NOT recovered: not in any '
               'factory-time harvested pool, not in decrypt '
               'regions reached in 240 s, not in buffer string '
               'traffic. Remaining hypotheses (execution-phase '
               'register values, unharvested fragments, '
               'runtime-constructed strings, buf3 unread '
               'sections, proto 12 body) are open work.'},
    {'id': 'loop_d_live_verification', 'status': 'OPEN',
     'detail': 'Loop-D target ops never fired in 240 s of '
               'tracing; loop-D formulas are source-derived '
               'until a longer or differently-seeded execution '
               'fires them.'},
    {'id': 'runner_gate_generalization', 'status': 'PARTLY-CLOSED',
     'detail': 'Grammar-evidence routing + mock-env runner capture '
               'are proven on synthetic BF-family controls only '
               '(captured bodies parsed by the real grammar, '
               'artifacts derived from the capture). BF-Main '
               'itself still uses proven-input transcription; a '
               'live BF-Main capture was not run in this phase '
               '(raw BF-Main spins in its hub loop under a mock '
               'env per phase-3/4 evidence, so executing it for '
               'capture would not have produced a body harvest). '
               'Unseen BF-family files without a successful '
               'capture still exit 2.'},
]

HUB_PATTERN = re.compile(
    r'http|discord|github|raw\.|\.com|\.gg|\.dev|webhook|api', re.I)
HANG_RE = re.compile(r'^(\S+) ([_gfX])(\d+)$')

BF_ARTIFACTS = ('report.md', 'bf_protos.json', 'bf_annotated.luau',
                'qa_report.json', 'folded.luau', 'fill_keystream.json')


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


def _load_json(name):
    with open(os.path.join(DATA_DIR, name), encoding='utf-8') as f:
        return json.load(f)


def _version_header(src):
    """Same rule as the method route: Luraph version header in a
    `--` comment line within the first 2000 chars."""
    m = re.search(r'(?m)^[ \t]*--.*Luraph Obfuscator v([0-9.]+)',
                  src[:2000])
    return m.group(1) if m else None


def _is_structural(src):
    return ('string.unpack' in src
            and ('[==[' in src or '[=[' in src)
            and bool(re.search(r'\}\)\.t\(', src)))


def _luau_compile_ok(luau, path):
    if not luau:
        return None
    d = os.path.dirname(luau)
    comp = next((os.path.join(d, n) for n in ('luau-compile',
                                              'luau-compile.exe')
                 if os.path.exists(os.path.join(d, n))), None)
    if not comp:
        return None
    try:
        r = subprocess.run([comp, path], capture_output=True, timeout=120)
        return r.returncode == 0
    except Exception:
        return None


def _write_rejected(outdir, reason, input_bytes, sha, extra=None):
    """Exit-2 path: ONLY report.md survives (stale BF artifacts
    from any earlier run in the same outdir are removed)."""
    for name in BF_ARTIFACTS:
        p = os.path.join(outdir, name)
        if name != 'report.md' and os.path.isfile(p):
            os.remove(p)
    with open(os.path.join(outdir, 'report.md'), 'w',
              encoding='utf-8') as f:
        f.write('# luraph-v151-deobf report -- buffer-bf variant\n\n')
        f.write(f'- input: {input_bytes} bytes, sha256 `{sha}`\n')
        f.write('- route: buffer-bf (headered buffer build)\n')
        f.write('- status: **REJECTED** -- ' + reason + '\n')
        if extra:
            f.write(extra)
        f.write('\nNo lifted file, no bf_protos.json and no PARTIAL '
                'qa_report were written: a misrouted or unproven '
                'file must never be reported as PARTIAL.\n')
    print(f'verdict: REJECTED ({reason}) -> {outdir}')
    return 2


def _validate_static(src):
    """Static validation for the BF stage. Returns (ok, reason)."""
    if _version_header(src) != '15.1':
        return False, 'not a v15.1-headered file'
    if _is_structural(src):
        return False, ('structural v15.1 fingerprint present: '
                       'method pipeline file misdispatched to '
                       'buffer-bf')
    reads = set(re.findall(r'buffer\.(read\w+)', src))
    writes = set(re.findall(r'buffer\.(write\w+)', src))
    if len(reads) < 5:
        return False, ('handler-table read-family validation '
                       f'failed: {len(reads)} distinct read '
                       'literals (< 5)')
    if len(writes) < 5:
        return False, ('handler-table write-family validation '
                       f'failed: {len(writes)} distinct write '
                       'literals (< 5)')
    return True, (f'read family {len(reads)} literals, write '
                  f'family {len(writes)} literals')


def _validate_fixtures():
    """Load bundled data, verify shas, validate metrics.

    Returns (data, metrics) or raises ValueError with the first
    problem (fail-closed: the caller exits 2)."""
    for name, want in FIXTURE_SHAS.items():
        got = sha256_file(os.path.join(DATA_DIR, name))
        if got != want:
            raise ValueError(
                f'fixture {name} sha mismatch: got {got}, '
                f'expected {want} (data corrupt or replaced)')
    protos_doc = _load_json('protos_v3.json')
    protos = protos_doc['protos']
    if len(protos) != 13:
        raise ValueError(f'fixture protos: {len(protos)} != 13')
    for (idx, entry, nconsts, body, ns, nr, np_, nt) in EXPECTED_PROTOS:
        p = protos[idx]
        got = (p['index'], p['entry'], p['nconsts'], p['body'],
               len(p['S']), len(p['r']), len(p['p']), len(p['T']))
        want = (idx, entry, nconsts, body, ns, nr, np_, nt)
        if got != want:
            raise ValueError(f'proto {idx} mismatch: got {got}, '
                             f'expected {want}')
    total_s = sum(len(p['S']) for p in protos)
    if total_s != 15683:
        raise ValueError(f'total S slots {total_s} != 15683')
    s_ge80 = sum(1 for p in protos for v in p['S'] if v >= 80)
    if s_ge80 != 8238:
        raise ValueError(f'all-proto S>=80 {s_ge80} != 8238')
    main_ge80 = sum(1 for v in protos[0]['S'] if v >= 80)
    if main_ge80 != 5738:
        raise ValueError(f'main S>=80 {main_ge80} != 5738')
    op17 = sum(1 for p in protos for v in p['S'] if v == 17)
    if op17 != 80:
        raise ValueError(f'op17 total {op17} != 80')
    main_op17 = sum(1 for v in protos[0]['S'] if v == 17)
    if main_op17 != 39:
        raise ValueError(f'main op17 {main_op17} != 39')
    if protos[12]['body'] is not None:
        raise ValueError('proto 12 body must be null (unvalidated)')
    pool_states = _load_json('pool_states.json')
    if len(pool_states) != 181 or '180' not in pool_states:
        raise ValueError('pool_states fixture must have 181 keys '
                         '0-180 (180 = default leaf)')
    loop2 = _load_json('loop2_states.json')
    loop81 = _load_json('loop81_states.json')
    loop131 = _load_json('loop131_states.json')
    if len(loop2) != 91 or len(loop81) != 159 or len(loop131) != 74:
        raise ValueError('loop fixtures key counts != 91/159/74')
    fill = _load_json('fill_keystream.json')
    if (fill.get('period_words') != 64 or fill.get('pairs') != 13518
            or fill.get('reconstructed') != 13518
            or len(fill.get('keystream30', [])) != 64):
        raise ValueError('fill_keystream fixture does not record '
                         '64 words / 13518 / 13518')
    hangs = _load_json('hangs_p4.json')
    if (hangs.get('confirmed_total') != 16
            or len(hangs.get('confirmed_all', [])) != 16):
        raise ValueError('hang ledger must confirm exactly 16 keys')
    seeds = formulas_mod.load_seeds()
    metrics = {
        'protos': 13, 'total_s_slots': total_s,
        's_ge80_all': s_ge80, 's_ge80_main': main_ge80,
        'op17_total': op17, 'op17_main': main_op17,
        'decrypt_sites': seeds['decrypt_sites'],
        'inplace_expands': seeds['inplace_expands'],
        'forward_expands': seeds['forward_expands'],
        'forward_simulation': seeds['forward_simulation'],
    }
    data = {'protos_doc': protos_doc, 'protos': protos,
            'pool_states': pool_states, 'loop2': loop2,
            'loop81': loop81, 'loop131': loop131,
            'fill': fill, 'hangs': hangs, 'seeds': seeds}
    return data, metrics


def _literal_maps(data):
    """Return (per-proto literal dicts, hang set, entry->index).

    Literal dicts are flat: keys like '_[721]', 'g[372]'.
    Hang set entries are (proto_index, pool, key)."""
    protos = data['protos']
    entry_to_idx = {p['entry']: p['index'] for p in protos}
    entry_to_idx[10110] = 0
    maps = []
    for p in protos:
        if p['index'] == 0:
            maps.append(p.get('literals_main', {}))
        else:
            maps.append(p.get('literals_sub', {}))
    hangs = set()
    for item in data['hangs'].get('confirmed_all', []):
        m = HANG_RE.match(item)
        if not m:
            continue
        label, pool, key = m.group(1), m.group(2), int(m.group(3))
        if label == 'main':
            idx = 0
        else:
            idx = entry_to_idx.get(int(label))
        if idx is not None:
            hangs.add((idx, pool, key))
    return maps, hangs, entry_to_idx


def _pool_counts(protos, maps):
    """Per-proto per-pool harvested/total/hang counts."""
    out = []
    for p, lit in zip(protos, maps):
        totals = {'_': len(p['p']), 'g': len(p['r']),
                  'f': len(p['S']), 'X': len(p['T'])}
        harvested = {pool: 0 for pool in totals}
        types = {pool: {} for pool in totals}
        for key, ent in lit.items():
            m = re.match(r'^([_gfX])\[(\d+)\]$', key)
            if not m or not isinstance(ent, dict):
                continue
            pool = m.group(1)
            harvested[pool] += 1
            t = ent.get('type', 'unknown')
            types[pool][t] = types[pool].get(t, 0) + 1
        out.append({'index': p['index'], 'entry': p['entry'],
                    'harvested': harvested, 'totals': totals,
                    'types': types})
    return out


def _render_literal(lit, pool, key, idx, maps_hang):
    """Compact rendering of one literal entry for the listing.

    Missing keys render HANG (confirmed hang) or
    NOT_HARVESTED; ERR entries keep their error class, not
    their full message, in the per-pc line (full text lives
    in bf_protos.json)."""
    if lit is None:
        return 'HANG' if (idx, pool, key) in maps_hang else \
            'NOT_HARVESTED'
    t = lit.get('type')
    if t == 'ERR':
        return 'ERR'
    if t == 'str':
        v = lit.get('value', '')
        v = ''.join(ch if (ch.isprintable() or ch == ' ') else '?'
                    for ch in str(v))
        if len(v) > 48:
            return '"%s"... len=%s' % (v[:48], lit.get('len', len(v)))
        return '"%s"' % v
    if t == 'num':
        return str(lit.get('value'))
    if t == 'bool':
        return str(lit.get('value'))
    if t == 'table':
        return 'table'
    if t == 'function':
        if pool == '_' and key == 721:
            return 'function: entry-10110 self-reference'
        return 'function'
    return str(t)


def _clean_comment(text):
    return ''.join(ch if (ch not in '\n\r' and (ch.isprintable()
                    or ord(ch) > 127)) else '?' for ch in str(text))


def _build_annotated(data, maps, hangs, metrics):
    """v3-style annotated listing: data tables + one comment
    line per pc per proto. Comments over data tables, NOT
    executable code. Pre-expansion instructions are shown
    PRE-expansion and labelled as such: expand/decrypt pcs
    are runtime-rewritten and must never be read as final
    code (see header)."""
    protos = data['protos']
    loop2, loop81, loop131 = data['loop2'], data['loop81'], data['loop131']
    lines = []
    lines.append('-- bf_annotated.luau -- buffer-bf route, '
                 + TOOL_VERSION)
    lines.append('-- verdict: PARTIAL (exit 5). This is an ANNOTATED '
                 'LISTING, not executable code and not a structured '
                 'lift: per-pc comments over proto data tables.')
    lines.append('-- Hub strings: NOT recovered. The only '
                 'hub-pattern hit in all harvested literals is the '
                 'standard service name HttpService, which is NOT '
                 'a hub identifier, URL or endpoint. Zero URLs, '
                 'zero discord/github/raw domains, zero webhooks, '
                 'zero game/feature names.')
    lines.append('-- Pre-expansion warning: S/r/p/T arrays below '
                 'are PRE-expansion. Expand (in-place/forward) and '
                 'decrypt leaves rewrite instructions at runtime; '
                 'never present a pre-expansion pc as final code.')
    lines.append('-- Factory-time warning: literal values are '
                 'factory-time harvest values. Values at '
                 'execution-used pcs remain provisional where '
                 'execution-phase state could differ '
                 '(cache-pollution warning). ERR/HANG/'
                 'NOT_HARVESTED are shown explicitly, never dropped.')
    lines.append('-- Pool annotation: pools@{pc} renders the pool '
                 'entries at the pc POSITION (pool key = pc+1), '
                 'not an operand claim. Pool mapping: _ <-> p, '
                 'g <-> r, f <-> S, X <-> T.')
    lines.append('-- Gaps (full list in qa_report.json): buf3 '
                 'section grammar OPEN; proto 12 body OPEN; 45 X '
                 '3-slot discrepancy OPEN; NESTED F=319 + 9 '
                 'unresolved F values OPEN; structured lift '
                 'BLOCKED; sub-proto tables undumped; 27/59 '
                 'function constants unmapped.')
    lines.append('-- Loop opcode sources: A from S, B from T, '
                 'C from p, D from S. Loop A default >= 80 = '
                 'INDEX. Pool entry state 164, default -> 54, '
                 'cache states 59 (write) / 110 (return).')
    for p, lit in zip(protos, maps):
        idx = p['index']
        lines.append('')
        lines.append('-- proto %d: entry %s, nconsts %s, body %s, '
                     'S=%d r=%d p=%d T=%d' % (
                         idx, p['entry'], p['nconsts'], p['body'],
                         len(p['S']), len(p['r']), len(p['p']),
                         len(p['T'])))
        if p['body'] is None:
            lines.append('--   body: null / unvalidated (arrays '
                         'only; body bytes never captured)')
        for arr in ('S', 'r', 'p', 'T'):
            vals = p[arr]
            lines.append('local bf_p%d_%s = {' % (idx, arr))
            for j in range(0, len(vals), 16):
                lines.append('  ' + ', '.join(str(v) for v in
                                              vals[j:j + 16]) + ',')
            lines.append('}')
        for pc in range(len(p['S'])):
            s_val = p['S'][pc]
            r_val = p['r'][pc] if pc < len(p['r']) else None
            p_val = p['p'][pc] if pc < len(p['p']) else None
            t_val = p['T'][pc] if pc < len(p['T']) else None
            aop = tables_mod.loop_a_op(s_val)
            b_txt = tables_mod.loop_leaf_first_line(
                loop2, t_val, tables_mod.LOOP_B) if t_val is not None \
                else 'n/a'
            c_txt = tables_mod.loop_leaf_first_line(
                loop81, p_val, tables_mod.LOOP_C) if p_val is not None \
                else 'n/a'
            d_txt = tables_mod.loop_leaf_first_line(
                loop131, s_val, tables_mod.LOOP_D)
            pos = pc + 1
            lits = []
            for pool, arr_vals in (('_', p['p']), ('g', p['r']),
                                   ('f', p['S']), ('X', p['T'])):
                ent = lit.get('%s[%d]' % (pool, pos))
                lits.append('%s=%s' % (
                    pool, _render_literal(ent, pool, pos, idx, hangs)))
            lines.append('-- pc %d | S=%s (%s) r=%s p=%s T=%s | '
                         'B:%s | C:%s | D:%s | pools@%d: %s' % (
                             pc, s_val, aop, r_val, p_val, t_val,
                             _clean_comment(b_txt),
                             _clean_comment(c_txt),
                             _clean_comment(d_txt), pos,
                             ' '.join(lits)))
    lines.append('')
    lines.append('-- end of annotated listing: %d protos, %d '
                 'instruction slots (S entries), verdict PARTIAL.'
                 % (len(protos), metrics['total_s_slots']))
    return '\n'.join(lines) + '\n'


def _load_proven_inputs():
    """Proven-input sha set, loaded from fixture data (never a
    literal in route code). Raises ValueError when the fixture
    is missing or malformed -- the caller fail-closes."""
    doc = _load_json('proven_inputs.json')
    entries = doc.get('proven_inputs')
    if not isinstance(entries, list):
        raise ValueError('proven_inputs.json malformed')
    out = set()
    for ent in entries:
        if not isinstance(ent, dict) or not isinstance(
                ent.get('sha256'), str):
            raise ValueError('proven_inputs.json entry malformed')
        out.add(ent['sha256'])
    return out


def _build_runner_annotated(protos, capture_summary):
    """Loop-A annotated listing for runner-captured protos.
    Loop B/C/D fixture leaves are BF-Main fixtures and are NOT
    applied to an unseen file: only the generic loop-A opcode
    name (from tables.py) is shown per pc, plus the raw arrays.
    Comments over data tables, NOT executable code."""
    lines = []
    lines.append('-- bf_annotated.luau -- buffer-bf route, '
                 + TOOL_VERSION)
    lines.append('-- verdict: PARTIAL (exit 5). This is an ANNOTATED '
                 'LISTING from a mock-env runner capture, not '
                 'executable code and not a structured lift.')
    lines.append('-- Hub strings: NOT recovered. This capture path '
                 'harvests body arrays only; no string literals '
                 'were captured or invented for this input.')
    lines.append('-- Loop annotation: loop-A opcode names only. '
                 'Loop B/C/D leaves are BF-Main fixture data and '
                 'are deliberately not applied here.')
    lines.append('-- Capture: %s' % capture_summary)
    total = 0
    for p in protos:
        total += len(p['S'])
        lines.append('')
        lines.append('-- proto %d: entry %s, nconsts %s, body %s, '
                     'buffer %s, S=%d r=%d p=%d T=%d' % (
                         p['index'], p['entry'], p['nconsts'],
                         p['body'], p['buffer_id'], len(p['S']),
                         len(p['r']), len(p['p']), len(p['T'])))
        for arr in ('S', 'r', 'p', 'T'):
            vals = p[arr]
            lines.append('local bf_p%d_%s = {' % (p['index'], arr))
            for j in range(0, len(vals), 16):
                lines.append('  ' + ', '.join(str(v) for v in
                                              vals[j:j + 16]) + ',')
            lines.append('}')
        for pc in range(len(p['S'])):
            s_val = p['S'][pc]
            r_val = p['r'][pc] if pc < len(p['r']) else None
            p_val = p['p'][pc] if pc < len(p['p']) else None
            t_val = p['T'][pc] if pc < len(p['T']) else None
            lines.append('-- pc %d | S=%s (%s) r=%s p=%s T=%s'
                         % (pc, s_val, tables_mod.loop_a_op(s_val),
                            r_val, p_val, t_val))
    lines.append('')
    lines.append('-- end of annotated listing: %d protos, %d '
                 'instruction slots (S entries), verdict PARTIAL.'
                 % (len(protos), total))
    return '\n'.join(lines) + '\n'


def _runner_path(src, data, outdir, luau, sha, static_reason):
    """Runner-capture path for unseen BF-family files. Any
    capture/parse failure -> exit 2 via _write_rejected. Success
    -> exit 5 with artifacts derived from the capture."""
    workdir = os.path.join(outdir, '_runner_tmp')
    try:
        capture = runner_mod.run_proxy_capture(src, luau, workdir)
    except Exception as e:
        shutil.rmtree(workdir, ignore_errors=True)
        return _write_rejected(
            outdir, 'runner capture failed: ' + repr(e),
            len(data), sha)
    try:
        protos = runner_mod.parse_captured_protos(capture)
    except Exception as e:
        shutil.rmtree(workdir, ignore_errors=True)
        return _write_rejected(
            outdir, 'runner capture did not validate: ' + repr(e),
            len(data), sha)
    # Fold audit artifact (compile result recorded, not gated).
    try:
        import fold as fold_mod
        folded = fold_mod.fold_source(src)
    except Exception as e:
        print(f'[buffer-bf] fold failed (audit artifact only): {e}')
        folded = src
    folded_path = os.path.join(outdir, 'folded.luau')
    with open(folded_path, 'w', encoding='utf-8') as f:
        f.write(folded)
    folded_ok = _luau_compile_ok(luau, folded_path)
    print(f'[buffer-bf] fold: {len(src)} -> {len(folded)} bytes; '
          f'luau-compile folded: {folded_ok}')
    total_s = sum(len(p['S']) for p in protos)
    capture_summary = ('%d protos from %d buffer snapshots, '
                       'chunk_ok=%s, timed_out=%s'
                       % (len(protos), len(capture['buffers']),
                          capture['chunk_ok'], capture['timed_out']))
    bf_protos = {
        'format': 'bf-protos-runner-v1',
        'route': ROUTE,
        'tool_version': TOOL_VERSION,
        'input_bytes': len(data),
        'input_sha256': sha,
        'provenance': {
            'mechanism': 'mock-env runner capture: buffer '
                         'snapshots + factory descriptors parsed '
                         'by the body grammar with exact '
                         'consumption and descriptor cross-checks',
            'capture': capture_summary,
            'buffers': sorted(capture['buffers']),
        },
        'protos': protos,
    }
    with open(os.path.join(outdir, 'bf_protos.json'), 'w',
              encoding='utf-8') as f:
        json.dump(bf_protos, f, indent=1, sort_keys=True,
                  ensure_ascii=False)
    annotated = _build_runner_annotated(protos, capture_summary)
    annotated_path = os.path.join(outdir, 'bf_annotated.luau')
    with open(annotated_path, 'w', encoding='utf-8') as f:
        f.write(annotated)
    ann_ok = _luau_compile_ok(luau, annotated_path)
    print(f'[buffer-bf] runner annotated: {len(annotated)} bytes, '
          f'{total_s} pcs; luau-compile: {ann_ok} (syntax only)')
    literals = []
    for p in protos:
        literals.append({'index': p['index'], 'entry': p['entry'],
                         'harvested': {'_': 0, 'g': 0, 'f': 0,
                                       'X': 0},
                         'totals': {'_': len(p['p']),
                                    'g': len(p['r']),
                                    'f': len(p['S']),
                                    'X': len(p['T'])},
                         'types': {}})
    qa = {
        'verdict': 'PARTIAL',
        'exit': 5,
        'route': ROUTE,
        'tool_version': TOOL_VERSION,
        'input_bytes': len(data),
        'input_sha256': sha,
        'hub_strings_recovered': False,
        'structured_lift': False,
        'mechanism': 'mock-env runner capture; body arrays '
                     'derived from captured buffers, literals not '
                     'harvested on this path and never invented',
        'body_grammar_validation': {
            'note': 'Captured bodies parsed by the body grammar '
                    'with exact consumption; descriptor nconsts '
                    'and entry cross-checked against the parsed '
                    'body; each descriptor matched a distinct '
                    'buffer.',
            'protos_validated': len(protos),
            'proto12_body': 'not applicable to runner path',
            'header_shape': 'varint(2) varint(nconsts) '
                            'varint(150) varint(2) + 2x u32',
            'sections': 'p/r/S/T in VM-varint with opaque '
                        'suffixes; exact-consumption enforced '
                        'by the grammar parser',
        },
        'runner_capture': {
            'buffers': sorted(capture['buffers']),
            'descriptors': capture['descriptors'],
            'chunk_ok': capture['chunk_ok'],
            'timed_out': capture['timed_out'],
            'protos_parsed': len(protos),
        },
        'metrics': {
            'protos': len(protos),
            'total_s_slots': total_s,
            'distinct_strings': 0,
            'hub_pattern_hits': [],
            'nonascii_distinct': 0,
            'luau_compile_folded': folded_ok,
            'luau_compile_annotated': ann_ok,
        },
        'literals': literals,
        'hangs_confirmed': [],
        'gaps': GAPS,
        'defects_not_fixed': [
            {'category': 'literals_not_harvested',
             'detail': 'Runner path captures body arrays only; '
                       'pool literals were not harvested for this '
                       'input, so no string claims are made.'},
            {'category': 'structured_lift_missing',
             'detail': 'Annotated listing only; no structured '
                       'executable lift is produced on this path.'},
        ],
        'identity_report': 'absent by design: the spoof stage is '
                           'not applicable to runner-captured '
                           'controls; no identity artifact was '
                           'fabricated',
    }
    with open(os.path.join(outdir, 'qa_report.json'), 'w',
              encoding='utf-8') as f:
        json.dump(qa, f, indent=1, sort_keys=True, ensure_ascii=False)
    with open(os.path.join(outdir, 'fill_keystream.json'), 'w',
              encoding='utf-8') as f:
        json.dump({'route': ROUTE, 'tool_version': TOOL_VERSION,
                   'fill_captured': False,
                   'note': 'No buf4 fill was captured on the runner '
                           'path; the BF-Main keystream block is '
                           'fixture-specific and is not copied '
                           'into a runner artifact.'},
                  f, indent=1, sort_keys=True)
    gap_lines = '\n'.join(
        '- gap %s [%s]: %s' % (g['id'], g['status'], g['detail'])
        for g in GAPS)
    with open(os.path.join(outdir, 'report.md'), 'w',
              encoding='utf-8') as f:
        f.write('# luraph-v151-deobf report -- buffer-bf variant\n\n')
        f.write(f'- input: {len(data)} bytes, sha256 `{sha}`\n')
        f.write('- route: buffer-bf (headered buffer build, '
                'v15.1 header, non-structural)\n')
        f.write(f'- static validation: {static_reason}\n')
        f.write('- body-grammar validation: ' + capture_summary
                + '; captured bodies parsed with exact consumption '
                  'and descriptor cross-checks\n')
        f.write('- hub strings: NOT recovered. No string literals '
                'were captured on this path and none are claimed.\n')
        f.write('- structured lift: NOT produced (BLOCKED, see '
                'gaps). bf_annotated.luau is comments over data '
                'tables; luau-compile exit 0 means syntax only, '
                'never executability.\n')
        f.write('- mechanism note: this run used the mock-env '
                'runner-capture path (buffer snapshots + factory '
                'descriptors, parsed by the body grammar). It did '
                'not use proven-input transcription and did not '
                'invent any literal, string or proto.\n')
        f.write('- identity_report.json: absent by design (spoof '
                'stage not applicable; no artifact fabricated).\n')
        f.write('- status: **PARTIAL** (exit 5)\n\n')
        f.write('## Gaps\n\n' + gap_lines + '\n')
        f.write('\nOutputs: report.md, bf_protos.json, '
                'bf_annotated.luau, qa_report.json, folded.luau, '
                'fill_keystream.json\n')
    shutil.rmtree(workdir, ignore_errors=True)
    print('verdict: PARTIAL')
    for g in GAPS:
        print('gap: %s [%s]' % (g['id'], g['status']))
    print(f'done (PARTIAL buffer-bf runner) -> {outdir}')
    return 5


def buffer_bf_route(src, data, outdir, luau, sha, spoof_id='auto',
                    qa_flag='on'):
    os.makedirs(outdir, exist_ok=True)
    ok, reason = _validate_static(src)
    if not ok:
        return _write_rejected(outdir, 'static validation failed: '
                               + reason, len(data), sha)
    try:
        proven = _load_proven_inputs()
    except Exception as e:
        return _write_rejected(outdir, 'proven-input fixture '
                               'failed: ' + repr(e), len(data), sha)
    if sha not in proven:
        return _runner_path(src, data, outdir, luau, sha, reason)
    try:
        fdata, metrics = _validate_fixtures()
    except Exception as e:
        return _write_rejected(outdir, 'fixture validation failed: '
                               + repr(e), len(data), sha)
    maps, hangs, _entry_to_idx = _literal_maps(fdata)
    pool_counts = _pool_counts(fdata['protos'], maps)

    # Distinct-string / hub-pattern / non-ASCII audit, computed
    # from the transcribed literals (never from a stored count).
    distinct = set()
    for lit in maps:
        for ent in lit.values():
            if isinstance(ent, dict) and ent.get('type') == 'str':
                v = ent.get('value')
                if isinstance(v, str):
                    distinct.add(v)
    hub_hits = sorted(v for v in distinct if HUB_PATTERN.search(v))
    nonascii = sorted(v for v in distinct
                      if any(ord(ch) > 127 for ch in v))
    str_entries = sum(
        1 for lit in maps for ent in lit.values()
        if isinstance(ent, dict) and ent.get('type') == 'str')
    if len(distinct) != 231 or hub_hits != ['HttpService'] \
            or len(nonascii) != 2:
        return _write_rejected(
            outdir,
            'literal audit failed: distinct=%d hub_hits=%r '
            'nonascii=%d (expected 231 / [HttpService] / 2)'
            % (len(distinct), hub_hits, len(nonascii)),
            len(data), sha)

    # folded.luau (audit artifact; compile result recorded, not
    # a gate -- same rule as the old buffer route's folded file).
    folded = None
    folded_ok = None
    try:
        import fold as fold_mod
        folded = fold_mod.fold_source(src)
    except Exception as e:
        print(f'[buffer-bf] fold failed (audit artifact only): {e}')
        folded = src
    folded_path = os.path.join(outdir, 'folded.luau')
    with open(folded_path, 'w', encoding='utf-8') as f:
        f.write(folded)
    folded_ok = _luau_compile_ok(luau, folded_path)
    print(f'[buffer-bf] fold: {len(src)} -> {len(folded)} bytes; '
          f'luau-compile folded: {folded_ok}')

    # bf_protos.json: fixture protos verbatim + provenance.
    bf_protos = {
        'format': 'bf-protos-v1',
        'route': ROUTE,
        'tool_version': TOOL_VERSION,
        'input_bytes': len(data),
        'input_sha256': sha,
        'provenance': {
            'mechanism': 'static/transcription of the proven '
                         'phase-3/phase-4 harvest bundled under '
                         'routes/buffer_bf/data/; no live harvest '
                         'was run by this route version',
            'fixture_shas': FIXTURE_SHAS,
            'literals_source': fdata['protos_doc'].get(
                'literals_source'),
        },
        'protos': fdata['protos'],
    }
    bf_protos_path = os.path.join(outdir, 'bf_protos.json')
    with open(bf_protos_path, 'w', encoding='utf-8') as f:
        json.dump(bf_protos, f, indent=1, sort_keys=True,
                  ensure_ascii=False)

    annotated = _build_annotated(fdata, maps, hangs, metrics)
    annotated_path = os.path.join(outdir, 'bf_annotated.luau')
    with open(annotated_path, 'w', encoding='utf-8') as f:
        f.write(annotated)
    ann_ok = _luau_compile_ok(luau, annotated_path)
    print(f'[buffer-bf] annotated: {len(annotated)} bytes, '
          f'{metrics["total_s_slots"]} pcs; luau-compile: {ann_ok} '
          '(syntax only, never executability)')

    fill_src = os.path.join(DATA_DIR, 'fill_keystream.json')
    shutil.copyfile(fill_src, os.path.join(outdir,
                                            'fill_keystream.json'))

    decrypt_status = {}
    for site, ent in metrics['decrypt_sites'].items():
        decrypt_status[site] = {
            'seed_formula': ent.get('seed_formula'),
            'rewrite': ent.get('rewrite'),
            'fired_v2': ent.get('fired'),
            'status': ent.get('status'),
            'note': ent.get('note'),
        }
    hang_list = sorted(
        '%s %s%d' % (
            'main' if idx == 0 else str(fdata['protos'][idx]['entry']),
            pool, key)
        for (idx, pool, key) in hangs)
    qa = {
        'verdict': 'PARTIAL',
        'exit': 5,
        'route': ROUTE,
        'tool_version': TOOL_VERSION,
        'input_bytes': len(data),
        'input_sha256': sha,
        'hub_strings_recovered': False,
        'structured_lift': False,
        'mechanism': 'static/transcription of proven fixtures; '
                     'no live harvest, no payload execution, no '
                     'structured lift in this route version',
        'body_grammar_validation': {
            'note': 'Raw body bytes are not present in the input '
                    'file (bodies are runtime-constructed '
                    'buffers). This transcription path validates '
                    'VM-varint + section-header parsing by '
                    'synthetic round-trip (tests/check_bf.py), '
                    'fixture proto arrays for section-2a '
                    'consistency (lengths, totals, counts), and '
                    'the buf4 fill transform as a pure function. '
                    'Live body-byte parsing from a mock-env '
                    'capture exists on the runner path for unseen '
                    'inputs; this proven input was not executed '
                    'in this run.',
            'protos_validated': 13,
            'proto12_body': None,
            'header_shape': 'varint(2) varint(nconsts) '
                            'varint(150) varint(2) + 2x u32',
            'sections': 'p/r/S/T in VM-varint with opaque '
                        'suffixes; exact-consumption enforced '
                        'by the grammar parser',
        },
        'metrics': {
            'protos': metrics['protos'],
            'total_s_slots': metrics['total_s_slots'],
            's_ge80_all': metrics['s_ge80_all'],
            's_ge80_main': metrics['s_ge80_main'],
            'op17_total': metrics['op17_total'],
            'op17_main': metrics['op17_main'],
            'str_entries_as_stored': str_entries,
            'distinct_strings': len(distinct),
            'hub_pattern_hits': hub_hits,
            'nonascii_distinct': len(nonascii),
            'luau_compile_folded': folded_ok,
            'luau_compile_annotated': ann_ok,
        },
        'literals': pool_counts,
        'hangs_confirmed': hang_list,
        'gaps': GAPS,
        'defects_not_fixed': [
            {'category': 'source_only_formula',
             'detail': 'decrypt sites with 0 firings are '
                       'source-only, not live-verified: ' +
                       ', '.join(sorted(
                           s for s, e in decrypt_status.items()
                           if e['status'] == 'source-only'))},
            {'category': 'proto45_x_discrepancy',
             'detail': 'Proto 45 X factory 786 vs T length 789: '
                       '3 excess slots, unreconciled.'},
            {'category': 'proto12_body_missing',
             'detail': 'Proto 12 body bytes never captured; '
                       'arrays only, body null.'},
            {'category': 'count_delta',
             'detail': '19218 typed-str entries as stored vs '
                       '19135 quoted in the case report (delta '
                       '83, unreconciled); neither count is used '
                       'as a golden.'},
            {'category': 'main_gf_continuations',
             'detail': 'Main g (371/10145) and f (2300/10147) '
                       'continuations never attempted; hangs '
                       'g372/f2301 listed, not present as values.'},
            {'category': 'sub_proto_tables_undumped',
             'detail': 'Table constants dumped for main _ only; '
                       'sub-proto tables not dumped.'},
            {'category': 'function_constants_unmapped',
             'detail': '27/59 sub function constants unmapped.'},
            {'category': 'loop_d_unfired',
             'detail': 'Loop-D target ops 0 events in 240 s; '
                       'loop-D formulas source-derived.'},
            {'category': 'forward_simulation_artifacts',
             'detail': 'Forward simulation 284 matched of 287 '
                       'scored; 3 mismatches + 22 skips are '
                       'trace-attribution artifacts across '
                       'nested-call returns (stack-aware '
                       'attribution required for any structured '
                       'lift), not formula failures.'},
        ],
        'decrypt_formulas': decrypt_status,
        'fill_transform': {
            'period_words': 64,
            'pairs': 13518,
            'reconstructed': 13518,
            'formula': 'buf4_u32[i] = ((buf3_u32[86939+4i] >> 2) '
                       'XOR K[i mod 64]) << 2 | (buf3_u32 & 3)',
            'note': 'Proven 13518/13518 as recorded in the '
                    'fixture; periodicity proven, generator '
                    'not claimed.',
        },
        'identity_report': 'absent by design: the spoof stage is '
                           'not applicable to BF-Main (pool values '
                           'are factory-time provisional); no '
                           'identity artifact was fabricated',
    }
    with open(os.path.join(outdir, 'qa_report.json'), 'w',
              encoding='utf-8') as f:
        json.dump(qa, f, indent=1, sort_keys=True, ensure_ascii=False)

    gap_lines = '\n'.join(
        '- gap %s [%s]: %s' % (g['id'], g['status'], g['detail'])
        for g in GAPS)
    with open(os.path.join(outdir, 'report.md'), 'w',
              encoding='utf-8') as f:
        f.write('# luraph-v151-deobf report -- buffer-bf variant\n\n')
        f.write(f'- input: {len(data)} bytes, sha256 `{sha}`\n')
        f.write('- route: buffer-bf (headered buffer build, '
                'v15.1 header, non-structural)\n')
        f.write(f'- static validation: {reason}\n')
        f.write('- body-grammar validation: 13 protos validated '
                'against the section-2a consistency checks '
                '(lengths, totals, S>=80 / op17 counts); proto 12 '
                'flagged body null / unvalidated; raw body bytes '
                'are runtime-constructed and are NOT parsed from '
                'the input file on this transcription path (see '
                'mechanism note below)\n')
        f.write('- harvest coverage: main _ 10146/10146, X '
                '10146/10146, g 371/10145, f 2300/10147; '
                'sub-protos 8/12 COMPLETE, 4 PARTIAL '
                '(hang-bounded); exact per-pool table in '
                'qa_report.json\n')
        f.write('- hub strings: NOT recovered. The only '
                'hub-pattern hit in all harvested literals is the '
                'standard service name HttpService, which is NOT '
                'a hub identifier, URL or endpoint. Zero URLs, '
                'zero discord/github/raw domains, zero webhooks, '
                'zero game/feature names in any harvested pool, '
                'in decrypt regions reached in 240 s, or in '
                'buffer string traffic.\n')
        f.write('- _721 identity: the main _721 function constant '
                'is the entry-10110 function itself '
                '(self-recursive reference), never a separately '
                'named function.\n')
        f.write('- structured lift: NOT produced (BLOCKED, see '
                'gaps). bf_annotated.luau is comments over data '
                'tables; luau-compile exit 0 means syntax only, '
                'never executability.\n')
        f.write('- mechanism note: this run used proven-input '
                'transcription. It does not execute the input, '
                'does not run a mock-env capture, and does not '
                're-harvest pools at runtime. It transcribes the '
                'proven phase-3/phase-4 harvest bundled under '
                'routes/buffer_bf/data/ (fixture shas verified at '
                'load) for an input listed in '
                'data/proven_inputs.json. Unseen inputs take the '
                'runner-capture path and exit 2 when capture '
                'fails; static evidence alone never yields '
                'PARTIAL.\n')
        f.write('- identity_report.json: absent by design (spoof '
                'stage not applicable; no artifact fabricated).\n')
        f.write('- status: **PARTIAL** (exit 5)\n\n')
        f.write('## Gaps\n\n' + gap_lines + '\n')
        f.write('\nOutputs: report.md, bf_protos.json, '
                'bf_annotated.luau, qa_report.json, folded.luau, '
                'fill_keystream.json\n')
    print('verdict: PARTIAL')
    for g in GAPS:
        print('gap: %s [%s]' % (g['id'], g['status']))
    print(f'done (PARTIAL buffer-bf) -> {outdir}')
    return 5
