"""Mock-env runner pipeline for the BF-family buffer route (v6.6.0).

Three mechanisms, all under the mock-env Luau CLI (bin/luau), isolated
VM, no network, no real credentials, no real Roblox runtime:

  (a) Buffer capture via a single-pass proxy runner. The proxy is
      built in ONE loop over pairs(realBuffer): wrapping create to
      assign creation-order ids, wrapping every write/read/copy to
      log, and printing a full snapshot per buffer after the target
      chunk completes. (A second proxy loop would overwrite write
      proxies with real functions -- the phase-1 proxy bug -- so
      there is exactly one loop.) Target source is embedded as
      decimal byte escapes and loaded under an env whose buffer is
      the proxy; Instance/CFrame are stubs as in the method route.
      A target that needs a real service errors and fails capture:
      that is fail-closed, not a partial success.
  (b) Factory harvest with hang isolation. Keys are harvested in
      chunks; a chunk timeout binary-splits the chunk recursively
      until each hang is isolated to a singleton timeout. One hang
      never kills the whole harvest. Each non-hang key's value comes
      from exactly one successful chunk run.
  (c) Clean op-leaf traces. parse_op_trace consumes OPH lines from a
      run with no harvest injection (cache-pollution warning) and
      returns per-mode/per-entry coverage plus loop-A opcode names
      and decrypt-seed spot checks computed from each event's OWN
      M/q (never reused across events or instances). Sites that
      never fire stay source-only; this parser never upgrades them.

This module never imports buffer_body or buffer_lifter, never reads
fixture literals as code, and never invents a value: capture failure
raises CaptureError and the caller must exit 2.

Body grammar note: section lengths are NOT derivable from body bytes
alone (see grammar.py). A capture therefore needs a descriptor line
(BFPROTO, printed by the target's own factory metadata) giving the
section lengths; the parser still validates header shape, suffix and
marker shapes, varint decoding, exact trailer consumption, and
cross-checks descriptor nconsts and entry against the parsed body.
A descriptor that disagrees with its body is rejected.
"""

import os
import subprocess

from . import formulas as formulas_mod
from . import grammar as grammar_mod
from . import tables as tables_mod


class CaptureError(ValueError):
    pass


MAX_SNAPSHOT_BYTES = 262144
DEFAULT_CAPTURE_TIMEOUT = 60
DEFAULT_HARVEST_TIMEOUT = 10
DEFAULT_HARVEST_CHUNK = 8

# Descriptor line printed by a target's factory metadata:
#   BFPROTO <entry> <nconsts> <p_len> <r_len> <S_len> <T_len> <trailer>
# Luau print() separates arguments with tabs, so the parser splits
# on tabs (and falls back to whitespace).
PROXY_TEMPLATE = r'''
local smt = _G["setmeta" .. "table"]
local realPrint = print
local realBuffer = buffer
local proxyBuffer = {}
local ids = {}
local bufs = {}
local nextId = 0
local function hexEncode(s)
    local parts = {}
    for i = 1, #s do
        parts[i] = string.format("%02x", string.byte(s, i))
    end
    return table.concat(parts)
end
for name, fn in pairs(realBuffer) do
    if name == "create" then
        proxyBuffer[name] = function(size, ...)
            local b = fn(size, ...)
            nextId = nextId + 1
            ids[b] = nextId
            bufs[nextId] = b
            realPrint("BUF|NEW|" .. nextId .. "|" .. tostring(size))
            return b
        end
    elseif name == "copy" then
        proxyBuffer[name] = function(dst, dstOff, src, srcOff, len, ...)
            realPrint("BUF|COPY|" .. tostring(ids[dst]) .. "|" .. tostring(dstOff) .. "|" .. tostring(ids[src]) .. "|" .. tostring(srcOff) .. "|" .. tostring(len))
            return fn(dst, dstOff, src, srcOff, len, ...)
        end
    elseif type(fn) == "function" and string.sub(name, 1, 5) == "write" then
        proxyBuffer[name] = function(b, off, v, ...)
            if type(v) == "string" then
                realPrint("BUF|WR|" .. tostring(ids[b]) .. "|" .. name .. "|" .. tostring(off) .. "|HEX:" .. hexEncode(v))
            else
                realPrint("BUF|WR|" .. tostring(ids[b]) .. "|" .. name .. "|" .. tostring(off) .. "|" .. tostring(v))
            end
            return fn(b, off, v, ...)
        end
    elseif type(fn) == "function" and string.sub(name, 1, 4) == "read" then
        proxyBuffer[name] = function(b, off, ...)
            local res = { fn(b, off, ...) }
            local vals = {}
            for i = 1, #res do
                local v = res[i]
                vals[#vals + 1] = (type(v) == "string") and ("HEX:" .. hexEncode(v)) or tostring(v)
            end
            realPrint("BUF|RD|" .. tostring(ids[b]) .. "|" .. name .. "|" .. tostring(off) .. "|" .. table.concat(vals, ","))
            return table.unpack(res)
        end
    else
        proxyBuffer[name] = fn
    end
end
local function anyNew(...)
    return smt({}, {
        __index = function(_, k)
            if k == "new" then return anyNew end
            return anyNew
        end,
        __call = function() return anyNew() end,
    })
end
local env = smt({
    buffer = proxyBuffer,
    Instance = { new = function(...) return anyNew() end },
    CFrame = { new = function(...) return anyNew() end },
}, { __index = _G })
local src = "__TARGET_SOURCE__"
local chunk, err = loadstring(src, "target")
if not chunk then
    realPrint("LOADERR", err)
else
    setfenv(chunk, env)
    local ok, res = pcall(chunk)
    realPrint("CHUNK_DONE ok=", ok, "res=", tostring(res))
end
for id = 1, nextId do
    local b = bufs[id]
    local n = buffer.len(b)
    if n <= 262144 then
        local parts = {}
        for i = 0, n - 1 do
            parts[#parts + 1] = string.format("%02x", buffer.readu8(b, i))
        end
        realPrint("BUF|SNAP|" .. id .. "|" .. n .. "|" .. table.concat(parts))
    else
        realPrint("BUF|SNAP|" .. id .. "|" .. n .. "|TOO_BIG")
    end
end
'''

HARVEST_DRIVER_TEMPLATE = r'''
local keys = {__KEYS__}
for _, k in ipairs(keys) do
    local v = HARVEST_KEY(k)
    realPrint2("HARVEST|" .. tostring(k) .. "|" .. tostring(v))
end
realPrint2("HARVEST_DONE")
'''


def _escape_source(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    return ''.join('\\%03d' % b for b in data)


def run_proxy_capture(src, luau, workdir, timeout=DEFAULT_CAPTURE_TIMEOUT):
    """Run src under the proxy runner. Returns a dict with buffers
    (id -> bytes, sorted by id), descriptors (list of dicts in log
    order), chunk_ok, timed_out and the raw log text. Raises
    CaptureError only for unusable setups (missing luau binary);
    a target-side failure is reported in the dict (chunk_ok False
    or timed_out True) so the caller can fail closed with a reason.
    """
    if not luau or not os.path.exists(luau):
        raise CaptureError('Luau CLI not available for runner capture')
    os.makedirs(workdir, exist_ok=True)
    runner_path = os.path.join(workdir, 'runner_capture.luau')
    with open(runner_path, 'w', encoding='utf-8') as f:
        f.write(PROXY_TEMPLATE.replace('__TARGET_SOURCE__',
                                       _escape_source(src)))
    log_path = os.path.join(workdir, 'runner_capture.log')
    timed_out = False
    try:
        with open(log_path, 'w', encoding='utf-8') as lf:
            r = subprocess.run([luau, runner_path], stdout=lf,
                               stderr=subprocess.STDOUT, timeout=timeout)
        rc = r.returncode
    except subprocess.TimeoutExpired:
        timed_out = True
        rc = None
    with open(log_path, encoding='utf-8', errors='replace') as f:
        log_text = f.read()
    buffers = {}
    descriptors = []
    chunk_ok = False
    for line in log_text.splitlines():
        parts = line.split('\t')
        if not parts:
            continue
        head = parts[0]
        if head.startswith('BUF|SNAP|'):
            seg = line.split('|')
            if len(seg) >= 5:
                try:
                    bid = int(seg[2])
                    hexpart = seg[4]
                    if hexpart != 'TOO_BIG':
                        buffers[bid] = bytes.fromhex(hexpart)
                except ValueError:
                    pass
        elif head == 'BFPROTO' or line.startswith('BFPROTO'):
            toks = line.replace('\t', ' ').split()
            if len(toks) == 8:
                try:
                    descriptors.append({
                        'entry': int(toks[1]),
                        'nconsts': int(toks[2]),
                        'p': int(toks[3]), 'r': int(toks[4]),
                        'S': int(toks[5]), 'T': int(toks[6]),
                        'trailer': int(toks[7]),
                    })
                except ValueError:
                    pass
        elif 'CHUNK_DONE' in line and 'ok=\ttrue' in line.replace(' ', '\t'):
            chunk_ok = True
        elif 'CHUNK_DONE ok=' in line and 'true' in line:
            # Luau print separates args with tabs; the ok flag is
            # its own token in the common case.
            chunk_ok = 'ok=\ttrue' in line or 'ok= true' in line
    # The CHUNK_DONE line is printed as: CHUNK_DONE ok= <bool> res= ...
    # with tab separators, so re-scan robustly:
    for line in log_text.splitlines():
        if line.startswith('CHUNK_DONE'):
            toks = line.replace('\t', ' ').split()
            chunk_ok = any(t == 'true' for t in toks[1:3])
    return {'buffers': dict(sorted(buffers.items())),
            'descriptors': descriptors, 'chunk_ok': chunk_ok,
            'timed_out': timed_out, 'returncode': rc,
            'log_text': log_text, 'runner_path': runner_path,
            'log_path': log_path}


def parse_captured_protos(capture):
    """Match every descriptor to a distinct captured buffer and
    parse it under the body grammar. Returns a list of proto dicts
    (index/entry/nconsts/body/S/r/p/T, in descriptor order).
    Raises CaptureError on any mismatch -- never a partial list."""
    if capture.get('timed_out'):
        raise CaptureError('runner capture timed out')
    if not capture.get('chunk_ok'):
        raise CaptureError('runner chunk did not complete ok')
    descriptors = capture.get('descriptors') or []
    if not descriptors:
        raise CaptureError('no BFPROTO descriptor in capture log')
    buffers = capture.get('buffers') or {}
    if not buffers:
        raise CaptureError('no buffer snapshot in capture log')
    used = set()
    seen_entries = set()
    protos = []
    for idx, d in enumerate(descriptors):
        if d['entry'] in seen_entries:
            raise CaptureError('duplicate descriptor entry %r'
                               % d['entry'])
        seen_entries.add(d['entry'])
        if d['trailer'] not in (4, 5):
            raise CaptureError('descriptor trailer %r not 4/5'
                               % d['trailer'])
        if min(d['p'], d['r'], d['S'], d['T']) < 1:
            raise CaptureError('descriptor section length < 1')
        matched = None
        for bid in sorted(buffers):
            if bid in used:
                continue
            try:
                parsed = grammar_mod.parse_bf_body(
                    buffers[bid],
                    {'p': d['p'], 'r': d['r'], 'S': d['S'],
                     'T': d['T']}, d['trailer'])
            except Exception:
                continue
            if parsed['nconsts'] != d['nconsts']:
                continue
            if parsed['entry_pc'] != d['entry']:
                continue
            matched = (bid, parsed)
            break
        if matched is None:
            raise CaptureError(
                'descriptor entry %r matched no captured buffer'
                % d['entry'])
        bid, parsed = matched
        used.add(bid)
        secs = parsed['sections']
        protos.append({'index': idx, 'entry': d['entry'],
                       'nconsts': d['nconsts'], 'body': 'captured',
                       'buffer_id': bid,
                       'S': secs['S'], 'r': secs['r'],
                       'p': secs['p'], 'T': secs['T']})
    return protos


def run_harvest_chunk(harvest_luau, keys, luau, workdir,
                      timeout=DEFAULT_HARVEST_TIMEOUT):
    """Run one harvest chunk. harvest_luau defines HARVEST_KEY(k).
    Returns a dict key -> printed value string. Raises TimeoutError
    when the chunk does not finish in time (the hang signal)."""
    if not luau or not os.path.exists(luau):
        raise CaptureError('Luau CLI not available for harvest')
    os.makedirs(workdir, exist_ok=True)
    driver = HARVEST_DRIVER_TEMPLATE.replace(
        '__KEYS__', ', '.join(str(int(k)) for k in keys))
    script = (harvest_luau + '\nlocal realPrint2 = print\n' + driver)
    path = os.path.join(workdir, 'harvest_chunk.luau')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(script)
    try:
        r = subprocess.run([luau, path], capture_output=True, text=True,
                           timeout=timeout)
    except subprocess.TimeoutExpired:
        raise TimeoutError('harvest chunk timed out')
    values = {}
    done = False
    for line in r.stdout.splitlines():
        if line.startswith('HARVEST|'):
            seg = line.split('|', 2)
            if len(seg) == 3:
                try:
                    values[int(seg[1])] = seg[2]
                except ValueError:
                    pass
        elif line.strip() == 'HARVEST_DONE':
            done = True
    if not done or set(values) != set(int(k) for k in keys):
        raise CaptureError('harvest chunk incomplete: got %d of %d'
                           % (len(values), len(keys)))
    return values


def harvest_with_isolation(harvest_luau, keys, luau, workdir,
                           chunk_size=DEFAULT_HARVEST_CHUNK,
                           timeout=DEFAULT_HARVEST_TIMEOUT):
    """Chunked harvest with binary-split hang isolation. Returns
    (values, hangs): values maps every non-hang key to its printed
    value; hangs is the sorted list of confirmed hang keys (each
    isolated to a singleton timeout)."""
    keys = sorted(int(k) for k in keys)
    values = {}
    hangs = []

    def _harvest(chunk):
        if not chunk:
            return
        try:
            got = run_harvest_chunk(harvest_luau, chunk, luau,
                                    workdir, timeout=timeout)
            values.update(got)
            return
        except TimeoutError:
            if len(chunk) == 1:
                hangs.append(chunk[0])
                return
            mid = len(chunk) // 2
            _harvest(chunk[:mid])
            _harvest(chunk[mid:])
            return

    for i in range(0, len(keys), chunk_size):
        _harvest(keys[i:i + chunk_size])
    return values, sorted(hangs)


def decrypt_seed_for_event(event):
    """Decrypt seed for one loop-A op-leaf event, from the event's
    own M/q. event: dict with mode, S, r, p, T, M, q. Returns
    (seed, formula) or None when the event is not a loop-A
    decrypt op. Loop-A decrypts are {16, 31, 60} (op 15 is a
    handler load, op 61 a load-imm -- never decrypts)."""
    if event.get('mode') != 'A':
        return None
    op = event.get('S')
    if op == 16:
        return event.get('r'), 'r raw'
    if op == 31:
        return formulas_mod.mix29(event.get('T'), event.get('M')), \
            'M-mix29(T, M)'
    if op == 60:
        return formulas_mod.mix29(event.get('T'), event.get('q')), \
            'q-mix29(T, q)'
    return None


def parse_op_trace(log_text):
    """Parse OPH op-leaf lines: OPH|entry|mode|pc|S|r|p|T|M|q.
    Returns events (in log order), coverage {mode: count},
    per-entry counts, and decrypt seed checks for loop-A decrypt
    events. Malformed lines are skipped and counted, never
    silently treated as events."""
    events = []
    skipped = 0
    for line in log_text.splitlines():
        if not line.startswith('OPH|'):
            continue
        seg = line.split('|')
        if len(seg) != 10:
            skipped += 1
            continue
        try:
            ev = {'entry': int(seg[1]), 'mode': seg[2],
                  'pc': int(seg[3]), 'S': int(seg[4]),
                  'r': int(seg[5]), 'p': int(seg[6]),
                  'T': int(seg[7]), 'M': int(seg[8]),
                  'q': int(seg[9])}
        except ValueError:
            skipped += 1
            continue
        ev['loop_a_op'] = tables_mod.loop_a_op(ev['S']) \
            if ev['mode'] == 'A' else None
        seed = decrypt_seed_for_event(ev)
        if seed is not None:
            ev['decrypt_seed'], ev['decrypt_formula'] = seed
        events.append(ev)
    coverage = {}
    per_entry = {}
    for ev in events:
        coverage[ev['mode']] = coverage.get(ev['mode'], 0) + 1
        per_entry[ev['entry']] = per_entry.get(ev['entry'], 0) + 1
    return {'events': events, 'coverage': coverage,
            'per_entry': per_entry, 'skipped': skipped}
