"""Decrypt / expand formulas for the BF VM (spec section 2 tables).

All formula DATA is loaded at runtime from data/seeds_p4.json --
never hardcoded case values. What is implemented here as code
is the generic arithmetic:

  u32 key  = seed * 16843009 (mod 2**32); byte key = seed.
  M-mix29(base, reg) =
      bxor(base, band(bxor(reg, band(rshift(reg, 29), 7)),
                      536870911))
  M-mix14_28(reg) =
      bxor(reg, band(rshift(reg, 14), 262143),
           band(rshift(reg, 28), 15))
  hash chain (identical in all forward leaves):
      c = band(bxor(c, lshift(c, 13)), 536870911)
      c = bxor(c, rshift(c, 13))
      c = band(bxor(c, lshift(c, 14)), 536870911)

Seeds are per-event values computed from that event's own M/q
registers (M/q come from D[1]/D[2], change mid-execution, and
differ per proto instance). They must NEVER be reused across
events or instances. Sites that never fired in the 240 s
phase-4 traces (A16, B90, C50 and the never-fired expands)
are labelled source-only in every report: their formulas are
source-derived, not live-verified.

Decrypt-leaf shape (all sites): an index into table V[4];
SN = bxor(V[4][idx], 169827604), stored back; a VM-varint read
from buffer V[7] at SN+1 (same swapped-4-byte rule) gives a
length FN and region start BN; the region [BN, BN+FN) in V[7]
is XOR-decrypted (u32 part stepping by 4 with the u32 key,
tail bytes with the byte key); then the current instruction
is rewritten per the site's rewrite tuple.

The buf4 fill transform (spec section 2i, proven 13518/13518):
  buf4_u32[i] = ((buf3_u32[86939 + 4*i] >> 2) XOR K[i mod 64]) << 2
                | (buf3_u32[86939 + 4*i] & 3)
with K the 64-word 30-bit periodic keystream from
data/fill_keystream.json. Low 2 bits pass through untouched.
The proven fact is periodicity (64 words), not the generator
behind K; no generator is claimed here.

These are pure functions over caller-supplied buffers/values.
This route version never runs them against live payload
buffers (see stage.py mechanism note); they exist so the
annotation layer and the later capture phase share one
formula implementation.
"""

import json
import os

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        'data')
MASK32 = 0xFFFFFFFF
U32_KEY_MULT = 16843009
DECRYPT_XOR_CONST = 169827604


def _band(*args):
    v = MASK32
    for a in args:
        v &= a & MASK32
    return v


def _bxor(*args):
    v = 0
    for a in args:
        v ^= a & MASK32
    return v


def _rshift(v, n):
    return (v & MASK32) >> n


def _lshift(v, n):
    return (v << n) & MASK32


def mix29(base, reg):
    """M-mix29(base, reg) for reg in {M, q}."""
    return _bxor(base, _band(_bxor(reg, _band(_rshift(reg, 29), 7)),
                             536870911))


def mix14_28(reg):
    """M-mix14_28(reg): the 14/28-shift variant."""
    return _bxor(reg, _band(_rshift(reg, 14), 262143),
                 _band(_rshift(reg, 28), 15))


def decrypt_u32_key(seed):
    return (seed * U32_KEY_MULT) & MASK32


def decrypt_region(buf, start, length, seed):
    """XOR-decrypt buf[start:start+length] in place (bytearray).

    u32 part stepping by 4 with the u32 key (little-endian
    words), tail bytes with the byte key. Returns the number
    of bytes decrypted. Raises ValueError on out-of-range
    regions instead of silently truncating.
    """
    if start < 0 or length < 0 or start + length > len(buf):
        raise ValueError('decrypt region out of range')
    key = decrypt_u32_key(seed)
    byte_key = seed & 0xFF
    i = 0
    while i + 4 <= length:
        word = int.from_bytes(buf[start + i:start + i + 4], 'little')
        word ^= key
        buf[start + i:start + i + 4] = word.to_bytes(4, 'little')
        i += 4
    while i < length:
        buf[start + i] ^= byte_key
        i += 1
    return length


def hash_chain_step(c):
    """One full hash-chain pass over state c (forward leaves)."""
    c = _band(_bxor(c, _lshift(c, 13)), 536870911)
    c = _bxor(c, _rshift(c, 13))
    c = _band(_bxor(c, _lshift(c, 14)), 536870911)
    return c


def fill_word(buf3_word, keystream_word):
    """One word of the buf4 fill transform (spec section 2i)."""
    return ((((buf3_word >> 2) ^ (keystream_word & 0x3FFFFFFF)) << 2)
            | (buf3_word & 3)) & MASK32


def fill_buf4(buf3_words, keystream):
    """Apply the fill transform to a list of buf3 u32 words."""
    if len(keystream) != 64:
        raise ValueError('keystream must have exactly 64 words')
    return [fill_word(w, keystream[i % 64])
            for i, w in enumerate(buf3_words)]


def load_seeds():
    """Load data/seeds_p4.json and normalise the formula tables."""
    path = os.path.join(DATA_DIR, 'seeds_p4.json')
    with open(path, encoding='utf-8') as f:
        raw = json.load(f)
    decrypt = {}
    for site, ent in raw.get('decrypt_sites', {}).items():
        if not isinstance(ent, dict):
            continue
        fired = ent.get('fired_v2', ent.get('fired', 0)) or 0
        prose = ent.get('status')
        # Normalised status (the fixture's prose status for
        # unfired sites is kept as 'note', never as the status):
        # live = fired at least once; source-only = formula
        # present but never fired; no-decrypt-leaves = loop D,
        # which has no decrypt leaves at all (a different
        # category from source-only, and must not be conflated).
        if ent.get('seed_formula') is None \
                and ent.get('rewrite') is None:
            status = 'no-decrypt-leaves'
        elif fired > 0:
            status = 'live'
        else:
            status = 'source-only'
        decrypt[site] = {'seed_formula': ent.get('seed_formula'),
                         'rewrite': ent.get('rewrite'),
                         'fired': fired,
                         'status': status,
                         'note': prose}
    return {'decrypt_sites': decrypt,
            'inplace_expands': raw.get('inplace_expands', {}),
            'forward_expands': raw.get('forward_expands', {}),
            'forward_simulation': raw.get('forward_simulation_v2', {}),
            'main_registers_note': raw.get('main_registers', {}),
            'caveats': raw.get('caveats', [])}
