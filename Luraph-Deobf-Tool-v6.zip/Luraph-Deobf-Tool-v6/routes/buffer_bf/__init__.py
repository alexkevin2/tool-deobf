"""buffer_bf — BF-family buffer route for Luraph-Deobf-Tool-v6 (v6.6.0).

This package implements the headered-buffer dispatch (see
routes/method/luraph151.py main()): a v15.1-headered, non-structural
buffer build is routed here, never to the old headerless buffer
route. It deliberately does NOT import routes/method/buffer_body or
routes/method/buffer_lifter: the BF body grammar is disjoint from
the old ULEB body grammar (see grammar.py).

Mechanism note (v1): this route is static/transcription-based.
The BF bodies are runtime-constructed buffers, so no body bytes
are present in the input file to parse directly. The route
therefore (a) validates the input statically (header, buffer
evidence, write family, no structural fingerprint, no bootstrap
vetoes), (b) fail-closes to exit 2 unless the input is the
proven BF-Main input (sha gate in stage.py), and (c) transcribes
the phase-3/phase-4 proven harvest bundled under data/ (fixture
shas verified at load) into bf_protos.json / bf_annotated.luau.
A general BF-family harvest (mock-env buffer capture + factory
harvest + clean traces) is NOT implemented in v1; a different
BF-family file exits 2 rather than emitting an unverified
PARTIAL. The grammar, varint, formula and fill-transform modules
are real implementations (unit-tested by tests/check_bf.py) so
the later harvest phase can reuse them against captured bytes.
"""
