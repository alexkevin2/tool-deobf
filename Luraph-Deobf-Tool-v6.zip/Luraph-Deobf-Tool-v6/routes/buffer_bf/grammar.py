"""BF proto-body grammar parser (spec section 2a).

Per proto body, in order (VM varint; see varint.py):

  header:   varint(2) varint(nconsts) varint(150) varint(2)
            u32 u32            (both u32s opaque; their role is
                                NOT proven -- never used as seeds)
  section p: [suffix 3 bytes]                    varint[p values]
  section r: [u32 0][suffix 3 bytes]             varint[r values]
  section S: [22][suffix 3 bytes]                varint[S values]
  section T: [entry-pc varint][0 or 1][suffix 3] varint[T values]
  trailer:  4 bytes (small protos) / 5 bytes (main proto)

Section-suffix bytes, header u32s and trailer bytes are treated
as opaque prefixes: they are consumed and recorded, never
interpreted (their semantics -- checksum/count candidates -- are
OPEN).

SPEC AMBIGUITY (recorded, not papered over): section 2a as
written gives no section-length field, so a standalone parser
cannot derive where one section ends and the next begins from
the body bytes alone. parse_bf_body therefore takes the section
lengths as caller-supplied parameters (in the route, they come
from the validated fixture proto arrays) and enforces EXACT
consumption: after the four sections, exactly trailer_len bytes
must remain, otherwise the body is rejected. A future live
capture phase must supply the length rule (or the body byte
offsets) before this parser can run on raw captured bodies
without fixture lengths. The parser itself -- header shape,
suffix shapes, varint decoding, exact-consumption -- is fully
implemented and round-trip tested.
"""

import struct

from .varint import decode_varint, decode_varint_list


class BFBodyError(ValueError):
    pass


def parse_bf_header(data, pos=0):
    """Parse and validate the body header; return
    (nconsts, u32a, u32b, next_pos). Any mismatch raises
    BFBodyError (fail-closed: the caller must exit 2)."""
    v, pos = decode_varint(data, pos)
    if v != 2:
        raise BFBodyError('body header first varint != 2 (got %r)' % v)
    nconsts, pos = decode_varint(data, pos)
    v, pos = decode_varint(data, pos)
    if v != 150:
        raise BFBodyError('body header mode != 150 (got %r)' % v)
    v, pos = decode_varint(data, pos)
    if v != 2:
        raise BFBodyError('body header fourth varint != 2 (got %r)' % v)
    if pos + 8 > len(data):
        raise BFBodyError('body header truncated before u32 pair')
    u32a, u32b = struct.unpack_from('<II', data, pos)
    return nconsts, u32a, u32b, pos + 8


def parse_bf_body(data, section_lengths, trailer_len):
    """Parse one body with caller-supplied section lengths.

    section_lengths: dict with keys 'p', 'r', 'S', 'T' (counts).
    trailer_len: 4 or 5. Returns a dict with header fields,
    section suffix bytes, the four value lists, entry_pc and
    trailer bytes. Raises BFBodyError on any desync, so the
    caller can fail closed (exit 2) without emitting output.
    """
    nconsts, u32a, u32b, pos = parse_bf_header(data, 0)
    sections = {}
    suffixes = {}
    # section p: 3 opaque suffix bytes, then values
    if pos + 3 > len(data):
        raise BFBodyError('section p header truncated')
    suffixes['p'] = bytes(data[pos:pos + 3])
    pos += 3
    sections['p'], pos = decode_varint_list(
        data, pos, section_lengths['p'])
    # section r: u32 0, then 3 opaque suffix bytes, then values
    if pos + 4 > len(data):
        raise BFBodyError('section r header truncated')
    r_zero, = struct.unpack_from('<I', data, pos)
    if r_zero != 0:
        raise BFBodyError('section r u32 prefix != 0 (got %r)' % r_zero)
    pos += 4
    if pos + 3 > len(data):
        raise BFBodyError('section r suffix truncated')
    suffixes['r'] = bytes(data[pos:pos + 3])
    pos += 3
    sections['r'], pos = decode_varint_list(
        data, pos, section_lengths['r'])
    # section S: byte 22, then 3 opaque suffix bytes, then values
    if pos + 1 > len(data) or data[pos] != 22:
        raise BFBodyError('section S marker != 22')
    pos += 1
    if pos + 3 > len(data):
        raise BFBodyError('section S suffix truncated')
    suffixes['S'] = bytes(data[pos:pos + 3])
    pos += 3
    sections['S'], pos = decode_varint_list(
        data, pos, section_lengths['S'])
    # section T: entry-pc varint, 0/1 byte, 3 suffix bytes, values
    entry_pc, pos = decode_varint(data, pos)
    if pos >= len(data) or data[pos] not in (0, 1):
        raise BFBodyError('section T flag byte not 0/1')
    t_flag = data[pos]
    pos += 1
    if pos + 3 > len(data):
        raise BFBodyError('section T suffix truncated')
    suffixes['T'] = bytes(data[pos:pos + 3])
    pos += 3
    sections['T'], pos = decode_varint_list(
        data, pos, section_lengths['T'])
    # trailer: exact consumption required
    if len(data) - pos != trailer_len:
        raise BFBodyError(
            'trailer desync: %d bytes remain, expected %d'
            % (len(data) - pos, trailer_len))
    trailer = bytes(data[pos:])
    return {'nconsts': nconsts, 'u32a': u32a, 'u32b': u32b,
            'suffixes': suffixes, 'sections': sections,
            'entry_pc': entry_pc, 't_flag': t_flag,
            'trailer': trailer}


def build_bf_body(nconsts, u32a, u32b, sections, entry_pc,
                  trailer, suffixes=None, t_flag=0):
    """Build a body in the grammar above (used by the regression
    synthetic round-trip; the inverse of parse_bf_body)."""
    from .varint import encode_varint
    suffixes = suffixes or {'p': b'\xf0\xa2\x06',
                            'r': b'\xef\xa2\x06',
                            'S': b'\xf1\xa2\x06',
                            'T': b'\xf0\xa2\x06'}
    out = bytearray()
    out += encode_varint(2)
    out += encode_varint(nconsts)
    out += encode_varint(150)
    out += encode_varint(2)
    out += struct.pack('<II', u32a, u32b)
    out += suffixes['p']
    for v in sections['p']:
        out += encode_varint(v)
    out += struct.pack('<I', 0)
    out += suffixes['r']
    for v in sections['r']:
        out += encode_varint(v)
    out += bytes([22])
    out += suffixes['S']
    for v in sections['S']:
        out += encode_varint(v)
    out += encode_varint(entry_pc)
    out += bytes([t_flag])
    out += suffixes['T']
    for v in sections['T']:
        out += encode_varint(v)
    out += trailer
    return bytes(out)
