"""Interpreter tables for the BF four-loop VM (spec sections 2b-2g).

Loop A (mode 150): opcode source is the S array. 80 opcodes
0-79 plus a default: any S value >= 80 executes as INDEX
(default leaf D[r] = D[T][p]) until an EXPAND rewrites it.
Correction applied (spec section 2b, phase-4): decrypts are
{16, 31, 60}; op 15 is a handler load and op 61 is load-imm.
The phase-1 lifter's 15/16 swap is NOT copied here.

Loop B (mode 2): opcode source is the T array. 91 fixture
keys: singletons 0-90 except 24, plus default key 91.
Op 24 is an empty leaf (NOP). Default >= 91 is a phase-switch.
Op 90 is a decrypt rewrite (seed = raw register value times
the u32 constant; see formulas.py).

Loop C (mode 81): opcode source is the p array. 159 fixture
keys: singletons 0-158 except 140, plus default key 159.
Op 140 is an empty else branch (NOP). Default 159 stores
s[f[G]] = g[G].

Loop D (mode 131): opcode source is the S array. 74 fixture
keys: singletons 0-73 except 57/58 as separate keys, plus
combined key 57 and default key 74. Key 57 IS the combined
(57,58) leaf; there is no separate op 58 to fill in. Loop D
has NO decrypt leaves.

Pool __index (spec section 2c): 180 states 0-179 plus a
default leaf (fixture key 180) that routes to state 54.
Entry state is 164. The cache is real: state 59 writes the
cache (k[d] = v; U = 110) and state 110 returns the cached
value -- so each key must be harvested exactly once per pool
instance and the cached value trusted thereafter.

Phase-switch chain (spec section 2g): loop A op 17 leaves
loop A with Y = r[G]; Y=2 -> loop B, Y=81 -> loop C,
Y=131 -> loop D. Other Y values are NOT assumed to re-enter
loop A in the same call.
"""

# Loop A opcode names, indices 0-79, in spec-table order.
LOOP_A_OPS = [
    'call-const', 'jump-if', 'load-ENV', 'load-Q',
    'vararg-setup', 'call', 'jump-lt', 'sub',
    'vararg-move', 'index', 'bxor-imm', 'add',
    'idiv', 'expand-in-place', 'LOADK', 'handler-load',
    'decrypt', 'PHASE-SWITCH', 'for-step', 'movepair-imm',
    'jump-le', 'movepair', 'vararg-call', 'jump-truthy',
    'band-const', 'frame-switch', 'sub-imm', 'jump-ne',
    'mod', 'call', 'mul-const', 'decrypt',
    'expand-in-place', 'jump-reg', 'bor', 'env-store',
    'expand-forward', 'mul', 'xor-const', 'xor-reg',
    'neg', 'env-index-reg', 'env-index', 'jump-le-imm',
    'index-const', 'env-load', 'frame-setup', 'mul-imm',
    'u32floor', 'table-slice', 'expand-forward', 'move',
    'NOP', 'call-const', 'not', 'bxor',
    'call4', 'return', 'add-const', 'call3',
    'decrypt', 'load-imm', 'jump-lt-imm', 'ne-imm',
    'load-M', 'jump-le-const', 'store-M', 'add-imm',
    'jump', 'expand-forward', 'load-Q', 'idiv-reg',
    'add-imm', 'bare-call', 'eq-imm', 'sub-const',
    'bare-return', 'env-store-const', 'index', 'mul-imm',
]

LOOP_A_DECRYPT_OPS = (16, 31, 60)
LOOP_A_PHASE_SWITCH_OP = 17
LOOP_A_DEFAULT = 'INDEX'

POOL_ENTRY_STATE = 164
POOL_DEFAULT_STATE = 54
POOL_CACHE_WRITE_STATE = 59
POOL_CACHE_RETURN_STATE = 110
POOL_STATE_COUNT = 180  # states 0-179; fixture key 180 = default

# Loop metadata: (fixture key count, NOP ops, default key, opcode source)
LOOP_B = {'states': 91, 'nop': (24,), 'default': 91,
          'source': 'T', 'decrypt_rewrite': 90,
          'phase_switch': (89, 91)}
LOOP_C = {'states': 159, 'nop': (140,), 'default': 159,
          'source': 'p', 'decrypt_rewrite': None,
          'phase_switch': None}
LOOP_D = {'states': 74, 'nop': (), 'default': 74,
          'source': 'S', 'decrypt_rewrite': None,
          'combined': (57, 58),
          'phase_switch': None}

PHASE_SWITCH_TARGETS = {2: 'B', 81: 'C', 131: 'D'}


def loop_a_op(value):
    """Loop A opcode name for an S value (default INDEX >= 80)."""
    if value < 0:
        raise ValueError('loop A opcode value must be non-negative')
    if value < len(LOOP_A_OPS):
        return LOOP_A_OPS[value]
    return LOOP_A_DEFAULT


def loop_leaf_first_line(states, opcode, meta):
    """First line of a loop B/C/D leaf text for an opcode value.

    states: fixture dict keyed by str(opcode). Returns a short
    annotation string: 'NOP' for empty leaves, 'phase-switch'
    for default/phase-switch leaves, else the leaf's first line
    truncated to 100 characters. Unknown opcodes (outside the
    fixture range) map to the default leaf's first line when a
    default key exists, else 'UNKNOWN'.
    """
    if opcode in meta.get('nop', ()):
        return 'NOP'
    # Loop B default is a phase-switch for EVERY opcode >= 91,
    # not just for the fixture's default key 91 itself.
    if meta is LOOP_B and opcode >= 91:
        return 'phase-switch'
    _ps = meta.get('phase_switch') or ()
    if opcode in _ps or opcode == meta['default']:
        if meta is LOOP_D and opcode == meta['default']:
            return 'default: D[p[G]] = J(D[r[G]], X[G])'
        return 'phase-switch'
    if meta is LOOP_D and opcode in (57, 58):
        txt = states.get('57', '')
        return txt.split('\n')[0].strip()[:100] if txt else 'combined (57,58)'
    txt = states.get(str(opcode))
    if txt is None:
        txt = states.get(str(meta['default']), '')
        return ('default: ' + txt.split('\n')[0].strip()[:100]) if txt \
            else 'UNKNOWN'
    first = txt.split('\n')[0].strip()
    return first[:100] if first else 'NOP'
