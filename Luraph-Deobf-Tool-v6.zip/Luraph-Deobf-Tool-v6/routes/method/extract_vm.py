#!/usr/bin/env python3
"""Extract the opcode-name table (y[]) and handler bodies (k={}) from a
folded Luraph v15.1 VM source, and disassemble parsed protos.

Conventions (v15.1 state-machine VM, verified by manual RE):
- instruction = 4 streams [opcode, A, B, C]; disasm labels operands A/B/C
  as stream2/stream3/stream4 values.
Usage: extract_vm.py <folded.luau> <protos.json> <outdir>
Writes: opnames.json, handlers.json, disasm.txt into outdir.
"""
import sys, os, json, re

def luau_unescape(s):
    def rep(m):
        e = m.group(1)
        if e.startswith("x"): return chr(int(e[1:], 16))
        if e.startswith("u"): return chr(int(e[2:-1], 16))
        if e[0].isdigit(): return chr(int(e))
        return {"n": "\n", "t": "\t", "r": "\r", "\\": "\\", '"': '"', "'": "'", "0": "\0"}.get(e, e)
    return re.sub(r'\\(x[0-9a-fA-F]{2}|u\{[0-9a-fA-F]+\}|\d{1,3}|.)', rep, s)

def _table_body(src, start):
    """Return the body of the table constructor starting at src[start]=='{',
    scanning with string awareness (entries may contain '\\u{...}' braces)."""
    i = src.index("{", start)
    depth, j, n = 0, i, len(src)
    while j < n:
        c = src[j]
        if c in '"\'':
            q = c; j += 1
            while j < n:
                if src[j] == '\\': j += 2; continue
                if src[j] == q: j += 1; break
                j += 1
            continue
        if c == '{': depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0: return src[i:j+1]
        j += 1
    raise ValueError("unterminated table")

def extract_y(src):
    i = src.find("local y={")
    if i < 0: raise ValueError("opcode table 'local y={' not found")
    body = _table_body(src, i)
    y = {}
    for m in re.finditer(r'\[(-?\d+(?:-\(-?\d+\))?)\]=(["\'])((?:\\.|(?!\2).)*)\2', body):
        idx_raw = m.group(1)
        try: idx = int(idx_raw)
        except ValueError: idx = eval(idx_raw)
        y[idx] = luau_unescape(m.group(3))
    return y

TOKEN = re.compile(r"""
    (?P<str>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\[(=*)\[(?:(?!\]\2\]).)*\]\2\])
  | (?P<word>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<other>.)
""", re.S | re.X)

def _tokens(s):
    for m in TOKEN.finditer(s):
        if m.group("str") is not None: yield ("str", m.group(0), m.start(), m.end())
        elif m.group("word") is not None: yield ("word", m.group(0), m.start(), m.end())
        else: yield ("other", m.group(0), m.start(), m.end())

OPEN = {"function", "if", "do", "while", "for", "repeat"}

def extract_handlers(src):
    # There are also empty `local k={}` tables elsewhere in the file; the
    # handler table is the non-empty `local k={` whose entries are functions.
    start = -1
    for m in re.finditer(r'local k=\{', src):
        j = m.end()
        while j < len(src) and src[j] in ' \t\r\n': j += 1
        if j < len(src) and src[j] != '}':
            start = m.start()
    if start < 0: raise ValueError("handler table 'local k={' not found")
    endmark = src.find("repeat u=G[q]", start)
    if endmark < 0: raise ValueError("dispatch loop 'repeat u=G[q]' not found")
    table_src = src[start:endmark]
    handlers = {}
    toks = list(_tokens(table_src))
    i = 0
    while i < len(toks):
        kind, txt, s0, e0 = toks[i]
        if kind == "word" and i + 2 < len(toks) and toks[i+1][1] == "=" and toks[i+2][1] == "function":
            name = txt
            depth, j, body_end = 0, i + 2, None
            pending_do = 0          # `for ... do` / `while ... do`: the do is not a block
            while j < len(toks):
                k2, t2 = toks[j][0], toks[j][1]
                if k2 == "word":
                    if t2 in ("for", "while"):
                        depth += 1; pending_do += 1
                    elif t2 == "do":
                        if pending_do: pending_do -= 1
                        else: depth += 1
                    elif t2 in OPEN: depth += 1
                    elif t2 == "until": depth -= 1
                    elif t2 == "end":
                        depth -= 1
                        if depth == 0:
                            body_end = toks[j][3]; break
                j += 1
            if body_end:
                handlers[name] = table_src[s0:body_end]
                i = j + 1
                continue
        i += 1
    return handlers

def disassemble(protos, y, out_path):
    out = open(out_path, "w", encoding="utf-8")
    def dis(p, name):
        A, B, C, D = p["code"]["A"], p["code"]["B"], p["code"]["C"], p["code"]["D"]
        consts = p["consts"]
        out.write(f"\n===== PROTO {name}  a={p['a']} b={p['b']} instr={len(A)} =====\n")
        pc = 0
        while pc < len(A):
            run = 1
            while pc + run < len(A) and (A[pc+run], B[pc+run], C[pc+run], D[pc+run]) == (A[pc], B[pc], C[pc], D[pc]):
                run += 1
            op = A[pc]
            nm = y.get(op, f"op{op}")
            line = f"{pc+1:4}  {nm:4} A={B[pc]:6} B={C[pc]:6} C={D[pc]:6}"
            notes = []
            for lbl, v in (("A", B[pc]), ("B", C[pc]), ("C", D[pc])):
                if isinstance(v, int) and 0 <= v < len(consts):
                    notes.append(f"{lbl}->K[{v}]={consts[v]!r}")
            if notes: line += "   ; " + "  ".join(notes)
            if run > 1: line += f"   (x{run})"
            out.write(line + "\n")
            pc += run
        for i, ch in enumerate(p["children"]):
            dis(ch, f"{name}.{i}")
    dis(protos, "root")
    out.close()

def main():
    folded_path, protos_path, outdir = sys.argv[1], sys.argv[2], sys.argv[3]
    os.makedirs(outdir, exist_ok=True)
    src = open(folded_path, encoding="utf-8").read()
    y = extract_y(src)
    handlers = extract_handlers(src)
    print(f"opnames: {len(y)}  handlers: {len(handlers)}")
    json.dump({str(k): v for k, v in sorted(y.items())},
              open(os.path.join(outdir, "opnames.json"), "w"), indent=0)
    json.dump(handlers, open(os.path.join(outdir, "handlers.json"), "w"), indent=1)
    protos = json.load(open(protos_path))
    disassemble(protos, y, os.path.join(outdir, "disasm.txt"))
    print("disassembly written")

if __name__ == "__main__":
    main()
