#!/usr/bin/env python3
"""Classify v15.1 VM handlers into semantic ops.

Dispatch convention (verified by manual RE): the interpreter calls
  handler(S1, S2, S3, S4, R, K, CH, ENV, UPB, CAP)
where S1..S4 are the 4 instruction streams (S1=opcode, S2=A, S3=B, S4=C),
R=registers, K=constants, CH=child protos, ENV=_ENV, UPB=upvalue box,
CAP=capture list. Handler parameter names are obfuscated and duplicated;
in Luau the LAST duplicate wins, so each distinct name maps to its last
position. Normalising a body with that mapping (plus numeric folding and
local renaming by first appearance) yields a signature that is stable
across builds of the same handler. Plain handlers are classified by exact
signature match against the reference corpus (reference_handlers.json,
from the manually reversed v15.1 sample). "Mangled" handlers (state
machines over M.P constants) always execute a fixed sequence of core ops,
consuming 1+len(sequence)-1 extra instructions whose own opcodes are
shadows of the cores; they are classified by their core-op sequence.
"""
import os, re, sys, json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fold as _fold

ROLES = {1: 'S1', 2: 'S2', 3: 'S3', 4: 'S4', 5: 'R', 6: 'K', 7: 'CH', 8: 'ENV', 9: 'UPB', 10: 'CAP'}
KEYWORDS = {'local','function','end','if','then','else','elseif','do','while','for','repeat',
            'until','break','return','in','and','or','not','nil','true','false'}
FREE = {'q', 'T', 'O', 'J', 'M', 'z'}   # VM-level upvalues referenced by handlers

# Semantic labels for the reference corpus (handler name in the sample build).
LABELS = {
    'N': 'SELF', 'bD': 'SETTABLE_KK', 'rY': 'ADD_RR', 'kL': 'LT_K_SKIP',
    'hZ': 'CONCAT', 'LQ': 'POW_KR', 'fq': 'NEWTABLE', 'EX': 'SUB_RR',
    'aM': 'SUB_RK', 'V': 'MOD_RR', 'XJ': 'GETUPVAL', 'Aq': 'FORLOOP',
    'bR': 'LOADBOOL', 'W': 'GETTABLE_R', 'CM': 'GETGLOBAL', 'sO': 'LEN',
    'YE': 'MOVE', 'Dw': 'CLOSURE', 'Y': 'JMP', 'm': 'RETURN', 'E': 'LOADK',
    'c': 'CALL', 'a': 'GETTABLE_K', 'M': 'EQ_K_SKIP', 'mL': 'SUB_KR',
    'tH': 'FORPREP', 'lR': 'TAILCALL', 'F': 'TEST_SKIP', 'p': 'CLOSE',
}
# Mangled handlers -> fixed net core sequence (consumes len(seq) instructions).
MANGLED = {
    'Rh': ['GETGLOBAL', 'LOADK'],
    'Da': ['GETGLOBAL', 'GETTABLE_K'],
    'O':  ['SELF', 'LOADK'],
    'Dm': ['LOADK', 'LOADK'],
    'e':  ['MOVE', 'MOVE'],
    'rT': ['MOVE', 'LOADK'],
    'd':  ['SELF', 'MOVE'],
    'v':  ['POW_KR', 'MOD_RR'],
    'X':  ['CALL', 'GETGLOBAL'],
    'AG': ['CALL', 'GETGLOBAL', 'LOADK'],
    'YV': ['LOADK'],   # unused in the reference sample; single-core fallback
}

TOKEN_RE = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|\S')

def parse_handler(text):
    """'NAME=function(p,...) BODY end' -> (params list, body text)."""
    m = re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\s*\(([^)]*)\)', text)
    if not m: return None, None
    params = [p.strip() for p in m.group(2).split(',') if p.strip()]
    body = text[m.end():]
    body = re.sub(r'end\s*$', '', body)
    return params, body

def normalize(text):
    params, body = parse_handler(text)
    if params is None: return None
    eff = {}
    for i, p in enumerate(params, 1):
        eff[p] = i                      # last duplicate wins
    locals_map = {}
    out = []
    for tok in TOKEN_RE.findall(body):
        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', tok):
            if tok in KEYWORDS:
                out.append(tok)
            elif tok in eff:
                out.append(ROLES[eff[tok]])
            elif tok in FREE or tok in ('S', 'k'):
                out.append(tok)
            else:
                if tok not in locals_map:
                    locals_map[tok] = f"L{len(locals_map)+1}"
                out.append(locals_map[tok])
        else:
            out.append(tok)
    s = ''.join(out)
    s = _fold.fold_parens(s)
    s = _fold.fold_runs(s)
    s = s.replace('S2[q]', '@A').replace('S3[q]', '@B').replace('S4[q]', '@C').replace('S1[q]', '@OP')
    return re.sub(r'\s+', '', s)

CORE_PATTERNS = [
    (r'R\[@A\]=ENV\[K\[@B\]\]', 'GETGLOBAL'),
    (r'R\[@A\]=R\[@B\]\[K\[@C\]\]', 'GETTABLE_K'),
    (r'R\[@A\]=K\[@B\]\^R\[@C\]', 'POW_KR'),
    (r'R\[@A\]=R\[@B\]%R\[@C\]', 'MOD_RR'),
    (r'R\[@A\]=K\[@B\]', 'LOADK'),
    (r'R\[@A\]=R\[@B\]', 'MOVE'),
]

def extract_cores(norm):
    cores = []
    if re.search(r'R\[\w+\+1\]=\w+;R\[\w+\]=\w+\[K\[@C\]\]', norm):
        cores.append('SELF')
    found = []
    for pat, label in CORE_PATTERNS:
        for m in re.finditer(pat, norm):
            found.append((m.start(), label))
    found.sort()
    seq = []
    for _, label in found:
        if not seq or seq[-1] != label:
            seq.append(label)
    if 'SELF' in cores:
        seq = ['SELF'] + [c for c in seq if c != 'SELF']
    if re.search(r'\(S\(R,', norm) or re.search(r'\w+\(S\(\w+,', norm):
        if 'CALL' not in seq:
            seq = ['CALL'] + seq
    return seq

_ref_cache = None
def reference_signatures():
    global _ref_cache
    if _ref_cache is None:
        _ref_cache = {}
        ref = json.load(open(os.path.join(HERE, 'reference_handlers.json')))
        for name, text in ref.items():
            sig = normalize(text)
            if sig:
                _ref_cache[sig] = name
    return _ref_cache

def classify(handlers):
    """handlers: {name: raw text} -> {name: label or [sequence] or 'UNKNOWN'}"""
    ref = reference_signatures()
    out = {}
    known_mangled_seqs = {tuple(v): v for v in MANGLED.values()}
    for name, text in handlers.items():
        if name in ('f', 'Z', '__index', '__newindex', 'R'):
            continue                    # VM helper functions, not opcodes
        sig = normalize(text)
        if sig is None:
            out[name] = 'UNKNOWN'; continue
        refname = ref.get(sig)
        if refname is not None:
            out[name] = MANGLED.get(refname, LABELS.get(refname, 'UNKNOWN'))
            continue
        if 'M.Z' in text or 'M.f' in text:   # mangled state machine
            seq = extract_cores(sig)
            if tuple(seq) in known_mangled_seqs:
                out[name] = known_mangled_seqs[tuple(seq)]
            elif seq:
                out[name] = seq               # plausible sequence, caller flags it
            else:
                out[name] = 'UNKNOWN'
            continue
        out[name] = 'UNKNOWN'
    return out

if __name__ == '__main__':
    handlers = json.load(open(sys.argv[1]))
    res = classify(handlers)
    for k in sorted(res):
        print(f"{k:4} -> {res[k]}")
