#!/usr/bin/env python3
"""identity.py — automatic game-ID spoofing for the method route
(--spoof-id auto).  THIN ADAPTER over the shared spoof engine
(spoof_engine.py, vendored in this directory; canonical copy at the
v6 tool root).  All portable semantics — gate kinds, candidate
bookkeeping, fork planning, report shapes — live in the engine;
this module keeps only what is method-route-specific:

  * the symbolic register-provenance scan over lift_mod.Proto trees
    (eq-const / set-membership / lt-bound gate sites + pool
    fallback, buffer-variant pool scan);
  * the Luau-CLI behavior forks (runner_behavior.luau): the mock
    `game` serves identity fields at READ time from the fork's
    seeds and logs every identity read (IDREAD), print (PRINT)
    and mock call (MOCKCALL — HttpGet & friends are logged and
    answered with inert values; NOTHING is ever fetched).

Why not a Luau __eq sentinel?  Verified empirically with the bundled
Luau CLI: `==` between a table and a number NEVER fires __eq (it is
false by type), so a table sentinel cannot capture the compared
number inside the Luau sandbox.  The working Luau-side mechanism is
therefore: exact static candidates, pre-seeded at read time, plus
differential forks (and pool-harvest candidates when no gate site
matches).  True comparison-capture exists only in the bootstrap
route's Python executor (see routes/bootstrap/modules/stageE).

No game ID is hardcoded here or in the engine: every served value
comes from extract_from_protos / extract_buffer over the analysed
script.  PROBE_VALUE is a distinctive probe marker for unseeded
reads (see spoof_engine), never a candidate or a default.
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

try:
    import spoof_engine as _engine
except ImportError:  # isolated copy: load the vendored/root engine
    import importlib.util as _ilu
    _cand_paths = [
        os.path.join(HERE, 'spoof_engine.py'),
        os.path.join(HERE, '..', '..', 'spoof_engine.py'),
    ]
    _engine = None
    for _p in _cand_paths:
        if os.path.isfile(_p):
            _spec = _ilu.spec_from_file_location('spoof_engine', _p)
            _engine = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_engine)
            break
    if _engine is None:
        raise

import lift as lift_mod

IDENTITY_FIELDS = _engine.IDENTITY_FIELDS
PROBE_VALUE = _engine.PROBE_VALUE
MAX_FORKS_PER_FIELD = _engine.MAX_FORKS_PER_FIELD
MAX_FORKS_TOTAL = _engine.MAX_FORKS_TOTAL
_STRONG = _engine.STRONG_KINDS
_KIND_RANK = _engine.KIND_RANK

# Re-exported engine functions (same names/signatures as before,
# so luraph151.py and tests need no changes).
plan_forks = _engine.plan_forks
candidate_source = _engine.candidate_source


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


# ---------------------------------------------------------------- extraction
def _field_of(proto, prov, reg):
    """Provenance tuple for a register, or None."""
    return prov.get(reg)


def _classify_base(prov_val):
    return prov_val[0] if prov_val else None


def extract_from_protos(root_proto):
    """root_proto: lift_mod.Proto (already expanded).  Returns
    (candidates, fields_read) where candidates maps field ->
    [ {value, kind, evidence:[{proto, pc, pattern}]} ] in
    deterministic order (strong kinds first, then by value), and
    fields_read maps field -> [proto paths that read it]."""
    candidates = {}
    fields_read = {}

    def add_cand(field, value, kind, proto_path, pc, pattern):
        _engine.add_candidate(candidates, field, value, kind,
                              proto=proto_path, pc=pc, pattern=pattern)

    def scan(proto, upv_prov):
        prov = {}                     # reg -> provenance tuple
        setlits = {}                  # reg -> {numkey: True}

        def kill(reg):
            setlits.pop(reg, None)

        for d in proto.instrs:
            pc = d['pc']
            for (label, A, B, C) in d['ops']:
                if label == 'LOADK':
                    kill(A)
                    v = proto.K(B)
                    prov[A] = ('const', v) if v is not None else \
                        ('other',)
                elif label == 'LOADBOOL':
                    kill(A)
                    prov[A] = ('const', B != 0)
                elif label == 'GETGLOBAL':
                    kill(A)
                    name = proto.K(B)
                    if name == 'game':
                        prov[A] = ('game', pc)
                    elif isinstance(name, str):
                        prov[A] = ('global', name)
                    else:
                        prov[A] = ('other',)
                elif label == 'GETUPVAL':
                    kill(A)
                    prov[A] = upv_prov.get(B, ('other',))
                elif label == 'MOVE':
                    kill(A)
                    prov[A] = prov.get(B, ('other',))
                elif label == 'NEWTABLE':
                    prov[A] = ('newtable',)
                    setlits[A] = {}
                elif label == 'SETTABLE_KK':
                    key = proto.K(B)
                    val = proto.K(C)
                    if A in setlits and _is_num(key) and val is True:
                        setlits[A][key] = True
                elif label == 'GETTABLE_K':
                    kill(A)
                    base = prov.get(B)
                    key = proto.K(C)
                    bk = _classify_base(base)
                    if bk == 'game' and key in IDENTITY_FIELDS:
                        prov[A] = ('idfield', key, pc)
                        fields_read.setdefault(key, [])
                        if proto.path not in fields_read[key]:
                            fields_read[key].append(proto.path)
                    elif bk in ('game', 'gamedesc'):
                        prov[A] = ('gamedesc',)
                    elif bk == 'idfield':
                        prov[A] = ('other',)
                    else:
                        prov[A] = ('other',)
                elif label == 'GETTABLE_R':
                    kill(A)
                    base = prov.get(B)
                    keyp = prov.get(C)
                    if base and base[0] == 'newtable' and \
                            keyp and keyp[0] == 'idfield' and \
                            B in setlits:
                        for numkey in setlits[B]:
                            add_cand(keyp[1], numkey,
                                     'set-membership', proto.path, pc,
                                     f'set[{keyp[1]}] membership')
                    prov[A] = ('other',)
                elif label == 'SELF':
                    kill(A)
                    kill(A + 1)
                    base = prov.get(B)
                    key = proto.K(C)
                    bk = _classify_base(base)
                    prov[A + 1] = base if base else ('other',)
                    if bk == 'game' and key in IDENTITY_FIELDS:
                        prov[A] = ('idfield', key, pc)
                        fields_read.setdefault(key, [])
                        if proto.path not in fields_read[key]:
                            fields_read[key].append(proto.path)
                    elif bk in ('game', 'gamedesc'):
                        prov[A] = ('gamedesc',)
                    else:
                        prov[A] = ('other',)
                elif label == 'CALL' or label == 'TAILCALL':
                    callee = prov.get(A)
                    res = ('gamedesc',) if callee and \
                        _classify_base(callee) in ('game', 'gamedesc') \
                        else ('other',)
                    nres = 1 if C == 2 else (0 if C == 1 else
                                             (C - 1 if C else 8))
                    for r in range(A, A + max(nres, 1)):
                        kill(r)
                        prov[r] = res
                elif label == 'EQ_K_SKIP':
                    rp = prov.get(B)
                    kv = proto.K(C)
                    if rp and rp[0] == 'idfield' and _is_num(kv):
                        add_cand(rp[1], kv, 'eq-const', proto.path, pc,
                                 f'{rp[1]} == const')
                elif label == 'LT_K_SKIP':
                    rp = prov.get(C)
                    kv = proto.K(B)
                    if rp and rp[0] == 'idfield' and _is_num(kv):
                        add_cand(rp[1], kv, 'lt-bound', proto.path, pc,
                                 f'const < {rp[1]} (bound)')
                elif label == 'CLOSURE':
                    child = proto.children[B]
                    cupv = {}
                    for i, (kind, idx) in enumerate(
                            d.get('caps') or []):
                        if kind == 'reg':
                            cupv[i] = prov.get(idx, ('other',))
                        else:
                            cupv[i] = upv_prov.get(idx, ('other',))
                    scan(child, cupv)
                elif label in ('ADD_RR', 'SUB_RR', 'SUB_RK', 'SUB_KR',
                               'MOD_RR', 'POW_KR', 'CONCAT', 'LEN'):
                    kill(A)
                    prov[A] = ('other',)
                elif label == 'FORPREP':
                    for r in (A, A + 1, A + 2):
                        kill(r)
                        prov[r] = ('other',)
                # JMP / TEST_SKIP / FORLOOP / RETURN / CLOSE: no writes
                # to a single dest register that provenance tracks.
        return prov

    scan(root_proto, {})
    # pool fallback: numeric consts of protos that read a field with
    # no strong candidate anywhere for that field
    strong_fields = {f for f, lst in candidates.items()
                     if any(c['kind'] in _STRONG for c in lst)}
    if fields_read:
        by_path = {}

        def collect(p):
            by_path[p.path] = p
            for ch in p.children:
                collect(ch)
        collect(root_proto)
        for field, paths in fields_read.items():
            if field in strong_fields:
                continue
            for path in paths:
                p = by_path.get(path)
                if not p:
                    continue
                for v in p.consts:
                    if _is_num(v):
                        add_cand(field, v, 'pool', path, None,
                                 'numeric const of field-reading proto')
    _engine.sort_candidates(candidates)
    return candidates, fields_read


def extract_buffer(pool_values, protos):
    """Buffer-variant static half.  pool_values: decoded pool list
    (buffer_lifter.decode_pool output); protos: buffer_body protos
    (dicts with 'consts' = pool indices).  Gate-site dataflow over
    the buffer VM's stream model is not attempted; candidates are
    the numeric pool values co-referenced by a proto that also
    references an identity field name (kind 'proto-consts', weak)."""
    fields_seen = []
    idx_of = {}
    for i, v in enumerate(pool_values):
        if isinstance(v, bytes):
            try:
                s = v.decode('utf-8')
            except UnicodeDecodeError:
                continue
            if s in IDENTITY_FIELDS:
                fields_seen.append(s)
                idx_of.setdefault(s, set()).add(i + 1)  # 1-based slots
    candidates = {}
    fields_read = {}
    if idx_of:
        for pi, pr in enumerate(protos):
            cset = set(pr.get('consts') or [])
            for field, idxs in idx_of.items():
                if not (cset & idxs):
                    continue
                fields_read.setdefault(field, []).append(f'proto{pi}')
                for ci in sorted(cset):
                    v = pool_values[ci - 1] if 1 <= ci <= \
                        len(pool_values) else None
                    if _is_num(v):
                        lst = candidates.setdefault(field, [])
                        if all(c['value'] != v for c in lst):
                            lst.append(
                                {'value': v, 'kind': 'proto-consts',
                                 'evidence': [{'proto': f'proto{pi}',
                                               'pc': None,
                                               'pattern':
                                               'numeric const of '
                                               'field-referencing '
                                               'proto'}]})
    return candidates, fields_read, fields_seen


# ---------------------------------------------------------------- behavior runs
def _seed_literal(seeds):
    parts = []
    for k in sorted(seeds):
        v = seeds[k]
        if isinstance(v, bool):
            parts.append(f'{k} = {str(v).lower()}')
        elif _is_num(v):
            parts.append(f'{k} = {v!r}' if isinstance(v, float)
                         else f'{k} = {v}')
        elif isinstance(v, str):
            parts.append(f'{k} = {lift_mod.luau_str(v)}')
    return '{ ' + ', '.join(parts) + ' }'


def run_behavior(luau, template_path, data, seeds, timeout=300):
    """Run one fork.  Returns (exit_code, log_text)."""
    esc = ''.join('\\%03d' % b for b in data)
    template = open(template_path, encoding='utf-8').read()
    runner = template.replace('__TARGET_SOURCE__', esc) \
                     .replace('__IDENTITY_SEEDS__', _seed_literal(seeds))
    import tempfile
    fd, path = tempfile.mkstemp(suffix='.luau', prefix='idbehav_')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(runner)
        r = subprocess.run([luau, path], capture_output=True,
                           timeout=timeout)
        return r.returncode, r.stdout.decode('utf-8', 'replace') + \
            r.stderr.decode('utf-8', 'replace')
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def parse_behavior_log(text):
    reads, prints, mockcalls, mockindex = [], [], [], []
    chunk = {}
    for line in text.splitlines():
        p = [x.strip() for x in line.split('\t')]
        if not p:
            continue
        tag = p[0]
        if tag == 'IDREAD|' and len(p) >= 4:
            reads.append({'field': p[1], 'value': p[2],
                          'source': p[3]})
        elif tag == 'PRINT|' and len(p) >= 3:
            prints.append({'channel': p[1],
                           'text': '\t'.join(p[2:])})
        elif tag == 'MOCKCALL|' and len(p) >= 3:
            mockcalls.append({'name': p[1],
                              'args': '\t'.join(p[2:])})
        elif tag == 'MOCKINDEX|' and len(p) >= 3:
            mockindex.append({'name': p[1], 'key': p[2]})
        elif tag.startswith('CHUNK_DONE'):
            chunk = {'raw': line}
    counts = {}
    for pr in prints:
        counts[pr['text']] = counts.get(pr['text'], 0) + 1
    top = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:5]
    http = [c for c in mockcalls
            if 'HttpGet' in c['name'] or 'HttpPost' in c['name']
            or c['name'].endswith('GetAsync')
            or c['name'].endswith('PostAsync')]
    return {
        'identity_reads': reads,
        'prints_total': len(prints),
        'prints_top': [{'text': t[:120], 'count': n} for t, n in top],
        'mock_calls': len(mockcalls),
        'http_attempts': len(http),
        'http_calls': http[:5],
        'chunk': chunk.get('raw', ''),
    }


def run_forks(luau, template_path, data, candidates, timeout=300,
              max_total=MAX_FORKS_TOTAL):
    """Execute the fork plan; return (fork_records, primary)."""
    forks, primary = plan_forks(candidates, max_total=max_total)
    records = []
    for i, seeds in enumerate(forks):
        code, log = run_behavior(luau, template_path, data, seeds,
                                 timeout=timeout)
        rec = parse_behavior_log(log)
        rec['fork'] = i
        rec['exit'] = code
        rec['seeds'] = {f: {'value': v,
                            'source': candidate_source(
                                candidates, f, v)}
                       for f, v in sorted(seeds.items())}
        records.append(rec)
    return records, primary


# ---------------------------------------------------------------- report
def build_report(route, candidates, fields_read, forks, notes,
                 fields_seen=None):
    return _engine.build_report_legacy_method(
        route, candidates, fields_read, forks, notes,
        fields_seen=fields_seen)


def report_section(rep):
    return _engine.report_section_legacy_method(rep)
