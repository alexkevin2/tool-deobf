#!/usr/bin/env python3
"""Lift parsed v15.1 protos + classified handlers into Luau source.

Model (verified by manual RE):
- Each dispatched instruction is one semantic op, except "mangled"
  handlers, which are superinstructions: a fixed sequence of core ops
  consuming consecutive instructions (the following instructions' own
  opcodes are shadows of the cores and are never dispatched).
- CLOSURE (Dw) additionally consumes C following instructions as upvalue
  capture descriptors: opcode==MOVE(17 in the sample) -> capture register
  B of the current frame, else capture upvalue B of the current closure.
- Control ops: JMP (pc += B, then the main loop's +1), conditional skips
  (skip the next dispatched instruction), FORPREP/FORLOOP numeric-for
  pair, CALL modes by operand C, RETURN by operand B.

The lifter first expands superinstructions, then tries a structured
reconstruction (sequence / if / if-else / numeric-for / return). If a
proto does not fit, it falls back to an explicit pc-loop with the same
semantic ops (still devirtualised, just not structured).

Usage: lift.py <protos.json> <opnames.json> <handlers.json> <out.luau> <report.json>
"""
import sys, os, json, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import semantics

KEYWORDS = {'and','break','do','else','elseif','end','false','for','function','goto','if','in',
            'local','nil','not','or','repeat','return','then','true','until','while','continue'}

def luau_str(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif ch == '\n': out.append('\\n')
        elif ch == '\r': out.append('\\r')
        elif ch == '\t': out.append('\\t')
        elif o < 32 or o == 127: out.append('\\%03d' % o)
        else: out.append(ch)
    return '"' + ''.join(out) + '"'

def luau_const(v):
    if v is None: return 'nil'
    if v is True: return 'true'
    if v is False: return 'false'
    if isinstance(v, str): return luau_str(v)
    if isinstance(v, float):
        return str(int(v)) if v == int(v) and abs(v) < 2**53 else repr(v)
    return str(v)

def is_ident(s):
    return bool(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', s or '')) and s not in KEYWORDS

class Proto:
    def __init__(self, node, path):
        self.node = node
        self.path = path                      # e.g. 'root', 'root.0'
        self.name = 'proto_' + path.replace('.', '_')
        self.A = node['code']['A']; self.B = node['code']['B']
        self.C = node['code']['C']; self.D = node['code']['D']
        self.consts = node['consts']
        self.nparams = node['a']
        self.children = [Proto(ch, f"{path}.{i}") for i, ch in enumerate(node['children'])]
        self.instrs = []                      # dispatched instructions after expansion
        self.structured_ok = False

    def K(self, idx):
        if isinstance(idx, int) and 0 <= idx < len(self.consts):
            return self.consts[idx]
        return None

    def Kc(self, idx):
        return luau_const(self.K(idx))

    def G(self, idx):
        v = self.K(idx)
        if isinstance(v, str) and is_ident(v):
            return v
        return f"_ENV[{luau_const(v)}]"

    def key(self, idx):
        v = self.K(idx)
        if isinstance(v, str) and is_ident(v):
            return f".{v}"
        return f"[{luau_const(v)}]"

    def keyb(self, idx):
        return f"[{luau_const(self.K(idx))}]"

# ---------------------------------------------------------------- expansion
def expand(proto, opnames, classes):
    """Build dispatched instruction list. Each item:
    {pc (1-based), ops: [(label, A, B, C)], } where ops use the operands of
    the instruction they came from."""
    n = len(proto.A)
    move_opnum = None
    for num, nm in opnames.items():
        if classes.get(nm) == 'MOVE':
            move_opnum = int(num)
    dispatched = []
    pc = 0
    while pc < n:
        opnum = proto.A[pc]
        nm = opnames.get(str(opnum)) or opnames.get(opnum)
        cls = classes.get(nm) if nm else None
        if cls is None:
            dispatched.append({'pc': pc + 1, 'ops': [('UNKNOWN', proto.B[pc], proto.C[pc], proto.D[pc])], 'name': nm})
            pc += 1
            continue
        if isinstance(cls, list):            # mangled superinstruction
            ops = []
            for j, label in enumerate(cls):
                q = pc + j
                ops.append((label, proto.B[q], proto.C[q], proto.D[q]))
            dispatched.append({'pc': pc + 1, 'ops': ops, 'name': nm})
            pc += len(cls)
            continue
        if cls == 'CLOSURE':
            cnt = proto.D[pc]
            caps = []
            for j in range(cnt):
                q = pc + 1 + j
                kind = 'reg' if proto.A[q] == move_opnum else 'upv'
                caps.append((kind, proto.C[q]))   # descriptor index is the B-operand stream (S in Dw)
            dispatched.append({'pc': pc + 1, 'ops': [('CLOSURE', proto.B[pc], proto.C[pc], proto.D[pc])],
                               'name': nm, 'caps': caps})
            pc += 1 + cnt
            continue
        dispatched.append({'pc': pc + 1, 'ops': [(cls, proto.B[pc], proto.C[pc], proto.D[pc])], 'name': nm})
        pc += 1
    proto.instrs = dispatched
    proto.pc2idx = {d['pc']: i for i, d in enumerate(dispatched)}
    proto.targets = set()
    for d in dispatched:
        for (label, a, b, c) in d['ops']:
            if label == 'JMP':
                proto.targets.add(d['pc'] + b + 1)
            if label == 'FORPREP':
                proto.targets.add(d['pc'] + b + 1)
            if label == 'FORLOOP':
                proto.targets.add(d['pc'] + b + 1)

# ---------------------------------------------------------------- op -> statements
def op_stmts(proto, label, A, B, C, instr=None):
    """Return (statements, control) where control is None for plain ops or a
    tuple describing control behaviour for the structurer / pc-loop."""
    R = lambda i: f"R[{i}]"
    if label == 'NEWTABLE': return [f"{R(A)} = {{}}"], None
    if label == 'SETTABLE_KK': return [f"{R(A)}{proto.keyb(B)} = {proto.Kc(C)}"], None
    if label == 'LOADK': return [f"{R(A)} = {proto.Kc(B)}"], None
    if label == 'MOVE': return [f"{R(A)} = {R(B)}"], None
    if label == 'GETUPVAL': return [f"{R(A)} = upv[{B}]"], None
    if label == 'GETGLOBAL': return [f"{R(A)} = {proto.G(B)}"], None
    if label == 'GETTABLE_R': return [f"{R(A)} = {R(B)}[{R(C)}]"], None
    if label == 'GETTABLE_K': return [f"{R(A)} = {R(B)}{proto.keyb(C)}"], None
    if label == 'SELF': return [f"{R(A+1)} = {R(B)}", f"{R(A)} = {R(B)}{proto.keyb(C)}"], None
    if label == 'LEN': return [f"{R(A)} = #{R(B)}"], None
    if label == 'ADD_RR': return [f"{R(A)} = {R(B)} + {R(C)}"], None
    if label == 'SUB_RR': return [f"{R(A)} = {R(B)} - {R(C)}"], None
    if label == 'SUB_RK': return [f"{R(A)} = {R(B)} - {proto.Kc(C)}"], None
    if label == 'SUB_KR': return [f"{R(A)} = {proto.Kc(B)} - {R(C)}"], None
    if label == 'MOD_RR': return [f"{R(A)} = {R(B)} % {R(C)}"], None
    if label == 'POW_KR': return [f"{R(A)} = {proto.Kc(B)} ^ {R(C)}"], None
    if label == 'CONCAT':
        parts = ' .. '.join(R(i) for i in range(B, C + 1)) if C >= B else "''"
        return [f"{R(A)} = {parts}"], None
    if label == 'LOADBOOL':
        st = [f"{R(A)} = {'true' if B != 0 else 'false'}"]
        if C != 0:
            return st, ('skip', 'true')
        return st, None
    if label == 'TEST_SKIP':
        cond = f"R[{A}]" if C != 0 else f"not R[{A}]"
        return [], ('skip', cond)
    if label == 'EQ_K_SKIP':
        eq = f"R[{B}] == {proto.Kc(C)}"
        cond = f"not ({eq})" if A != 0 else eq
        return [], ('skip', cond)
    if label == 'LT_K_SKIP':
        lt = f"{proto.Kc(B)} < R[{C}]"
        cond = f"not ({lt})" if A != 0 else lt
        return [], ('skip', cond)
    if label == 'JMP':
        return [], ('jmp', B)
    if label == 'FORPREP':
        return [f"{R(A)} = tonumber({R(A)})", f"{R(A+1)} = tonumber({R(A+1)})",
                f"{R(A+2)} = tonumber({R(A+2)})", f"{R(A)} = {R(A)} - {R(A+2)}"], ('forprep', B)
    if label == 'FORLOOP':
        return [], ('forloop', B, A)
    if label == 'CALL':
        args = call_args(proto, A, B)
        fn = R(A)
        if C == 1:
            return [f"{fn}({args})"], None
        if C == 0:
            return [f"do local _res = {{{fn}({args})}}",
                    f"for _i = 1, #_res do R[{A} + _i - 1] = _res[_i] end",
                    f"T = {A} + #_res - 1 end"], None
        if C == 2:
            return [f"{R(A)} = {fn}({args})"], None
        nres = C - 1
        temps = ', '.join(f"_r{i}" for i in range(1, nres + 1))
        assigns = '; '.join(f"R[{A + i}] = _r{i + 1}" for i in range(nres))
        return [f"do local {temps} = {fn}({args}); {assigns} end"], None
    if label == 'TAILCALL':
        return [f"return {R(A)}({call_args(proto, A, B)})"], ('ret',)
    if label == 'RETURN':
        if B == 1: return ["return"], ('ret',)
        if B == 0: return [f"return table.unpack(R, {A}, T)"], ('ret',)
        vals = ', '.join(R(A + i) for i in range(B - 1))
        return [f"return {vals}"], ('ret',)
    if label == 'CLOSURE':
        child = proto.children[B]
        caps = instr.get('caps') if instr else None
        if caps:
            # the VM's upvalue box is 0-based; Luau table constructors are 1-based
            vals = ', '.join(f"[{i}] = R[{idx}]" if kind == 'reg' else f"[{i}] = upv[{idx}]"
                             for i, (kind, idx) in enumerate(caps))
            return [f"{R(A)} = function(...) return {child.name}({{{vals}}}, ...) end"], None
        return [f"{R(A)} = function(...) return {child.name}(nil, ...) end"], None
    if label == 'CLOSE':
        return ["-- close upvalues (capture fixup; no value effect)"], None
    return [f"-- UNKNOWN op {label} A={A} B={B} C={C}"], None

def call_args(proto, A, B):
    if B == 0:
        return f"table.unpack(R, {A + 1}, T)"
    return ', '.join(f"R[{A + 1 + i}]" for i in range(B - 1))

# ---------------------------------------------------------------- structured emitter
class StructFail(Exception):
    pass

def emit_structured(proto):
    D = proto.instrs
    n = len(D)
    lines = []
    def target_idx(pc):
        if pc - 1 == len(proto.A):
            return n                     # proto end
        if pc in proto.pc2idx:
            return proto.pc2idx[pc]
        raise StructFail(f"jump target pc {pc} is not a dispatched instruction")

    def emit_range(lo, hi, indent, out):
        i = lo
        while i < hi:
            d = D[i]
            ops = d['ops']
            # multi-op (mangled) instructions: all plain ops, emit in order
            if len(ops) > 1 or (ops and ops[0][0] not in
                                ('JMP','TEST_SKIP','EQ_K_SKIP','LT_K_SKIP','FORPREP','FORLOOP','RETURN','TAILCALL')):
                # check for a skip/loadbool-with-skip inside single op
                stmts, ctrl = op_stmts(proto, ops[0][0], ops[0][1], ops[0][2], ops[0][3], d) if len(ops) == 1 else (None, None)
                if ctrl and ctrl[0] == 'skip':
                    pass                 # handled below by single-op path
                else:
                    for (label, a, b, c) in ops:
                        ss, cc = op_stmts(proto, label, a, b, c, d)
                        if cc is not None:
                            raise StructFail(f"control op {label} inside multi-op at pc {d['pc']}")
                        out.extend(indent + s for s in ss)
                    i += 1
                    continue
            label, A, B, C = ops[0]
            stmts, ctrl = op_stmts(proto, label, A, B, C, d)
            if ctrl is None:
                out.extend(indent + s for s in stmts); i += 1; continue
            kind = ctrl[0]
            if kind == 'ret':
                out.extend(indent + s for s in stmts)
                # trailing instructions in this range must be dead (no jump targets)
                rest = D[i + 1:hi]
                if any(x['pc'] in proto.targets for x in rest):
                    raise StructFail(f"return at pc {d['pc']} with live code after it")
                if rest:
                    out.append(indent + "-- (unreachable code after return omitted)")
                return
            if kind == 'jmp':
                tgt = target_idx(d['pc'] + B + 1)
                if tgt >= hi:
                    return                 # jump out of this region: region ends
                raise StructFail(f"bare forward jump at pc {d['pc']} to pc {d['pc'] + B + 1}")
            if kind == 'skip':
                out.extend(indent + s for s in stmts)
                if i + 1 >= hi:
                    raise StructFail(f"skip at pc {d['pc']} at region end")
                nd = D[i + 1]
                nlabel, nA, nB, nC = nd['ops'][0]
                if nlabel != 'JMP' or len(nd['ops']) != 1:
                    raise StructFail(f"skip at pc {d['pc']} not followed by JMP")
                tgt = target_idx(nd['pc'] + nB + 1)
                body_hi = min(tgt, hi)
                # if/else: body's last dispatched instr is a JMP over the else region
                else_lo = else_hi = None
                if body_hi - 1 > i + 1:
                    last = D[body_hi - 1]
                    if len(last['ops']) == 1 and last['ops'][0][0] == 'JMP':
                        t2 = target_idx(last['pc'] + last['ops'][0][2] + 1)
                        if t2 > tgt:
                            else_lo, else_hi = tgt, min(t2, hi)
                            body_hi -= 1
                # join pattern: the body's last instr is itself a skip whose JMP
                # is that trailing else-JMP; the else region then executes iff
                # (not outercond) or (inner skipcond).
                if else_lo is not None and body_hi - 1 >= i + 2:
                    binstr = D[body_hi - 1]
                    if len(binstr['ops']) == 1:
                        bs, bc = op_stmts(proto, binstr['ops'][0][0], binstr['ops'][0][1],
                                          binstr['ops'][0][2], binstr['ops'][0][3], binstr)
                        if bc and bc[0] == 'skip' and not bs:
                            # materialise the outer condition BEFORE the body runs:
                            # the body may overwrite the registers it reads.
                            tmp = f"_cond{d['pc']}"
                            out.append(indent + f"local {tmp} = {ctrl[1]}")
                            out.append(indent + f"if {tmp} then")
                            emit_range(i + 2, body_hi - 1, indent + '    ', out)
                            out.append(indent + "end")
                            out.append(indent + f"if not {tmp} or ({bc[1]}) then")
                            emit_range(else_lo, else_hi, indent + '    ', out)
                            out.append(indent + "end")
                            i = else_hi
                            continue
                if else_lo is not None:
                    tmp = f"_cond{d['pc']}"
                    out.append(indent + f"local {tmp} = {ctrl[1]}")
                    out.append(indent + f"if {tmp} then")
                    emit_range(i + 2, body_hi, indent + '    ', out)
                    out.append(indent + "else")
                    emit_range(else_lo, else_hi, indent + '    ', out)
                    out.append(indent + "end")
                    i = else_hi
                else:
                    out.append(indent + f"if {ctrl[1]} then")
                    emit_range(i + 2, body_hi, indent + '    ', out)
                    out.append(indent + "end")
                    i = tgt
                continue
            if kind == 'forprep':
                loop_idx = target_idx(d['pc'] + B + 1)
                if loop_idx >= hi:
                    raise StructFail("forprep target outside region")
                ld = D[loop_idx]
                if len(ld['ops']) != 1 or ld['ops'][0][0] != 'FORLOOP':
                    raise StructFail("forprep target is not FORLOOP")
                _, fA, fB, fC = ld['ops'][0]
                back = ld['pc'] + fB + 1
                if back != D[i + 1]['pc']:
                    raise StructFail("forloop does not jump back to forprep body start")
                out.extend(indent + s for s in stmts)
                out.append(indent + "while true do")
                ind2 = indent + '    '
                out.append(ind2 + f"R[{fA}] = R[{fA}] + R[{fA + 2}]")
                out.append(ind2 + f"if (R[{fA + 2}] > 0 and R[{fA}] > R[{fA + 1}]) or (R[{fA + 2}] <= 0 and R[{fA}] < R[{fA + 1}]) then break end")
                out.append(ind2 + f"R[{fA + 3}] = R[{fA}]")
                emit_range(i + 1, loop_idx, ind2, out)
                out.append(indent + "end")
                i = loop_idx + 1
                continue
            raise StructFail(f"unhandled control {kind} at pc {d['pc']}")
    emit_range(0, n, '    ', lines)
    return lines

# ---------------------------------------------------------------- pc-loop fallback
def emit_pcloop(proto):
    D = proto.instrs
    n = len(D)
    lines = ['    local pc = 1', '    while pc do']
    for i, d in enumerate(D):
        nxt = D[i + 1]['pc'] if i + 1 < n else None
        kw = 'if' if i == 0 else 'elseif'
        lines.append(f"        {kw} pc == {d['pc']} then")
        body = []
        jumped = False
        for (label, A, B, C) in d['ops']:
            stmts, ctrl = op_stmts(proto, label, A, B, C, d)
            if ctrl is None:
                body.extend(stmts); continue
            kind = ctrl[0]
            if kind == 'ret':
                body.extend(stmts); jumped = True
            elif kind == 'jmp':
                body.append(f"pc = {d['pc'] + B + 1}"); jumped = True
            elif kind == 'skip':
                body.extend(stmts)
                skip_to = D[i + 2]['pc'] if i + 2 < n else 'nil'
                body.append(f"if {ctrl[1]} then pc = {skip_to} else pc = {D[i + 1]['pc']} end")
                jumped = True
            elif kind == 'forprep':
                body.extend(stmts)
                body.append(f"pc = {d['pc'] + B + 1}"); jumped = True
            elif kind == 'forloop':
                _, _, fA = ctrl[0], ctrl[1], ctrl[2]
                body.append(f"R[{fA}] = R[{fA}] + R[{fA + 2}]")
                body.append(f"if (R[{fA + 2}] > 0 and R[{fA}] <= R[{fA + 1}]) or (R[{fA + 2}] <= 0 and R[{fA}] >= R[{fA + 1}]) then R[{fA + 3}] = R[{fA}]; pc = {d['pc'] + B + 1} else pc = {nxt if nxt else 'nil'} end")
                jumped = True
        if not jumped:
            body.append(f"pc = {nxt}" if nxt else "pc = nil")
        lines.extend('            ' + s for s in body)
    lines.append('        else')
    lines.append('            pc = nil')
    lines.append('        end')
    lines.append('    end')
    return lines

# ---------------------------------------------------------------- proto / file emission
def emit_proto(proto, report):
    body = [f"local function {proto.name}(upv, ...)",
            "    local R = {}",
            "    local T = -1",
            "    local _args = {...}",
            f"    for _i = 0, {max(proto.nparams - 1, -1)} do R[_i] = _args[_i + 1] end"]
    if proto.nparams == 0:
        body.pop()                       # no fixed params to load
    try:
        inner = emit_structured(proto)
        proto.structured_ok = True
    except StructFail as e:
        inner = emit_pcloop(proto)
        report.setdefault('fallback', {})[proto.path] = str(e)
    body.extend(inner)
    body.append("end")
    return body

def main():
    protos_path, opnames_path, handlers_path, out_path, report_path = sys.argv[1:6]
    root_node = json.load(open(protos_path))
    opnames = json.load(open(opnames_path))
    handlers = json.load(open(handlers_path))
    classes = semantics.classify(handlers)
    root = Proto(root_node, 'root')
    all_protos = []
    def collect(p):
        for ch in p.children: collect(ch)
        all_protos.append(p)
    collect(root)
    report = {'opcodes': {}, 'fallback': {}}
    for num, nm in sorted(opnames.items(), key=lambda kv: int(kv[0])):
        report['opcodes'][nm] = classes.get(nm, 'MISSING')
    for p in all_protos:
        expand(p, opnames, classes)
    lines = ["-- Devirtualised from Luraph v15.1 by luraph-v151-deobf (lift stage)",
             "-- Registers are kept in table R (R[0] is the first register);",
             "-- constants are inlined; upv = captured upvalues of the closure.",
             ""]
    for p in all_protos:
        lines.extend(emit_proto(p, report))
        lines.append("")
    lines.append("return proto_root(nil, ...)")
    open(out_path, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    report['protos'] = {p.path: {'instr': len(p.node['code']['A']),
                                 'dispatched': len(p.instrs),
                                 'structured': p.structured_ok} for p in all_protos}
    json.dump(report, open(report_path, 'w'), indent=1)
    print(f"lifted {len(all_protos)} protos -> {out_path}")
    for path, info in report['protos'].items():
        print(f"  {path}: instr={info['instr']} dispatched={info['dispatched']} structured={info['structured']}")
    if report['fallback']:
        print("fallback (pc-loop) protos:", report['fallback'])

if __name__ == '__main__':
    main()
