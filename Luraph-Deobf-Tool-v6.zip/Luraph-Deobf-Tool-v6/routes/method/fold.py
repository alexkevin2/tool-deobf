#!/usr/bin/env python3
"""Conservative Luau constant folder + formatter (v3).
Safety rules learned from verification failures:
- Strings AND comments are never touched (split out first): quoted strings,
  long-bracket strings, line comments and block comments are all opaque.
- Numeric literals are normalised first (code segments only): 0x hex,
  0b binary and `_` digit separators (Luraph buffer builds and MoonVeil
  emit all three) become plain decimal integers.
- Parenthesized pure-arithmetic groups fold to (value) — parens ALWAYS kept,
  so no token glue (e.g. `0then`, `--comment`) can ever be created.
- Bare runs fold ONLY when the previous non-space char is not an operator or
  operand-end (prevents stealing the first operand of a larger chain, e.g.
  `x-1-2` or `k-380907+380907`), and the next non-space char is not %, ^, ..
- Only integer + - * ; every intermediate and final |value| < 2^53.
Usage: fold.py <in> <out>
"""
import sys, re, ast

MAXV = 2**53

def safe_eval(expr):
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError:
        return None
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, int): return n.value
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub):
            v = -ev(n.operand)
            if abs(v) >= MAXV: raise ValueError
            return v
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.UAdd): return ev(n.operand)
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add): v = a + b
            elif isinstance(n.op, ast.Sub): v = a - b
            elif isinstance(n.op, ast.Mult): v = a * b
            else: raise ValueError
            if abs(v) >= MAXV: raise ValueError
            return v
        raise ValueError
    try:
        return ev(tree)
    except Exception:
        return None

PURE = re.compile(r'^[0-9\s+\-*()]+$')
def fold_parens(code):
    changed = True
    while changed:
        changed = False
        out, i, n = [], 0, len(code)
        while i < n:
            if code[i] == '(':
                depth, j = 1, i + 1
                while j < n and depth:
                    if code[j] == '(': depth += 1
                    elif code[j] == ')': depth -= 1
                    j += 1
                inner = code[i+1:j-1]
                if PURE.match(inner) and re.search(r'\d\s*[-+*]\s*-?\d', inner):
                    v = safe_eval(inner)
                    if v is not None:
                        out.append(f'({v})'); i = j; changed = True; continue
                out.append(code[i]); i += 1
            else:
                out.append(code[i]); i += 1
        code = ''.join(out)
    return code

RUN = re.compile(r'-?\d+(?:\s*[-+*]\s*-?\d+)+')
BAD_PREV = set('_.)]}+-*/%^#')
def fold_runs(code):
    def rep(m):
        s, i = m.string, m.start() - 1
        while i >= 0 and s[i] in ' \t': i -= 1
        if i >= 0 and (s[i].isalnum() or s[i] in BAD_PREV): return m.group(0)
        j = m.end()
        while j < len(s) and s[j] in ' \t': j += 1
        if j < len(s) and s[j] in '%^': return m.group(0)
        if j < len(s) and s[j] == '.': return m.group(0)
        v = safe_eval(m.group(0))
        return str(v) if v is not None else m.group(0)
    prev = None
    while prev != code:
        prev = code
        code = RUN.sub(rep, code)
    return code

_LBRACKET = re.compile(r'\[(=*)\[')
def _long_bracket_end(src, i):
    """If src[i] opens a long bracket [=*[ , return (end_index_exclusive, eq)
    else None."""
    m = _LBRACKET.match(src, i)
    if not m: return None
    eq = m.group(1)
    close = ']' + eq + ']'
    j = src.find(close, m.end())
    if j < 0: return (len(src), eq)
    return (j + len(close), eq)

def split_segments(src):
    segs, i, n, buf = [], 0, len(src), []
    def flush():
        if buf: segs.append(('code', ''.join(buf))); buf.clear()
    while i < n:
        c = src[i]
        if c in '"\'':
            flush()
            j = i + 1
            while j < n:
                if src[j] == '\\': j += 2; continue
                if src[j] == c: j += 1; break
                j += 1
            segs.append(('str', src[i:j])); i = j
        elif c == '-' and src.startswith('--', i):
            lb = _long_bracket_end(src, i + 2)
            flush()
            if lb:
                segs.append(('str', src[i:lb[0]])); i = lb[0]
            else:
                j = src.find('\n', i)
                j = n if j < 0 else j
                segs.append(('str', src[i:j])); i = j
        elif c == '[' :
            lb = _long_bracket_end(src, i)
            if lb:
                flush()
                segs.append(('str', src[i:lb[0]])); i = lb[0]
            else:
                buf.append(c); i += 1
        else:
            buf.append(c); i += 1
    flush()
    return segs

_NUM_TOKEN = re.compile(
    r'(?<![A-Za-z0-9_.])'
    r'(0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*(?:\.[\d_]*)?(?:[eE][+-]?[\d_]+)?)'
    r'(?![A-Za-z0-9_.])')
def normalize_numbers(code):
    def rep(m):
        tok = m.group(1)
        low = tok.lower()
        try:
            if low.startswith('0x'):
                return str(int(tok[2:].replace('_', ''), 16))
            if low.startswith('0b'):
                return str(int(tok[2:].replace('_', ''), 2))
        except ValueError:
            return tok
        if '_' not in tok:
            return tok
        if tok.endswith('.'):            # keep a concat dot out of the literal
            return tok[:-1].replace('_', '') + '.'
        return tok.replace('_', '')
    return _NUM_TOKEN.sub(rep, code)

KW_RE = re.compile(r'(?<![A-Za-z0-9_])(local function|local|while|repeat|until|elseif|else|if|break|return|for)(?=[\s(])')
def format_code(code):
    code = code.replace(';', ';\n')
    code = KW_RE.sub(lambda m: '\n' + m.group(0), code)
    return code

def fold_source(src):
    parts = []
    for kind, seg in split_segments(src):
        if kind == 'str':
            parts.append(seg)
        else:
            seg = normalize_numbers(seg)
            seg = fold_parens(seg)
            seg = fold_runs(seg)
            parts.append(format_code(seg))
    return re.sub(r'\n{3,}', '\n\n', ''.join(parts))

def main():
    src = open(sys.argv[1], encoding='utf-8', errors='strict').read()
    out = fold_source(src)
    open(sys.argv[2], 'w', encoding='utf-8').write(out)
    print(f"in={len(src)} out={len(out)}")

if __name__ == '__main__':
    main()
