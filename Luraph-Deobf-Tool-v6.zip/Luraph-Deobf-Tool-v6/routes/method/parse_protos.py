#!/usr/bin/env python3
"""Parse the string.unpack log from the instrumented run into a proto tree,
mirroring the v15.1 deserializer (function u() in the VM source)."""
import sys, json, re

KEY13 = [167,229,252,19,5,111,231,18,18,106,166,245,119]
KEY = list(KEY13)          # active XOR key for tag-3 strings (set_key overrides)

def set_key(key_bytes):
    global KEY
    KEY = list(key_bytes)

def load_log(path):
    reads = []
    for line in open(path, encoding="utf-8", errors="replace"):
        if not line.startswith("UNPACK|"):
            continue
        parts = [p.strip() for p in line.rstrip("\n").split("\t")]
        # parts: ['UNPACK|', fmt, pos, values, '->', newpos]
        fmt, pos, vals = parts[1], int(parts[2]), parts[3]
        reads.append((fmt, pos, vals))
    return reads

class P:
    def __init__(self, reads):
        self.r = reads; self.i = 0
    def next(self, expect=None):
        fmt, pos, vals = self.r[self.i]; self.i += 1
        if expect and fmt != expect:
            raise ValueError(f"read#{self.i}: expected {expect}, got {fmt} at pos {pos}")
        return fmt, pos, vals
    def u8(self): return int(self.next()[2])
    def u32(self): return int(self.next()[2])
    def i32(self): return int(self.next()[2])
    def u16(self): return int(self.next()[2])

def decrypt_str(raw: bytes) -> str:
    out = bytes(b ^ KEY[i % len(KEY)] for i, b in enumerate(raw))
    return out.decode("utf-8", errors="replace")

def read_proto(p: P, depth=0):
    a = p.u8()          # G() byte 1 (proto field 6 -> executor O: likely numparams)
    b = p.u8()          # G() byte 2 (proto field 8)
    n = p.u32()         # L() instruction-group count
    A, B, C, D = [], [], [], []
    q = 0
    while q < n:
        u = p.i32(); k = p.i32(); s = p.i32(); t = p.i32(); cnt = p.u8()
        for _ in range(cnt):
            A.append(u); B.append(k); C.append(s); D.append(t); q += 1
    tcount = p.u32()    # L() constants count
    consts = []
    for _ in range(tcount):
        tag = p.u8()
        fmt, pos, vals = p.r[p.i]  # peek next read
        if fmt == "<I1":           # boolean constant
            consts.append(bool(p.u8()))
        elif fmt == "<I2":         # string-ish constant
            ln = p.u16()
            if ln == 0:
                consts.append("")
                continue
            fmt2, pos2, vals2 = p.next()
            assert fmt2.startswith("c"), fmt2
            raw = bytes.fromhex(vals2[4:]) if vals2.startswith("HEX:") else b""
            if all(32 <= ch < 127 or ch in (9,) for ch in raw) and re.fullmatch(rb"[0-9eE+\-.]+", raw or b""):
                consts.append(float(raw) if any(c in raw for c in b".eE") else int(raw))
            else:
                consts.append(decrypt_str(raw))
        else:
            raise ValueError(f"const tag {tag}: unexpected next fmt {fmt} at read#{p.i}")
    j = p.u32()         # L() children count
    children = [read_proto(p, depth + 1) for _ in range(j)]
    return {"a": a, "b": b, "code": {"A": A, "B": B, "C": C, "D": D},
            "consts": consts, "children": children}

def main():
    reads = load_log(sys.argv[1])
    print(f"total reads: {len(reads)}")
    p = P(reads)
    root = read_proto(p)
    print(f"consumed: {p.i}/{len(reads)}")
    json.dump(root, open(sys.argv[2], "w"), indent=1)
    def stats(pr, d=0):
        print("  " * d + f"proto a={pr['a']} b={pr['b']} instr={len(pr['code']['A'])} consts={len(pr['consts'])} children={len(pr['children'])}")
        for c in pr["children"]: stats(c, d + 1)
    stats(root)

if __name__ == "__main__":
    main()
