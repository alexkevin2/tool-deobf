#!/usr/bin/env python3
"""Buffer-variant stage-1 VM lifter (Luraph-Deobf-Tool-v6, method route).

Cracked during the v6 regular-Luraph upgrade (see UPGRADE-REPORT.md):
the buffer variant's 57+ protos run on a stage-1 VM whose interpreter
is installed by the payload's Vj method at state slot 55. This module
  * parses the header constant pool (tagged stream),
  * decodes every packed instruction into the VM's operand streams
    (verified 100% against dynamic builder dumps of the reference
    sample: dense 43,496/43,496, sparse 3,812/3,812),
  * classifies all 162 dispatch opcodes from their handler bodies
    (optable_buffer.json; bodies in bodies_buffer.json),
  * lifts protos to structured Luau source (region structuring with
    for-pair recognition; irreducible protos fall back to a chunked
    dispatch kernel with the same semantic rendering).
Residues (named, honest): CLOSURE child identity binds through the
deserializer's deferred link registry -> rendered __descriptor(id);
the per-proto X field's exact role is unconfirmed (frame parameter);
sequence/mangled ops are emitted as handler-body transcriptions.
"""
import json
import os
import re
import struct

DESCRIPTOR = 'descriptor'
LINK = 'link'


def decode_pool(entries):
    """entries: [offset, tag, payload] -> list of Python values.
    Table/descriptor-valued entries are returned as (DESCRIPTOR, id)
    markers when the payload shape implies them (handled by callers
    for S==2 refs); scalar entries decode per tag."""
    out = []
    for off, tag, pay in entries:
        out.append(decode_pool_entry(tag, pay))
    return out


def decode_pool_entry(tag, pay):
    if tag == 0x23:                # u8
        return pay[0]
    if tag == 0x26:                # negative u8
        return -pay[0]
    if tag == 0x07:                # i32
        return pay[0]
    if tag == 0x4D:                # u16
        return pay[0]
    if tag == 0xBA:                # u32
        return pay[0]
    if tag == 0x48:                # i16 (payload already signed)
        return pay[0]
    if tag == 0xFC:                # f32
        return pay[0]
    if tag == 0x2B:                # f64
        return pay[0]
    if tag == 0x8E:                # string: payload = [hex]
        h = pay[0] if isinstance(pay, list) else pay
        return bytes.fromhex(h)
    if tag == 0xD1:                # signed 64-bit (lo, hi)
        lo, hi = pay[0], pay[1]
        v = lo + hi * 4294967296
        if v >= 9223372036854775808:
            v -= 18446744073709551616
        return v
    if tag == 0x09:
        return True
    if tag == 0xD4:
        return False
    return ('unknown-tag', tag, pay)


def decode_proto(instrs, pool):
    """instrs: raw [op, v2, v3, v4] rows. pool: decoded pool values.
    Returns dict of streams: J, y(Q), x(b), K(D), V(A), Y(u), b(W).
    Sparse streams (V, Y, b) map index->value only where filled;
    LINK/DESCRIPTOR values are (kind, pool_value) tuples."""
    J, Q, b, D, A, u, W = [], [], [], [], {}, {}, {}

    def pv(i):
        # runtime pool is a 1-based Lua array: slot i = entries[i-1]
        return pool[i - 1] if 1 <= i <= len(pool) else None

    for x, (op, v2, v3, v4) in enumerate(instrs, start=1):
        l, f = divmod(v2, 8)
        G, S = divmod(v3, 8)
        p, o = divmod(v4, 8)
        J.append(op)
        # Q (y stream)
        if S == 1:
            Q.append(x + G)
        elif S == 4:
            Q.append(x - G)
        else:
            Q.append(G)
        # b numeric stream (exec x): plain base l, digit adjusts only
        # for 1/4; f==0 and f==2 write the W stream / link registry.
        if f == 1:
            b.append(x + l)
        elif f == 4:
            b.append(x - l)
        else:
            b.append(l)
        # D stream (exec K): plain base p; o==0/o==2 write the u
        # stream / link registry instead.
        if o == 1:
            D.append(x + p)
        elif o == 4:
            D.append(x - p)
        else:
            D.append(p)
        # A stream (exec V) -- sparse
        if S == 0:
            A[x] = pv(G)
        elif S == 2:
            A[x] = (DESCRIPTOR, pv(G))
        # u stream (exec Y) -- sparse
        if o == 0:
            u[x] = pv(p)
        # W stream (exec b) -- sparse
        if f == 0:
            W[x] = pv(l)
    return {'J': J, 'Q': Q, 'b': b, 'D': D, 'A': A, 'u': u, 'W': W}




def _varint(buf, pos):
    v = 0
    shift = 0
    while True:
        b = buf[pos]
        pos += 1
        v |= (b & 0x7F) << shift
        if not (b & 0x80):
            return v, pos
        shift += 7


def parse_pool(buf, start=4, end=None):
    if end is None:
        end = len(buf)
    entries = []
    pos = start
    while pos < end:
        off = pos
        tag = buf[pos]
        pos += 1
        if tag == 0x23:
            pay = [buf[pos]]
            pos += 1
        elif tag == 0x26:
            pay = [buf[pos]]
            pos += 1
        elif tag == 0x07:
            pay = [struct.unpack_from('<i', buf, pos)[0]]
            pos += 4
        elif tag == 0x4D:
            pay = [struct.unpack_from('<H', buf, pos)[0]]
            pos += 2
        elif tag == 0xBA:
            pay = [struct.unpack_from('<I', buf, pos)[0]]
            pos += 4
        elif tag == 0x48:
            pay = [struct.unpack_from('<h', buf, pos)[0]]
            pos += 2
        elif tag == 0xFC:
            pay = [struct.unpack_from('<f', buf, pos)[0]]
            pos += 4
        elif tag == 0x2B:
            pay = [struct.unpack_from('<d', buf, pos)[0]]
            pos += 8
        elif tag == 0x8E:
            n, pos = _varint(buf, pos)
            pay = [bytes(buf[pos:pos + n]).hex()]
            pos += n
        elif tag == 0xD1:
            lo, hi = struct.unpack_from('<II', buf, pos)
            pay = [lo, hi]
            pos += 8
        elif tag in (0x09, 0xD4):
            pay = []
        else:
            raise ValueError('unknown pool tag %#x at offset %d'
                             % (tag, off))
        entries.append([off, tag, pay])
    if pos != end:
        raise ValueError('pool parse ended at %d, expected %d'
                         % (pos, end))
    return entries




# ------------------------------------------------------------------
# literals
# ------------------------------------------------------------------
def luau_num(v):
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if v != v:
            return '(0/0)'
        if v == float('inf'):
            return 'math.huge'
        if v == float('-inf'):
            return '-math.huge'
        r = repr(v)
        return r


def luau_str(b):
    if isinstance(b, str):
        b = b.encode('utf-8', 'replace')
    out = []
    for ch in b:
        c = chr(ch)
        if c == '"':
            out.append('\\"')
        elif c == '\\':
            out.append('\\\\')
        elif c == '\n':
            out.append('\\n')
        elif c == '\r':
            out.append('\\r')
        elif c == '\t':
            out.append('\\t')
        elif 32 <= ch < 127:
            out.append(c)
        else:
            out.append('\\%03d' % ch)
    return '"' + ''.join(out) + '"'


def luau_lit(v):
    if v is None:
        return 'nil'
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, (int, float)):
        return luau_num(v)
    if isinstance(v, bytes):
        return luau_str(v)
    if isinstance(v, str):
        return luau_str(v)
    if isinstance(v, tuple) and v and v[0] == DESCRIPTOR:
        return '__descriptor(%s)' % (luau_lit(v[1]),)
    if isinstance(v, tuple) and v and v[0] == LINK:
        return '__link(%s)' % (luau_lit(v[1]),)
    return 'nil /*bad-const*/'


_IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
_LUAU_KW = {'and', 'break', 'do', 'else', 'elseif', 'end', 'false',
            'for', 'function', 'if', 'in', 'local', 'nil', 'not', 'or',
            'repeat', 'return', 'then', 'true', 'until', 'while',
            'continue'}


def luau_global(v):
    """GETGLOBAL operand: bare identifier when the pool value is a
    string that is a valid non-keyword identifier, else o["..."]."""
    if isinstance(v, bytes):
        try:
            s = v.decode('utf-8')
        except UnicodeDecodeError:
            s = None
        if s and _IDENT.match(s) and s not in _LUAU_KW:
            return s
        return 'o[%s]' % luau_str(v)
    return 'o[%s]' % luau_lit(v)


# ------------------------------------------------------------------
# per-instruction rendering
# ------------------------------------------------------------------
class Instr:
    __slots__ = ('idx', 'op', 'entry', 'D', 'Q', 'b', 'A', 'u', 'W')

    def __init__(self, idx, op, dec):
        self.idx = idx
        self.op = op
        self.D = dec['D'][idx - 1]
        self.Q = dec['Q'][idx - 1]
        self.b = dec['b'][idx - 1]
        self.A = dec['A'].get(idx)
        self.u = dec['u'].get(idx)
        self.W = dec['W'].get(idx)

    def tgt(self, stream):
        v = {'K': self.D, 'y': self.Q, 'x': self.b}[stream]
        return v + 1  # loop does P+=1 after the body


def subst_tokens(text, ins):
    """Apply §-token substitution to a template/cond string."""
    def rep(m):
        tok = m.group(1)
        if tok == 'rK':
            return 'r[%s]' % ins.D
        if tok == 'ry':
            return 'r[%s]' % ins.Q
        if tok == 'rx':
            return 'r[%s]' % ins.b
        if tok == 'rK+3':
            return 'r[%s]' % (ins.D + 3)
        if tok == 'K':
            return str(ins.D)
        if tok == 'y':
            return str(ins.Q)
        if tok == 'x':
            return str(ins.b)
        if tok == 'V':
            return luau_lit(ins.A)
        if tok == 'Y':
            return luau_lit(ins.u)
        if tok == 'B':
            return luau_lit(ins.W)
        if tok == 'G':
            return luau_global(ins.A)
        return m.group(0)
    return re.sub(r'§(rK\+3|rK|ry|rx|K|y|x|V|Y|B|G)§', rep, text)


_P_STREAM = re.compile(r'^[Pp]\s*=\s*\(?\s*[Kxy]\s*\[\s*P\s*\]\s*\)?\s*;$')


def verbatim_lines(raw_stmts, ins, mangled=False):
    """Handler body -> lifted lines: drop the fetch/pc bookkeeping,
    substitute stream reads by their decoded values, rename the
    register file h -> r and the state table t -> __state."""
    out = []
    for st in raw_stmts:
        s = st.strip()
        if not s or s == ';':
            continue
        compact = re.sub(r'\s+', '', s)
        if compact in ('P+=1;', ';'):
            continue
        if _P_STREAM.match(s) and not mangled:
            continue  # control transfer handled by the structurer
        if not mangled:
            s = s.replace('K[P]', '§K§').replace('y[P]', '§y§') \
                 .replace('x[P]', '§x§').replace('V[P]', '§V§') \
                 .replace('Y[P]', '§Y§').replace('b[P]', '§B§')
            s = subst_tokens(s, ins)
        else:
            # mangled bodies keep J[P]/P (self-patching); other stream
            # reads are still substituted by value
            s = s.replace('K[P]', str(ins.D)).replace('y[P]', str(ins.Q)) \
                 .replace('x[P]', str(ins.b))
            s = s.replace('V[P]', luau_lit(ins.A)) \
                 .replace('Y[P]', luau_lit(ins.u)) \
                 .replace('b[P]', luau_lit(ins.W))
        s = re.sub(r'\bt\[', '__state[', s)
        s = re.sub(r'\bh\b', 'r', s)
        s = re.sub(r'\bn\b', '__methods', s)
        out.append(s)
    return out


def strip_lead_parens(line):
    """A statement starting with '(expr)' followed by an index/call
    is ambiguous in Luau; drop the redundant parens."""
    s = line
    while s.startswith('('):
        depth = 0
        close = -1
        for i, ch in enumerate(s):
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    close = i
                    break
        if close < 0:
            break
        rest = s[close + 1:]
        if rest[:1] in ('[', '(', '.', ':'):
            s = s[1:close] + rest
        else:
            break
    return s


def render_stmt_lines(ins, optable, bodies):
    """Statement lines for one instruction (excluding control)."""
    e = optable[str(ins.op)]
    if e.get('verbatim'):
        lines = verbatim_lines(bodies.get(str(ins.op), []), ins,
                               mangled=bool(e.get('mangled')))
    else:
        lines = [subst_tokens(t, ins) for t in e.get('stmt', [])]
    lines = [strip_lead_parens(l) for l in lines]
    if e.get('mangled'):
        # mangled bodies read/patch J[P]: bind P to this instruction
        lines = ['P = %d' % ins.idx] + lines
    return lines


def render_cond(ins, optable):
    e = optable[str(ins.op)]
    return subst_tokens(e['cond'], ins)


class Irreducible(Exception):
    pass


def _immediate_dominators(start, succ, preds, nodes):
    """Cooper/Harvey/Kennedy iterative algorithm. `succ`/`preds` are
    adjacency dicts on `nodes`; start is the entry. Returns dict
    node -> immediate dominator (None for start/unreached)."""
    # iterative DFS postorder from start
    order = []
    seen = set()
    stack = [(start, iter(succ.get(start, [])))]
    seen.add(start)
    while stack:
        u, it = stack[-1]
        advanced = False
        for t in it:
            if t in nodes and t not in seen:
                seen.add(t)
                stack.append((t, iter(succ.get(t, []))))
                advanced = True
                break
        if not advanced:
            order.append(u)
            stack.pop()
    post = {u: i for i, u in enumerate(order)}

    def lca(a, b):
        while a != b:
            while post[a] < post[b]:
                a = idom[a]
            while post[b] < post[a]:
                b = idom[b]
        return a

    idom = {start: None}
    rpo = list(reversed(order))
    changed = True
    while changed:
        changed = False
        for u in rpo:
            if u == start:
                continue
            ps = [p for p in preds.get(u, []) if p in idom]
            if not ps:
                continue
            new = ps[0]
            for p in ps[1:]:
                new = lca(p, new)
            if idom.get(u) != new:
                idom[u] = new
                changed = True
    for u in nodes:
        idom.setdefault(u, None)
    return idom


class Cfg:
    def __init__(self, instrs, optable):
        self.instrs = {i.idx: i for i in instrs}
        self.n = len(instrs)
        self.exit = self.n + 1
        self.optable = optable
        self.succ = {}
        self.ctrl = {}
        for i in instrs:
            e = optable[str(i.op)]
            c = e['ctrl']
            self.ctrl[i.idx] = c
            if c == 'fall':
                self.succ[i.idx] = [i.idx + 1]
            elif c.startswith('jump:'):
                self.succ[i.idx] = [i.tgt(c.split(':')[1])]
            elif c in ('cjump', 'forloop'):
                self.succ[i.idx] = [i.idx + 1, i.tgt(e['tgt'])]
            elif c == 'ret':
                self.succ[i.idx] = []
            elif c in ('forprep', 'tforprep'):
                self.succ[i.idx] = [i.tgt(e['tgt'])]
            elif c == 'none':
                self.succ[i.idx] = []
            else:
                raise ValueError('ctrl %r' % c)
            bad = [t for t in self.succ[i.idx]
                   if not (1 <= t <= self.exit)]
            if bad:
                # out-of-range target: the instruction's operand is a
                # data value, not a code address (dead/garbage edge --
                # the builder dump carries the same value). Clamp to
                # EXIT and count.
                self.bad_targets = getattr(self, 'bad_targets', 0) \
                    + len(bad)
                self.succ[i.idx] = [t if 1 <= t <= self.exit
                                    else self.exit
                                    for t in self.succ[i.idx]]
        # for-pairs: a prep whose only edge lands on a loop-end op;
        # the loop-end's jump target is the body start (blocks are
        # scattered, so the prep need not be adjacent to the body).
        self.pairs = {}
        self.pair_body = {}
        for i in instrs:
            c = self.ctrl[i.idx]
            if c in ('forprep', 'tforprep'):
                end = self.succ[i.idx][0]
                want = 'forloop' if c == 'forprep' else 'cjump'
                if end in self.instrs and self.ctrl[end] == want \
                        and end != i.idx:
                    e = optable[str(self.instrs[end].op)]
                    body = self.instrs[end].tgt(e['tgt'])
                    if body != end and body in self.instrs:
                        self.pairs[i.idx] = end
                        self.pair_body[i.idx] = body
        self.reach = set()
        stack = [1]
        while stack:
            u = stack.pop()
            if u in self.reach:
                continue
            self.reach.add(u)
            stack.extend(self.succ.get(u, []))
        nodes = sorted(set(self.reach) | {self.exit})
        preds = {u: [] for u in nodes}
        for u in nodes:
            for t in self.succ.get(u, []):
                if t in preds:
                    preds[t].append(u)
        self.preds = preds
        # immediate dominators via Cooper et al. (iterative, postorder)
        self.idom = _immediate_dominators(1, self.succ, preds, nodes)
        # immediate post-dominators: same algorithm on reversed graph;
        # terminal nodes (return / stub) get an edge to EXIT.
        psucc = {u: (self.succ.get(u) or [self.exit]) for u in nodes}
        ppreds = {u: [] for u in nodes}
        for u in nodes:
            for t in psucc[u]:
                if t in ppreds:
                    ppreds[t].append(u)
        self.ipdom = _immediate_dominators(self.exit, ppreds, psucc,
                                           nodes)
        for u in nodes:
            if self.ipdom.get(u) == u:
                self.ipdom[u] = None
        # dominator sets only where needed (back-edge test): u is
        # dominated by v iff v is on u's idom chain.
        self._dom_cache = {}

        def domset(u):
            if u not in self._dom_cache:
                s = set()
                w = u
                while w is not None:
                    s.add(w)
                    w = self.idom.get(w)
                    if w == u:
                        break
                self._dom_cache[u] = s
            return self._dom_cache[u]
        self.dom = {u: domset(u) for u in nodes}
        self.back_targets = set()
        for u in nodes:
            for t in self.succ.get(u, []):
                if t in self.dom.get(u, set()) or t == u:
                    self.back_targets.add(t)

    def natural_loop(self, header):
        """Nodes of the natural loop for back edges into `header`:
        header + every node that reaches a latch without passing
        through header. A latch is a predecessor of header that is
        dominated by header (a true back edge) -- other predecessors
        are entry edges, not latches."""
        latches = [u for u in self.reach
                   if header in self.succ.get(u, [])
                   and header in self.dom.get(u, set())]
        loop = {header}
        # reverse graph
        preds = {}
        for u in self.reach:
            for t in self.succ.get(u, []):
                preds.setdefault(t, []).append(u)
        stack = list(latches)
        while stack:
            u = stack.pop()
            if u in loop:
                continue
            loop.add(u)
            stack.extend(preds.get(u, []))
        return loop


class Structurer:
    def __init__(self, cfg, optable, bodies):
        self.cfg = cfg
        self.optable = optable
        self.bodies = bodies
        self.emitted = set()

    def stmts(self, idx):
        return render_stmt_lines(self.cfg.instrs[idx], self.optable,
                                 self.bodies)

    def dup_chain(self, start, stops, ind, ret_only=True):
        """Re-emit a short linear chain of already-emitted nodes
        (a shared block targeted from several sites). With ret_only,
        the chain must end in RETURN (returns lines). Otherwise the
        chain may end at a not-yet-emitted node (returns
        (lines, end_node))."""
        cfg = self.cfg
        pad = '  ' * ind
        lines = []
        seen = set()
        u = start
        while True:
            if u in seen or len(seen) > 8 or u in stops:
                return None
            if u not in cfg.instrs or u in cfg.back_targets:
                return None
            seen.add(u)
            c = cfg.ctrl[u]
            if c in ('fall', 'jump:K', 'jump:y', 'jump:x'):
                lines += [pad + s for s in self.stmts(u)]
                u = cfg.succ[u][0]
                if not ret_only and u not in self.emitted:
                    self.dup_count = getattr(self, 'dup_count', 0) \
                        + len(seen)
                    return lines, u
            elif c == 'ret':
                lines += [pad + s for s in self.stmts(u)]
                self.dup_count = getattr(self, 'dup_count', 0) + len(seen)
                return lines if ret_only else (lines, None)
            else:
                return None

    # --------------------------------------------------------------
    def emit_seq(self, start, stops, breaks, ind):
        cfg = self.cfg
        out = []
        pad = '  ' * ind
        node = start
        guard = 0
        while node not in stops and node != cfg.exit:
            guard += 1
            if guard > 8 * cfg.n + 32:
                raise Irreducible('runaway sequence')
            if node in self.emitted:
                dup = self.dup_chain(node, stops, ind, ret_only=False)
                if dup is not None:
                    lines, nxt = dup
                    out += lines
                    if nxt is None:
                        return out
                    node = nxt
                    continue
                raise Irreducible('node %s emitted twice' % node)
            if node not in cfg.instrs:
                raise Irreducible('bad node %s' % node)
            if node in cfg.pairs:
                end = cfg.pairs[node]
                out += self.emit_forpair(node, end, stops, breaks, ind)
                node = end + 1
                continue
            if node in cfg.back_targets and node not in stops:
                lines, nxt = self.emit_loop(node, stops, breaks, ind)
                out += lines
                if nxt is None:
                    return out
                node = nxt
                continue
            c = cfg.ctrl[node]
            succ = cfg.succ[node]
            if c in ('ret', 'none'):
                self.emitted.add(node)
                out += [pad + s for s in self.stmts(node)]
                return out
            if c in ('fall', 'jump:K', 'jump:y', 'jump:x',
                     'forprep', 'tforprep'):
                self.emitted.add(node)
                out += [pad + s for s in self.stmts(node)]
                nxt = succ[0]
                if nxt in stops:
                    return out
                node = nxt
                continue
            if c in ('cjump', 'forloop'):
                self.emitted.add(node)
                out += self.emit_cjump(node, stops, breaks, ind)
                return out
            raise Irreducible('ctrl %s' % c)
        return out

    # --------------------------------------------------------------
    def emit_loop(self, header, stops, breaks, ind):
        """Emit a while loop whose header is `header` (a back-edge
        target). Returns (lines, next_node)."""
        cfg = self.cfg
        pad = '  ' * ind
        loop = cfg.natural_loop(header)
        exits = set()
        for u in loop:
            for t in cfg.succ.get(u, []):
                if t not in loop:
                    exits.add(t)
        eff_exits = {t for t in exits if t not in stops}
        if len(eff_exits) > 1:
            # multi-exit loop: accept when every non-primary exit is
            # a statement-free trampoline chain into the primary exit
            primary = None
            chains = {}
            for cand in sorted(eff_exits):
                ok = True
                for e in eff_exits:
                    if e == cand:
                        continue
                    ch = self._tramp_chain(e, cand, loop, eff_exits)
                    if ch is None:
                        ok = False
                        break
                    chains[e] = ch
                if ok:
                    primary = cand
                    break
            if primary is None:
                raise Irreducible('loop at %s has exits %s'
                                   % (header, sorted(eff_exits)))
            for e, ch in chains.items():
                for u in ch:
                    self.emitted.add(u)
            eff_exits = {primary}
        exit_node = eff_exits.pop() if eff_exits else None
        body_stops = set(stops) | {header} | exits
        body_breaks = set(breaks) | exits
        c = cfg.ctrl[header]
        lines = []
        if c in ('cjump', 'forloop'):
            # branch header: exit check inside a while-true
            fall, tgt = cfg.succ[header]
            if exit_node is not None and fall in exits and tgt not in exits:
                chk = 'if not (%s) then break end'
                body_start = tgt
            elif exit_node is not None and tgt in exits and fall not in exits:
                chk = 'if %s then break end'
                body_start = fall
            else:
                # header branch stays inside the loop both ways
                body = self.emit_seq(header, body_stops, body_breaks,
                                     ind + 1)
                lines = [pad + 'while true do'] + body + [pad + 'end']
                return lines, exit_node
            self.emitted.add(header)
            cond = render_cond(cfg.instrs[header], cfg.optable)
            lines = [pad + 'while true do']
            lines += ['  ' * (ind + 1) + s for s in self.stmts(header)]
            lines.append('  ' * (ind + 1) + (chk % cond))
            lines += self.emit_seq(body_start, body_stops, body_breaks,
                                   ind + 1)
            lines.append(pad + 'end')
            return lines, exit_node
        # non-branch header: plain while-true with internal breaks.
        # The header is in body_stops (latch termination), so step it
        # manually before sequencing the rest of the body.
        self.emitted.add(header)
        body = ['  ' * (ind + 1) + s for s in self.stmts(header)]
        nxt = cfg.succ[header][0] if cfg.succ[header] else None
        if nxt is not None and nxt != header and nxt not in body_stops:
            body += self.emit_seq(nxt, body_stops, body_breaks,
                                  ind + 1)
        lines = [pad + 'while true do'] + body + [pad + 'end']
        return lines, exit_node

    def _tramp_chain(self, src, primary, loop, exits):
        """If `src` reaches `primary` through statement-free,
        single-successor nodes (pure jumps/NOPs) that are not shared
        with code outside the loop+chain, return the chain nodes."""
        cfg = self.cfg
        chain = []
        seen = set()
        u = src
        while u != primary:
            if u in seen or u in loop or u not in cfg.instrs:
                return None
            if u in exits and u != src:
                return None
            seen.add(u)
            chain.append(u)
            if len(cfg.succ.get(u, [])) != 1:
                return None
            if self.stmts(u):
                return None
            # not shared: every pred is in the loop or the chain
            for p in cfg.preds.get(u, []):
                if p not in loop and p not in seen and p != src:
                    return None
            u = cfg.succ[u][0]
        return chain

    # --------------------------------------------------------------
    def emit_cjump(self, node, stops, breaks, ind):
        cfg = self.cfg
        pad = '  ' * ind
        ins = cfg.instrs[node]
        pre = [pad + s for s in self.stmts(node)]
        cond = render_cond(ins, cfg.optable)
        fall, tgt = cfg.succ[node][0], cfg.succ[node][1]
        if fall == tgt:
            return pre
        # shared return tails on one or both sides: duplicate inline
        t_dup = self.dup_chain(tgt, stops, ind + 1) \
            if tgt in self.emitted else None
        f_dup = self.dup_chain(fall, stops, ind + 1) \
            if fall in self.emitted else None
        if t_dup is not None and f_dup is not None:
            return pre + [pad + 'if %s then' % cond] + t_dup + \
                [pad + 'else'] + f_dup + [pad + 'end']
        if t_dup is not None:
            rest = self.emit_seq(fall, stops, breaks, ind)
            return pre + [pad + 'if %s then' % cond] + t_dup + \
                [pad + 'end'] + rest
        if f_dup is not None:
            rest = self.emit_seq(tgt, stops, breaks, ind)
            return pre + [pad + 'if not (%s) then' % cond] + f_dup + \
                [pad + 'end'] + rest
        stops_u = set(stops) | set(breaks)
        t_break = tgt in breaks
        f_break = fall in breaks
        t_stop = tgt in stops_u
        f_stop = fall in stops_u
        if t_break and f_break:
            return pre + [pad + 'break']
        if t_break and f_stop and not f_break:
            return pre + [pad + 'if %s then break end' % cond]
        if f_break and t_stop and not t_break:
            return pre + [pad + 'if not (%s) then break end' % cond]
        if t_break:
            rest = self.emit_seq(fall, stops, breaks, ind)
            return pre + [pad + 'if %s then break end' % cond] + rest
        if f_break:
            rest = self.emit_seq(tgt, stops, breaks, ind)
            return pre + [pad + 'if not (%s) then break end' % cond] + rest
        if t_stop and f_stop:
            return pre
        if t_stop:
            inner = self.emit_seq(fall, stops, breaks, ind + 1)
            return pre + [pad + 'if not (%s) then' % cond] + inner + \
                [pad + 'end']
        if f_stop:
            inner = self.emit_seq(tgt, stops, breaks, ind + 1)
            return pre + [pad + 'if %s then' % cond] + inner + \
                [pad + 'end']
        follow = cfg.ipdom.get(node)
        if follow is None or follow == node:
            raise Irreducible('no ipdom for %s' % node)
        nstops = set(stops) | {follow}
        if tgt == follow:
            inner = self.emit_seq(fall, nstops, breaks, ind + 1)
            lines = pre + [pad + 'if not (%s) then' % cond] + inner + \
                [pad + 'end']
        elif fall == follow:
            inner = self.emit_seq(tgt, nstops, breaks, ind + 1)
            lines = pre + [pad + 'if %s then' % cond] + inner + \
                [pad + 'end']
        else:
            tlines = self.emit_seq(tgt, nstops, breaks, ind + 1)
            flines = self.emit_seq(fall, nstops, breaks, ind + 1)
            lines = pre + [pad + 'if %s then' % cond] + tlines + \
                [pad + 'else'] + flines + [pad + 'end']
        return lines + self.emit_seq(follow, stops, breaks, ind)

    # --------------------------------------------------------------
    def emit_forpair(self, prep, end, stops, breaks, ind):
        cfg = self.cfg
        pad = '  ' * ind
        self.emitted.add(prep)
        self.emitted.add(end)
        out = [pad + s for s in self.stmts(prep)]
        eins = cfg.instrs[end]
        head = [pad + 'while true do']
        head += ['  ' * (ind + 1) + s for s in self.stmts(end)]
        cond = render_cond(eins, cfg.optable)
        head.append('  ' * (ind + 1) + 'if not (%s) then break end' % cond)
        body_start = cfg.pair_body[prep]
        body = self.emit_seq(body_start, set(stops) | {end},
                             set(breaks) | {end + 1}, ind + 1)
        return out + head + body + [pad + 'end']

    # --------------------------------------------------------------
    def structure(self):
        lines = self.emit_seq(1, {self.cfg.exit}, set(), 1)
        missing = [i for i in self.cfg.reach
                   if i != self.cfg.exit and i not in self.emitted]
        if missing:
            raise Irreducible('reachable but unemitted: %s'
                              % (missing[:8],))
        return lines


# ------------------------------------------------------------------
# kernel fallback
# ------------------------------------------------------------------
def kernel_lines(cfg, optable, bodies):
    """Dispatch kernel: chunked two-level dispatch (flat if/elseif
    chains of <=128 keep the parser recursion bounded)."""
    pad = '  '
    out = [pad + 'local P = 1',
           pad + 'while true do']
    n = cfg.n

    def block(idx, ind):
        p = '  ' * ind
        ins = cfg.instrs[idx]
        body = [p + '  ' + s
                for s in render_stmt_lines(ins, optable, bodies)]
        c = cfg.ctrl[idx]
        if c == 'fall':
            body.append(p + '  P = %d' % (idx + 1))
        elif c.startswith('jump:'):
            body.append(p + '  P = %d' % cfg.succ[idx][0])
        elif c in ('cjump', 'forloop'):
            cond = render_cond(ins, optable)
            body.append(p + '  if %s then P = %d else P = %d end'
                        % (cond, cfg.succ[idx][1], cfg.succ[idx][0]))
        elif c in ('forprep', 'tforprep'):
            body.append(p + '  P = %d' % cfg.succ[idx][0])
        return body

    CH = 128
    chunks = [(s, min(s + CH - 1, n)) for s in range(1, n + 1, CH)]
    for ci, (lo, hi) in enumerate(chunks):
        kw = 'if' if ci == 0 else 'elseif'
        out.append(pad + '  %s P <= %d then' % (kw, hi))
        for idx in range(lo, hi + 1):
            kw2 = 'if' if idx == lo else 'elseif'
            out.append(pad + '    %s P == %d then' % (kw2, idx))
            out += block(idx, 3)
        out.append(pad + '    end')
    out.append(pad + '  else break end')
    out.append(pad + 'end')
    return out


# ------------------------------------------------------------------
# driver
# ------------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))
_OPTABLE = None
_BODIES = None

MANGLED = {101, 124, 127, 132}
STREAM_LOCAL = {122: 'x', 128: 'K', 137: 'J', 152: 'y'}


def _data():
    global _OPTABLE, _BODIES
    if _OPTABLE is None:
        _OPTABLE = json.load(open(os.path.join(_HERE,
                                               'optable_buffer.json')))
        _BODIES = json.load(open(os.path.join(_HERE,
                                              'bodies_buffer.json')))
    return _OPTABLE, _BODIES


def _preamble(proto, dec, kernel):
    lines = []
    ops = [i[0] for i in proto['instrs']]
    need = set()
    for op in ops:
        if op in STREAM_LOCAL:
            need.add(STREAM_LOCAL[op])
    if kernel or any(op in MANGLED for op in ops):
        need.add('J')
    lines.append('  local r = {} -- register file')
    lines.append('  local f, o, p, l, G, s = 1, __env, nil, nil, nil, nil')
    decl = '  local A, F, z, E, B, a, j, R, m, M, q, N, C, c, L = ' \
           '1, 0, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil'
    if 'J' in need or any(op in MANGLED for op in ops):
        decl = decl.replace('local A, F,', 'local A, F, P,')
        decl = decl.replace('= 1, 0, nil', '= 1, 0, 1, nil', 1)
    lines.append(decl)
    lines.append('  local __proto = nil -- this proto table (VM object)')
    if 'J' in need:
        lines.append('  local J = { %s }'
                     % ', '.join(str(v) for v in dec['J']))
    if 'x' in need:
        lines.append('  local x = { %s }'
                     % ', '.join(str(v) for v in dec['b']))
    if 'y' in need:
        lines.append('  local y = { %s }'
                     % ', '.join(str(v) for v in dec['Q']))
    if 'K' in need:
        lines.append('  local K = { %s }'
                     % ', '.join(str(v) for v in dec['D']))
    return lines


def _lift_proto(pi, proto, dec, optable, bodies):
    instrs = [Instr(x, row[0], dec)
              for x, row in enumerate(proto['instrs'], start=1)]
    if not instrs:
        return ['  -- (empty proto)'], 'structured', 0
    try:
        cfg = Cfg(instrs, optable)
    except Irreducible:
        return None, 'failed', 0
    st = Structurer(cfg, optable, bodies)
    try:
        body = st.structure()
        unreach = len([i for i in cfg.instrs if i not in cfg.reach])
        return _preamble(proto, dec, kernel=False) + body, \
            'structured', unreach
    except Irreducible:
        pass
    body = kernel_lines(cfg, optable, bodies)
    return _preamble(proto, dec, kernel=True) + body, 'kernel', 0


def lift_buffer(protos, pool_entries):
    """protos: buffer_body protos ({'instrs': [[op,v2,v3,v4]..],
    'x': X, ...}); pool_entries: parse_pool output.
    Returns (source_text, stats dict)."""
    optable, bodies = _data()
    pool = decode_pool(pool_entries)
    n_instr = sum(len(p['instrs']) for p in protos)
    out = ['-- lifted from Luraph buffer-variant bytecode (stage-1 VM)',
           '-- protos: %d, instructions: %d' % (len(protos), n_instr),
           'local __state = {} -- VM state table (helpers/factories)',
           'local __env = _G -- VM environment (globals)',
           'local __methods = nil -- VM method/factory table',
           'local function __descriptor(id) return { __descriptor = id } end',
           'local function __link(v) return v end',
           '']
    stats = {'protos': len(protos), 'instrs': n_instr,
             'structured': 0, 'kernel': 0, 'unreachable': 0,
             'kernel_protos': []}
    for pi, proto in enumerate(protos):
        dec = decode_proto(proto['instrs'], pool)
        body, mode, unreach = _lift_proto(pi, proto, dec, optable,
                                          bodies)
        if body is None:
            body = ['  -- CFG build failed for this proto']
            mode = 'kernel'
        stats[mode] = stats.get(mode, 0) + 1
        stats['unreachable'] += unreach
        if mode == 'kernel':
            stats['kernel_protos'].append(pi)
        out.append('-- proto %d: %d instructions, X=%s, mode=%s'
                   % (pi, len(proto['instrs']),
                      proto.get('x', proto.get('X', '?')), mode))
        out.append('local function proto_%d(U, ...)' % pi)
        out += body
        out.append('end')
        out.append('')
    return '\n'.join(out) + '\n', stats
