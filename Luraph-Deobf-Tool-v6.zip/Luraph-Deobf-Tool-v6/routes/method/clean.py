#!/usr/bin/env python3
"""clean.py — source-clean stage for the method route (v6 upgrade).

Post-processes lift.py's lifted.luau: promotes the register table
R[k] to real local variables with evidence-based names and emits an
equivalence map (clean_map.json). Every transformation is
provable-only:

  * a proto is promoted ONLY if its register table never escapes
    (no bare `R` use such as table.unpack(R, ...)), is never indexed
    dynamically (the two lift.py prologue idioms — argument copy and
    multret spill — are recognised; a spill disqualifies the proto),
    and every R[k] access uses a literal index;
  * naming evidence comes from the lifted text itself:
      CONFIRMED — the register is defined exactly once, by a bare
        known-global identifier (game, loadstring, ...), and never
        redefined;
      INFERRED  — the register's definition chain is rooted at a
        global and refined through constant string members; the name
        is the final member (placeId from game.PlaceId), camelCased;
        closures take the child proto's role (closure<Id>);
      NEUTRAL   — everything else: kind-based names from the first
        definition's RHS shape (s<n> string, n<n> number, b<n>
        boolean, t<n> table, f<n> function, v<n> call, r<n> other).
  * rewrites are string-literal aware (literals are never touched);
    a literal-multiset check over the whole file proves no string or
    number constant was altered.

Protos that fail a gate are copied through unchanged and recorded in
the map with the reason. Instruction accounting is anchored to
lift_report.json (instr/dispatched per proto), i.e. equivalence is
measured against the route's lifted output, as required.
"""
import json
import re

KNOWN_GLOBALS = {
    'game', 'workspace', 'script', 'Instance', 'loadstring', 'load',
    'print', 'warn', 'pairs', 'ipairs', 'next', 'tonumber', 'tostring',
    'type', 'typeof', 'select', 'unpack', 'table', 'string', 'math',
    'task', 'os', 'io', 'tick', 'wait', 'spawn', 'delay', 'pcall',
    'xpcall', 'error', 'assert', 'setmetatable', 'getmetatable',
    'rawget', 'rawset', 'rawequal', 'rawlen', 'require', 'utf8',
    'buffer', 'vector', 'Color3', 'UDim2', 'UDim', 'Vector3',
    'Vector2', 'CFrame', 'Enum', 'BrickColor', 'TweenInfo', 'Random',
    'DateTime', 'coroutine', 'bit32', 'shared', 'plugin', 'settings',
    'UserSettings', 'getfenv', 'setfenv', 'gcinfo', 'time', 'ypcall',
    'collectgarbage', 'newproxy', 'elapsedTime',
}

LUAU_KEYWORDS = {
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
    'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
    'repeat', 'return', 'then', 'true', 'until', 'while', 'continue',
    'export', 'type',
}

RESERVED_LOCALS = {'upv', 'T', '_args', '_i', '_res', 'R'}


# ------------------------------------------------------------------
# string-aware segmentation: split a line into (is_string, text) parts
# ------------------------------------------------------------------
def segments(line, in_long):
    """Yield (is_str, text); in_long = inside [[ ]] across lines."""
    out = []
    i = 0
    n = len(line)
    buf = ''
    while i < n:
        if in_long:
            j = line.find(']]', i)
            if j < 0:
                out.append((True, line[i:]))
                return out, True
            out.append((True, line[i:j + 2]))
            i = j + 2
            in_long = False
            continue
        c = line[i]
        if line.startswith('[[', i):
            if buf:
                out.append((False, buf))
                buf = ''
            j = line.find(']]', i + 2)
            if j < 0:
                out.append((True, line[i:]))
                return out, True
            out.append((True, line[i:j + 2]))
            i = j + 2
        elif c in '"\'':
            if buf:
                out.append((False, buf))
                buf = ''
            j = i + 1
            while j < n:
                if line[j] == '\\':
                    j += 2
                    continue
                if line[j] == c:
                    break
                j += 1
            out.append((True, line[i:j + 1]))
            i = j + 1
        else:
            buf += c
            i += 1
    if buf:
        out.append((False, buf))
    return out, in_long


def code_only(lines):
    """Concatenated non-string text of a block (for analysis)."""
    in_long = False
    parts = []
    for ln in lines:
        segs, in_long = segments(ln, in_long)
        parts.append(''.join(t for is_str, t in segs if not is_str))
    return parts


def literal_multiset(lines):
    """Multiset of STRING literals only: register indices (numbers in
    code) legitimately disappear under promotion, and header comments
    add numbers; strings are the corruption risk this check guards."""
    in_long = False
    lits = []
    for ln in lines:
        segs, in_long = segments(ln, in_long)
        for is_str, t in segs:
            if is_str:
                lits.append(t)
    from collections import Counter
    return Counter(lits)


# ------------------------------------------------------------------
# per-proto analysis
# ------------------------------------------------------------------
ARGCOPY = re.compile(r'for _i = 0, (\d+) do R\[_i\] = _args\[_i \+ 1\] end')
R_LIT = re.compile(r'R\[(-?\d+)\]')
R_ANY = re.compile(r'R\[')
DEF = re.compile(r'^\s*R\[(\d+)\] = (.+?);?\s*$')


def _camel(member):
    if not member:
        return None
    name = member[0].lower() + member[1:]
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', name):
        return None
    if name in LUAU_KEYWORDS:
        return None
    return name


def _kind_name(k, rhs):
    r = rhs.strip()
    if r.startswith('"') or r.startswith("'"):
        return f's{k}'
    if re.match(r'^-?[\d.]', r):
        return f'n{k}'
    if r in ('true', 'false'):
        return f'b{k}'
    if r.startswith('{'):
        return f't{k}'
    if r.startswith('function'):
        return f'f{k}'
    if '(' in r:
        return f'v{k}'
    return f'r{k}'


def analyse_proto(lines):
    """Returns (ok, reason, names) where names maps reg -> (name, label).
    lines: the proto's source lines (code view precomputed outside)."""
    code = code_only(lines)
    joined = '\n'.join(code)
    # gate 1: register table must exist
    if not any('local R = {}' in c for c in code):
        return False, 'no register table', {}, {}
    # gate 2: dynamic indexing (outside the arg-copy idiom)
    for c in code:
        c2 = ARGCOPY.sub('', c)
        for m in R_ANY.finditer(c2):
            if not re.match(r'R\[-?\d+\]', c2[m.start():]):
                return False, 'dynamic register index', {}, {}
    # gate 3: bare R escape (whole-table use)
    stripped = R_LIT.sub('', joined)
    stripped = re.sub(r'local R = \{\}', '', stripped)
    if re.search(r'(?<![\w.])R(?![\w\[])', stripped):
        return False, 'register table escapes (bare R use)', {}, {}
    regs = sorted({int(m.group(1)) for c in code
                   for m in R_LIT.finditer(c)})
    if any(k < 0 for k in regs):
        return False, 'negative register index', {}, {}
    # definitions per register (string-aware: work on raw lines, but
    # DEF lines are single statements; string RHS is fine here because
    # we only classify its shape / exact bare-identifier form)
    defs = {k: [] for k in regs}
    for ln in lines:
        m = DEF.match(ln)
        if m and int(m.group(1)) in defs:
            defs[int(m.group(1))].append(m.group(2).strip())
    names = {}
    init_globals = {}
    used = set(RESERVED_LOCALS)
    proto_fns = set(re.findall(r'proto_[A-Za-z0-9_]+', joined))
    # identifiers referenced bare in the proto (collision universe for
    # inferred/neutral names)
    all_idents = set(re.findall(r'(?<![\w.])[A-Za-z_][A-Za-z0-9_]*',
                                joined))
    # first textual access line index per register (for the
    # confirmed-global shadowing gate)
    first_access = {}
    for li, c in enumerate(code):
        for m in R_LIT.finditer(c):
            first_access.setdefault(int(m.group(1)), li)
    def_line = {}
    for li, ln in enumerate(lines):
        m = DEF.match(ln)
        if m:
            def_line.setdefault(int(m.group(1)), li)
    claimed_globals = set()
    for k in regs:
        ds = defs[k]
        name = None
        label = 'neutral'
        if len(ds) == 1:
            rhs = ds[0]
            if rhs in KNOWN_GLOBALS and rhs not in claimed_globals:
                # shadowing gate: a local named after the global is
                # initialised at declaration from the outer global
                # (Luau RHS scope rule) — provably equal ONLY if the
                # register's first access is this very definition and
                # the global is never assigned bare in the proto.
                bare_assign = re.search(
                    r'(?<![\w.])' + re.escape(rhs) + r'\s*=(?![=])',
                    joined)
                if (first_access.get(k) == def_line.get(k)
                        and not bare_assign):
                    name, label = rhs, 'confirmed'
                    init_globals[k] = rhs
                    claimed_globals.add(rhs)
            else:
                pm = re.search(r'proto_([A-Za-z0-9_]+)', rhs) \
                    if rhs.startswith('function') else None
                if rhs in proto_fns or pm:
                    cid = (rhs if rhs in proto_fns
                           else 'proto_' + pm.group(1)).replace(
                               'proto_', '')
                    name, label = f'closure_{cid}', 'inferred'
        if name is None and ds:
            # global-rooted self-refining chain -> final member name
            first = ds[0]
            if first in KNOWN_GLOBALS and all(
                    d.startswith(f'R[{k}]') for d in ds[1:]):
                members = re.findall(r'\["([^"]+)"\]', ' '.join(ds))
                if members:
                    cand = _camel(members[-1])
                    if cand:
                        name, label = cand, 'inferred'
        if name is None:
            name = _kind_name(k, ds[0]) if ds else f'r{k}'
            label = 'neutral'
        taken = used if label == 'confirmed' else used | all_idents
        base = name
        n = 2
        while name in taken:
            name = f'{base}{n}'
            n += 1
        used.add(name)
        names[k] = (name, label)
    return True, '', names, init_globals


def rewrite_proto(lines, names, init_globals=None):
    """Apply R[k] -> name in code segments only; rewrite the prologue
    idioms; declare locals in place of the register table. Confirmed
    global bindings are initialised at the declaration from the outer
    global of the same name (Luau: RHS of a local statement resolves
    in the enclosing scope)."""
    init_globals = init_globals or {}
    out = []
    in_long = False
    for ln in lines:
        if 'local R = {}' in ln:
            ks = sorted(names)
            decl = ', '.join(names[k][0] for k in ks)
            inits = ', '.join(init_globals.get(k, 'nil') for k in ks)
            out.append(re.sub(r'local R = \{\}',
                              f'local {decl} = {inits}', ln))
            continue
        m = ARGCOPY.search(ln)
        if m:
            n = int(m.group(1))
            ind = ln[:len(ln) - len(ln.lstrip())]
            for i in range(n + 1):
                out.append(f'{ind}{names[i][0]} = _args[{i + 1}]')
            continue
        segs, in_long = segments(ln, in_long)
        parts = []
        for is_str, t in segs:
            if not is_str:
                t = R_LIT.sub(
                    lambda mm: names[int(mm.group(1))][0], t)
            parts.append(t)
        out.append(''.join(parts))
    return out


# ------------------------------------------------------------------
# driver
# ------------------------------------------------------------------
FN_START = re.compile(r'^local function (proto_(\S+))\(upv, \.\.\.\)')


def clean_source(lifted_text, lift_report):
    """Returns (cleaned_text, map_dict). lift_report: parsed
    lift_report.json ({proto_id: {instr, dispatched, structured}}),
    used for accounting anchoring only."""
    lines = lifted_text.split('\n')
    out = ['-- Source-cleaned by the v6 clean stage (clean.py): register '
           'promotion with',
           '-- evidence-labelled names (CONFIRMED global bindings / '
           'INFERRED derivations /',
           '-- neutral kind names). Protos failing a safety gate are '
           'kept verbatim and',
           '-- listed in clean_map.json. Instruction accounting is '
           'anchored to lift_report.json.',
           '']
    pmap = {}
    i = 0
    stats = {'protos': 0, 'promoted': 0, 'skipped': 0,
             'names_confirmed': 0, 'names_inferred': 0,
             'names_neutral': 0}
    while i < len(lines):
        m = FN_START.match(lines[i])
        if not m:
            out.append(lines[i])
            i += 1
            continue
        j = i + 1
        while j < len(lines) and lines[j] != 'end':
            j += 1
        block = lines[i:j + 1]
        pid = m.group(2).replace('_', '.')
        stats['protos'] += 1
        ok, reason, names, init_globals = analyse_proto(block)
        rep = (lift_report or {}).get(pid, {})
        entry = {'proto': pid,
                 'instr': rep.get('instr'),
                 'dispatched': rep.get('dispatched'),
                 'structured': rep.get('structured'),
                 'lines_in': len(block)}
        if ok:
            new_block = rewrite_proto(block, names, init_globals)
            cnt = {'confirmed': 0, 'inferred': 0, 'neutral': 0}
            for k, (nm, lab) in names.items():
                cnt[lab] += 1
            stats['promoted'] += 1
            stats['names_confirmed'] += cnt['confirmed']
            stats['names_inferred'] += cnt['inferred']
            stats['names_neutral'] += cnt['neutral']
            entry.update({'promoted': True,
                          'registers': len(names),
                          'names': {str(k): list(v)
                                    for k, v in names.items()},
                          'name_counts': cnt,
                          'lines_out': len(new_block)})
            out.append(f'-- cleaned: {len(names)} registers promoted '
                       f'({cnt["confirmed"]} CONFIRMED, '
                       f'{cnt["inferred"]} INFERRED, '
                       f'{cnt["neutral"]} neutral)')
            out += new_block
        else:
            stats['skipped'] += 1
            entry.update({'promoted': False, 'reason': reason,
                          'lines_out': len(block)})
            out += block
        pmap[pid] = entry
        i = j + 1
    text = '\n'.join(out)
    before = literal_multiset(lines)
    after = literal_multiset(text.split('\n'))
    cmap = {'stage': 'method-clean-v1',
            'protos': pmap,
            'totals': stats,
            'literal_multiset_equal': before == after,
            'note': 'Equivalence anchor: per-proto instr/dispatched '
                    'from lift_report.json; transformation is '
                    'statement-preserving (register promotion only).'}
    return text, cmap
