#!/usr/bin/env python3
"""luraph-v151-deobf — deobfuscator for Luraph v15.1 (state-machine VM layout).

Built on the architecture of caomod2077/Deobfuscator-Luraph-V15 (which only
supports the v15.0 layout) plus a v15.1 engine written from a manual RE of
the v15.1 VM:

  1. detect   header / layout markers for v15.1
  2. fold     conservative integer constant folding (fold.py)
  3. dump     run the target in the standalone Luau CLI with string.unpack
              hooked (runner_template.luau); the deserializer parses the
              whole proto tree eagerly, so all protos/constants are dumped
              in one run
  4. parse    rebuild the proto tree from the unpack log (parse_protos.py);
              the parse must consume the log exactly or the run is rejected
  5. extract  opcode-name table + handler bodies from the folded VM source
              (extract_vm.py), classify handlers into semantic ops
              (semantics.py; "mangled" handlers are superinstructions with a
              fixed core sequence)
  6. lift     devirtualise to structured Luau source (lift.py) and verify
              with luau-compile when available

Safety: stage 3 EXECUTES the target inside the Luau CLI sandbox (no
network, no io in that runtime) to trigger its deserializer — the same
approach as the upstream v15 tool. Only run scripts you own or are
authorised to analyse, on an isolated machine, with no real credentials.

Usage: python3 luraph151.py <input.lua> [-o outdir] [--luau /path/to/luau]
"""
import argparse, hashlib, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fold as fold_mod
import parse_protos
import extract_vm
import semantics
import lift as lift_mod

def find_luau(cli_value):
    cands = [cli_value, os.environ.get('LUAU_BIN'),
             os.path.join(HERE, 'bin', 'luau'),
             os.path.expanduser('~/workspace/roblox_deobf/bin/luau'),
             os.path.join(HERE, '..', 'Deobfuscator-Luraph-V15', 'bin', 'luau'),
             'luau']
    for c in cands:
        if not c: continue
        p = os.path.normpath(c) if '/' in c else c
        try:
            r = subprocess.run([p, '--help'], capture_output=True, timeout=10)
            if r.returncode == 0 or b'Usage' in (r.stdout + r.stderr):
                return p
        except Exception:
            continue
    return None

def luau_compile_ok(luau, path):
    if not luau: return None
    d = os.path.dirname(luau)
    comp = next((os.path.join(d, n) for n in ('luau-compile', 'luau-compile.exe')
                 if os.path.exists(os.path.join(d, n))), None)
    if not comp: return None
    r = subprocess.run([comp, path], capture_output=True, timeout=60)
    return r.returncode == 0

def luau_analyze(luau, path):
    """Return (exit_code, n_warnings) or None when luau-analyze is absent.
    Info only: obfuscated sources always draw warnings."""
    if not luau: return None
    d = os.path.dirname(luau)
    ana = next((os.path.join(d, n) for n in ('luau-analyze', 'luau-analyze.exe')
                if os.path.exists(os.path.join(d, n))), None)
    if not ana: return None
    r = subprocess.run([ana, path], capture_output=True, timeout=120)
    out = (r.stdout + r.stderr).decode('utf-8', errors='replace')
    return (r.returncode, out.count('Warning'))

def extract_key_candidates(folded):
    """Find candidate XOR keys for tag-3 strings: table literals of >=8
    comma-separated arithmetic items that all evaluate to bytes. The real
    key in the sample sits in the deserializer's string helper, its last
    byte written as an arithmetic expression."""
    cands = []
    for m in re.finditer(r'\{([0-9\s,+\-*()]{16,600})\}', folded):
        items = [it.strip() for it in m.group(1).split(',')]
        if len(items) < 8 or len(items) > 40: continue
        vals = []
        for it in items:
            v = fold_mod.safe_eval(it) if it else None
            if v is None or not (0 <= v <= 255): vals = None; break
            vals.append(v)
        if vals and len(vals) >= 8:
            cands.append(vals)
    return cands

def string_score(node):
    """Fraction of decrypted string constants that look like real text."""
    tot, good = 0, 0
    def walk(pr):
        nonlocal tot, good
        for v in pr['consts']:
            if isinstance(v, str):
                tot += 1
                if v and all(ch.isprintable() or ch in '\n\t\r' for ch in v):
                    good += 1
        for c in pr['children']: walk(c)
    walk(node)
    return (good / tot) if tot else 0.0

_BUFFER_READERS = {'readu8','readu16','readi16','readu32','readi32',
                   'readf32','readf64','readstring'}
def version_header(src):
    """L6: Luraph version header in a `--` comment line within the
    first 2000 chars (see luraph_v6.version_header — same rule)."""
    m = re.search(r'(?m)^[ \t]*--.*Luraph Obfuscator v([0-9.]+)',
                  src[:2000])
    return m.group(1) if m else None


# Foreign-family headers (v6.5.0: shared predicate). Same list as
# luraph_v6.foreign_header_in (v6's L1 evidence veto); this copy
# lets the method route itself veto foreign headers, so the
# predicate is single and shared (v6 reuses it via method_detect
# and must NOT define a second, divergent predicate).
_FOREIGN_HEADERS = (
    'AntiLua Obfuscator v',
    'generated by [https://obf.antilua.xyz/]',
    'created by XHider v',
    'generated by luast v',
    'generated using MoonVeil',
)


def foreign_header_in(src):
    """Foreign-family header in the first 4096 chars, or None.
    A mere mention deeper in the file never vetoes."""
    head = src[:4096]
    for h in _FOREIGN_HEADERS:
        if h in head:
            return h
    return None


def is_buffer_variant(src):
    # v6.5.0 (BF-Main fix): the buffer screen is HEADER-AGNOSTIC.
    # The old version-header veto is DELETED: BF-Main HAS a v15.1
    # header and the veto was the entire misroute (headered files
    # never reached this screen). What keeps the screen honest:
    # the foreign-header veto (shared, above), the load-bearing
    # bootstrap vetoes (MY=[==[ + LPH magic, Fz=function
    # definition -- StealAnEggs stays False), and reader evidence
    # (name set >= 5 OR literal buffer.read* set >= 5). The
    # buffer build never writes buffer.read* literally in the
    # old golden (readers are slot-table-installed by name), so
    # the name-set branch is load-bearing and a literal-only
    # predicate is forbidden. The write* set is deliberately NOT
    # a routing conjunct (old golden has ~0 write literals):
    # write-family validation lives inside the BF stage, which
    # fail-closes to exit 2. bf-tester (v15.0) returns True
    # here by design and is harmless: the upstream delegate in
    # main() runs BEFORE this screen is ever consulted.
    if 'buffer' not in src:
        return False
    if foreign_header_in(src) is not None:
        return False
    bi = src.find('MY=[==[')
    if bi >= 0 and src[bi + 7:bi + 10] == 'LPH':
        return False
    if re.search(r'\bFz=function', src) is not None:
        return False
    found = {r for r in _BUFFER_READERS if r in src}
    literals = set(re.findall(r'buffer\.(read\w+)', src))
    return len(found) >= 5 or len(literals) >= 5

def buffer_route(src, data, outdir, luau, sha, spoof_id='auto',
                   qa_flag='on'):
    buffer_qa = None
    """Buffer-based Luraph build (no string.unpack): fold, dump every
    buffer.read* via the proxy runner, and harvest the constant pool from
    the log. Header (tagged pool), body grammar and stage-1 opcode
    semantics are all cracked (v6 upgrade); the route lifts protos to
    Luau source (lifted.luau, buffer_lifter.py) and ends PARTIAL with
    the named residues in the report."""
    folded = fold_mod.fold_source(src)
    folded_path = os.path.join(outdir, 'folded.luau')
    open(folded_path, 'w', encoding='utf-8').write(folded)
    ok = luau_compile_ok(luau, folded_path)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes; luau-compile folded: {ok}")
    esc = ''.join('\\%03d' % b for b in data)
    template = open(os.path.join(HERE, 'runner_buffer.luau'), encoding='utf-8').read()
    runner_path = os.path.join(outdir, 'runner.luau')
    open(runner_path, 'w', encoding='utf-8').write(template.replace('__TARGET_SOURCE__', esc))
    log_path = os.path.join(outdir, 'buf.log')
    with open(log_path, 'w', encoding='utf-8') as lf:
        r = subprocess.run([luau, runner_path], stdout=lf, stderr=subprocess.STDOUT, timeout=600)
    reads, strings = [], []
    for line in open(log_path, encoding='utf-8', errors='replace'):
        p = line.rstrip('\n').split('\t')
        if len(p) >= 4 and p[0] == 'BUF|':
            reads.append((p[1], int(p[2]), p[3]))
            if p[1] == 'readstring' and p[3].startswith('HEX:'):
                try: strings.append((int(p[2]), bytes.fromhex(p[3][4:]).decode('utf-8', errors='replace')))
                except ValueError: pass
    id_section = None
    mono = all(reads[i][1] <= reads[i + 1][1] for i in range(len(reads) - 1))
    with open(os.path.join(outdir, 'constant_pool.txt'), 'w', encoding='utf-8') as f:
        for off, s in strings:
            f.write(f"@{off}\t{s!r}\n")
    print(f"[3] buffer dump: {len(reads)} reads, offsets monotonic: {mono}, strings: {len(strings)}")
    # stage 3b: reconstruct the binary from the read log and try the
    # (case-verified) body grammar on the largest contiguous readu8 run
    body_info = None
    body_failed = None
    try:
        import struct as _struct
        import buffer_body
        size = max((off for _, off, _ in reads), default=0) + 64
        binbuf = bytearray(size)
        covered = bytearray(size)
        def put(off, bs):
            for n, b in enumerate(bs):
                if off + n < size:
                    binbuf[off + n] = b; covered[off + n] = 1
        for meth, off, val in reads:
            try:
                if meth == 'readu8': put(off, bytes([int(val) & 0xFF]))
                elif meth in ('readu16', 'readi16'): put(off, _struct.pack('<H', int(val) & 0xFFFF))
                elif meth in ('readu32', 'readi32'): put(off, _struct.pack('<I', int(val) & 0xFFFFFFFF))
                elif meth == 'readf32': put(off, _struct.pack('<f', float(val)))
                elif meth == 'readf64': put(off, _struct.pack('<d', float(val)))
                elif meth == 'readstring' and val.startswith('HEX:'):
                    put(off, bytes.fromhex(val[4:]))
            except (ValueError, OverflowError, _struct.error):
                pass
        u8 = sorted({off for meth, off, _ in reads if meth == 'readu8'})
        best = None
        if u8:
            run_s = prev = u8[0]; runs = []
            for o in u8[1:]:
                if o == prev + 1: prev = o; continue
                runs.append((run_s, prev)); run_s = prev = o
            runs.append((run_s, prev))
            best = max(runs, key=lambda r: r[1] - r[0])
        # L3: log the run length so a future worker can revisit the
        # 1000 threshold with data; the threshold itself is unchanged.
        print(f"[3b] largest contiguous readu8 run: "
              f"{best if best else None} "
              f"(length {best[1] - best[0] + 1 if best else 0})")
        if best and best[1] - best[0] > 1000:
            lo_b, hi_b = best[0], best[1] + 1
            magic, protos = buffer_body.parse_body(bytes(binbuf[lo_b:hi_b]))
            n_instr = sum(len(p['instrs']) for p in protos)
            with open(os.path.join(outdir, 'binary.bin'), 'wb') as f:
                f.write(bytes(binbuf[:max(o for _, o, _ in reads) + 1]))
            with open(os.path.join(outdir, 'protos.json'), 'w') as f:
                json.dump({'magic': magic, 'body_range': [lo_b, hi_b],
                           'protos': protos}, f)
            body_info = (len(protos), n_instr, lo_b, hi_b)
            print(f"[3b] body grammar parsed: {len(protos)} protos, {n_instr} instructions, body [{lo_b}, {hi_b})")
            # stage 3c: opcode semantics (cracked in the v6 upgrade;
            # see UPGRADE-REPORT.md) -> lift protos to Luau source
            try:
                import buffer_lifter
                pool_entries = buffer_lifter.parse_pool(
                    bytes(binbuf[:lo_b]), 4, lo_b)
                lifted_src, lift_stats = buffer_lifter.lift_buffer(
                    protos, pool_entries)
                lifted_path = os.path.join(outdir, 'lifted.luau')
                with open(lifted_path, 'w', encoding='utf-8') as f:
                    f.write(lifted_src)
                lift_ok = luau_compile_ok(luau, lifted_path)
                body_info = body_info + (lift_stats, lift_ok)
                print(f"[3c] lifted source: {lift_stats['structured']} "
                      f"structured + {lift_stats['kernel']} kernel protos, "
                      f"luau-compile: {lift_ok} -> lifted.luau")
            except Exception as e:
                print(f"[3c] lift not applied: {e}")
            # stage 3e: qa_clean + QA report (v6.2.0, additive).
            # lifted.luau is the buffer route's cleaned-equivalent
            # output, so it gets the buffer-lift passes; a post-qa
            # compile failure restores the pre-qa text.
            try:
                import qa_clean as _qc
                import qa_report as _qr
                _lp = os.path.join(outdir, 'lifted.luau')
                if os.path.isfile(_lp):
                    _pre_buf = open(_lp, encoding='utf-8').read()
                    _pre_a = _qr.audit_text(_pre_buf)
                    _stats_b = {}
                    _new_buf = _pre_buf
                    if qa_flag == 'on' and lift_ok:
                        _new_buf, _stats_b, _rem_b = _qc.clean_text(
                            _pre_buf, 'buffer-lift')
                        with open(_lp, 'w', encoding='utf-8') as f:
                            f.write(_new_buf)
                        if not luau_compile_ok(luau, _lp):
                            print('[3e] qa post-qa compile FAILED; '
                                  'restored pre-qa lifted.luau')
                            with open(_lp, 'w', encoding='utf-8') as f:
                                f.write(_pre_buf)
                            _new_buf, _stats_b = _pre_buf, {}
                    _post_a = _qr.audit_text(_new_buf)
                    _def_b = [{'file': 'lifted.luau', 'line': d['line'],
                               'category': '__descriptor',
                               'detail': 'runtime deferred-link key id=%s; '
                                         'not recoverable statically' % d['id']}
                              for d in _post_a['descriptor']]
                    _def_b.append({'file': 'lifted.luau', 'line': None,
                                   'category': 'unfolded_arith',
                                   'detail': '%d q+N-M residues; not folded '
                                             '(double rounding is not '
                                             'associative)' % len(_post_a['unfolded_arith'])})
                    buffer_qa = _qr.build_report(
                        '6.2.0', 'method-buffer',
                        {'lifted.luau': {'before': _pre_a,
                                         'after': _post_a}},
                        _stats_b, None,
                        {'kernel_protos': _post_a['proto_kernel_ids'],
                         'kernel_count': _post_a['proto_kernel'],
                         'kind_changes_note': 'VM register reuse '
                         '(single-letter vars change kind constantly); '
                         'expected, not a defect'},
                        _def_b, qa_enabled=(qa_flag == 'on' and lift_ok))
            except Exception as e:
                print(f"[3e] qa not applied: {e}")
            # stage 3d: identity spoofing (additive; --spoof-id auto).
            # Static half over the decoded pool; behavior forks run
            # the payload with a fabricated game env (nothing is
            # fetched — HttpGet & co are logged mock interactions).
            if spoof_id == 'auto':
                try:
                    import identity as identity_mod
                    import buffer_lifter
                    pool_entries = buffer_lifter.parse_pool(
                        bytes(binbuf[:lo_b]), 4, lo_b)
                    pool_values = buffer_lifter.decode_pool(pool_entries)
                    icands, ifields, iseen = identity_mod \
                        .extract_buffer(pool_values, protos)
                    iforks, _ = identity_mod.run_forks(
                        luau, os.path.join(
                            HERE, 'runner_buffer_behavior.luau'),
                        data, icands, timeout=600, max_total=4)
                    irep = identity_mod.build_report(
                        'method-buffer', icands, ifields, iforks,
                        notes=['buffer VM gate-site dataflow is not '
                               'modelled; candidates are numeric '
                               'constants co-referenced by protos '
                               'that reference an identity field '
                               '(weak evidence), resolved by the '
                               'behavior forks.'],
                        fields_seen=iseen)
                    with open(os.path.join(
                            outdir, 'identity_report.json'),
                            'w', encoding='utf-8') as f:
                        json.dump(irep, f, indent=1)
                    id_section = identity_mod.report_section(irep)
                    print(f"[3d] identity: fields seen={iseen}, "
                          f"candidates={ {k: len(v) for k, v in icands.items()} }, "
                          f"forks={len(iforks)} -> identity_report.json")
                except Exception as e:
                    print(f"[3d] identity stage not applied: {e}")
        else:
            # L3: no contiguous readu8 run > 1000 -> the body
            # grammar cannot validate this file as a buffer build.
            body_failed = (
                'no contiguous readu8 run > 1000 '
                f'(best run: {best}, length '
                f'{best[1] - best[0] + 1 if best else 0})')
    except Exception as e:
        print(f"[3b] body parse not applied: {e}")
        body_failed = f'body grammar parse failed: {e}'
    # L3 (P1): body-grammar failure is a rejection (exit 2), not a
    # PARTIAL. A misrouted foreign file (e.g. mos_hub via a direct
    # luraph151 invocation, whose readu8 count is 1) must not be
    # reported as a PARTIAL buffer result. Exit 5 is kept only when
    # the body parses (the buffer golden's behaviour, unchanged).
    if not body_info:
        reason = body_failed or 'body grammar did not validate'
        with open(os.path.join(outdir, 'report.md'), 'w',
                  encoding='utf-8') as f:
            f.write('# luraph-v151-deobf report — buffer variant\n\n')
            f.write(f'- input: {len(data)} bytes, sha256 `{sha}`\n')
            f.write('- route: buffer-based Luraph build '
                    '(no string.unpack deserializer)\n')
            f.write(f'- buffer reads logged: {len(reads)} '
                    f'(monotonic offsets: {mono})\n')
            f.write(f'- strings harvested from readstring: '
                    f'{len(strings)} (constant_pool.txt)\n')
            f.write(f'- luau-compile folded: {ok}\n')
            f.write('- status: **REJECTED** — buffer screen matched '
                    'but body grammar did not validate — not a '
                    f'buffer-variant Luraph build ({reason}).\n')
        print(f'done (REJECTED buffer variant: {reason}) -> {outdir}')
        return 2
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write("# luraph-v151-deobf report — buffer variant\n\n")
        f.write(f"- input: {len(data)} bytes, sha256 `{sha}`\n")
        f.write(f"- route: buffer-based Luraph build (no string.unpack deserializer)\n")
        f.write(f"- buffer reads logged: {len(reads)} (monotonic offsets: {mono})\n")
        f.write(f"- strings harvested from readstring: {len(strings)} (constant_pool.txt)\n")
        f.write(f"- luau-compile folded: {ok}\n")
        if body_info:
            f.write(f"- body grammar: **parsed** — {body_info[0]} protos, {body_info[1]} instructions, "
                    f"body [{body_info[2]}, {body_info[3]}) (protos.json, binary.bin)\n")
            if len(body_info) > 4:
                ls, lok = body_info[4], body_info[5]
                f.write(f"- opcode semantics: **cracked** — all 162 stage-1 dispatch "
                        f"opcodes classified from their handler bodies "
                        f"(optable_buffer.json; 158 packed op words in this sample "
                        f"incl. the 2^52-1 stub sentinel)\n")
                f.write(f"- lifted source: lifted.luau — {ls['structured']} structured + "
                        f"{ls['kernel']} dispatch-kernel protos, {ls['instrs']} instructions "
                        f"accounted, luau-compile: {lok}\n")
                f.write("- status: **PARTIAL** — source lifted and compile-verified; "
                        "residues: CLOSURE child identity binds via the deserializer's "
                        "deferred link registry (rendered __descriptor(id), 65 closure "
                        "instructions in the reference sample); per-proto X field role "
                        "unconfirmed; kernel protos are exact pc-dispatched "
                        "transcriptions, not structured control flow.\n")
            else:
                f.write("- status: **PARTIAL** — bytecode fully recovered and verified "
                        "(parser consumption == read log); the source lift stage "
                        "was not applicable to this build.\n")
        else:
            f.write("- status: **PARTIAL** — deserializer fully dumped; body grammar\n")
            f.write("  parse was not applicable to this build.\n")
        if id_section:
            f.write(id_section)
    if buffer_qa is not None:
        try:
            import qa_report as _qr2
            with open(os.path.join(outdir, 'qa_report.json'), 'w',
                      encoding='utf-8') as f:
                json.dump(buffer_qa, f, indent=1)
            with open(os.path.join(outdir, 'report.md'), 'a',
                      encoding='utf-8') as f:
                f.write('\n'.join(_qr2.section(buffer_qa)) + '\n')
        except Exception as e:
            print(f"[3e] qa report write failed: {e}")
    print(f"done (PARTIAL buffer variant) -> {outdir}")
    return 5

def find_upstream():
    for cand in (os.environ.get('LURAPH_UPSTREAM_DIR', ''),
                 os.path.join(HERE, '..', 'Deobfuscator-Luraph-V15'),
                 os.path.expanduser('~/luau-deobf/tools/Deobfuscator-Luraph-V15')):
        if cand and os.path.isfile(os.path.join(cand, 'deob.js')):
            return os.path.abspath(cand)
    return None

# P0 (2026-10-24, AnimeDice v20.0 misroute): the upstream engine is
# verified ONLY for v15.0/v14.x layouts. Any other version must never
# be sent to it -- an upstream exit 0 on an unsupported layout is a
# misroute, not a recovery (v20.0 produced a 61-line / 0.136%-of-input
# env-probe fragment with exit 0 under v6.2.0).
UPSTREAM_ALLOWED_RE = re.compile(r'^(15\.0|14\.[0-9]+)$')


def is_upstream_allowed(version):
    return bool(version and UPSTREAM_ALLOWED_RE.match(version))


# Output-validity gate for upstream outputs (P0, revised
# 2026-10-24 after a golden false positive): the gate is the
# PROGRAM TERMINUS, not a size ratio.  The first version of this
# gate rejected outputs < 5% of input -- but the genuine v5 golden
# for bf-tester is only 1.726% of its input (18,523 / 1,073,339
# bytes, 434 lines ending in real statements), so a ratio test
# false-positives on real recoveries and was removed.  What
# distinguishes the AnimeDice fragment is its terminus: it ends
# in a dangling unused local (`local RunService =
# game:GetService("RunService")`, never used) with no program
# terminus -- a strict prefix, not a program.  That check (on a
# < 50% output, to avoid flagging complete scripts that happen
# to end in an unused local) is the gate.  The version allowlist
# above remains the primary defence: unsupported versions never
# reach the upstream engine at all.
def _upstream_output_valid(out_path, data_len):
    """Return (valid, reason). reason is '' when valid."""
    try:
        out_size = os.path.getsize(out_path)
    except OSError:
        return False, 'upstream output file missing'
    if out_size == 0:
        return False, 'upstream output is empty'
    try:
        text = open(out_path, encoding='utf-8', errors='replace').read()
    except OSError:
        return False, 'upstream output unreadable'
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if lines and data_len and out_size < 0.5 * data_len:
        m = re.match(r'\s*local\s+([A-Za-z_][A-Za-z0-9_]*)\s*=',
                     lines[-1])
        if m:
            # Count identifier uses outside string literals: the
            # baseline fragment's final line is
            # `local RunService = game:GetService("RunService")`,
            # where a naive count sees the name twice (declaration
            # + string literal) although nothing ever uses it.
            stripped = re.sub(r'"[^"\n]*"|\'[^\'\n]*\'',
                              '""', text)
            uses = len(re.findall(r'\b' + re.escape(m.group(1))
                                  + r'\b', stripped))
            if uses == 1:
                return False, (f'upstream output ends in a dangling '
                               f'unused local {m.group(1)!r} with no '
                               'program terminus: prefix-only fragment')
    return True, ''


def upstream_route(input_path, outdir, version, data_len, sha):
    """Luraph v15.0 / v14.x layouts are handled by the verified upstream
    Deobfuscator-Luraph-V15 (this engine cannot read them). Run it
    directly when the clone is available."""
    if not is_upstream_allowed(version):
        print(f"    REJECTED: Luraph v{version} is not an upstream-"
              "supported layout (allowlist: 15.0 / 14.x only); "
              "refusing to send it to the upstream engine.")
        with open(os.path.join(outdir, 'report.md'), 'w',
                  encoding='utf-8') as f:
            f.write('# luraph-deobf report — upstream route\n\n')
            f.write(f'- input: {data_len} bytes, sha256 `{sha}`\n')
            f.write(f'- detected: Luraph v{version} (not the v15.1 '
                    'layout)\n')
            f.write('- status: **REJECTED** — version not in the '
                    'upstream allowlist (15.0 / 14.x only). No '
                    'upstream output was accepted.\n')
        return 2
    up = find_upstream()
    if not up:
        print("    upstream Deobfuscator-Luraph-V15 clone not found "
              "(set LURAPH_UPSTREAM_DIR); cannot process this layout here.")
        return 3
    out_path = os.path.join(outdir, 'deobfuscated_upstream.lua')
    env = dict(os.environ, PYTHON_BIN='python3')
    print(f"[upstream] Luraph v{version} -> upstream tool at {up}")
    try:
        r = subprocess.run(['node', 'deob.js', os.path.abspath(input_path),
                            '-o', out_path], cwd=up, env=env,
                           capture_output=True, text=True, timeout=1800)
    except subprocess.TimeoutExpired:
        print("    upstream tool timed out")
        return 5
    ok = r.returncode == 0 and os.path.isfile(out_path)
    tail = (r.stdout or '')[-500:]
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write("# luraph-deobf report — upstream route\n\n")
        f.write(f"- input: {data_len} bytes, sha256 `{sha}`\n")
        f.write(f"- detected: Luraph v{version} (not the v15.1 layout)\n")
        f.write(f"- engine: upstream Deobfuscator-Luraph-V15 at `{up}`\n")
        f.write(f"- result: {'ok' if ok else 'failed'} (exit {r.returncode})\n")
        f.write(f"- output: deobfuscated_upstream.lua\n\n```\n{tail}\n```\n")
    print(f"    upstream exit={r.returncode} output={'yes' if ok else 'no'}")
    if ok:
        # P0 output-validity gate: an upstream exit 0 with a
        # prefix-only fragment must never become a tool exit 0.
        valid, reason = _upstream_output_valid(out_path, data_len)
        if not valid:
            print(f"    REJECTED by output-validity gate: {reason}")
            rejected_path = os.path.join(
                outdir, 'deobfuscated_upstream_REJECTED.lua')
            try:
                os.rename(out_path, rejected_path)
            except OSError:
                rejected_path = out_path
            with open(os.path.join(outdir, 'report.md'), 'w',
                      encoding='utf-8') as f:
                f.write('# luraph-deobf report — upstream route\n\n')
                f.write(f'- input: {data_len} bytes, sha256 `{sha}`\n')
                f.write(f'- detected: Luraph v{version} (not the '
                        'v15.1 layout)\n')
                f.write(f'- engine: upstream Deobfuscator-Luraph-V15 '
                        f'at `{up}`\n')
                f.write(f'- upstream exit: {r.returncode}\n')
                f.write('- status: **REJECTED** — output-validity '
                        f'gate: {reason}. The upstream fragment was '
                        f'renamed to '
                        f'`{os.path.basename(rejected_path)}` and '
                        'must not be delivered as a deobfuscation.\n')
            return 2
        # QA report, audit-only: upstream output is reproduced
        # verbatim and is never modified by qa_clean.
        try:
            import qa_report as _qr
            _up = os.path.join(outdir, 'deobfuscated_upstream.lua')
            _a = _qr.audit_text(open(_up, encoding='utf-8').read()) \
                if os.path.isfile(_up) else _qr.audit_text('')
            _rep = _qr.build_report(
                '6.2.0', 'method-upstream',
                {'deobfuscated_upstream.lua': {'before': _a, 'after': _a}},
                {}, None, {},
                [{'file': 'deobfuscated_upstream.lua', 'line': None,
                  'category': 'upstream-verbatim',
                  'detail': 'output of the upstream engine, reproduced '
                            'verbatim; qa_clean never modifies it'}],
                qa_enabled=False)
            with open(os.path.join(outdir, 'qa_report.json'), 'w',
                      encoding='utf-8') as f:
                json.dump(_rep, f, indent=1)
            with open(os.path.join(outdir, 'report.md'), 'a',
                      encoding='utf-8') as f:
                f.write('\n'.join(_qr.section(_rep)) + '\n')
        except Exception as e:
            print(f"[qa] upstream qa report failed: {e}")
        print(tail[-300:])
        return 0
    print("    upstream stderr:", (r.stderr or '')[-300:])
    return 5

def is_v151_structural(src):
    """v15.1 layout fingerprint for files whose header comment was
    stripped: string.unpack proto deserializer + long-bracket blob +
    the `}).t(` method entry. The pipeline's later stages validate
    (exact log consumption + handler classification), so a false
    positive aborts there instead of producing garbage."""
    return ('string.unpack' in src
            and ('[==[' in src or '[=[' in src)
            and bool(re.search(r'\}\)\.t\(', src)))

def detect(src):
    # L6: header window 400 -> 2000 chars, comment-line anchored
    # (version_header); goldens sit at offset 33, unchanged.
    v151 = version_header(src) == '15.1'
    markers = {
        'header_v15.1': v151,
        'string.unpack deserializer': 'string.unpack' in src,
        'ascii85+lz blob': '[==[' in src or '[=[' in src,
        'method entry .t(': bool(re.search(r'\}\)\.t\(', src)),
        'structural_v15.1': is_v151_structural(src),
    }
    return markers

def main():
    ap = argparse.ArgumentParser(description='Deobfuscate Luraph v15.1 scripts')
    ap.add_argument('input')
    ap.add_argument('-o', '--outdir', default=None)
    ap.add_argument('--luau', default=None)
    ap.add_argument('--force', action='store_true', help='continue even if v15.1 header not found')
    ap.add_argument('--spoof-id', choices=('auto', 'off'), default='auto',
                    help='automatic game-ID spoofing for identity gates '
                         '(identity_report.json + behavior forks); '
                         'off = byte-identical legacy behaviour')
    ap.add_argument('--qa-clean', choices=('on', 'off'), default='on',
                    help='v6.2.0 QA passes on cleaned.luau / buffer '
                         'lifted.luau (nil compaction, dead-write '
                         'elimination, kind-downgrade, junk removal); '
                         'off restores exact v6.1.0 bytes for those files')
    args = ap.parse_args()

    data = open(args.input, 'rb').read()
    src = data.decode('utf-8', errors='strict')
    sha = hashlib.sha256(data).hexdigest()
    outdir = args.outdir or os.path.splitext(os.path.basename(args.input))[0] + '-v151-deobf'
    os.makedirs(outdir, exist_ok=True)
    print(f"[0] input {args.input}  {len(data)} bytes  sha256={sha[:16]}...")

    markers = detect(src)
    print(f"[1] detect: {markers}")

    # L6: same comment-anchored 2000-char window as detect().
    # The upstream delegate's own regex is unchanged.
    vm_ver = version_header(src)
    if vm_ver and vm_ver != '15.1':
        return upstream_route(args.input, outdir, vm_ver, len(data), sha)

    luau = find_luau(args.luau)
    if not luau:
        print("    Luau CLI not found (needed for stage 3/6). Set --luau or LUAU_BIN.")
        return 2
    print(f"    luau: {luau}")

    # v6.5.0 three-way buffer dispatch: AFTER the upstream
    # delegate (above -- bf-tester/hune at 15.0 never reach here)
    # and BEFORE the method pipeline. Headered + structural ->
    # method pipeline (pass through); headered + buffer + not
    # structural -> NEW buffer-bf stage (BF-Main lands here);
    # headerless + buffer -> OLD buffer route (L7 order kept).
    # The structural guard is load-bearing: a headered v15.1
    # METHOD file can also satisfy the buffer predicate (its VM
    # handler tables contain buffer entries), so a two-way
    # dispatch without the guard would misroute method files.
    if is_buffer_variant(src):
        if markers['header_v15.1'] and markers['structural_v15.1']:
            print("    headered method file with buffer handler "
                  "entries -> method pipeline")
        elif markers['header_v15.1']:
            print("    headered buffer build detected -> buffer-bf route")
            _routes = os.path.normpath(os.path.join(HERE, '..'))
            if _routes not in sys.path:
                sys.path.insert(0, _routes)
            import buffer_bf.stage as _bf_stage
            return _bf_stage.buffer_bf_route(
                src, data, outdir, luau, sha,
                spoof_id=args.spoof_id, qa_flag=args.qa_clean)
        else:
            print("    buffer-based Luraph variant detected -> buffer route")
            return buffer_route(src, data, outdir, luau, sha,
                                spoof_id=args.spoof_id,
                                qa_flag=args.qa_clean)

    # L7 (documented precedence, implemented order): v6 auto checks
    # bootstrap first; inside this route a version header beats
    # everything (upstream for != 15.1, above); for headerless files
    # buffer is checked before structural (pre-existing order,
    # preserved deliberately — the buffer body-grammar gate (L3)
    # now fail-closes, so a both-evidence headerless file that is
    # not a real buffer build exits 2 rather than misrouting).
    # (The v6.5.0 dispatch above already returned for every
    # buffer-variant file, so this block now only sees
    # non-buffer headerless files; its meaning is unchanged.)
    if not markers['header_v15.1']:
        if is_buffer_variant(src):
            print("    buffer-based Luraph variant detected -> buffer route")
            return buffer_route(src, data, outdir, luau, sha,
                                spoof_id=args.spoof_id,
                                qa_flag=args.qa_clean)
        if markers['structural_v15.1']:
            print("    header missing but v15.1 structural fingerprint matches -> proceeding (validated downstream)")
        elif not args.force:
            print("    NOT a Luraph v15.1 file (header missing). Aborting; use --force to try anyway.")
            return 2

    # stage 2: fold
    folded_path = os.path.join(outdir, 'folded.luau')
    folded = fold_mod.fold_source(src)
    open(folded_path, 'w', encoding='utf-8').write(folded)
    ok = luau_compile_ok(luau, folded_path)
    ana = luau_analyze(luau, folded_path)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes; luau-compile folded: {ok}; analyze: {ana}")
    if ok is False:
        print("    folded source does not compile; aborting")
        return 3

    # stage 3: dump unpack log via generated runner (target embedded, no io needed)
    esc = ''.join('\\%03d' % b for b in data)
    template = open(os.path.join(HERE, 'runner_template.luau'), encoding='utf-8').read()
    runner_path = os.path.join(outdir, 'runner.luau')
    open(runner_path, 'w', encoding='utf-8').write(template.replace('__TARGET_SOURCE__', esc))
    log_path = os.path.join(outdir, 'unpack.log')
    with open(log_path, 'w', encoding='utf-8') as lf:
        r = subprocess.run([luau, runner_path], stdout=lf, stderr=subprocess.STDOUT, timeout=300)
    print(f"[3] dump: runner exit={r.returncode}, log={log_path}")

    # stage 4: parse protos (must consume the log exactly). The XOR key for
    # string constants is build-specific in principle, so try every
    # candidate key found in the folded source and keep the parse whose
    # decrypted strings look most like real text.
    reads = parse_protos.load_log(log_path)
    candidates = extract_key_candidates(folded)
    if list(parse_protos.KEY13) not in candidates:
        candidates.append(list(parse_protos.KEY13))
    root_node, p, best = None, None, -1.0
    for cand in candidates:
        parse_protos.set_key(cand)
        try:
            pp = parse_protos.P(reads)
            node = parse_protos.read_proto(pp)
        except Exception:
            continue
        if pp.i != len(reads):
            continue
        score = string_score(node)
        if score > best:
            root_node, p, best, used_key = node, pp, score, cand
        if score >= 0.999:
            break
    if root_node is None:
        print(f"    PARSE MISMATCH: no candidate key consumed the full log "
              f"({len(candidates)} candidates tried); aborting")
        return 4
    print(f"    xor key: {used_key} (string score {best:.3f})")
    protos_path = os.path.join(outdir, 'protos.json')
    json.dump(root_node, open(protos_path, 'w'), indent=1)
    def count(pr):
        sub = [count(c) for c in pr['children']]
        return 1 + sum(s[0] for s in sub), len(pr['code']['A']) + sum(s[1] for s in sub)
    nproto, ninstr = count(root_node)
    print(f"[4] parse: consumed {p.i}/{len(reads)} reads; {nproto} protos, {ninstr} instructions")

    # stage 5: extract + classify
    opnames = extract_vm.extract_y(folded)
    handlers = extract_vm.extract_handlers(folded)
    json.dump({str(k): v for k, v in sorted(opnames.items())},
              open(os.path.join(outdir, 'opnames.json'), 'w'), indent=0)
    json.dump(handlers, open(os.path.join(outdir, 'handlers.json'), 'w'), indent=1)
    extract_vm.disassemble(root_node, opnames, os.path.join(outdir, 'disasm.txt'))
    classes = semantics.classify(handlers)
    json.dump({k: v for k, v in sorted(classes.items())},
              open(os.path.join(outdir, 'ops.json'), 'w'), indent=1)
    unknown = [nm for nm in opnames.values() if classes.get(nm) in (None, 'UNKNOWN')]
    print(f"[5] extract: {len(opnames)} opcodes, {len(handlers)} handlers, unknown ops: {unknown or 'none'}")

    # stage 6: lift + verify
    lifted_path = os.path.join(outdir, 'lifted.luau')
    report_path = os.path.join(outdir, 'lift_report.json')
    sys.argv = ['lift.py', protos_path, os.path.join(outdir, 'opnames.json'),
                os.path.join(outdir, 'handlers.json'), lifted_path, report_path]
    lift_mod.main()
    ok2 = luau_compile_ok(luau, lifted_path)
    ana2 = luau_analyze(luau, lifted_path)
    print(f"[6] lift: luau-compile lifted: {ok2}; analyze: {ana2}")

    lift_report = json.load(open(report_path))
    structured = sum(1 for v in lift_report['protos'].values() if v['structured'])

    # stage 6b: source-clean (v6 upgrade) — register promotion with
    # evidence-labelled names over the lifted output. Additive:
    # lifted.luau is never modified; failures only skip the stage.
    clean_info = None
    qa_rep = None
    try:
        import clean as clean_stage
        lifted_text = open(lifted_path, encoding='utf-8').read()
        cleaned_text, cmap = clean_stage.clean_source(
            lifted_text, lift_report['protos'])
        # stage 6c: qa_clean (v6.2.0) + QA report. The clean map is
        # patched (renamed registers, per-proto lines_out) so it
        # keeps describing the final cleaned text; totals and the
        # literal multiset are unaffected (renames touch no literal).
        _cmap_pre = None
        try:
            _cmap_pre = json.loads(json.dumps(cmap))
            import qa_clean as _qc
            import qa_report as _qr
            _pre_c = cleaned_text
            _pre_a = _qr.audit_text(_pre_c)
            _pre_l = _qr.audit_text(lifted_text)
            _stats = {}
            if args.qa_clean == 'on':
                cleaned_text, _stats, _removed = _qc.clean_text(
                    _pre_c, 'method-clean')
                cmap['qa_clean'] = _stats
                for (bname, old, new, _touched) in \
                        _stats.get('rename', {}).get('locations', []):
                    pid = bname[6:].replace('_', '.') \
                        if bname.startswith('proto_') else bname
                    ent = cmap['protos'].get(pid)
                    if ent and ent.get('names'):
                        dg = re.search(r'(\d+)$', old)
                        if dg and dg.group(1) in ent['names']:
                            lab = ent['names'][dg.group(1)][1]
                            ent['names'][dg.group(1)] = [new, lab]
                for (s, e, bname, _p) in _qc.find_blocks(
                        _pre_c.split('\n')):
                    pid = bname[6:].replace('_', '.') \
                        if bname.startswith('proto_') else bname
                    ent = cmap['protos'].get(pid)
                    if ent and 'lines_out' in ent:
                        ent['lines_out'] -= sum(
                            1 for r in _removed if s + 1 <= r <= e + 1)
            _post_a = _qr.audit_text(cleaned_text)
            _def = [{'file': 'cleaned.luau', 'line': p['proto'],
                     'category': 'skipped-proto',
                     'detail': 'gate %s; R-table kept verbatim' % p['reason']}
                    for p in cmap['protos'].values()
                    if not p.get('promoted')]
            _def += [{'file': 'cleaned.luau', 'line': kc['line'],
                      'category': 'kind-change-kind-lettered',
                      'detail': '%s in %s: %s' % (kc['name'],
                      kc['function'], kc['kinds'])}
                     for kc in _post_a['kind_changes']
                     if re.match(r'^[snbtf]\d+$', kc['name'])]
            qa_rep = _qr.build_report(
                '6.2.0', 'method',
                {'cleaned.luau': {'before': _pre_a, 'after': _post_a},
                 'lifted.luau': {'before': _pre_l, 'after': _pre_l}},
                _stats, cmap['totals'],
                {'neutral_kind_changes_post': sum(
                    1 for kc in _post_a['kind_changes']
                    if not re.match(r'^[snbtf]\d+$', kc['name'])),
                 'note': 'neutral-name kind changes are register reuse, '
                         'not misleading names'},
                _def, qa_enabled=(args.qa_clean == 'on'))
            print(f"[6c] qa_clean: { {k: v.get('changed', 0) for k, v in _stats.items()} }")
        except Exception as e:
            print(f"[6c] qa not applied: {e}")
            qa_rep = None
        cleaned_path = os.path.join(outdir, 'cleaned.luau')
        with open(cleaned_path, 'w', encoding='utf-8') as f:
            f.write(cleaned_text)
        clean_ok = luau_compile_ok(luau, cleaned_path)
        if not clean_ok and args.qa_clean == 'on' and qa_rep is not None \
                and qa_rep['qa_clean']['enabled']:
            # Roll back to the pre-qa text (the v6.1.0 behaviour) and
            # report the rollback instead of shipping a broken file.
            with open(cleaned_path, 'w', encoding='utf-8') as f:
                f.write(_pre_c)
            if _cmap_pre is not None:
                cmap = _cmap_pre
            clean_ok = luau_compile_ok(luau, cleaned_path)
            qa_rep['qa_clean']['enabled'] = False
            qa_rep['defects_not_fixed'].append(
                {'file': 'cleaned.luau', 'line': None,
                 'category': 'qa_clean_rollback',
                 'detail': 'post-qa compile failed; pre-qa text restored'})
            print('[6c] qa post-qa compile FAILED; restored pre-qa text')
        cmap['luau_compile'] = clean_ok
        with open(os.path.join(outdir, 'clean_map.json'), 'w',
                  encoding='utf-8') as f:
            json.dump(cmap, f, indent=1)
        clean_info = (cmap['totals'], clean_ok,
                      cmap['literal_multiset_equal'])
        print(f"[6b] clean: {cmap['totals']['promoted']}/"
              f"{cmap['totals']['protos']} protos promoted; "
              f"luau-compile cleaned: {clean_ok}")
    except Exception as e:
        print(f"[6b] clean stage not applied: {e}")

    # stage 7: identity spoofing (v6 feature; --spoof-id auto) —
    # static gate-site extraction over the recovered protos, then
    # behavior forks executing the target with a fabricated game
    # env whose identity fields are pre-seeded with the candidates.
    # Additive: identity_report.json + this report section only.
    identity_section = None
    if args.spoof_id == 'auto':
        try:
            import identity as identity_mod
            iroot = lift_mod.Proto(root_node, 'root')
            iall = []

            def _collect(p):
                for ch in p.children:
                    _collect(ch)
                iall.append(p)
            _collect(iroot)
            for _ip in iall:
                lift_mod.expand(_ip, opnames, classes)
            icands, ifields = identity_mod.extract_from_protos(iroot)
            iforks, _ = identity_mod.run_forks(
                luau, os.path.join(HERE, 'runner_behavior.luau'),
                data, icands)
            irep = identity_mod.build_report(
                'method', icands, ifields, iforks,
                notes=['Luau == never fires __eq for table-vs-number '
                       '(verified with the bundled CLI), so no Luau '
                       'sentinel can capture the compared value in '
                       'this sandbox; candidates are extracted '
                       'statically, pre-seeded at read time, and '
                       'resolved across differential forks. '
                       'HttpGet & co are logged mock interactions; '
                       'nothing is fetched.'])
            with open(os.path.join(outdir, 'identity_report.json'),
                      'w', encoding='utf-8') as f:
                json.dump(irep, f, indent=1)
            identity_section = identity_mod.report_section(irep)
            print(f"[7] identity: candidates="
                  f"{ {k: [c['value'] for c in v] for k, v in icands.items()} }, "
                  f"forks={len(iforks)} -> identity_report.json")
        except Exception as e:
            print(f"[7] identity stage not applied: {e}")

    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write(f"# luraph-v151-deobf report\n\n")
        f.write(f"- input: `{os.path.basename(args.input)}` ({len(data)} bytes, sha256 `{sha}`)\n")
        f.write(f"- detect: {markers}\n")
        f.write(f"- protos: {nproto}, instructions: {ninstr}, unpack reads consumed: {p.i}/{len(reads)}\n")
        f.write(f"- opcodes classified: {len(opnames) - len(unknown)}/{len(opnames)}"
                f" (unknown: {unknown or 'none'})\n")
        f.write(f"- lifted protos structured: {structured}/{len(lift_report['protos'])}"
                f"; pc-loop fallback: {list(lift_report['fallback']) or 'none'}\n")
        f.write(f"- xor key used: {used_key} (string score {best:.3f})\n")
        f.write(f"- luau-compile: folded={ok}, lifted={ok2}; luau-analyze: folded={ana}, lifted={ana2}\n")
        if clean_info:
            ct, cok, lit_eq = clean_info
            f.write(f"- source-cleaned: cleaned.luau — {ct['promoted']}/{ct['protos']} protos "
                    f"register-promoted ({ct['names_confirmed']} CONFIRMED, "
                    f"{ct['names_inferred']} INFERRED, {ct['names_neutral']} neutral names); "
                    f"luau-compile cleaned={cok}; literal multiset preserved={lit_eq}; "
                    f"see clean_map.json\n")
        if identity_section:
            f.write(identity_section)
        f.write(f"\nOutputs: folded.luau, protos.json, opnames.json, handlers.json, ops.json,\ndisasm.txt, lifted.luau, lift_report.json, cleaned.luau, clean_map.json, unpack.log, runner.luau"
                + (", identity_report.json" if identity_section else "")
                + "\n")
    if qa_rep is not None:
        try:
            import qa_report as _qr3
            with open(os.path.join(outdir, 'qa_report.json'), 'w',
                      encoding='utf-8') as f:
                json.dump(qa_rep, f, indent=1)
            with open(os.path.join(outdir, 'report.md'), 'a',
                      encoding='utf-8') as f:
                f.write('\n'.join(_qr3.section(qa_rep)) + '\n')
        except Exception as e:
            print(f"[6c] qa report write failed: {e}")
    print(f"done -> {outdir}")
    return 0

if __name__ == '__main__':
    sys.exit(main())
