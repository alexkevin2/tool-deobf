#!/usr/bin/env python3
"""buffer_body.py — body parser for the Luraph buffer variant.

Byte grammar of the body section (CONFIRMED in the luraph-payload case,
cross-validated 3 ways: parser consumption == the deserializer's own
readu8 log 61,554/61,554 bytes; per-proto instruction counts match
dynamic ground truth 57/57):

    body  := varint(magic) proto* trailing_u8(0x0A)
    proto := varint(nconsts) varint(pool_idx)[nconsts]
             varint(X) varint(zero) varint(big)
             instr[big - 64412]
    instr := varint(op) varint(v2) varint(v3) varint(v4)   (ULEB128)

The constants of a proto are indices into the chunk's header constant
pool. Opcode semantics (158 distinct packed `op` words, split into
fields at the value level by the executor) are a separate RE phase —
this module stops at verified bytecode structure.
"""
COUNT_BIAS = 64412

def rv(buf, i):
    """Read one ULEB128 varint at buf[i:]; return (value, next_index)."""
    v, shift = 0, 0
    while True:
        b = buf[i]; i += 1
        v |= (b & 0x7F) << shift; shift += 7
        if not (b & 0x80):
            return v, i

def parse_body(body, count_bias=COUNT_BIAS):
    """Parse a body byte string. Returns (magic, protos) and requires
    exact consumption (body bytes = protos + 1 trailing byte). Raises
    ValueError on any desync."""
    i = 0
    magic, i = rv(body, i)
    protos = []
    while i < len(body) - 1:
        start = i
        nconsts, i = rv(body, i)
        if nconsts > 100000:
            raise ValueError(f'proto #{len(protos)}: implausible nconsts {nconsts} @body+{start}')
        consts = []
        for _ in range(nconsts):
            c, i = rv(body, i)
            consts.append(c)
        x, i = rv(body, i)
        zero, i = rv(body, i)
        big, i = rv(body, i)
        count = big - count_bias
        if count < 0 or count > 2000000:
            raise ValueError(f'proto #{len(protos)}: implausible instr count {count} @body+{start}')
        instrs = []
        for _ in range(count):
            op, i = rv(body, i)
            v2, i = rv(body, i)
            v3, i = rv(body, i)
            v4, i = rv(body, i)
            instrs.append([op, v2, v3, v4])
        protos.append({'consts': consts, 'x': x, 'zero': zero, 'instrs': instrs})
    if i != len(body) - 1:
        raise ValueError(f'body desync: consumed {i} of {len(body) - 1} bytes before trailer')
    if body[i] != 0x0A:
        raise ValueError(f'body trailer is 0x{body[i]:02x}, expected 0x0A')
    return magic, protos
