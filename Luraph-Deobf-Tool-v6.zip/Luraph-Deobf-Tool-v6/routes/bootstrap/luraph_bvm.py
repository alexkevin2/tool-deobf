#!/usr/bin/env python3
"""luraph_bvm.py — deobfuscator for the Luraph v15.1 "virtualized
bootstrap" sub-variant (StealAnEggs family).

Usage: python3 luraph_bvm.py <file.luau> -o <outdir> [--clean-work]

Pipeline (the target is never executed in a Luau runtime — the
bootstrap's own FSMs are re-implemented as faithful Python
transcriptions, oracle-validated in the original case; the payload
interpreter is likewise simulated by a Python AST interpreter over
the live simulator objects, with permissive logged mocks):

  detect   family fingerprint (see detect() below)
  stage1   blob decode: gsub alphabet fix -> in-place Ascii85 ->
           structure table E -> payload chunk (oracle-verified)
  stage2   Fz builder simulation -> root operand streams + eager
           materialization (protos.json) -> C1 disassembly walk
           (root_disasm.txt) -> fast state-178 child-descriptor
           census -> access-order constant materialization
           (children.json, proto_structs.json) -> lift (lifted.luau)
           -> luau-compile validation
  stageE   executor route (v2): the payload interpreter (slot
           15209) is executed IN CONTEXT by a Python AST interpreter
           over live fz_sim objects, so child protos materialize
           with their real captures and streams decrypt in place.
           The in-context sweep is the SOURCE OF TRUTH for the
           child set and constant coverage; the stage2 census is
           kept only as a labeled cross-check (it is phantom-prone:
           of its 47 descriptors, 34 are plain constants and 11
           garbage — only 2 are real children). dz children are
           walked from build-time snapshots (lane-padded walk);
           bz children are constant artifacts (single-table group +
           verbatim slot utility closure, see walk_bz). Output:
           full.luau (root + all recovered children), compile-
           validated. The sweep requires EXEC_ACT_BUDGET=2000000
           (set by this driver): the per-activation budget under
           which the family's execution is deterministic.
  clean    source-cleaning pass (v6 addition; clean.py +
           clean_lib.py, folded in from the case): renders the
           same walked instructions as idiomatic Luau —
           structured control flow where the jump graph is safely
           structurable, promoted/renamed registers, CONFIRMED
           stdlib names for the factory aliases, named placeholders
           for unresolved constants. Output: full_clean.luau (the
           headline deliverable) + clean_map.json (every walked
           instruction mapped) + clean_stats.json. The raw lift
           (full.luau) stays alongside as ground truth.
  clean2   restructuring pass (v6.1 addition; build_cfg2.py +
           clean2.py + clean2_lib.py): rebuilds the COMPLETED walk
           graph (children2.py now also harvests the walks' JMPR
           target unions into stage2/jmpr_harvest.json — the edges
           the first-visit serialization drops), elides the
           trampoline JMPR hubs by constant propagation, and
           structures with loop-aware joins, validated candidate
           joins and bounded flagged duplication; SCCs that
           provably resist structuring become scoped dispatch
           kernels. This is the default clean stage; the v6 clean
           stage remains as fallback if clean2 ever fails. Its
           outputs are renamed onto the usual deliverable names
           (full_clean.luau + clean_map.json + clean_stats.json,
           from full_clean2.luau + clean2_map.json +
           clean2_stats.json).

Exit codes (house style):
  0  full recovery, including every child proto and constant
  5  PARTIAL — the expected result for this family today: root +
     19/20 executor children are recovered and compile-validated
     (15 dz walked, 4 bz as constant artifacts; child18 (the 16th dz) is a
     proven-phantom descriptor), but 270/434 referenced constants
     remain placeholders (coverage is limited by a capture/register
     fidelity wall inside proto5 — see report.md) and 2 dynamic
     DECRYPTSTR sites are unreached. Also used when a pipeline
     stage fails on a file that DID match the family fingerprint.
  2  not this sub-variant / rejected (fingerprint mismatch). The
     Fz/interpreter transcriptions are build-family-specific; the
     tool never emits garbage for other builds.

The workdir (<outdir>/.work) mirrors the original case layout
(static/ + stage2/) because the pipeline modules resolve their
inputs relative to it. It is kept for inspection unless
--clean-work is given.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

TOOL = os.path.dirname(os.path.abspath(__file__))
MODULES = os.path.join(TOOL, 'modules')
BIN = os.path.join(TOOL, 'bin')
VERSION = '2.2.0'  # v6.1: + restructuring clean2 stage (was 2.1.0)


# ---------------------------------------------------------------- detect
def detect(text, dec):
    """Family fingerprint. Returns (ok, checks dict). Every check is
    structural and cheap; extract_vm_fields success + the LPH magic
    is the strongest gate."""
    checks = {}
    checks['luraph_v151_header'] = 'Luraph Obfuscator v15.1' in text[:512]
    checks['setmetatable_vm_table'] = 'return setmetatable({' in text[:4096]
    checks['numeric_keyed_slots'] = \
        len(re.findall(r'\[\d+\]=', text[:120000])) >= 5
    bi = text.find('MY=[==[')
    checks['blob_field_MY'] = bi >= 0
    checks['blob_magic_LPH'] = bi >= 0 and text[bi + 7:bi + 10] == 'LPH'
    checks['gsub_pattern_YY'] = "YY=\"[ -'}~]\"" in text
    checks['gsub_table__Y'] = text.find('_Y={', 1000000) >= 0
    checks['entry_vY'] = ':vY()(' in text[-4096:]
    checks['interpreter_Fz'] = re.search(r'\bFz=function', text) is not None
    try:
        MY, yy, table = dec.extract_vm_fields(text)
        checks['extract_vm_fields'] = MY[:3] == b'LPH' and len(table) >= 10
        checks['gsub_pattern_value'] = (yy == "[ -'}~]")
    except Exception as ex:
        checks['extract_vm_fields'] = False
        checks['extract_error'] = f'{type(ex).__name__}: {ex}'
    ok = all(v for k, v in checks.items()
             if k not in ('extract_error', 'gsub_pattern_value'))
    return ok, checks


# ---------------------------------------------------------------- driver
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


def run_stage(name, argv, cwd, env, log_path, timeout):
    t0 = time.time()
    with open(log_path, 'w') as log:
        log.write('$ ' + ' '.join(argv) + '\n\n')
        log.flush()
        try:
            p = subprocess.run(argv, cwd=cwd, env=env, stdout=log,
                               stderr=subprocess.STDOUT, timeout=timeout)
            rc = p.returncode
            err = None
        except subprocess.TimeoutExpired:
            rc, err = -1, f'timeout after {timeout}s'
    dt = time.time() - t0
    print(f'  [{name}] {"ok" if rc == 0 else "FAILED"} in {dt:.1f}s'
          + (f' ({err})' if err else ''), flush=True)
    return {'name': name, 'seconds': round(dt, 1), 'ok': rc == 0,
            'returncode': rc, 'error': err, 'log': os.path.basename(log_path)}


def jload(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default


def main():
    ap = argparse.ArgumentParser(
        description='Luraph v15.1 virtualized-bootstrap deobfuscator')
    ap.add_argument('input', help='obfuscated .luau file')
    ap.add_argument('-o', '--outdir', required=True, help='output directory')
    ap.add_argument('--clean-work', action='store_true',
                    help='delete the .work directory at the end')
    ap.add_argument('--spoof-id', choices=('auto', 'off'),
                    default='auto',
                    help='automatic game-ID spoofing in the executor '
                         'sweep (identity_report.json); off = legacy '
                         'mock behaviour, no identity artifacts')
    args = ap.parse_args()

    raw = os.path.abspath(args.input)
    if not os.path.isfile(raw):
        print(f'error: input not found: {raw}', file=sys.stderr)
        return 2
    outdir = os.path.abspath(args.outdir)
    os.makedirs(outdir, exist_ok=True)
    work = os.path.join(outdir, '.work')
    logs = os.path.join(work, 'logs')

    text = open(raw, encoding='utf-8', errors='surrogateescape').read()

    sys.path.insert(0, os.path.join(MODULES, 'static'))
    import decode_stage1 as dec  # noqa: E402 (bundled module copy)

    ok, checks = detect(text, dec)
    print('fingerprint:')
    for k, v in checks.items():
        print(f'  {k}: {v}')
    if not ok:
        print('REJECTED: this file does not match the Luraph v15.1 '
              'virtualized-bootstrap family fingerprint; the Fz '
              'transcriptions are build-family-specific and no output '
              'was produced.', file=sys.stderr)
        return 2

    # ---- workdir with the case layout (static/ + stage2/) ----
    if os.path.isdir(work):
        shutil.rmtree(work)
    os.makedirs(logs)
    shutil.copytree(os.path.join(MODULES, 'static'),
                    os.path.join(work, 'static'))
    shutil.copytree(os.path.join(MODULES, 'stage2'),
                    os.path.join(work, 'stage2'))
    shutil.copytree(os.path.join(MODULES, 'stageE'),
                    os.path.join(work, 'stageE'))
    os.makedirs(os.path.join(work, 'stageE', 'ast_cache'),
                exist_ok=True)
    for junk in ('__pycache__',):
        for root, dirs, _ in os.walk(work):
            if junk in dirs:
                shutil.rmtree(os.path.join(root, junk))
                dirs.remove(junk)

    env = dict(os.environ)
    env['BVM_RAW'] = raw
    env['BVM_LUAU_AST'] = os.path.join(BIN, 'luau-ast')
    env['BVM_SPOOF_ID'] = args.spoof_id
    py = sys.executable
    s2 = os.path.join(work, 'stage2')
    s1 = os.path.join(work, 'static')
    sE = os.path.join(work, 'stageE')

    stages = []
    # eager materialization is sharded per operand table (4 fresh
    # processes): the sim retains gigabytes of decompressed stream
    # state per table, and a monolithic run OOM-kills on small hosts.
    plan = [
        ('stage1_decode', [py, os.path.join(s1, 'decode_stage1.py'), raw],
         s1, 300, None),
        ('table_parse', [py, os.path.join(s2, 'table_parse.py')], s2, 300,
         None),
        ('e_fields', [py, os.path.join(s2, 'make_e_fields.py')], s2, 600,
         None),
        ('streams', [py, os.path.join(s2, 'dump_streams.py')], s2, 600,
         None),
    ]
    for ti in range(4):
        plan.append((f'eager_t{ti}', [py, os.path.join(s2, 'eager.py')],
                     s2, 3600, {'EAGER_TABLE': str(ti)}))
    plan += [
        ('eager_merge', [py, os.path.join(s2, 'merge_protos.py')], s2, 300,
         None),
        ('gen_disasm2', [py, os.path.join(s2, 'make_disasm2.py')], s2, 300,
         None),
        ('root_disasm', [py, os.path.join(s2, 'disasm.py')], s2, 1200, None),
        ('census178', [py, os.path.join(s2, 'probe178_fast.py')], s2, 3600,
         None),
        ('children', [py, os.path.join(s2, 'children2.py')], s2, 3600, None),
        ('lift', [py, os.path.join(s2, 'lift2.py')], s2, 1200, None),
    ]
    t_all = time.time()
    failed = None
    for name, argv, cwd, timeout, env_extra in plan:
        stage_env = dict(env)
        if env_extra:
            stage_env.update(env_extra)
        st = run_stage(name, argv, cwd, stage_env,
                       os.path.join(logs, name + '.log'), timeout)
        stages.append(st)
        if not st['ok']:
            failed = name
            break
        if name.startswith('eager_t'):
            src_shard = os.path.join(s2, 'protos_shard.json')
            dst_shard = os.path.join(
                s2, f'protos_shard{name[-1]}.json')
            if os.path.isfile(src_shard):
                os.replace(src_shard, dst_shard)

    # ---- identity spoofing: static extraction over the stage-2
    # walk records + materializer output; the seed file configures
    # the executor sweep's game mock (stageE/identity.py) ----
    id_static = None
    if args.spoof_id == 'auto' and failed is None:
        try:
            if sE not in sys.path:
                sys.path.insert(0, sE)
            import identity as idmod
            structs = {}
            ps_path = os.path.join(s2, 'proto_structs.json')
            if os.path.isfile(ps_path):
                structs = json.load(open(ps_path)) or {}
            icands, iseen = idmod.extract_structs(structs)
            mat_seen = {}
            mp_path = os.path.join(s2, 'protos.json')
            if os.path.isfile(mp_path):
                mat_seen = idmod.extract_materialized(
                    json.load(open(mp_path)) or {})
            iseed = idmod.build_seed(icands)
            seed_path = os.path.join(sE, 'identity_seed.json')
            with open(seed_path, 'w') as f:
                json.dump({'seed': iseed, 'candidates': icands,
                           'fields_seen': iseen,
                           'materialized_seen': mat_seen}, f, indent=1)
            env['BVM_IDENTITY_SEED'] = seed_path
            id_static = {'candidates': icands, 'fields_seen': iseen,
                         'materialized_seen': mat_seen,
                         'seed': iseed}
            print(f'[identity] fields seen: '
                  f'{sorted(set(iseen) | set(mat_seen))}; '
                  f'candidates: '
                  f'{ {k: [c["value"] for c in v] for k, v in icands.items()} }; '
                  f'seed: {iseed}', flush=True)
        except Exception as e:
            print(f'[identity] static extraction not applied: {e}',
                  flush=True)

    # ---- stageE: executor route (in-context sweep; v2) ----
    # A failure here does NOT fail the whole run: the stage2 outputs
    # remain valid deliverables and the verdict stays PARTIAL with
    # the executor stage marked failed in the manifest/report.
    # The clean stage (v6) runs after liftE; its failure is tracked
    # separately (clean_failed) and only downgrades the headline
    # deliverable, never the recovered data.
    exec_failed = None
    clean_failed = None
    clean_fell_back = False
    if failed is None:
        eplan = [
            ('factory_ast', [py, os.path.join(sE, 'make_factory_ast.py'),
                             raw], sE, 300, None),
            ('executor_sweep', [py, os.path.join(sE, 'sweepE.py')],
             sE, 2400, {'EXEC_ACT_BUDGET': '2000000'}),
            ('liftE', [py, os.path.join(sE, 'liftD.py')], sE, 600, None),
            ('build_cfg2', [py, os.path.join(sE, 'build_cfg2.py')],
             sE, 300, None),
            ('clean2', [py, os.path.join(sE, 'clean2.py')], sE, 1200,
             None),
        ]
        for name, argv, cwd, timeout, env_extra in eplan:
            stage_env = dict(env)
            if env_extra:
                stage_env.update(env_extra)
            st = run_stage(name, argv, cwd, stage_env,
                           os.path.join(logs, name + '.log'), timeout)
            stages.append(st)
            if not st['ok']:
                if name in ('build_cfg2', 'clean2'):
                    # restructuring failed: fall back to the v6
                    # clean stage so the headline deliverable
                    # still ships (marked in the manifest).
                    fb = run_stage(
                        'clean_fallback',
                        [py, os.path.join(sE, 'clean.py')], sE,
                        dict(env), os.path.join(
                            logs, 'clean_fallback.log'), 1200)
                    stages.append(fb)
                    if fb['ok']:
                        clean_fell_back = True
                    else:
                        clean_failed = 'clean'
                else:
                    exec_failed = name
                break
        # clean2's outputs take the standard deliverable names
        for src_n, dst_n in (('full_clean2.luau', 'full_clean.luau'),
                             ('clean2_map.json', 'clean_map.json'),
                             ('clean2_stats.json', 'clean_stats.json')):
            src_p = os.path.join(sE, src_n)
            if os.path.isfile(src_p):
                os.replace(src_p, os.path.join(sE, dst_n))

    # ---- collect results ----
    def wpath(*parts):
        return os.path.join(work, *parts)

    stage1_info = {}
    for n in ('gsub', 'src', 'dst'):
        p = wpath('static', n + '.bin')
        if os.path.isfile(p):
            stage1_info[n] = {'bytes': os.path.getsize(p),
                              'sha256': sha256_file(p)}
    children = jload(wpath('stage2', 'children.json'), {}) or {}
    census_meta = jload(wpath('stage2', 'census178_meta.json'), {}) or {}
    lift_stats = jload(wpath('stage2', 'lift_stats.json'), {}) or {}
    root_info = children.get('root', {}) if children else {}
    cstats = children.get('stats', {}) if children else {}
    census_list = children.get('child_descriptor_census', []) \
        if children else []
    n_censused = cstats.get('child_descriptors_censused', len(census_list))
    n_recovered = len(children.get('children', [])) if children else 0
    # executor-sweep results (source of truth for children/constants)
    sweep_state = jload(wpath('stageE', 'sweep_state.json'), {}) or {}
    exec_children = jload(wpath('stageE', 'children_recovered.json'),
                          []) or []
    if not isinstance(exec_children, list):
        exec_children = []
    exec_lift_stats = jload(wpath('stageE', 'lift_stats.json'), {}) or {}
    ref_consts = sweep_state.get('referenced_constants', {}) or {}
    walk_infos = sweep_state.get('walk_infos', {}) or {}
    n_exec_children = len(exec_children)
    n_bz = sum(1 for v in walk_infos.values()
               if isinstance(v, dict) and v.get('kind') == 'bz-constant')
    n_dz_walked = sum(1 for k, v in walk_infos.items()
                      if k.startswith('child') and isinstance(v, dict)
                      and 'error' not in v and v.get('kind')
                      != 'bz-constant')
    n_unrecovered = sum(1 for k, v in walk_infos.items()
                        if k.startswith('child') and isinstance(v, dict)
                        and 'error' in v)
    clean_map = jload(wpath('stageE', 'clean_map.json'), {}) or {}
    clean_stats = jload(wpath('stageE', 'clean_stats.json'), {}) or {}
    dyn_strings = sweep_state.get('dynamic_strings', {}) or {}
    n_dyn_blob = sum(1 for v in dyn_strings.values()
                     if isinstance(v, dict) and v.get('blob_decrypted'))
    # identity spoofing report (static half + sweep-half state)
    identity_rep = None
    identity_section = None
    if args.spoof_id == 'auto' and id_static is not None:
        try:
            sweepE_doc = jload(wpath('stageE', 'sweepE_state.json'),
                               {}) or {}
            id_state = sweepE_doc.get('identity') or {}
            identity_rep = idmod.build_report(
                id_static['candidates'], id_static['fields_seen'],
                id_static['materialized_seen'], id_state,
                notes=['static candidates come from stage-2 walk '
                       'records (numeric constants co-occurring in '
                       'an instruction that references an identity '
                       'field); the materializer scan is presence '
                       'evidence only.',
                       'fields with exactly one candidate are '
                       'pre-seeded into the sweep game mock; other '
                       'fields are sentinel-served and calibrated '
                       'by comparison capture (executor cmpeq hook).',
                       'the canonical sweep is a single deterministic '
                       'run (EXEC_ACT_BUDGET pin), so this route '
                       'does not fork per candidate; ambiguity '
                       'surfaces as logged contradictions.',
                       'spoofing configures only the local mock '
                       'environment used for analysis; nothing is '
                       'fetched and server-side ID checks are out '
                       'of scope.'])
            with open(os.path.join(outdir, 'identity_report.json'),
                      'w') as f:
                json.dump(identity_rep, f, indent=1)
            identity_section = idmod.report_section(identity_rep)
            print('[identity] identity_report.json written',
                  flush=True)
        except Exception as e:
            print(f'[identity] report assembly failed: {e}',
                  flush=True)
    exec_complete = (
        exec_failed is None and n_exec_children > 0
        and n_unrecovered == 0
        and ref_consts.get('resolved') == ref_consts.get('total'))

    # ---- copy deliverables ----
    ps_src = wpath('stageE', 'proto_structs.json') \
        if exec_failed is None and os.path.isfile(
            wpath('stageE', 'proto_structs.json')) \
        else wpath('stage2', 'proto_structs.json')
    copies = [
        (wpath('stage2', 'lifted.luau'), 'lifted.luau'),
        (wpath('stage2', 'children.json'), 'children.json'),
        (wpath('stage2', 'protos.json'), 'protos.json'),
        (ps_src, 'proto_structs.json'),
        (wpath('stage2', 'root_disasm.txt'), 'root_disasm.txt'),
        (wpath('stage2', 'lift_stats.json'), 'lift_stats.json'),
        (wpath('stageE', 'full.luau'), 'full.luau'),
        (wpath('stageE', 'children_recovered.json'),
         'children_recovered.json'),
        (wpath('stageE', 'sweep_state.json'), 'sweep_state.json'),
        (wpath('stageE', 'sweepE_state.json'), 'sweepE_state.json'),
        (wpath('stageE', 'full_clean.luau'), 'full_clean.luau'),
        (wpath('stageE', 'clean_map.json'), 'clean_map.json'),
        (wpath('stageE', 'clean_stats.json'), 'clean_stats.json'),
    ]
    for src, dst in copies:
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(outdir, dst))
    if stage1_info:
        os.makedirs(os.path.join(outdir, 'stage1'), exist_ok=True)
        for n in ('gsub', 'src', 'dst'):
            src = wpath('static', n + '.bin')
            if os.path.isfile(src):
                shutil.copy2(src, os.path.join(outdir, 'stage1', n + '.bin'))

    # ---- validate the lifts ----
    compile_ok = None
    lifted_path = os.path.join(outdir, 'lifted.luau')
    encrypted_left = None
    if os.path.isfile(lifted_path):
        lifted_text = open(lifted_path, encoding='utf-8',
                           errors='replace').read()
        encrypted_left = lifted_text.count('ENCRYPTED (dynamic seed')
        compiler = os.path.join(BIN, 'luau-compile')
        try:
            p = subprocess.run([compiler, lifted_path],
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.PIPE, timeout=300)
            compile_ok = (p.returncode == 0)
        except Exception:
            compile_ok = False
    full_compile_ok = None
    full_path = os.path.join(outdir, 'full.luau')
    if os.path.isfile(full_path):
        compiler = os.path.join(BIN, 'luau-compile')
        try:
            p = subprocess.run([compiler, full_path],
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.PIPE, timeout=300)
            full_compile_ok = (p.returncode == 0)
        except Exception:
            full_compile_ok = False
    clean_compile_ok = None
    clean_path = os.path.join(outdir, 'full_clean.luau')
    if os.path.isfile(clean_path):
        compiler = os.path.join(BIN, 'luau-compile')
        try:
            p = subprocess.run([compiler, clean_path],
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.PIPE, timeout=300)
            clean_compile_ok = (p.returncode == 0)
        except Exception:
            clean_compile_ok = False
    clean_ok = (clean_failed is None and clean_compile_ok is True
                and clean_map.get('mapped')
                == clean_map.get('total_instructions')
                and (clean_map.get('total_instructions') or 0) > 0)

    # ---- verdict ----
    if failed:
        verdict, exit_code = 'FAILED', 5
    elif compile_ok and full_compile_ok and exec_complete and clean_ok:
        verdict, exit_code = 'FULL_RECOVERY', 0
    else:
        verdict, exit_code = 'PARTIAL', 5

    total = round(time.time() - t_all, 1)
    manifest = {
        'tool': 'Luraph-BootstrapVM-Deobf',
        'version': VERSION,
        'input': {'path': raw, 'bytes': os.path.getsize(raw),
                  'sha256': sha256_file(raw)},
        'fingerprint': checks,
        'stages': stages,
        'failed_stage': failed,
        'stage1': stage1_info,
        'root': {
            'visited_pcs': root_info.get('visited_pcs'),
            'visited_by_mode': root_info.get('visited_by_mode'),
            'constants_summary': root_info.get('constants_summary'),
        },
        'census': {
            'eager_error_keys_scanned': census_meta.get('scanned'),
            'child_descriptors_censused': n_censused,
            'child_descriptors_blocked':
                cstats.get('child_descriptors_blocked'),
            'descriptors': [[c['table'], c['key']] for c in census_list],
        },
        'children_recovered': n_recovered,
        'executor': {
            'failed_stage': exec_failed,
            'children_total': n_exec_children,
            'dz_walked': n_dz_walked,
            'bz_constant_artifacts': n_bz,
            'unrecovered': n_unrecovered,
            'referenced_constants': ref_consts,
            'dynamic_strings_blob_decrypted': n_dyn_blob,
            'dynamic_strings_total': len(dyn_strings),
            'full_instructions': exec_lift_stats.get(
                'instructions_visited'),
            'full_compile_ok': full_compile_ok,
            'complete': exec_complete,
        },
        'clean': {
            'failed_stage': clean_failed,
            'structurer': 'clean (v6 fallback)' if clean_fell_back
                          else 'clean2 (restructuring)',
            'ok': clean_ok,
            'compile_ok': clean_compile_ok,
            'lines': clean_stats.get('lines'),
            'instructions_mapped': clean_map.get('mapped'),
            'instructions_total': clean_map.get('total_instructions'),
            'audit': clean_stats.get('audit'),
            'sha256': sha256_file(clean_path)
            if os.path.isfile(clean_path) else None,
        },
        'lift_stats': lift_stats,
        'encrypted_strings_remaining': encrypted_left,
        'luau_compile_ok': compile_ok,
        'verdict': verdict,
        'exit_code': exit_code,
        'total_seconds': total,
    }
    if identity_rep is not None:
        manifest['identity'] = {
            'fields_seen': sorted(
                (identity_rep.get('fields_seen') or {}).keys()),
            'candidates': {
                f: [c['value'] for c in lst]
                for f, lst in (identity_rep.get('candidates')
                               or {}).items()},
            'captures': identity_rep.get('captures'),
            'contradictions': identity_rep.get('contradictions'),
            'reads_total': identity_rep.get('identity_reads_total'),
        }
    with open(os.path.join(outdir, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=1)

    # ---- report.md ----
    L = []
    L.append('# Luraph-BootstrapVM-Deobf — run report')
    L.append('')
    L.append(f'- input: `{os.path.basename(raw)}` '
             f'({manifest["input"]["bytes"]} bytes, '
             f'sha256 `{manifest["input"]["sha256"]}`)')
    L.append('- family: Luraph v15.1, virtualized-bootstrap sub-variant '
             '(numeric-keyed VM table, blob field `MY`, FSM entry `vY`)')
    L.append(f'- verdict: **{verdict}** (exit {exit_code})')
    L.append(f'- total runtime: {total}s')
    L.append('')
    L.append('## Stages')
    L.append('')
    L.append('| stage | result | seconds |')
    L.append('|---|---|---|')
    for st in stages:
        L.append(f'| {st["name"]} | {"ok" if st["ok"] else "FAILED"} '
                 f'| {st["seconds"]} |')
    if failed:
        L.append('')
        L.append(f'Pipeline stopped at stage `{failed}` '
                 f'(see `.work/logs/{failed}.log`).')
    L.append('')
    L.append('## Stage 1 — static blob decode')
    L.append('')
    for n in ('gsub', 'src', 'dst'):
        if n in stage1_info:
            L.append(f'- {n}.bin: {stage1_info[n]["bytes"]} bytes, '
                     f'sha256 `{stage1_info[n]["sha256"]}`')
    L.append('')
    L.append('Method: gsub alphabet repair (`YY="[ -\' }~]"` class -> '
             '`_Y` table) -> vY FSM Ascii85 decode in place -> '
             'structure table E -> payload chunk slice. The algorithm '
             'was verified byte-identically against live VM buffer '
             'captures in the original case.')
    L.append('')
    L.append('## Root proto')
    L.append('')
    if root_info:
        cs = root_info.get('constants_summary', {})
        L.append(f'- instructions visited by the disassembly walk: '
                 f'{root_info.get("visited_pcs")} '
                 f'(by mode: {root_info.get("visited_by_mode")})')
        L.append(f'- access-order constants: {cs.get("materialized")} '
                 f'materialized, {cs.get("errors")} unresolved '
                 f'(of {cs.get("attempted")} attempted)')
    if lift_stats:
        L.append(f'- lift: {lift_stats.get("ok")} of '
                 f'{lift_stats.get("instructions_visited")} visited '
                 f'instructions translated with bodies; '
                 f'{lift_stats.get("unimpl")} UNIMPL')
    if encrypted_left is not None:
        L.append(f'- DECRYPTSTR strings still ENCRYPTED (dynamic seed '
                 f'or unresolved header): {encrypted_left} — left '
                 f'marked in the output, never guessed')
    L.append(f'- luau-compile validation of lifted.luau: '
             f'{"PASS" if compile_ok else "FAIL" if compile_ok is False else "not run"}')
    L.append('')
    L.append('## Child protos — executor sweep (source of truth)')
    L.append('')
    if exec_failed:
        L.append(f'- executor stage FAILED at `{exec_failed}` '
                 f'(see `.work/logs/{exec_failed}.log`); the numbers '
                 f'below fall back to the static census cross-check.')
    else:
        L.append(f'- real child protos (in-context sweep): '
                 f'{n_exec_children}')
        L.append(f'- dz children walked + lifted: {n_dz_walked}')
        L.append(f'- bz children (constant artifacts — single-table '
                 f'group + verbatim slot utility closure, no '
                 f'instruction stream exists): {n_bz}')
        L.append(f'- unrecovered children: {n_unrecovered} '
                 f'(child18: descriptor proven phantom — its build '
                 f'reads slot 753511, not a function slot, and its '
                 f'captured factory args are incoherent in every '
                 f'explored state; see sweep_state.json walk_infos)')
        L.append(f'- referenced constants resolved in context: '
                 f'{ref_consts.get("resolved")}/{ref_consts.get("total")}'
                 f' — the remainder are placeholders: coverage ends '
                 f'at a capture/register fidelity wall inside proto5 '
                 f'(mode C pc 35, nil-index write with an unpopulated '
                 f'base register) under both mock policies tried')
        L.append(f'- dynamic DECRYPTSTRs decrypted in context: '
                 f'{n_dyn_blob}/{len(dyn_strings)} (contents are '
                 f'binary blobs, no readable text; the unreached '
                 f'sites stay ENCRYPTED)')
        L.append(f'- full.luau (root + children): '
                 f'{exec_lift_stats.get("instructions_visited")} '
                 f'instructions, luau-compile '
                 f'{"PASS" if full_compile_ok else "FAIL"}')
    L.append('')
    L.append('Method: the slot-15209 payload interpreter is executed '
             'by a Python AST interpreter over the live fz_sim '
             'objects, so materializer calls fire with their real '
             'captures and streams/fields decrypt in place (out-of-'
             'context builds, by contrast, cycle forever in the '
             '_z/v walker pair). Requires EXEC_ACT_BUDGET=2000000 '
             '(set by the driver) for deterministic execution.')
    L.append('')
    L.append('## Child descriptors — static census (cross-check only)')
    L.append('')
    L.append(f'- eager-error keyspace scanned: '
             f'{census_meta.get("scanned")} keys')
    L.append(f'- child descriptors censused (state-178): {n_censused}')
    L.append(f'- child protos recovered by the static route: '
             f'{n_recovered}')
    L.append('')
    L.append('The static census is PHANTOM-PRONE and is kept only as '
             'a cross-check: of its 47 descriptors, the in-context '
             'sweep showed only 2 are real children — 34 are plain '
             'constants and 11 are garbage subtrees. Never use the '
             'census as the child set; the executor sweep above is '
             'authoritative.')
    L.append('')
    L.append('## Cleaned source (headline deliverable)')
    L.append('')
    if clean_failed:
        L.append(f'- clean stage FAILED at `{clean_failed}` '
                 f'(see `.work/logs/clean.log`); full.luau (raw '
                 f'lift) remains the deliverable for this run.')
    elif os.path.isfile(clean_path):
        L.append(f'- `full_clean.luau` — the same '
                 f'{clean_map.get("total_instructions")} walked '
                 f'instructions rendered as idiomatic Luau '
                 f'({clean_stats.get("lines")} lines): structured '
                 f'control flow where the jump graph is safely '
                 f'structurable (the remaining protos keep a '
                 f'cleaned dispatch form — per-proto reasons in '
                 f'clean_map.json), promoted/renamed registers, '
                 f'CONFIRMED stdlib names for factory aliases, '
                 f'`CONST_UNRESOLVED_*` placeholders for unresolved '
                 f'constants (never invented values)')
        L.append(f'- instruction mapping: '
                 f'{clean_map.get("mapped")}/'
                 f'{clean_map.get("total_instructions")} in '
                 f'clean_map.json; equivalence audit: '
                 f'{clean_stats.get("audit")}')
        L.append(f'- luau-compile validation of full_clean.luau: '
                 f'{"PASS" if clean_compile_ok else "FAIL"}')
        L.append(f'- full_clean.luau sha256: '
                 f'`{sha256_file(clean_path)}`')
    else:
        L.append('- clean stage produced no full_clean.luau '
                 '(executor stage incomplete).')
    if identity_section:
        L.extend(identity_section.rstrip('\n').split('\n'))
        L.append('')
    L.append('## Outputs')
    L.append('')
    L.append('- `full_clean.luau` — cleaned source (headline '
             'deliverable; see section above)')
    L.append('- `clean_map.json` / `clean_stats.json` — cleaning '
             'pass mapping + equivalence audit')
    L.append('- `full.luau` — lifted root + all recovered child '
             'protos (executor route; compile-validated; ground '
             'truth for the cleaned source)')
    L.append('- `lifted.luau` — lifted root proto only (static '
             'route; compile-validated)')
    L.append('- `children_recovered.json` — executor-harvested '
             'child protos (the authoritative child set)')
    L.append('- `sweep_state.json` — executor sweep accounting '
             '(constants, walks, dynamic strings)')
    L.append('- `sweepE_state.json` — executor evidence (factory-arg '
             'captures, bz build log, child18 attempts)')
    L.append('- `children.json` — root materialization results + '
             'static child descriptor census (cross-check only)')
    L.append('- `protos.json` — eager materialization of the root '
             'operand tables')
    L.append('- `proto_structs.json` — per-proto structured walk '
             'records, root + children (the lifter input)')
    L.append('- `root_disasm.txt` — root proto disassembly (C1 walk)')
    L.append('- `stage1/` — gsub.bin / src.bin / dst.bin')
    L.append('- `manifest.json` — machine-readable run manifest')
    if identity_rep is not None:
        L.append('- `identity_report.json` — game-ID spoofing: '
                 'static candidates, seeds, comparison captures, '
                 'identity-read log (see the identity section)')
    L.append('- `.work/` — full pipeline workdir (logs in `.work/logs`)'
             if not args.clean_work else
             '- workdir removed (--clean-work)')
    L.append('')
    with open(os.path.join(outdir, 'report.md'), 'w') as f:
        f.write('\n'.join(L))

    if args.clean_work:
        shutil.rmtree(work, ignore_errors=True)

    print(f'verdict: {verdict} (exit {exit_code}); '
          f'root visited={root_info.get("visited_pcs")}, '
          f'census={n_censused}, recovered={n_recovered}, '
          f'executor children={n_exec_children} '
          f'(dz {n_dz_walked}, bz {n_bz}, unrecovered '
          f'{n_unrecovered}), constants='
          f'{ref_consts.get("resolved")}/{ref_consts.get("total")}, '
          f'compile_ok={compile_ok}, full_compile_ok='
          f'{full_compile_ok}, clean_ok={clean_ok}, total={total}s')
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
