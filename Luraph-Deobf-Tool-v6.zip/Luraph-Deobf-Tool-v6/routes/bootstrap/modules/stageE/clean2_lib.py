#!/usr/bin/env python3
"""clean2_lib.py — completed-CFG construction, trampoline elision and
condensation analysis for the StealAnEggs restructuring pass.

Graph edges come from the disasm2 walk records (proto_structs.json)
completed with the re-harvested jmpr_followed unions (cfg2.json
provenance: walk-succ / walk-switch / walk-jmpr).  Trampoline
elision: a JMPR hub whose dispatch register is provably a singleton
constant at every in-edge (constant propagation where a hub edge
hub->t carries exactly {t-1} — the value the register must hold for
control to have arrived at t) is replaced by direct edges; the
consistency check is that every propagated in-edge value K satisfies
K+1 in the walk's own jmpr_followed target set.
"""
import json
import os
import re
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import clean_lib as CL

U2MODE = {114: 'A', 49: 'B', 210: 'C', 113: 'D'}
TOP = None  # dataflow sentinel: unknown / too many values


def load_cfg2():
    with open(os.path.join(HERE, 'cfg2.json')) as fo:
        return json.load(fo)['protos']


def completed_edges(pid, cfg2p):
    """key -> list[(target, provenance)] from cfg2.json."""
    edges = {}
    for k, vs in cfg2p['edges'].items():
        m, p = k.split(':')
        edges[(m, int(p))] = [((v[0], v[1]), v[2]) for v in vs]
    return edges


def sccs(nodes, succ):
    index, low, onstack, stack, result = {}, {}, set(), [], []
    counter = [0]
    sys.setrecursionlimit(1000000)

    def strongconnect(v):
        index[v] = low[v] = counter[0]
        counter[0] += 1
        stack.append(v)
        onstack.add(v)
        for w in succ.get(v, []):
            if w not in nodes:
                continue
            if w not in index:
                strongconnect(w)
                low[v] = min(low[v], low[w])
            elif w in onstack:
                low[v] = min(low[v], index[w])
        if low[v] == index[v]:
            comp = []
            while True:
                w = stack.pop()
                onstack.discard(w)
                comp.append(w)
                if w == v:
                    break
            result.append(comp)

    for v in sorted(nodes):
        if v not in index:
            strongconnect(v)
    return result


_WRITE_RE_CACHE = {}


def reg_write_status(effects, reg):
    """Classify a record's effect on register `reg` (pre-rename
    effects use n[<idx>] syntax):
      ('const', K) — every write assigns the same int literal, >=1 write
      ('unknown',) — some write is not a plain int literal
      ('none',)    — no writes
    Also returns read flag: register read as data anywhere."""
    pat_w = re.compile(rf'\bn\[{reg}\]\s*=\s*(-?\d+)\s*[;,]')
    pat_any = re.compile(rf'\bn\[{reg}\]\s*=')
    pat_read = re.compile(rf'\bn\[{reg}\]')
    status = ('none',)
    read = False
    for ln in effects:
        for st in CL.split_statements(ln):
            s = st.strip()
            mw = pat_w.search(s)
            lhs_spans = [m.span() for m in pat_any.finditer(s)]
            if lhs_spans:
                if mw and len(lhs_spans) == 1 and \
                        mw.span() == lhs_spans[0] or \
                        (mw and s.rstrip(';').strip() ==
                         f'n[{reg}]={mw.group(1)}' or
                         s.rstrip(';').strip() ==
                         f'n[{reg}] = {mw.group(1)}'):
                    k = int(mw.group(1))
                    if status[0] == 'none':
                        status = ('const', k)
                    elif status[0] == 'const' and status[1] != k:
                        status = ('unknown',)
                else:
                    # any other assignment form to the register
                    if not (mw and len(lhs_spans) == 1 and
                            s.replace(' ', '').rstrip(';') ==
                            f'n[{reg}]={mw.group(1)}'):
                        status = ('unknown',)
                    else:
                        k = int(mw.group(1))
                        if status[0] == 'none':
                            status = ('const', k)
                        elif status[0] == 'const' and status[1] != k:
                            status = ('unknown',)
            # reads: occurrences not on an LHS
            for m in pat_read.finditer(s):
                after = s[m.end():].lstrip()
                if not after.startswith('=') or after.startswith('=='):
                    read = True
    return status, read


def _writes_reg(effects, reg):
    """Simpler robust write classification used by the dataflow:
    returns ('const', K) | ('unknown',) | ('none',). A statement is a
    const write iff it is exactly `n[reg] = <int>` (modulo spaces)."""
    target = re.compile(rf'^n\[{reg}\]\s*=\s*(-?\d+)$')
    anyw = re.compile(rf'\bn\[{reg}\]\s*=(?!=)')
    saw = None
    for ln in effects:
        for st in CL.split_statements(ln):
            s = st.strip().rstrip(';').strip()
            m = target.match(s)
            if m:
                k = int(m.group(1))
                if saw is None:
                    saw = ('const', k)
                elif saw[0] == 'const' and saw[1] != k:
                    saw = ('unknown',)
            elif anyw.search(s):
                saw = ('unknown',)
    return saw if saw is not None else ('none',)


def reads_reg(effects, reg):
    """True if n[reg] is ever read (occurrence not a plain-LHS)."""
    pat = re.compile(rf'\bn\[{reg}\]')
    for ln in effects:
        for st in CL.split_statements(ln):
            s = st.strip()
            for m in pat.finditer(s):
                rest = s[m.end():].lstrip()
                if rest.startswith('==') or not rest.startswith('='):
                    return True
    return False


def propagate_reg(nodes, succ, recs, reg, hub, hub_targets):
    """Constant propagation of `reg` over the graph.
    State: frozenset of possible int values, or TOP.
    Hub semantics: the hub does not write the register; an execution
    leaving the hub to target t carries exactly {t-1}.  Entry state:
    TOP (register unknown at proto entry) — but hub in-edges are what
    we solve for; iteration to fixpoint with cap 6 values."""
    CAP = 6

    def join(a, b):
        if a is TOP or b is TOP:
            return TOP
        u = a | b
        return TOP if len(u) > CAP else u

    def transfer(key, inval):
        if inval is TOP:
            # a const write still pins the value on this path, but
            # with TOP input other paths may differ; per-node out we
            # need path union -> handled by join at targets.  For a
            # single node's out given TOP in: const write dominates
            # only if it is the record's only effect on reg AND the
            # record always executes it — records are straight-line
            # effect lists, so a const write DOES pin out.
            pass
        st = _writes_reg(recs[key].effects, reg)
        if st[0] == 'const':
            return frozenset({st[1]})
        if st[0] == 'unknown':
            return TOP
        return inval

    in_s = {n: frozenset() for n in nodes}
    out_s = {n: frozenset() for n in nodes}
    # entry: nothing known
    changed = True
    it = 0
    while changed and it < 200:
        changed = False
        it += 1
        for n in nodes:
            # in = join of out-edges from preds, hub-aware
            vals = frozenset()
            started = False
            for p in _preds(succ, nodes).get(n, ()):
                if p == hub and n in hub_targets:
                    contrib = frozenset({n[1] - 1})
                elif p == hub:
                    contrib = TOP
                else:
                    contrib = out_s[p]
                vals = contrib if not started else join(vals, contrib)
                started = True
            if n == _entry_of(nodes, succ):
                vals = join(vals, TOP) if started else TOP
            if vals != in_s[n]:
                in_s[n] = vals
                changed = True
            o = transfer(n, in_s[n])
            if n == hub:
                o = in_s[n]  # hub itself passes values to its dispatch
            if o != out_s[n]:
                out_s[n] = o
                changed = True
    return in_s, out_s


_PRED_CACHE = {}


def _preds(succ, nodes):
    key = id(succ)
    if key not in _PRED_CACHE:
        pr = defaultdict(set)
        for u, ss in succ.items():
            for v in ss:
                if v in nodes:
                    pr[v].add(u)
        _PRED_CACHE[key] = pr
    return _PRED_CACHE[key]


_ENTRY_CACHE = {}


def _entry_of(nodes, succ):
    return None


class AtomRec:
    """Pseudo-record standing in for a condensed SCC in the graph."""
    __slots__ = ('key', 'pid', 'mode', 'pc', 'name', 'raw_name', 'op',
                 'op_final', 'kind', 'effects', 'ctrl', 'notes', 'risk',
                 'succ', 'group_span', 'rec', 'placeholders',
                 'transforms', 'fold_failed_dyn', 'bare_n_value',
                 'dyn_index', 'in_state', 'for_conv', 'step_effects',
                 'elided_into', 'atom_kind', 'members', 'entries',
                 'exits', 'entry_by_pred')

    def __init__(self, key, atom_kind, members, entries, exits):
        self.key = key
        self.pid = None
        self.mode, self.pc = key
        self.name = f'<atom:{atom_kind}>'
        self.raw_name = self.name
        self.op = self.op_final = -1
        self.kind = 'atom'
        self.effects = []
        self.ctrl = ('atom', atom_kind)
        self.notes = []
        self.risk = []
        self.succ = []
        self.group_span = 0
        self.rec = {}
        self.placeholders = set()
        self.transforms = []
        self.fold_failed_dyn = False
        self.bare_n_value = False
        self.dyn_index = False
        self.in_state = None
        self.for_conv = None
        self.step_effects = None
        self.elided_into = None
        self.atom_kind = atom_kind      # 'kernel' | 'spin-empty'
        self.members = members          # [keys]
        self.entries = entries          # [member keys]
        self.exits = exits              # [keys outside]
        self.entry_by_pred = {}         # pred key -> entry member key


def condense(recs, edges, entry_key, force_kernels=()):
    """Condense SCCs that the plain structurer cannot handle:
      - terminal SCCs whose members are all pure control (no
        effects) -> 'spin-empty' atoms (rendered `while true do end`)
      - SCCs with >1 entry and >=1 exit -> 'kernel' atoms
      - terminal SCCs with >1 entry and effects -> 'kernel' atoms
        (never exit; the kernel function's dispatch never returns)
      - SCCs whose member set is listed in `force_kernels` ->
        'kernel' atoms regardless of entry count (used when the
        structurer provably fails on the raw SCC; the caller
        records the failure as evidence).
    Natural loops (single entry) and single-entry terminal SCCs stay
    as raw nodes.  Returns (recs2, edges2, atoms) where edges2 maps
    key -> [(target, prov, entry_member_or_None)] and atoms maps
    atom key -> AtomRec.  Member records are removed from recs2;
    edges into an atom carry the member they targeted as entry."""
    force_sets = [set(fs) for fs in force_kernels]
    by_key = {r.key: r for r in recs}
    nodes = set(by_key)
    succ = {k: [t for t, _ in v] for k, v in edges.items()}
    pred = defaultdict(set)
    for u, ss in succ.items():
        for v in ss:
            pred[v].add(u)
    comps = sccs(nodes, succ)
    atoms = {}
    member_of = {}
    for comp in comps:
        if len(comp) == 1:
            n = comp[0]
            if n not in succ.get(n, []):
                continue
            # single-node self-loop: leave to the structurer
            continue
        cs = set(comp)
        exits = sorted({t for n in cs for t in succ.get(n, [])
                        if t not in cs})
        entries = sorted({n for n in cs
                          if any(p not in cs for p in pred[n])})
        if entry_key in cs:
            entries = sorted(set(entries) | {entry_key})
        pure = all(not by_key[n].effects and
                   by_key[n].kind in ('ok', 'folded')
                   for n in cs)
        kind = None
        if any(cs == fs for fs in force_sets):
            kind = 'kernel'
        elif not exits and pure:
            kind = 'spin-empty'
        elif len(entries) > 1:
            kind = 'kernel'
        if kind is None:
            continue
        akey = ('ATOM', f'{kind}:{comp[0][0]}{comp[0][1]}')
        atom = AtomRec(akey, kind, sorted(cs), entries, exits)
        atoms[akey] = atom
        for n in cs:
            member_of[n] = akey
    if not atoms:
        return recs, {k: [(t, prov, None) for t, prov in v]
                      for k, v in edges.items()}, atoms
    recs2 = [r for r in recs if r.key not in member_of]
    recs2 += list(atoms.values())
    edges2 = {}
    for u, vs in edges.items():
        if u in member_of:
            continue
        nv = []
        for t, prov in vs:
            if t in member_of:
                nv.append((member_of[t], prov, t))
            else:
                nv.append((t, prov, None))
        edges2[u] = nv
    for akey, atom in atoms.items():
        nv = []
        for x in atom.exits:
            nv.append((x, 'atom-exit', None))
        edges2[akey] = nv
        for n in atom.members:
            for t, prov in edges.get(n, []):
                if t in member_of and member_of[t] != akey:
                    edges2[akey].append((member_of[t], prov, t))
        # entry_by_pred: for each outside pred, which member it hits
        for u, vs in edges2.items():
            if u == akey:
                continue
            for t, prov, entry_member in vs:
                if t == akey and entry_member is not None:
                    atom.entry_by_pred[u] = entry_member
    return recs2, edges2, atoms


def make_cfg(pid, recs2, edges2, entry_key):
    """Build a CL.CFG-compatible object over condensed edges
    (edges2: key -> [(target, prov, entry_member)])."""
    cfg = object.__new__(CL.CFG)
    cfg.pid = pid
    cfg.recs = {r.key: r for r in recs2}
    cfg.entry = entry_key
    cfg.succ = {}
    for k, vs in edges2.items():
        out = []
        for t, _prov, _e in vs:
            if t in cfg.recs and t not in out:
                out.append(t)
        cfg.succ[k] = out
    for r in recs2:
        cfg.succ.setdefault(r.key, [])
    cfg.pred = defaultdict(set)
    for k, ss in cfg.succ.items():
        for s in ss:
            cfg.pred[s].add(k)
    cfg.reachable = set()
    stack = [entry_key]
    while stack:
        n = stack.pop()
        if n in cfg.reachable or n not in cfg.recs:
            continue
        cfg.reachable.add(n)
        stack += cfg.succ.get(n, [])
    cfg.atom_of = {}
    for r in recs2:
        if getattr(r, 'kind', None) == 'atom':
            for m in r.members:
                cfg.atom_of[m] = r.key
    cfg.dom = {}
    cfg._dominators()
    return cfg


class Structurer2(CL.Structurer):
    """CL.Structurer + loop-aware joins + atom awareness.

    - _common_join retries with the active loop headers treated as
      sinks (paths stop AT a header instead of wrapping around the
      loop), which finds the true in-loop join for branches whose
      arms reconverge before the next iteration.
    - atom nodes (condensed SCCs) render through atom_fn; a kernel
      atom is only ever a region stop: paths stepping into it emit
      an entry-assignment leaf through self.leaf_hook.
    """

    def __init__(self, cfg, effects_fn, atom_fn=None, leaf_hook=None):
        super().__init__(cfg, effects_fn)
        self.atom_fn = atom_fn
        self.leaf_hook = leaf_hook
        self._forced_join = None  # (branch node, join) during a retry
        self.atom_dups = []       # spin atoms rendered more than once
        self.dup_nodes = set()    # nodes rendered more than once
        self.dup_budget = 64      # per-proto duplicated-node budget
        self._rr_depth = 0        # re-render nesting depth
        self._active = set()      # branch nodes being structured

    # -- loop-aware join
    def _reach_blocked(self, start, blocked):
        cfg = self.cfg
        seen = set()
        stack = [start]
        while stack:
            u = stack.pop()
            if u in seen or u not in cfg.reachable:
                continue
            seen.add(u)
            if u in blocked:
                continue
            stack += cfg.succ.get(u, ())
        return seen

    def _common_join(self, node, k1, k2):
        if self._forced_join is not None and \
                self._forced_join[0] == node:
            return self._forced_join[1]
        j = super()._common_join(node, k1, k2)
        if j is not None:
            return j
        blocked = {lp['header'] for lp in self.loop_stack}
        if not blocked:
            return None
        cfg = self.cfg
        if k1 not in cfg.recs or k2 not in cfg.recs:
            return None
        r1 = self._reach_blocked(k1, blocked)
        r2 = self._reach_blocked(k2, blocked)
        common = (r1 & r2) - {node}
        if not common:
            return None
        minimal = [c for c in common
                   if not any(c != o and c in self._reach_blocked(o, blocked)
                              for o in common)]
        if len(minimal) == 1:
            return minimal[0]
        return None

    def _join_candidates(self, node, stops, rec):
        """Candidate joins for a branch whose natural join could
        not be proven: active loop headers (innermost first), the
        immediate postdominator, then stops both arms reach.  Each
        candidate is validated by actually rendering the arms
        (a wrong candidate makes an arm leak and raises)."""
        cfg = self.cfg
        _, _cond, t1, t2 = rec.ctrl
        k1, k2 = (rec.mode, t1), (rec.mode, t2)
        out = []
        for lp in reversed(self.loop_stack):
            out.append(lp['header'])
        ipd = self.ipdom.get(node)
        if ipd in cfg.recs:
            out.append(ipd)
        common_stops = (self.reach.get(k1, set()) &
                        self.reach.get(k2, set())) & set(stops)
        out += sorted(common_stops)
        # A stop reached by exactly ONE arm is also a valid join
        # when the other arm is closed (every path through it
        # terminates inside its own reachable set — e.g. a loop
        # whose exits all end in return / dead-end regions).
        def closed(k):
            rk = self.reach.get(k, set())
            return all(not cfg.succ.get(w) or
                       all(s in rk for s in cfg.succ.get(w, ()))
                       for w in rk)

        for s in sorted(stops):
            if s in cfg.recs and \
                    (s in self.reach.get(k1, set())) != \
                    (s in self.reach.get(k2, set())):
                other = k2 if s in self.reach.get(k1, set()) else k1
                if not (self.reach.get(other, set()) & set(stops)) \
                        and closed(other):
                    out.append(s)
        headers = {lp['header'] for lp in self.loop_stack}
        seen, res = set(), []
        for c in out:
            if c != node and c not in seen and c in cfg.recs and \
                    (c not in self.done or c in headers):
                seen.add(c)
                res.append(c)
        return res

    # -- atom-aware node handling
    def _is_kernel(self, key):
        rec = self.cfg.recs.get(key)
        return rec is not None and getattr(rec, 'kind', None) == 'atom' \
            and rec.atom_kind == 'kernel'

    def _node(self, node, stops, indent):
        rec = self.cfg.recs[node]
        if getattr(rec, 'kind', None) == 'atom':
            if rec.atom_kind == 'kernel':
                raise CL.StructFail(f'kernel atom {node} reached as '
                                    'a plain node (must be a stop)')
            # spin-empty atom: terminal, renders its own lines
            self.done.add(node)
            lines = self.atom_fn(node, indent) if self.atom_fn else []
            return lines, None
        # If this node's continuation is a kernel atom that is
        # currently a stop, un-stop it so the continuation (and the
        # entry leaf) propagates instead of being swallowed.  Only
        # for single-successor nodes: a branch that ends at the
        # atom has already selected the entry per arm inside
        # _branch_atom / CL._branch, so appending the leaf here
        # would overwrite the arm's own entry choice.
        succ = self.cfg.succ.get(node, [])
        kstops = {s for s in succ
                  if s in stops and self._is_kernel(s)}
        if rec.ctrl and rec.ctrl[0] == 'branch':
            kstops = set()
        if kstops:
            lines, cont = super()._node(node, set(stops) - kstops,
                                        indent)
            if cont is not None and self._is_kernel(cont) and \
                    self.leaf_hook is not None:
                atom_rec = self.cfg.recs[cont]
                entry_key = atom_rec.entry_by_pred.get(node)
                lines = lines + self.leaf_hook(cont, indent,
                                               entry_key, node)
            return lines, cont
        return super()._node(node, stops, indent)

    def _branch(self, node, stops, indent, eff):
        self._active.add(node)
        try:
            return self._branch_inner(node, stops, indent, eff)
        finally:
            self._active.discard(node)

    def _branch_inner(self, node, stops, indent, eff):
        rec = self.cfg.recs[node]
        if rec.ctrl and rec.ctrl[0] == 'branch':
            _, cond, t1, t2 = rec.ctrl
            a1 = self.cfg.atom_of.get((rec.mode, t1))
            a2 = self.cfg.atom_of.get((rec.mode, t2))
            if a1 is not None or a2 is not None:
                akey = a1 or a2
                if self.cfg.recs[akey].atom_kind == 'kernel':
                    return self._branch_atom(node, stops, indent, eff,
                                             cond, t1, t2, a1, a2)
                return self._branch_spin(node, stops, indent, eff,
                                         cond, t1, t2, a1, a2)
        # Plain branch: try CL's structurer; if it cannot prove a
        # join, retry with validated candidate joins (state is
        # snapshotted because a failed attempt may have consumed
        # nodes / loop state).
        snap_done = set(self.done)
        snap_loops = list(self.loop_stack)
        try:
            return CL.Structurer._branch(self, node, stops, indent,
                                         eff)
        except CL.StructFail:
            self.done = set(snap_done)
            self.loop_stack = list(snap_loops)
            headers = {lp['header'] for lp in snap_loops}
            for cand in self._join_candidates(node, stops, rec):
                self._forced_join = (node, cand)
                # CL._branch discards a join that is already in
                # done; an active loop header is legitimately in
                # done (it was emitted as the loop header) yet is a
                # valid join (continue semantics), so un-mark it
                # for the attempt and restore it on success.
                unmark = cand in headers and cand in self.done
                if unmark:
                    self.done.discard(cand)
                try:
                    res = CL.Structurer._branch(self, node, stops,
                                                indent, eff)
                    self._forced_join = None
                    if unmark:
                        self.done.add(cand)
                    return res
                except CL.StructFail:
                    self._forced_join = None
                    self.done = set(snap_done)
                    self.loop_stack = list(snap_loops)
            # Last resort: render each arm with a FRESH structurer
            # (own done set) and merge — shared tail blocks are
            # rendered once per arm (bounded duplication, recorded
            # in self.dup_nodes).
            try:
                return self._branch_dup(node, stops, indent, eff)
            except CL.StructFail:
                self.done = set(snap_done)
                self.loop_stack = list(snap_loops)
            raise

    def _branch_dup(self, node, stops, indent, eff):
        """Branch fallback via per-arm fresh structurers.

        Each arm is structured independently with the enclosing
        stops (plus a candidate join J).  Nodes rendered by both
        arms — or already rendered by the enclosing context — are
        duplicated; the duplication must fit the remaining budget.
        Continuations must agree: both arms end at J, or one ends
        at J / a stop and the other terminates."""
        cfg = self.cfg
        rec = cfg.recs[node]
        if any(self._is_kernel(k) for k in cfg.recs):
            raise CL.StructFail('dup fallback unavailable with '
                                'kernel atoms')
        _, cond, t1, t2 = rec.ctrl
        k1, k2 = (rec.mode, t1), (rec.mode, t2)
        if getattr(self, '_dup_depth', 0) >= 2:
            raise CL.StructFail('dup fallback depth cap')
        # An arm whose reachable set contains the branch node
        # itself is cyclic through this branch — fresh rendering
        # would recurse into the same branch forever.
        if node in self.reach.get(k1, set()) or \
                node in self.reach.get(k2, set()):
            raise CL.StructFail(f'branch at {node}: arm cycles '
                                'back to the branch node')
        joins = [s for s in sorted(stops) if s in cfg.recs] + [None]
        for J in joins:
            arm_stops = set(stops) | ({J} if J is not None else set())
            rendered = []
            ok = True
            for k in (k1, k2):
                sub = Structurer2(cfg, self.effects_fn,
                                  atom_fn=self.atom_fn,
                                  leaf_hook=self.leaf_hook)
                sub._dup_depth = getattr(self, '_dup_depth', 0) + 1
                try:
                    lines, cont = sub.run_region(k, arm_stops,
                                                 indent + 1)
                except CL.StructFail:
                    ok = False
                    break
                if cont is not None and cont != J and \
                        cont not in stops:
                    ok = False
                    break
                if node in sub.done:
                    ok = False
                    break
                rendered.append((lines, cont, sub))
            if not ok:
                continue
            (l1, c1, s1), (l2, c2, s2) = rendered
            conts = {c for c in (c1, c2) if c is not None}
            if len(conts) > 1:
                continue
            dup = (s1.done & s2.done) | \
                ((s1.done | s2.done) & self.done)
            if len(dup) + len(self.dup_nodes) > self.dup_budget:
                continue
            out = list(eff)
            cont_out = conts.pop() if conts else None
            # fall-through arm: no lines, continuation is the join
            if not l1 and c1 is not None and c1 == cont_out and \
                    l2:
                out.append(CL.ELine(
                    indent, f'if {CL.invert_cond(cond)} then', node,
                    'construct'))
                out += l2
                out.append(CL.ELine(indent, 'end', node,
                                    'construct'))
            elif not l2 and c2 is not None and c2 == cont_out and \
                    l1:
                out.append(CL.ELine(indent, f'if {cond} then', node,
                                    'construct'))
                out += l1
                out.append(CL.ELine(indent, 'end', node,
                                    'construct'))
            else:
                out.append(CL.ELine(indent, f'if {cond} then', node,
                                    'construct'))
                out += l1
                out.append(CL.ELine(indent, 'else', node,
                                    'construct'))
                out += l2
                out.append(CL.ELine(indent, 'end', node,
                                    'construct'))
            self.done |= s1.done | s2.done
            self.dup_nodes |= dup | s1.dup_nodes | s2.dup_nodes
            self.atom_dups += s1.atom_dups + s2.atom_dups
            return out, cont_out
        raise CL.StructFail(f'branch at {node}: dup fallback '
                            'exhausted')

    # -- sequences: re-reaching a spin-empty atom from a second
    # structured path duplicates its (3-instruction, pure-control)
    # rendering instead of failing; the duplication is recorded.
    # Re-reaching an ordinary emitted node re-renders its region
    # with a fresh structurer (bounded: region <= 24 nodes, total
    # duplicated nodes <= dup_budget, no re-entry into a branch
    # currently being structured, nesting depth <= 3).
    def _seq(self, start, stops, indent):
        lines = []
        node = start
        while node is not None and node not in stops:
            if node in self.done:
                rec = self.cfg.recs.get(node)
                if rec is not None and \
                        getattr(rec, 'kind', None) == 'atom' and \
                        rec.atom_kind == 'spin-empty':
                    self.atom_dups.append(node)
                    if self.atom_fn is not None:
                        lines += self.atom_fn(node, indent)
                    return lines, None
                l2, node = self._rerender(node, stops, indent)
                lines += l2
                continue
            l2, node = self._node(node, stops, indent)
            lines += l2
        return lines, node

    def _rerender(self, node, stops, indent):
        """Re-render the region starting at an already-emitted
        node (a shared tail reached from a second structured
        path).  Returns (lines, cont)."""
        if self._rr_depth >= 3:
            raise CL.StructFail(f'node {node} emitted twice '
                                '(re-render depth cap)')
        # Cheap bound first: the re-rendered region is contained
        # in the nodes reachable from `node` without passing a
        # stop; if that envelope is large, do not even attempt it.
        envelope = self._reach_blocked(node, set(stops))
        if len(envelope) > 24:
            raise CL.StructFail(
                f'node {node} emitted twice (shared region '
                f'envelope {len(envelope)} nodes > 24)')
        sub = Structurer2(self.cfg, self.effects_fn,
                          atom_fn=self.atom_fn,
                          leaf_hook=self.leaf_hook)
        sub._rr_depth = self._rr_depth + 1
        sub._active = set(self._active)
        sub.dup_budget = self.dup_budget - len(self.dup_nodes)
        lines, cont = sub.run_region(node, set(stops), indent)
        region = set(sub.done)
        if len(region) > 24:
            raise CL.StructFail(
                f'node {node} emitted twice (shared region '
                f'{len(region)} nodes > 24)')
        if region & self._active:
            raise CL.StructFail(
                f'node {node} emitted twice (region re-enters an '
                'active branch)')
        dup_here = region & self.done
        if len(self.dup_nodes) + len(dup_here) + \
                len(sub.dup_nodes) > self.dup_budget:
            raise CL.StructFail(
                f'node {node} emitted twice (duplication budget '
                'exceeded)')
        self.done |= region
        self.dup_nodes |= dup_here | sub.dup_nodes
        self.atom_dups += sub.atom_dups
        return lines, cont

    def _branch_spin(self, node, stops, indent, eff, cond, t1, t2,
                     a1, a2):
        """Branch where an arm enters a spin-empty atom (a terminal
        pure-control cycle): that arm never returns, so it renders
        as an if-then whose body is the spin; the other arm is the
        continuation sequenced after the if."""
        cfg = self.cfg
        rec = cfg.recs[node]
        atom = a1 or a2
        out = list(eff)

        def spin_lines(ind):
            if atom in self.done:
                self.atom_dups.append(atom)
            self.done.add(atom)
            if self.atom_fn is None:
                return []
            return self.atom_fn(atom, ind)

        if a1 is not None and a2 is not None:
            if a1 != a2:
                raise CL.StructFail(
                    f'branch at {node} enters two spin atoms '
                    f'{a1} {a2}')
            # both arms spin forever in the same pure cycle; the
            # (side-effect-free) condition cannot change the outcome
            out += spin_lines(indent)
            return out, None
        if a1 is not None:
            out.append(CL.ELine(indent, f'if {cond} then', node,
                                'construct'))
            out += spin_lines(indent + 1)
            out.append(CL.ELine(indent, 'end', node, 'construct'))
            lines, cont = self._seq((rec.mode, t2), stops, indent)
            return out + lines, cont
        out.append(CL.ELine(indent,
                            f'if {CL.invert_cond(cond)} then', node,
                            'construct'))
        out += spin_lines(indent + 1)
        out.append(CL.ELine(indent, 'end', node, 'construct'))
        lines, cont = self._seq((rec.mode, t1), stops, indent)
        return out + lines, cont

    def _branch_atom(self, node, stops, indent, eff, cond, t1, t2,
                     a1, a2):
        """Branch where at least one arm target is a kernel-atom
        member.  The atom is the join: arms entering it end with an
        entry-assignment leaf; an arm that continues in normal nodes
        is sequenced with the atom as its stop (its own last step
        emits the leaf through _node)."""
        cfg = self.cfg
        rec = cfg.recs[node]
        atom = a1 or a2
        if a1 is not None and a2 is not None and a1 != a2:
            raise CL.StructFail(f'branch at {node} enters two '
                                f'different atoms {a1} {a2}')
        if not self._is_kernel(atom):
            raise CL.StructFail(f'branch at {node} enters non-kernel '
                                f'atom {atom}')
        out = list(eff)

        def leaf(entry_key):
            if self.leaf_hook is None:
                return []
            return self.leaf_hook(atom, indent + 1, entry_key, node)

        def arm(k, a, arm_cond):
            """Render one arm; returns lines. arm_cond is the
            condition text under which this arm is taken."""
            if a is not None:
                return leaf((rec.mode, k))
            lines, cont = self._seq((rec.mode, k),
                                    set(stops) | {atom}, indent + 1)
            if cont is not None and cont != atom and cont not in stops:
                raise CL.StructFail(
                    f'branch arm from {node} leaks to {cont} '
                    f'(atom join {atom})')
            return lines

        k1 = (rec.mode, t1)
        k2 = (rec.mode, t2)
        if a1 is not None and a2 is not None:
            out.append(CL.ELine(indent, f'if {cond} then', node,
                                'construct'))
            out += leaf(k1)
            out.append(CL.ELine(indent, 'else', node, 'construct'))
            out += leaf(k2)
            out.append(CL.ELine(indent, 'end', node, 'construct'))
            return out, atom
        if a1 is not None:
            out.append(CL.ELine(indent, f'if {cond} then', node,
                                'construct'))
            out += leaf(k1)
            out.append(CL.ELine(indent, 'else', node, 'construct'))
            out += arm(t2, None, None)
            out.append(CL.ELine(indent, 'end', node, 'construct'))
            return out, atom
        out.append(CL.ELine(indent,
                            f'if {CL.invert_cond(cond)} then', node,
                            'construct'))
        out += leaf(k2)
        out.append(CL.ELine(indent, 'else', node, 'construct'))
        out += arm(t1, None, None)
        out.append(CL.ELine(indent, 'end', node, 'construct'))
        return out, atom

    def run_region(self, entry, stops, indent=0):
        """Structure a region starting at `entry`, stopping at any
        node in `stops`.  Returns (lines, cont)."""
        return self._seq(entry, set(stops), indent)


def elide_trampolines(pid, recs, edges, jmpr_regs):
    """Attempt trampoline elision for each JMPR hub of the proto.
    jmpr_regs: {(mode,pc): reg} from the walk records' extras.
    Returns (new_edges, elided_hubs, elision_info) where new_edges has
    the same shape as `edges` (key -> [(target, prov)]); hub nodes are
    removed from the node set implicitly (callers rebuild node set
    from edges + recs minus elided hubs)."""
    nodes = {r.key for r in recs}
    succ = {k: [t for t, _ in v] for k, v in edges.items()}
    by_key = {r.key: r for r in recs}
    elided = {}
    info = {'hubs': {}}
    for hub, reg in sorted(jmpr_regs.items()):
        if hub not in nodes:
            continue
        targets = [t for t in succ.get(hub, [])]
        if len(targets) < 2:
            # single-target JMPRs are plain dynamic gotos (the walk
            # resolved exactly one target); zero-target ones are
            # path ends.  Neither is a trampoline hub.
            info['hubs'][f'{hub[0]}:{hub[1]}'] = {
                'reg': reg, 'targets': [list(t) for t in targets],
                'resolution': {}, 'elided': False,
                'note': 'single/zero-target JMPR — not a hub'}
            continue
        target_set = set(targets)
        in_s, out_s = propagate_reg(nodes, succ, by_key, reg, hub,
                                    target_set)
        pred_map = _preds(succ, nodes)
        resolution = {}
        ok = True
        for p in sorted(pred_map.get(hub, ())):
            v = out_s[p]
            if v is TOP or len(v) != 1:
                resolution[f'{p[0]}:{p[1]}'] = ('unresolved', 
                                                None if v is TOP else sorted(v))
                ok = False
            else:
                k = next(iter(v))
                if (hub[0], k + 1) not in target_set and \
                        (hub[0], k + 1) not in nodes:
                    resolution[f'{p[0]}:{p[1]}'] = ('inconsistent', k)
                    ok = False
                elif (hub[0], k + 1) not in target_set:
                    resolution[f'{p[0]}:{p[1]}'] = ('inconsistent', k)
                    ok = False
                else:
                    resolution[f'{p[0]}:{p[1]}'] = ('edge', k + 1)
        info['hubs'][f'{hub[0]}:{hub[1]}'] = {
            'reg': reg, 'targets': [list(t) for t in targets],
            'resolution': resolution, 'elided': ok}
        if not ok:
            continue
        # rewrite edges: preds now point at their resolved targets
        new_edges = {}
        for u, vs in edges.items():
            if u == hub:
                continue
            nv = []
            for t, prov in vs:
                if t == hub and \
                        resolution.get(f'{u[0]}:{u[1]}', (None,))[0] == 'edge':
                    k = resolution[f'{u[0]}:{u[1]}'][1]
                    nv.append(((hub[0], k), 'trampoline-elision'))
                else:
                    nv.append((t, prov))
            new_edges[u] = nv
        edges = new_edges
        succ = {k: [t for t, _ in v] for k, v in edges.items()}
        elided[hub] = reg
    return edges, elided, info
