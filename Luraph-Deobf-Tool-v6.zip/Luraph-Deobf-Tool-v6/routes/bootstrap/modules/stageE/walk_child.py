#!/usr/bin/env python3
"""walk_child.py — disasm2 walk of a harvested child proto, with
constants resolved LIVE through the child's own operand tables (the
materializer runs in context, in walk order).  Used by the Phase D
proof gate and the full sweep's per-child structured records."""
import importlib.util
import os

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
STAGE2 = os.path.join(CASE, 'stage2')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


d2 = load('disasm2', os.path.join(STAGE2, 'disasm2.py'))

MODE_LETTER = {114: 'A', 49: 'B', 210: 'C', 113: 'D'}
DZ_NAMES = ('e', 'A', 'P', 'y')


def encode_const(v):
    """Live value -> protos.json-style constant (fmt_const-consumable)."""
    if v is None or isinstance(v, (bool, int, float)):
        return v
    if isinstance(v, bytes):
        return {'other': repr(v)}
    if isinstance(v, tuple):
        return {'other': repr(v)[:60]}
    return {'other': f'<{type(v).__name__}>'}


class LiveMat(dict):
    """dict whose .get() falls back to the live materializer."""

    def __init__(self, rt, table):
        super().__init__()
        self.rt = rt
        self.table = table
        self.errors = set()
        for k, v in table.d.items():
            if isinstance(k, int):
                self[k] = encode_const(v)

    def get(self, k, default=None):
        if dict.__contains__(self, k):
            return dict.get(self, k)
        if k in self.errors:
            return default
        try:
            v = self.rt.tget(self.table, k)
        except Exception:
            self.errors.add(k)
            return default
        enc = encode_const(v)
        if enc is None:
            self.errors.add(k)
            return default
        self[k] = enc
        return enc


def stream_list(tab, fz):
    sub = tab.d.get(fz.num_key(-2))
    if not isinstance(sub, fz.LT):
        return [0]
    n = (max((k for k in sub.d if isinstance(k, int)), default=0)) + 1
    return [sub.d.get(i, 0) for i in range(n)]


def walk_child(rt, live_rec):
    """Run the disasm2 walk for one harvested child.  Returns
    (dis, info) where info has entry/mode/visited/const stats.

    Streams/fields/chunk come from the harvest-time walk snapshot (the
    child's initial state — the walk simulates decryptors itself);
    constants resolve LIVE through the child's operand tables."""
    fz = rt.fz
    group = live_rec['group']
    fargs = live_rec['factory_args'][0]
    factory = {'u': fargs[3], 'A': fargs[4], 'R2': fargs[14],
               'P1': fz.tget_raw(fargs[1], 1),
               'P2': fz.tget_raw(fargs[1], 2)}
    snap = live_rec.get('walk_snapshot')
    streams = {}
    mats = []
    errs = []
    raw_lanes = []
    lane_lengths = {}
    for i, (name, tab) in enumerate(zip(DZ_NAMES, group[1:])):
        if snap and snap['streams'][i]:
            sd = snap['streams'][i]
            raw_lanes.append([sd.get(j, 0) for j in range(max(sd) + 1)])
        else:
            raw_lanes.append(stream_list(tab, fz))
        lane_lengths[name] = len(raw_lanes[-1])
    # Phase E fix (child13/child15 truncation): the four stream lanes
    # have INDEPENDENT lengths (per-table descriptor sizes — healthy
    # child1 is 104/101/104/104).  disasm2 indexes every lane at
    # pc-1 up to n_slots, so a fallthrough past the shortest lane
    # raised IndexError and truncated the walk.  Pad all lanes to the
    # common length with 0 (absent slot; the same convention
    # stream_list's .get(j, 0) uses).  Values within each lane's own
    # range are unchanged, so previously-completing walks are
    # unaffected.
    n_common = max(len(l) for l in raw_lanes)
    for (name, _tab), lane in zip(zip(DZ_NAMES, group[1:]), raw_lanes):
        streams[name] = lane + [0] * (n_common - len(lane))
    for tab in group[1:]:
        lm = LiveMat(rt, tab)
        mats.append(lm)
        errs.append(lm.errors)
    if snap and snap.get('fields') is not None:
        fields = {k: v for k, v in snap['fields'].items()
                  if isinstance(v, (int, float))}
        chunk = snap['chunk']
    else:
        fields = {int(k): v for k, v in rt.fields.d.items()
                  if isinstance(v, (int, float)) and isinstance(k, int)}
        chunk = bytes(rt.chunk.data)
    n_slots = max(len(s) for s in streams.values())
    dis = d2.Dis(streams=streams, factory=factory, fields=fields,
                 chunk=chunk, mat=mats, mat_err=errs, n_slots=n_slots)
    mode = MODE_LETTER.get(factory['A'], 'A')
    truncated = None
    try:
        dis.run(entry_mode=mode, entry_pc=factory['R2'])
    except Exception as e:
        # The walk state diverged from the execution-time state (e.g.
        # stream slots still encrypted at build time whose decryption
        # depends on caller context).  Records gathered so far are
        # real; keep them and report the truncation.
        truncated = f'{type(e).__name__}: {e}'
    # Sanitize decrypted strings: a wrong field/key state yields long
    # non-printable garbage (observed: 19,838-byte blob); drop those.
    dropped = []
    for k, v in list(dis.decrypted_strings.items()):
        if len(v) > 4096 or (v and sum(
                1 for b in v if 32 <= b < 127 or b in (9, 10, 13))
                / len(v) < 0.8):
            dropped.append(f'{k[0]}:{k[1]}')
            del dis.decrypted_strings[k]
    resolved = sum(len(m) for m in mats)
    info = {'mode': mode, 'entry': factory['R2'], 'u': factory['u'],
            'visited': len(dis.visited),
            'struct': len(dis.struct),
            'consts_resolved': resolved,
            'const_errors': sum(len(e) for e in errs),
            'unresolved_jmpr': len(dis.unresolved_jmpr),
            'decrypted_strings': len(dis.decrypted_strings),
            'notes': dis.notes[:20]}
    if truncated:
        info['truncated'] = truncated
    if dropped:
        info['dropped_strings'] = dropped
    info['lane_lengths'] = lane_lengths
    # Slots whose opcode-lane value exceeds every mode loop's opcode
    # space (max 139) are data words sitting in the stream; the VM's
    # loop-A dispatch would treat them as catch-all ops if control
    # reached them.  Count them so the report can flag them honestly.
    info['data_tail_slots'] = sum(
        1 for r in dis.struct.values()
        if isinstance(r.get('op'), (int, float)) and r['op'] > 139)
    return dis, info
