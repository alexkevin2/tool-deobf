#!/usr/bin/env python3
"""make_factory_ast.py — generate stage2/factory_ast.json for the
executor stage.

The payload interpreter lives in VM-table slot 15209 (a 3-level
factory: factory -> middle -> inner).  The executor consumes its
luau-ast parse from stage2/factory_ast.json (root.body[0].values[0]
must be the factory function node).

table_parse.py's span for this entry under-measures the true end
(the case's luau-ast-verified span is 8 chars longer than the table
span: the token matcher misses the outer closing `end`s).  So:
take the table span, extend the end in small steps, wrap each
candidate as `local f = <src>` and accept the first that luau-ast
parses AND whose node chain is function -> return function ->
return function (the 3-level factory shape).

Env: BVM_RAW (input path; or argv[1]), BVM_LUAU_AST (luau-ast path).
CWD: the stageE workdir (../stage2 holds table_map.json).
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
STAGE2 = os.path.join(HERE, '..', 'stage2')
SLOT = '15209'


def returned_fn(node):
    body = (node or {}).get('body') or {}
    for st in body.get('body', []):
        if st.get('type') == 'AstStatReturn' and st.get('list'):
            return st['list'][0]
    return None


def is_factory(doc):
    try:
        fac = doc['root']['body'][0]['values'][0]
        mid = returned_fn(fac)
        inner = returned_fn(mid)
        return inner is not None and \
            inner.get('type') == 'AstExprFunction'
    except Exception:
        return False


def main():
    raw_path = sys.argv[1] if len(sys.argv) > 1 else \
        os.environ.get('BVM_RAW')
    luau_ast = os.environ.get('BVM_LUAU_AST')
    if not raw_path or not luau_ast:
        print('make_factory_ast: BVM_RAW / BVM_LUAU_AST not set',
              file=sys.stderr)
        return 1
    raw = open(raw_path, encoding='utf-8',
               errors='surrogateescape').read()
    tm = json.load(open(os.path.join(STAGE2, 'table_map.json')))
    entry = None
    for e in tm['entries']:
        if e.get('key_type') == 'slot' and str(e.get('key')) == SLOT \
                and e.get('kind') == 'function':
            entry = e
            break
    if entry is None:
        print('make_factory_ast: slot 15209 function entry not found',
              file=sys.stderr)
        return 1
    start, end0 = int(entry['start']), int(entry['end'])
    tmp = os.path.join(HERE, '_factory_candidate.luau')
    for ext in range(0, 65):
        src = raw[start:end0 + ext]
        with open(tmp, 'w', encoding='utf-8',
                  errors='surrogateescape') as fo:
            fo.write(f'local f = {src}\nreturn f\n')
        p = subprocess.run([luau_ast, tmp], capture_output=True,
                           text=True, timeout=120)
        if p.returncode != 0:
            continue
        try:
            doc = json.loads(p.stdout)
        except Exception:
            continue
        if is_factory(doc):
            with open(os.path.join(STAGE2, 'factory_ast.json'),
                      'w') as fo:
                json.dump(doc, fo)
            print(f'make_factory_ast: factory span {start}..'
                  f'{end0 + ext} (table end {end0}, +{ext})')
            return 0
    print('make_factory_ast: no parseable factory span found',
          file=sys.stderr)
    return 1


if __name__ == '__main__':
    sys.exit(main())
