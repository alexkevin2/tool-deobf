#!/usr/bin/env python3
"""walk_bz.py — Phase E "walk" for bz protos.

Findings (stageD/diag1.py + diag2.py, canonical sweep,
EXEC_ACT_BUDGET=2000000):

* A bz descriptor (fz_sim m_bz, IY branch A=200) finalizes ONE table:
  u[-2] = stream table, u[-1] = empty table, metatable set — and then
  calls H.slot[X] with (H, None, None, u).  For this file X is 41
  (child14/16/19) or 67 (child20).  Slots 41/67 are NOT the slot-15209
  interpreter factory: they are small payload-level utility closures
  (bit/PRNG helpers over structure field tables, ~260-290 chars,
  verbatim in the raw file).  The 4 factory args are discarded by the
  outer closure, which just returns its middle closure.
* The harvested bz group table is an EMPTY SHELL: keys {-2, -1} only,
  both empty tables, no metatable visible post-build.  The two
  state-198 u32 writes during each build go into a transient IY
  working table, not into the harvested group (captured per-build in
  sweepE's BZ_LOG; recorded below as build-time consumption, not as
  group contents).
* The slot-15209 interpreter NEVER executes a bz group: dz protos are
  the only instruction-carrying protos (4 operand tables + packed
  factory header).  The payload-visible materialized value of a bz
  descriptor is the slot-41/67 OUTER closure itself.

So the faithful "walk" of a bz proto = a struct record in the shape
liftD consumes, with instructions=[] and the verbatim closure source
that liftD emits as the proto's definition (kind='bz-constant').
No instruction stream exists to walk; claiming one would fabricate
code.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import executor as ex

fz = ex.fz


def _table_summary(tab):
    if not isinstance(tab, fz.LT):
        return {'type': type(tab).__name__}
    out = {'n_keys': len(tab.d), 'keys': []}
    for k in sorted(tab.d, key=lambda v: (str(type(v)), str(v))):
        v = tab.d[k]
        if isinstance(v, fz.LT):
            out['keys'].append([ex.ser_value(k),
                                {'$lt': len(v.d)}])
        else:
            out['keys'].append([ex.ser_value(k), ex.ser_value(v)])
    out['metatable'] = tab.mt is not None
    return out


def build_bz_struct(rt, live, bz_calls, children_rec):
    """Build the liftD struct record for one bz child.

    rt: executor Runtime (post-sweep); live: children_live record;
    bz_calls: sweepE BZ_LOG entries for this child's build frame;
    children_rec: the children_recovered record (M, access, site)."""
    group = live['group']
    tab = group[1]
    fini = [c for c in bz_calls if c['A'] == 200]
    slot = fini[-1]['X'] if fini else None
    entry = rt.table_map_index.get(f'slot{slot}') if slot else None
    src = None
    span = None
    if entry is not None:
        span = [int(entry['start']), int(entry['end'])]
        src = rt.raw_text[span[0]:span[1]]
    writes = []
    for c in bz_calls:
        for k, v in c['writes']:
            writes.append({'state': c['A'], 'key': k, 'value': v})
    return {
        'kind': 'bz-constant',
        'M': children_rec.get('descriptor_M'),
        'frame': live.get('frame'),
        'slot': slot,
        'closure_span': span,
        'closure_source': src,
        'group_table': _table_summary(tab),
        'build_writes': writes,
        'instructions': [],
        'decrypted_strings': {},
        'factory': None,
        'n_slots': 0,
        'site': children_rec.get('access'),
        'note': ('bz proto: no interpreter instruction stream; the '
                 'materialized constant is the slot-%s utility '
                 'closure (verbatim).  Group table is an empty '
                 'shell (keys -2/-1).' % slot),
    }
