#!/usr/bin/env python3
"""mocks.py — permissive Roblox/environment mocks for the Phase D executor.

Every mock interaction is appended to MOCKLOG (list of tuples) so the
STAGED-REPORT can cite exactly what the payload touched.  Mocks are
identity-stable: the same (parent, key) always yields the same object,
so `game.Workspace` is one singleton, `x == x` holds, etc.

Value policy (driven by executor.Runtime.decide):
- indexing a mock -> child mock (identity-stable), except members with
  a known concrete implementation (a small Roblox surface).
- calling a mock -> a fresh-ish child mock named '<call>' (cached per
  (mock, args-repr) only when args are hashable scalars).
- truthiness / comparisons / length / arithmetic on mocks are NOT
  decided here: the interpreter raises DecisionNeeded and the driver
  policy answers (and logs).  This module only provides the objects.
"""
import math

MOCKLOG = []


def log(*entry):
    MOCKLOG.append(entry)


# ---------------------------------------------------------- identity spoofing
# --spoof-id support: the game mock's identity fields are served
# from a static seed (exactly one candidate) or as an IdSentinel
# that the executor's comparison hook calibrates (see identity.py).
# Field set + capture semantics are owned by the shared spoof
# engine (spoof_engine.py, vendored in this directory); this module
# keeps only the mock-object mechanics.  No game ID is hardcoded
# anywhere on this path: seeds arrive from static extraction.
try:
    import spoof_engine as _engine
    IDENTITY_FIELDS = _engine.IDENTITY_FIELDS
except ImportError:
    import importlib.util as _ilu
    import os as _os
    _here = _os.path.dirname(_os.path.abspath(__file__))
    _engine = None
    for _p in (_os.path.join(_here, 'spoof_engine.py'),
               _os.path.join(_here, '..', '..', '..', '..',
                             'spoof_engine.py')):
        if _os.path.isfile(_p):
            _spec = _ilu.spec_from_file_location('spoof_engine', _p)
            _engine = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_engine)
            break
    if _engine is None:
        raise
    IDENTITY_FIELDS = _engine.IDENTITY_FIELDS
IDENTITYLOG = []
_ID_CONFIG = {'enabled': True, 'seed': {}}


def configure_identity(enabled, seed=None):
    _ID_CONFIG['enabled'] = bool(enabled)
    _ID_CONFIG['seed'] = dict(seed or {})


def ilog(*entry):
    IDENTITYLOG.append(entry)


class Mock:
    """Universal permissive mock (Roblox Instance / service / value)."""

    _next_id = [1]

    def __init__(self, name):
        self._name = name
        self._children = {}
        self._props = {}
        self._id = Mock._next_id[0]
        Mock._next_id[0] += 1

    # -- identity ------------------------------------------------------
    def __repr__(self):
        return f'<mock {self._name}#{self._id}>'

    def __hash__(self):
        return object.__hash__(self)

    # -- access --------------------------------------------------------
    def get(self, key):
        if isinstance(key, bytes):
            try:
                key = key.decode('utf-8', 'replace')
            except Exception:
                key = repr(key)
        if _ID_CONFIG['enabled'] and getattr(self, '_is_game', False) \
                and key in IDENTITY_FIELDS:
            return self._identity_get(key)
        if key in self._props:
            return self._props[key]
        v = KNOWN_MEMBERS.get((self._name, key))
        if v is not None:
            return v(self) if callable(v) else v
        child = self._children.get(key)
        if child is None:
            child = Mock(f'{self._name}.{key}')
            self._children[key] = child
        log('index', self._name, key)
        return child

    def _identity_get(self, key):
        """Serve a game identity field under the spoof policy:
        seeded/adopted concrete value if known (logged as a read),
        else a per-field IdSentinel the comparison hook calibrates."""
        if key in self._props:
            src = 'static-seed' if key in _ID_CONFIG['seed'] \
                else 'adopted'
            ilog('read', key, self._props[key], src)
            return self._props[key]
        sents = getattr(self, '_sentinels', None)
        if sents is None:
            sents = self._sentinels = {}
        s = sents.get(key)
        if s is None:
            s = IdSentinel(self, key)
            sents[key] = s
            log('index', self._name, key)
        ilog('read', key, None, 'sentinel')
        return s

    def set(self, key, value):
        if isinstance(key, bytes):
            key = key.decode('utf-8', 'replace')
        self._props[key] = value
        log('newindex', self._name, key, _short(value))

    def call(self, *args):
        log('call', self._name, tuple(_short(a) for a in args))
        r = self._children.get('<call>')
        if r is None:
            r = Mock(f'{self._name}()')
            self._children['<call>'] = r
        return r


def _short(v):
    r = repr(v)
    return r if len(r) <= 60 else r[:57] + '...'


class IdSentinel(Mock):
    """Placeholder for an unseeded game identity field.  The
    executor's decide('cmpeq') hook calls adopt() with the first
    scalar the sentinel is compared against; from then on the
    owner mock serves the adopted value directly."""

    def __init__(self, owner, field):
        super().__init__(f'game.{field}?')
        self.owner = owner
        self.field = field
        self.adopted = None

    def adopt(self, value, site):
        self.adopted = value
        self.owner._props[self.field] = value
        ilog('capture', self.field, value, site)
        return value


# ---------------------------------------------------------------- Roblox
class _Vec:
    """Minimal concrete Vector3/Vector2 value (payload does real math)."""

    def __init__(self, kind, comps):
        self.kind = kind
        self.comps = tuple(float(c) for c in comps)

    def __repr__(self):
        return f'{self.kind}({", ".join(repr(c) for c in self.comps)})'

    def get(self, key):
        if isinstance(key, bytes):
            key = key.decode('utf-8', 'replace')
        axes = ('X', 'Y', 'Z') if self.kind == 'Vector3' else ('X', 'Y')
        if key in axes:
            return self.comps[axes.index(key)]
        if key == 'Magnitude':
            return math.sqrt(sum(c * c for c in self.comps))
        if key == 'Unit':
            m = math.sqrt(sum(c * c for c in self.comps))
            if m == 0:
                return _Vec(self.kind, self.comps)
            return _Vec(self.kind, tuple(c / m for c in self.comps))
        return Mock(f'{self.kind}.{key}')

    def binop(self, op, other):
        if isinstance(other, _Vec):
            if op == 'Add':
                return _Vec(self.kind, tuple(a + b for a, b in
                                             zip(self.comps, other.comps)))
            if op == 'Sub':
                return _Vec(self.kind, tuple(a - b for a, b in
                                             zip(self.comps, other.comps)))
            if op == 'Mul':
                return _Vec(self.kind, tuple(a * b for a, b in
                                             zip(self.comps, other.comps)))
            if op == 'Div':
                return _Vec(self.kind, tuple(a / b for a, b in
                                             zip(self.comps, other.comps)))
        if isinstance(other, (int, float)) and not isinstance(other, bool):
            if op == 'Add':
                return _Vec(self.kind, tuple(a + other for a in self.comps))
            if op == 'Sub':
                return _Vec(self.kind, tuple(a - other for a in self.comps))
            if op == 'Mul':
                return _Vec(self.kind, tuple(a * other for a in self.comps))
            if op == 'Div':
                return _Vec(self.kind, tuple(a / other for a in self.comps))
        return None


def _vec_new(kind):
    def _new(*args):
        n = 3 if kind == 'Vector3' else 2
        comps = [0.0] * n
        for i, a in enumerate(args[:n]):
            if isinstance(a, (int, float)) and not isinstance(a, bool):
                comps[i] = float(a)
        return _Vec(kind, comps)
    return _new


KNOWN_MEMBERS = {}


def _register():
    # game:GetService(name) handled generically by Mock.call; give the
    # well-known singletons stable names through the env builder instead.
    pass


# ---------------------------------------------------------------- env
def build_env(fz, stdlib):
    """The getfenv() table (payload global environment) as an fz.LT with
    an __index fallback that mints identity-stable mocks for unknown
    global names.  `stdlib` provides real implementations for the Luau
    globals the payload may read (pairs, tostring, ...)."""
    env = fz.LT()
    d = env.d
    game = Mock('game')
    game._is_game = True
    game._sentinels = {}
    if _ID_CONFIG['enabled']:
        for f, v in _ID_CONFIG['seed'].items():
            if f in IDENTITY_FIELDS:
                game._props[f] = v
                ilog('seed', f, v, 'static')
    workspace = Mock('Workspace')
    script = Mock('script')
    d[b'game'] = game
    d[b'workspace'] = workspace
    d[b'Workspace'] = workspace
    d[b'script'] = script
    d[b'plugin'] = None
    for name, fn in stdlib.items():
        d[name.encode()] = fn
    d[b'Vector3'] = _Namespace(fz, {'new': _vec_new('Vector3')})
    d[b'Vector2'] = _Namespace(fz, {'new': _vec_new('Vector2')})
    for ns in ('Instance', 'Enum', 'UDim2', 'UDim', 'CFrame', 'Color3',
               'BrickColor', 'Random', 'DateTime', 'task', 'math',
               'string', 'table', 'bit32', 'buffer', 'utf8', 'os',
               'coroutine', 'debug'):
        if ns.encode() not in d:
            d[ns.encode()] = Mock(ns)

    mt = fz.LT()
    cache = {}

    def _index(t, k):
        if isinstance(k, bytes):
            name = k.decode('utf-8', 'replace')
        else:
            name = str(k)
        v = cache.get(name)
        if v is None:
            v = Mock(f'global:{name}')
            cache[name] = v
        log('global', name)
        return v

    mt.d['__index'] = _index
    env.mt = mt
    return env


class _Namespace:
    """A small concrete namespace table (e.g. Vector3 with .new)."""

    def __init__(self, fz, members):
        self._fz = fz
        self._members = members
        self._t = None

    def to_lt(self):
        if self._t is None:
            self._t = self._fz.LT()
            for k, v in self._members.items():
                self._t.d[k.encode()] = v
        return self._t

    def get(self, key):
        if isinstance(key, bytes):
            key = key.decode('utf-8', 'replace')
        if key in self._members:
            return self._members[key]
        return Mock(f'ns.{key}')
