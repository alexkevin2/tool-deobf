#!/usr/bin/env python3
"""clean2.py — StealAnEggs restructuring pass.

Same cosmetics pipeline as clean.py (renaming, folding, idioms —
reused unchanged), but the control-flow graph is the COMPLETED
walk graph (cfg2.json: branch successors + mode switches + the
re-harvested jmpr_followed unions), trampoline JMPR hubs are
elided by constant propagation over the dispatch register, and
the structurer (clean2_lib.Structurer2) adds loop-aware joins,
validated candidate joins, bounded block duplication and scoped
dispatch kernels for SCCs that provably resist structuring.

Outputs (clean.py's outputs are NOT touched):
  full_clean2.luau, clean2_map.json, clean2_stats.json
Rerun:  python3 clean2.py
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import clean as C
import clean_lib as CL
import clean2_lib as C2

JMPR_RE = re.compile(r'pc = R\((\d+)\)')
CFG2 = C2.load_cfg2()
STATS2 = Counter()
NOTES2 = []


def tag(key):
    return f'{key[0]}{key[1]}'


# ------------------------------------------------------------ graph prep
def build_edges2(proto):
    """Completed walk edges for proto.recs + trampoline elision.
    Returns (recs, edges, elided, elision_info); recs = proto.recs
    minus elided hub records."""
    edges = C2.completed_edges(proto.pid, CFG2[proto.pid])
    jmpr_regs = {}
    for r in proto.recs:
        m = JMPR_RE.search(r.rec.get('extra') or '')
        if m and r.name == 'JMPR':
            jmpr_regs[r.key] = int(m.group(1))
    edges, elided, info = C2.elide_trampolines(proto.pid,
                                               proto.recs, edges,
                                               jmpr_regs)
    for h in elided:
        if proto.by_key[h].effects:
            raise AssertionError(
                f'{proto.pid}: elided hub {h} has effects '
                f'{proto.by_key[h].effects} — elision unsafe')
    recs = [r for r in proto.recs if r.key not in elided]
    keys = {r.key for r in recs}
    edges = {k: v for k, v in edges.items() if k in keys}
    return recs, edges, elided, info


def effects_fn_of(proto):
    def fn(key):
        rec = proto.by_key[key]
        return [t for t, _ in C.render_effect_lines(proto, rec)]
    return fn


def make_atom_fn(atoms):
    def atom_fn(key, indent):
        a = atoms[key]
        ent = a.entries[0] if a.entries else a.members[0]
        cyc = ' -> '.join(tag(m) for m in a.members)
        return [
            CL.ELine(indent,
                     f'-- terminal cycle ({len(a.members)} '
                     f'instructions, no exits): {cyc}',
                     ent, 'comment'),
            CL.ELine(indent, 'while true do end', ent, 'construct'),
        ]
    return atom_fn


def make_leaf_hook():
    def hook(atom_key, indent, entry_key, owner):
        return [CL.ELine(indent, f'__entry = "{tag(entry_key)}"',
                         owner, 'construct')]
    return hook


def fresh_structurer(proto, cfg, atoms):
    return C2.Structurer2(cfg, effects_fn_of(proto),
                          atom_fn=make_atom_fn(atoms),
                          leaf_hook=make_leaf_hook())


def kernel_name(proto, atom, idx):
    base = f'kernel_{C.FN_NAMES[proto.pid]}'
    return base if idx == 0 else f'{base}_{idx}'


# ------------------------------------------------------------ kernels
def kernel_ctrl_lines(proto, rec, edges, member_set):
    """One control line for a kernel member, from the completed
    (post-elision) edges.  Targets inside the kernel assign pc;
    targets outside return their tag to the caller."""
    succs = [t for t, _ in edges.get(rec.key, [])]

    def cls(t):
        if t in member_set:
            return f'pc = "{tag(t)}"'
        return f'return "{tag(t)}"'

    ctrl = rec.ctrl
    if ctrl is None or ctrl[0] == 'return':
        return [(4, 'return "RETURN"', rec.key, 'ctrl')]
    if ctrl[0] == 'branch':
        _, cond, t1, t2 = ctrl
        k1, k2 = (rec.mode, t1), (rec.mode, t2)
        return [(4, f'if {cond} then {cls(k1)} else {cls(k2)} end',
                 rec.key, 'ctrl')]
    if succs:
        return [(4, cls(succs[0]), rec.key, 'ctrl')]
    # no recorded successor (unresolved dynamic jump / dead switch):
    # execution leaves the walked proto here
    return [(4, 'return "RETURN"', rec.key, 'ctrl')]


def kernel_uses_return(atom, edges, proto):
    ms = set(atom.members)
    for m in atom.members:
        rec = proto.by_key[m]
        if rec.ctrl is None or rec.ctrl[0] == 'return':
            return True
        if rec.ctrl[0] not in ('branch',) and \
                not edges.get(m):
            return True
    return False


def kernel_def_lines(proto, atom, edges, kn):
    mem = sorted(atom.members)
    ms = set(mem)
    out = []
    ents = ', '.join(tag(e) for e in atom.entries) or '(entry)'
    exts = ', '.join(tag(e) for e in atom.exits) or '(none)'
    out.append((1, f'-- kernel {kn}: {len(mem)}-instruction strongly '
                   f'connected region (entries: {ents}; exits: '
                   f'{exts}); scoped dispatch — see STRUCTURE-REPORT',
                None, 'comment'))
    out.append((1, f'local function {kn}(pc, ...)', None, 'raw'))
    out.append((2, 'while true do', None, 'raw'))
    for i, m in enumerate(mem):
        rec = proto.by_key[m]
        kw = 'if' if i == 0 else 'elseif'
        out.append((3, f'{kw} pc == "{tag(m)}" then', m, 'ctrl'))
        for text, cat in C.render_effect_lines(proto, rec):
            out.append((4, text, m, cat))
        out += kernel_ctrl_lines(proto, rec, edges, ms)
    out.append((3, 'else', None, 'raw'))
    out.append((4, 'error("kernel reached an unlisted pc")', None,
                'raw'))
    out.append((3, 'end', None, 'raw'))
    out.append((2, 'end', None, 'raw'))
    out.append((1, 'end', None, 'raw'))
    return out


# ------------------------------------------------------------ structuring
def drop_empty_else(raw):
    kept = []
    for i, ln in enumerate(raw):
        if ln.text == 'else' and ln.cat == 'construct' and \
                i + 1 < len(raw) and raw[i + 1].text == 'end' and \
                raw[i + 1].indent == ln.indent:
            STATS2['empty-else-dropped'] += 1
            continue
        kept.append(ln)
    return kept


def structure_attempt(proto, recs, edges, force=()):
    """One full structuring attempt.  Returns a result dict or
    raises CL.StructFail."""
    recs2, edges2, atoms = C2.condense(recs, edges, proto.entry_key,
                                       force_kernels=force)
    cfg = C2.make_cfg(proto.pid, recs2, edges2, proto.entry_key)
    kernels = [k for k, a in atoms.items()
               if a.atom_kind == 'kernel']
    knames = {k: kernel_name(proto, atoms[k], i)
              for i, k in enumerate(kernels)}
    body = []
    dup_nodes = set()
    atom_dups = []

    def absorb(st):
        nonlocal dup_nodes
        dup_nodes |= st.dup_nodes
        atom_dups.extend(st.atom_dups)

    st = fresh_structurer(proto, cfg, atoms)
    if not kernels:
        body = st.run()
        absorb(st)
        return {'body': drop_empty_else(body), 'atoms': atoms,
                'cfg': cfg, 'dup_nodes': dup_nodes,
                'atom_dups': atom_dups, 'knames': knames,
                'edges': edges,
                'atom_key_of': {m: k for k, a in atoms.items()
                                for m in a.members}}

    stops = set(kernels)
    cur = st
    node = proto.entry_key
    pending = None
    guard = 0
    while True:
        guard += 1
        if guard > 8:
            raise CL.StructFail('kernel stitching did not converge')
        if pending is None:
            lines, cont = cur.run_region(node, stops, 0)
            body += lines
            absorb(cur)
            if cont is None:
                break
            pending = cont
        atom = atoms[pending]
        kn = knames[pending]
        pending = None
        has_ret = kernel_uses_return(atom, edges, proto)
        eff_exits = list(atom.exits)
        if eff_exits:
            body.append(CL.ELine(0, f'__exit = {kn}(__entry, ...)',
                                 None, 'raw'))
        else:
            body.append(CL.ELine(0, f'{kn}(__entry, ...)', None,
                                 'raw'))
            if not has_ret:
                break
            # kernel can only leave via a member return
            body.append(CL.ELine(0, 'return', None, 'raw'))
            break
        if has_ret:
            body.append(CL.ELine(0, 'if __exit == "RETURN" then',
                                 None, 'construct'))
            body.append(CL.ELine(1, 'return', None, 'construct'))
            body.append(CL.ELine(0, 'end', None, 'construct'))
        if len(eff_exits) == 1:
            node = eff_exits[0]
            cur = fresh_structurer(proto, cfg, atoms)
            continue
        # join = ipdom of the atom in the condensed cfg, if real
        join = None
        for k, a in atoms.items():
            if a is atom:
                join = st.ipdom.get(k)
        if join == st.EXIT or join not in cfg.recs:
            join = None
        conts = []
        for i, ex in enumerate(eff_exits):
            kw = 'if' if i == 0 else 'elseif'
            body.append(CL.ELine(0, f'{kw} __exit == "{tag(ex)}" '
                                    f'then', None, 'construct'))
            sub = fresh_structurer(proto, cfg, atoms)
            lines2, cont2 = sub.run_region(
                ex, stops | ({join} if join else set()), 1)
            body += lines2
            absorb(sub)
            conts.append(cont2)
        body.append(CL.ELine(0, 'else', None, 'construct'))
        body.append(CL.ELine(1, 'error("kernel returned an unknown '
                                'exit")', None, 'raw'))
        body.append(CL.ELine(0, 'end', None, 'construct'))
        kconts = [c for c in conts if c in stops]
        if join is not None:
            if any(c is not None and c != join and c not in stops
                   for c in conts) or kconts:
                raise CL.StructFail(
                    'kernel exit regions do not rejoin cleanly')
            node = join
            cur = fresh_structurer(proto, cfg, atoms)
            continue
        if all(c is None for c in conts):
            break
        if len(kconts) == 1 and \
                all(c is None or c in stops for c in conts):
            pending = kconts[0]
            continue
        raise CL.StructFail('kernel exit regions diverge')
    return {'body': drop_empty_else(body), 'atoms': atoms,
            'cfg': cfg, 'dup_nodes': dup_nodes,
            'atom_dups': atom_dups, 'knames': knames,
            'edges': edges,
            'atom_key_of': {m: k for k, a in atoms.items()
                            for m in a.members}}


def katom_key(cfg, atom):
    for k, r in cfg.recs.items():
        if r is atom:
            return k
    return None


def sccs_of(recs, edges):
    nodes = {r.key for r in recs}
    succ = {k: [t for t, _ in v] for k, v in edges.items()}
    return [c for c in C2.sccs(nodes, succ) if len(c) > 1]


def structure_proto(proto, recs, edges):
    """Try plain structuring; on failure, force-kernel resistant
    SCCs (largest first, then cumulative) and retry.  Returns the
    result dict with 'forced' info, or None if all attempts fail
    (caller falls back to v1 dispatch)."""
    try:
        res = structure_attempt(proto, recs, edges)
        res['forced'] = []
        res['first_fail'] = None
        return res
    except CL.StructFail as e:
        first_fail = str(e)
    comps = sorted(sccs_of(recs, edges), key=len, reverse=True)
    tried = []
    for comp in comps:
        tried.append(comp)
        try:
            res = structure_attempt(proto, recs, edges,
                                    force=[frozenset(comp)])
            res['forced'] = [{'members': sorted(comp),
                              'size': len(comp)}]
            res['first_fail'] = first_fail
            return res
        except CL.StructFail:
            continue
    if len(comps) > 1:
        try:
            res = structure_attempt(
                proto, recs, edges,
                force=[frozenset(c) for c in comps])
            res['forced'] = [{'members': sorted(c), 'size': len(c)}
                             for c in comps]
            res['first_fail'] = first_fail
            return res
        except CL.StructFail:
            pass
    return None


# ------------------------------------------------------------ assembly
def header_comment2(proto, form, detail):
    n = len(proto.recs)
    modes = C.proto_modes(proto)
    desc = ', '.join(f'mode {C.MODE_NUM[m]}: '
                     f'{sum(1 for r in proto.recs if r.mode == m)}'
                     for m in modes)
    fn = C.FN_NAMES[proto.pid]
    return [f'-- {fn}: {n} walked instructions ({desc}); {detail}.']


def build_proto_block2(proto, prep):
    rn = C.Renamer(proto)
    body = []
    res = prep['result']
    atoms = res['atoms']
    edges = res['edges']
    kernels = [k for k, a in atoms.items()
               if a.atom_kind == 'kernel']
    # elided trampoline hubs: one comment line each, owned by the hub
    for h in sorted(prep['elided']):
        reg = prep['elision_info']['hubs'][f'{h[0]}:{h[1]}']['reg']
        body.append((1, f'-- trampoline hub {tag(h)} elided: the '
                        f'dispatch register n[{reg}] is provably a '
                        f'singleton constant at every in-edge (see '
                        f'STRUCTURE-REPORT)', h, 'comment'))
    for k in kernels:
        body += kernel_def_lines(proto, atoms[k], edges,
                                 res['knames'][k])
    if kernels:
        body.append((1, 'local __entry, __exit', None, 'raw'))
    body += [(ln.indent + 1, ln.text, ln.owner, ln.cat)
             for ln in res['body']]
    renamed = []
    for ind, text, owner, cat in body:
        rec = proto.by_key.get(owner) if owner else None
        renamed.append((ind, rn.rename(text, rec), owner, cat))
    decls = C.declarations(proto, renamed)
    params = C.proto_params(proto, renamed)
    fn = C.FN_NAMES[proto.pid]
    block = [(0, t, None, 'comment')
             for t in header_comment2(proto, prep['form'],
                                      prep['form_detail'])]
    block.append((0, f'local function {fn}({", ".join(params)})',
                  None, 'raw'))
    block.extend(decls)
    if not renamed:
        why = ('switches to a mode with no walked segment; '
               'returns immediately')
        block.append((1, f'-- {why}', None, 'comment'))
    block.extend(renamed)
    block.append((0, 'end', None, 'raw'))
    block.append((0, '', None, 'raw'))
    return block


FILE_HEADER2 = [
    '-- StealAnEggs.luau — source-cleaned reconstruction (pass 2: '
    'restructured)',
    '-- The original file was a Luraph v15.1 virtualized bootstrap; '
    'the original',
    '-- source text was never present in it. This file is the '
    'restructured',
    '-- presentation of the verified devirtualized lift '
    '(full.luau): the same',
    '-- 796 walked instructions, equivalence-mapped in '
    'clean2_map.json.',
    '-- Control flow was rebuilt from the completed walk graph '
    '(see',
    '-- STRUCTURE-REPORT.md): real structured loops/branches '
    'wherever the graph',
    '-- provably allows, bounded duplication of shared tails '
    '(flagged), and',
    '-- dispatch scoped to the few irreducible kernels (flagged '
    'in the map).',
    '-- Names are reconstructed, never recovered: stdlib renames '
    'are CONFIRMED',
    '-- from the interpreter factory bindings; all other names are '
    'INFERRED and',
    '-- listed in CLEAN-REPORT.md. Style: StyLua-like, 4-space '
    'indent.',
    '',
]


def dup_instruction_count(res, atoms):
    """Duplicated original instructions: dup_nodes expanded over
    atom membership, plus repeated spin-atom renderings."""
    n = 0
    for k in res['dup_nodes']:
        if k in atoms:
            n += len(atoms[k].members)
        else:
            n += 1
    for k in res['atom_dups']:
        if k in atoms:
            n += len(atoms[k].members)
    return n


def main():
    protos = {}
    for pid, pstruct in CL.STRUCTS.items():
        protos[pid] = C.prepare(pid, pstruct)
    order = C.topo_order(protos)

    preps = {}
    for pid in order:
        p = protos[pid]
        if p.kind == 'bz-constant' or not p.recs:
            continue
        recs, edges, elided, einfo = build_edges2(p)
        res = structure_proto(p, recs, edges)
        if res is None:
            preps[pid] = {'form': 'dispatch',
                          'form_detail': 'dispatch form retained — '
                                         'structuring failed (see '
                                         'STRUCTURE-REPORT)',
                          'result': None, 'elided': elided,
                          'elision_info': einfo}
            continue
        atoms = res['atoms']
        nk = sum(1 for a in atoms.values()
                 if a.atom_kind == 'kernel')
        ndup = dup_instruction_count(res, atoms)
        parts = ['structured control flow reconstructed from the '
                 'completed walk graph']
        suffix = ''
        if nk:
            suffix += '+kernel'
            parts.append(f'{nk} irreducible kernel(s) kept as '
                         f'scoped dispatch')
        if ndup:
            suffix += '+duplication'
            parts.append(f'{ndup} instructions duplicated (shared '
                         f'tails, flagged in clean2_map)')
        form = 'structured' + suffix
        if elided:
            parts.append(f'{len(elided)} trampoline hub(s) elided')
        preps[pid] = {'form': form, 'form_detail': '; '.join(parts),
                      'result': res, 'elided': elided,
                      'elision_info': einfo}

    tagged = []
    for t in FILE_HEADER2:
        tagged.append((0, t, None, None, 'comment'))
    tagged.append((0, 'local function UNIMPL(mode, pc, op)',
                   None, None, 'raw'))
    tagged.append((1, 'error("unimplemented opcode (mode " .. '
                      'tostring(mode) .. ", pc " .. tostring(pc) .. '
                      '", op " .. tostring(op) .. ")")',
                   None, None, 'raw'))
    tagged.append((0, 'end', None, None, 'raw'))
    tagged.append((0, '', None, None, 'raw'))

    for pid in order:
        p = protos[pid]
        if pid == 'root':
            for ind, text, owner, cat in C.build_stub_block():
                tagged.append((ind, text, 'child18', owner, cat))
        if p.kind == 'bz-constant':
            block = C.build_bz_block(pid, p.pstruct)
        elif pid == 'child18':
            block = C.build_stub_block()
        elif preps[pid]['result'] is None:
            block = C.build_proto_block(p)
        else:
            block = build_proto_block2(p, preps[pid])
        for ind, text, owner, cat in block:
            tagged.append((ind, text, pid, owner, cat))
    tagged.append((0, 'return main', None, None, 'raw'))

    lines_out = []
    ranges = {}
    for i, (ind, text, pid, owner, cat) in enumerate(tagged):
        lines_out.append(('    ' * ind + text) if text else '')
        # 'construct' lines are counted too (unlike clean.py): a
        # branch/loop record owns its if/while header line, which
        # keeps pure-control records locatable in the map.
        if owner is not None and cat in ('effect', 'comment',
                                         'ctrl', 'construct'):
            key = (pid, owner)
            lo, hi = ranges.get(key, (i + 1, i + 1))
            ranges[key] = (min(lo, i + 1), max(hi, i + 1))
    # spin-atom members share the atom rendering's range
    for pid, prep in preps.items():
        if not prep['result']:
            continue
        for ak, a in prep['result']['atoms'].items():
            if a.atom_kind != 'spin-empty':
                continue
            ent = a.entries[0] if a.entries else a.members[0]
            r = ranges.get((pid, ent))
            if r:
                for m in a.members:
                    ranges[(pid, m)] = (r[0], r[1] + 1)

    src = '\n'.join(lines_out) + '\n'
    out_path = os.path.join(HERE, 'full_clean2.luau')
    with open(out_path, 'w') as f:
        f.write(src)

    # ------------------------------------------------ clean2_map.json
    entries = []
    proto_info = {}
    for pid in order:
        p = protos[pid]
        if p.kind == 'bz-constant' or not p.recs:
            proto_info[pid] = {
                'function': C.FN_NAMES[pid], 'kind': p.kind,
                'form': 'verbatim', 'instructions': 0}
            continue
        prep = preps[pid]
        res = prep['result']
        member_of = {}
        if res:
            for ak, a in res['atoms'].items():
                for m in a.members:
                    member_of[m] = a
        for rec in p.recs:
            lo, hi = ranges.get((pid, rec.key), (None, None))
            transforms = list(rec.transforms)
            if rec.key in prep['elided']:
                transforms.append('trampoline-elision')
            a = member_of.get(rec.key)
            if a is not None:
                transforms.append(
                    'kernel' if a.atom_kind == 'kernel'
                    else 'terminal-cycle-collapsed')
            if res and (rec.key in res['dup_nodes'] or
                        (a is not None and
                         res['atom_key_of'].get(rec.key)
                         in res['atom_dups'])):
                transforms.append('duplicated')
            entries.append({
                'proto': pid,
                'function': C.FN_NAMES[pid],
                'mode': rec.mode,
                'pc': rec.pc,
                'op': rec.name,
                'kind': rec.kind,
                'form': prep['form'],
                'lines': [lo, hi],
                'transforms': transforms,
                'risk': rec.risk,
            })
        info = {
            'function': C.FN_NAMES[pid],
            'kind': p.kind,
            'form': prep['form'],
            'form_detail': prep['form_detail'],
            'regime': p.regime,
            'instructions': len(p.recs),
            'elided_hubs': [list(h) for h in sorted(prep['elided'])],
        }
        if res:
            atoms = res['atoms']
            km = sum(len(a.members) for a in atoms.values()
                     if a.atom_kind == 'kernel')
            sm = sum(len(a.members) for a in atoms.values()
                     if a.atom_kind == 'spin-empty')
            info['structured'] = len(p.recs) - km - sm - \
                len(prep['elided'])
            info['kernel_instructions'] = km
            info['spin_instructions'] = sm
            info['duplicated_instructions'] = \
                dup_instruction_count(res, atoms)
            info['kernels'] = [
                {'name': res['knames'][k],
                 'members': [list(m) for m in sorted(a.members)],
                 'entries': [list(e) for e in a.entries],
                 'exits': [list(e) for e in a.exits],
                 'forced': any(
                     sorted(f['members']) == sorted(a.members)
                     for f in res['forced'])}
                for k, a in atoms.items()
                if a.atom_kind == 'kernel']
            info['spin_atoms'] = [
                {'members': [list(m) for m in sorted(a.members)]}
                for a in atoms.values()
                if a.atom_kind == 'spin-empty']
            info['forced_kernels'] = res['forced']
            info['first_fail'] = res['first_fail']
        proto_info[pid] = info

    total = sum(len(p.recs) for p in protos.values())
    cmap = {
        'file': 'full_clean2.luau',
        'raw_file': 'full.luau',
        'total_instructions': total,
        'mapped': len(entries),
        'protos': proto_info,
        'entries': entries,
    }
    with open(os.path.join(HERE, 'clean2_map.json'), 'w') as f:
        json.dump(cmap, f, indent=1)

    audit = C.audit_all(protos, ranges)
    stats = {
        'counters': dict(STATS2),
        'audit': audit,
        'forms': {pid: preps[pid]['form'] for pid in preps},
        'lines': src.count('\n'),
        'elseif_lines': sum(1 for ln in lines_out
                            if ln.strip().startswith('elseif')),
        'while_true_lines': sum(1 for ln in lines_out
                                if ln.strip() == 'while true do'),
    }
    with open(os.path.join(HERE, 'clean2_stats.json'), 'w') as f:
        json.dump(stats, f, indent=1)
    print(f'wrote full_clean2.luau ({stats["lines"]} lines), '
          f'clean2_map.json ({len(entries)}/{total})')
    print('audit:', json.dumps(audit))
    print('forms:', json.dumps(stats['forms'], indent=1))
    print('elseif:', stats['elseif_lines'],
          'while-true:', stats['while_true_lines'])


if __name__ == '__main__':
    main()
