#!/usr/bin/env python3
"""sweepE.py — Phase E driver.

Runs the canonical Phase D sweep (EXEC_ACT_BUDGET=2000000 — the only
budget under which the sweep reproduces the Phase D accounting; see
STAGEE-REPORT) with two capture wrappers installed:

  * dz wrapper: at every state-178 factory branch (B<=164), captures
    the WOULD-BE factory argument tuple from m_dz's registers
    (positional layout of the luafn call (H, i, e, f, O, P, X, R, z,
    y, A, a, S, E, _u)).  This recovers the factory header even when
    the call itself fails (child18: H.slot[753511] raises
    Untranscribed AFTER the group is appended).
  * bz wrapper: logs every m_bz call (frame, A, X) plus the write
    delta on the u table (state-198 u32 writes land in a transient
    IY working table; the delta proves where they go).

With the walk_child lane-padding fix, child13/child15 walks complete
inside sweep.main itself.  Post-processing then:
  1. builds bz struct records via walk_bz and merges them into
     proto_structs.json (+ truthful walk_infos in sweep_state.json);
  2. child18 route (c): re-probes the descriptor (child12 operand2
     key 305) in the final live state, then again after re-executing
     child12; if a build with a valid factory header results, the new
     child is walked and merged like any other;
  3. writes sweepE_state.json with all captures/attempts.
"""
import json
import os
import sys

os.environ.setdefault('EXEC_ACT_BUDGET', '2000000')

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import executor as ex
import sweep as sw
import walk_child as wc
import walk_bz as wb
import luau_interp as li
import identity as idmod

fz = ex.fz

DZ_CAPTURE = []
BZ_LOG = []


def _frame_id():
    rt = ex.RT
    return len(rt.fz_frames) - 1 if rt is not None else -1


_orig_dz = fz.METHODS['dz'][0]


def dz_wrap(H, *args):
    # m_dz(H, P0, E1, u2, A3, X4, y5, i6, J7, B8, z9, S10, f11, R12,
    #      h13, x14, e15, _u16, a17, O18)
    B = args[8] if len(args) > 8 else None
    if isinstance(B, (int, float)) and B <= 164:
        fact = (H, args[6], args[15], args[11], args[18], args[0],
                args[4], args[12], args[9], args[5], args[3], args[17],
                args[10], args[1], args[16])
        cap = {'frame': _frame_id(), 'x': args[14], 'u': fact[3],
               'mode': fact[4], 'entry': fact[14], 'hdr': None,
               'fact_args': fact}
        try:
            hdr = fact[1]
            if isinstance(hdr, fz.LT):
                cap['hdr'] = [ex.ser_value(fz.tget_raw(hdr, 1)),
                              ex.ser_value(fz.tget_raw(hdr, 2))]
        except Exception as e:
            cap['hdr'] = f'err {e}'
        DZ_CAPTURE.append(cap)
    return _orig_dz(H, *args)


fz.METHODS['dz'] = (dz_wrap, fz.METHODS['dz'][1])

_orig_bz = fz.METHODS['bz'][0]


def bz_wrap(H, *args):
    # m_bz(H, P0, E1, u2, A3, X4, y5, i6, J7, B8, z9, S10)
    frame = _frame_id()
    u = args[2] if len(args) > 2 else None
    before = dict(u.d) if isinstance(u, fz.LT) else {}
    r = _orig_bz(H, *args)
    writes = []
    if isinstance(u, fz.LT):
        for k, v in u.d.items():
            if k not in before or before[k] is not v:
                writes.append([ex.ser_value(k), ex.ser_value(v)])
    BZ_LOG.append({'frame': frame,
                   'A': args[3] if len(args) > 3 else None,
                   'X': args[4] if len(args) > 4 else None,
                   'writes': writes})
    return r


fz.METHODS['bz'] = (bz_wrap, fz.METHODS['bz'][1])


def jload(p):
    with open(p) as fo:
        return json.load(fo)


def jwrite(p, obj):
    with open(p, 'w') as fo:
        json.dump(obj, fo, indent=1, default=str)


def child18_reprobe(rt, structs, walk_infos):
    """Route (c): re-probe child18's descriptor in the final live
    state; then after re-executing its parent (child12); walk+merge
    if a valid build appears.  Returns the attempts log."""
    attempts = []
    idx18 = None
    for idx, rec in enumerate(rt.children):
        live = rt.children_live[idx]
        if live['group'][0] == 'dz' and not live.get('factory_args'):
            idx18 = idx
    if idx18 is None:
        return [{'result': 'no unrecovered dz child found'}]
    rec18 = rt.children[idx18]
    acc = rec18['access']
    ppid = sw.pid_of_tag(acc.get('proto'))
    pidx = int(ppid.replace('child', '')) - 1
    plive = rt.children_live[pidx]
    ti = int(acc['table'].rsplit('operand', 1)[1])
    tab = plive['group'][1 + ti]
    key = acc['key']

    def attempt(tag):
        cap0 = len(DZ_CAPTURE)
        ch0 = len(rt.children)
        if fz.num_key(key) in tab.d:
            del tab.d[fz.num_key(key)]
            cleared = True
        else:
            cleared = False
        rt.pctx.append((ppid, None, None))
        try:
            outcome, _ = sw.guarded_tget(rt, tab, key, 3_000_000)
        finally:
            rt.pctx.pop()
        caps = [{'x': c['x'], 'u': c['u'], 'mode': c['mode'],
                 'entry': c['entry'], 'hdr': c['hdr'],
                 'frame': c['frame']}
                for c in DZ_CAPTURE[cap0:]]
        att = {'attempt': tag, 'cleared_cached_key': cleared,
               'outcome': outcome, 'children_before': ch0,
               'children_after': len(rt.children), 'captures': caps}
        attempts.append(att)
        # a NEW child harvested by this probe?
        for j in range(ch0, len(rt.children)):
            live = rt.children_live[j]
            if live.get('factory_args'):
                pid = f'child{j + 1}'
                dis, info = wc.walk_child(rt, live)
                structs[pid] = sw.dis_to_struct(
                    dis, live['factory_args'][0], live, rt)
                walk_infos[pid] = info
                att['recovered_as'] = pid
                att['walk'] = info
        return att

    a1 = attempt('reprobe-final-state')
    if 'recovered_as' not in a1:
        # re-execute the parent (child12) once, then re-probe: its
        # execution decrypts more of its own streams in place.
        try:
            mid = sw.resolve_middle(rt, plive, rt.children[pidx])
            if mid is not None:
                if isinstance(mid, li.AstClosure):
                    mid.tag = ppid
                    mid.traceinfo = rt.traceinfo
                inner_vals = rt.call_value(mid, [None, fz.LT(), None],
                                           None)
                inner = inner_vals[0] if inner_vals else None
                rt.call_value(inner, [], None)
                attempts.append({'attempt': 're-execute-parent',
                                 'result': 'returned'})
            else:
                attempts.append({'attempt': 're-execute-parent',
                                 'result': 'unresolved-factory'})
        except Exception as e:
            attempts.append({'attempt': 're-execute-parent',
                             'result': f'{type(e).__name__}: '
                                       f'{str(e)[:120]}'})
        attempt('reprobe-after-parent-exec')
    return attempts


def main():
    # identity spoofing (--spoof-id): the driver may provide a
    # static seed (identity_seed.json); unseeded fields are served
    # as sentinels and calibrated by the executor's cmpeq hook.
    spoof = os.environ.get('BVM_SPOOF_ID', 'auto')
    if spoof != 'off':
        seed = {}
        sp = os.environ.get('BVM_IDENTITY_SEED')
        if sp and os.path.isfile(sp):
            try:
                seed = jload(sp).get('seed', {})
            except Exception:
                seed = {}
        ex.mocks.configure_identity(True, seed)
    else:
        ex.mocks.configure_identity(False)
    state = sw.main()
    rt = ex.RT
    structs = jload(os.path.join(HERE, 'proto_structs.json'))
    sw_state = jload(os.path.join(HERE, 'sweep_state.json'))
    walk_infos = sw_state.get('walk_infos', {})

    # ---- 1. bz structs ------------------------------------------------
    bz_frames = {}
    for e in BZ_LOG:
        bz_frames.setdefault(e['frame'], []).append(e)
    for idx, live in enumerate(rt.children_live):
        if live['group'][0] != 'bz':
            continue
        pid = f'child{idx + 1}'
        st = wb.build_bz_struct(rt, live,
                                bz_frames.get(live.get('frame'), []),
                                rt.children[idx])
        structs[pid] = st
        walk_infos[pid] = {
            'source': 'walk_bz (Phase E): constant artifact, no '
                      'instruction stream',
            'kind': 'bz-constant', 'slot': st['slot'], 'visited': 0}
        print(f'[sweepE] bz struct {pid}: slot {st["slot"]}, '
              f'span {st["closure_span"]}', flush=True)
    jwrite(os.path.join(HERE, 'proto_structs.json'), structs)

    # ---- 2. child18 route (c) -----------------------------------------
    attempts = child18_reprobe(rt, structs, walk_infos)
    recovered = [a.get('recovered_as') for a in attempts
                 if a.get('recovered_as')]
    if recovered:
        jwrite(os.path.join(HERE, 'proto_structs.json'), structs)
        # refresh children artifacts to include the new child
        crec = jload(os.path.join(HERE, 'children_recovered.json'))
        have = {c['pid'] for c in crec}
        for rec in rt.children:
            if rec['pid'] not in have:
                crec.append(rec)
        jwrite(os.path.join(HERE, 'children_recovered.json'), crec)
        access_results = {}
        for rec in rt.children:
            acc = rec.get('access') or {}
            parent = sw.pid_of_tag(acc.get('proto'))
            ttag = acc.get('table') or ''
            ti = None
            if ':operand' in ttag:
                ti = int(ttag.rsplit(':operand', 1)[1])
            if ti is None or acc.get('key') is None:
                continue
            access_results.setdefault(parent, []).append(
                {'table': ti, 'key': acc['key'],
                 'children': [rec['pid']]})
        jwrite(os.path.join(HERE, 'childrenD.json'),
               {'root': {}, 'children': rt.children,
                'access_results': access_results})
        print(f'[sweepE] child18 recovered as {recovered}', flush=True)
    else:
        walk_infos['child18'] = {
            'error': 'descriptor decodes incoherently in every '
                     'explored state: state-178 build appends the '
                     'group, then the dz factory branch reads slot '
                     '753511 (not a function slot) -> Untranscribed; '
                     'captured would-be factory args are garbage '
                     '(mode=40, u=269470934). Re-probes in the final '
                     'sweep state and after re-executing the parent '
                     '(child12) reproduced the same decode. See '
                     'sweepE_state.json child18_attempts.'}
        print('[sweepE] child18 NOT recovered; attempts logged',
              flush=True)

    sw_state['walk_infos'] = walk_infos
    jwrite(os.path.join(HERE, 'sweep_state.json'), sw_state)

    # ---- 3. Phase E evidence file --------------------------------------
    ev = {
        'dz_capture': [{'frame': c['frame'], 'x': c['x'], 'u': c['u'],
                        'mode': c['mode'], 'entry': c['entry'],
                        'hdr': c['hdr']} for c in DZ_CAPTURE],
        'bz_log': BZ_LOG,
        'child18_attempts': attempts,
        'env': {'EXEC_ACT_BUDGET': os.environ.get('EXEC_ACT_BUDGET')},
        'identity': idmod.log_to_state(ex.mocks.IDENTITYLOG)
                    if spoof != 'off' else None,
    }
    jwrite(os.path.join(HERE, 'sweepE_state.json'), ev)
    print('[sweepE] done. children:', len(rt.children),
          'structs:', sorted(structs.keys()), flush=True)


if __name__ == '__main__':
    import faulthandler
    import threading
    faulthandler.enable()
    sys.setrecursionlimit(200000)

    def _run():
        try:
            main()
        except Exception:
            import traceback
            traceback.print_exc()
            os._exit(1)

    try:
        threading.stack_size(1024 * 1024 * 1024)
    except (ValueError, RuntimeError):
        threading.stack_size(256 * 1024 * 1024)
    th = threading.Thread(target=_run)
    th.start()
    th.join()
