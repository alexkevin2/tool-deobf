#!/usr/bin/env python3
"""sweep.py — Phase D full sweep driver.

Pipeline (one process, checkpointed artifacts at each stage):
  1. organic in-context execution of the root payload (executor.py);
  2. PROOF GATE: walk harvested child #1 with disasm2 (live constants)
     and write PHASE-D1-REPORT.md;
  3. in-context probe of the 47 census descriptors not yet built;
  4. execute every harvested child's inner once (mock args), BFS over
     grandchildren; probe child operand tables over their stream range;
  5. walk root + every child with live constants -> proto_structs.json
     (lift2 format) + childrenD.json (closure wiring for the lifter);
  6. accounting: 47 census outcomes, 434 referenced constants, 9
     dynamic-seed DECRYPTSTR strings -> sweep_state.json.
"""
import json
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
STAGE2 = os.path.join(CASE, 'stage2')
sys.path.insert(0, HERE)

import executor as ex
import walk_child as wc
import luau_interp as li
import mocks

fz = ex.fz
MODE_LETTER = {114: 'A', 49: 'B', 210: 'C', 113: 'D'}


def jload(path):
    with open(path) as fo:
        return json.load(fo)


def pid_of_tag(tag):
    if tag is None or tag == 'proto0' or tag == 'root':
        return 'root'
    if isinstance(tag, str) and tag.startswith('proto'):
        return f'child{tag[5:]}'
    return tag


def group_of_pid(rt, pid):
    if pid in ('root', 'proto0'):
        return fz.PROTO_TABLES[0] if fz.PROTO_TABLES else None
    idx = None
    if isinstance(pid, str) and pid.startswith('child'):
        idx = int(pid[5:]) - 1
    elif isinstance(pid, str) and pid.startswith('proto'):
        idx = int(pid[5:]) - 1
    if idx is not None and 0 <= idx < len(rt.children_live):
        return rt.children_live[idx]['group']
    return None


def resolve_middle(rt, live_rec, rec):
    """The child's middle closure, via (a) the materialized value the
    parent table cached at the access site, or (b) a fresh factory
    invocation with the captured args."""
    acc = rec.get('access') or {}
    ttag = acc.get('table') or ''
    key = acc.get('key')
    if ':operand' in ttag and key is not None:
        parent_pid, ti = ttag.rsplit(':operand', 1)
        group = group_of_pid(rt, parent_pid)
        if group is not None and group[0] == 'dz':
            tab = group[1 + int(ti)]
            v = tab.d.get(fz.num_key(key))
            if isinstance(v, li.AstClosure):
                return v
    fa = live_rec.get('factory_args') or []
    if fa:
        return rt.invoke_factory(list(fa[0]))
    return None


def guarded_tget(rt, table, key, limit):
    rt.probe = {'count': 0, 'limit': limit}
    before_children = len(rt.children)
    before_frames = len(rt.fz_frames)
    try:
        v = rt.tget(table, key)
        outcome = 'value:' + ex._typename(v)
        if len(rt.children) > before_children:
            outcome = 'child-built'
        return outcome, v
    except ex.ProbeTimeout:
        return 'guard-timeout', None
    except Exception as e:
        return f'error:{type(e).__name__}:{str(e)[:60]}', None
    finally:
        rt.probe = None
        # a frame that errored mid-build records its error itself


def main():
    t0 = time.time()
    rt = ex.build_runtime()
    print(f'[sweep] setup {time.time() - t0:.1f}s', flush=True)

    # ---------- 0. field-write watcher (DECRYPTSTR recovery) ----------
    # A DECRYPTSTR execution rewrites fields[q] := bxor(hdr, 404445383)
    # and XORs the chunk string region in place.  Watch for that exact
    # signature to recover (site, field) pairs; the chunk region is
    # already plaintext afterwards.
    field_writes = []
    _orig_tset = rt.tset

    def tset_watch(t, k, v):
        if t is rt.fields and isinstance(k, int) and \
                isinstance(v, (int, float)):
            old = t.d.get(k)
            if isinstance(old, (int, float)) and \
                    v == fz.bit32_bxor(old, 404445383):
                field_writes.append(
                    {'field': k, 'old': old, 'new': v,
                     'pctx': rt.cur_pctx()})
        return _orig_tset(t, k, v)
    rt.tset = tset_watch

    # Pristine pre-execution state (for DECRYPTSTR key verification).
    pristine_fields = {k: v for k, v in rt.fields.d.items()
                       if isinstance(k, int)}
    pristine_chunk = bytes(rt.chunk.data)

    # ---------- 1. organic execution ----------
    status = ex.run_root(rt)
    print(f'[sweep] organic run: {status.get("status")} '
          f'steps={rt.steps_total} trace={len(rt.trace)} '
          f'children={len(rt.children)} t={time.time() - t0:.0f}s',
          flush=True)
    organic_tags = {t[0] for t in rt.trace}
    ex.write_state(rt, status)

    root_tables = list(fz.PROTO_TABLES[0][1:])
    census_path = os.path.join(STAGE2, 'probe178_all.json')
    if not os.path.exists(census_path):
        # tool layout: probe178_fast.py writes census178.json
        # (identical record shape)
        census_path = os.path.join(STAGE2, 'census178.json')
    census = jload(census_path)

    # ---------- 2. PROOF GATE: walk child #1 ----------
    gate = {'ok': False}
    if rt.children_live:
        try:
            dis, info = wc.walk_child(rt, rt.children_live[0])
            gate = {'ok': True, 'info': info,
                    'sample_records': [
                        dis.struct[k] for k in list(dis.struct)[:3]]}
            print(f'[sweep] GATE child1 walk: {info}', flush=True)
        except Exception as e:
            gate = {'ok': False, 'error': f'{type(e).__name__}: {e}',
                    'tb': traceback.format_exc()[-1500:]}
            print(f'[sweep] GATE FAILED: {e}', flush=True)
    write_gate_report(rt, status, gate, census)
    print('[sweep] PHASE-D1-REPORT.md written', flush=True)

    # ---------- 3. census probe (in-context) ----------
    census_outcomes = {}
    rt.pctx.append(('proto0', None, None))
    for ent in census:
        t, k = ent['table'], ent['key']
        tab = root_tables[t]
        if fz.num_key(k) in tab.d:
            census_outcomes[(t, k)] = 'already-built-organic'
            continue
        outcome, _v = guarded_tget(rt, tab, k, 3_000_000)
        census_outcomes[(t, k)] = outcome
    rt.pctx.pop()
    n_built = sum(1 for v in census_outcomes.values()
                  if v in ('child-built', 'already-built-organic'))
    print(f'[sweep] census probe: {n_built}/47 built; children now '
          f'{len(rt.children)} t={time.time() - t0:.0f}s', flush=True)
    ex.write_state(rt, status)

    # ---------- 4. execute children + probe their tables ----------
    exec_results = {}
    queue = list(range(len(rt.children_live)))
    qi = 0
    exec_budget_hits = []
    while qi < len(queue) and qi < 400:
        idx = queue[qi]
        qi += 1
        live = rt.children_live[idx]
        pid = f'child{idx + 1}'
        tag = f'proto{idx + 1}'
        print(f'[sweep] phase4 {pid} exec start t={time.time() - t0:.0f}s',
              flush=True)
        trace_before = len(rt.trace)
        acc_before = len(rt.accesses)
        children_before = len(rt.children)
        try:
            mid = resolve_middle(rt, live, rt.children[idx])
            if mid is None:
                exec_results[pid] = {
                    'status': 'unresolved-factory',
                    'organic': tag in organic_tags,
                    'trace_new': 0, 'children_spawned': 0}
                ex.write_state(rt, status)
                continue
            if isinstance(mid, li.AstClosure):
                mid.tag = tag
                mid.traceinfo = rt.traceinfo
            inner_vals = rt.call_value(mid, [None, fz.LT(), None], None)
            inner = inner_vals[0] if inner_vals else None
            out = rt.call_value(inner, [], None)
            exec_results[pid] = {
                'status': 'returned',
                'organic': tag in organic_tags,
                'trace_new': len(rt.trace) - trace_before,
                'children_spawned': len(rt.children) - children_before}
        except li.BudgetExceeded:
            exec_results[pid] = {
                'status': 'budget',
                'organic': tag in organic_tags,
                'trace_new': len(rt.trace) - trace_before,
                'children_spawned': len(rt.children) - children_before}
            exec_budget_hits.append(pid)
        except Exception as e:
            exec_results[pid] = {
                'status': f'{type(e).__name__}',
                'detail': str(e)[:160],
                'organic': tag in organic_tags,
                'trace_new': len(rt.trace) - trace_before,
                'children_spawned': len(rt.children) - children_before}
        # enqueue grandchildren
        for j in range(children_before, len(rt.children)):
            if j not in queue:
                queue.append(j)
        print(f'[sweep] phase4 {pid} exec end '
              f'({exec_results[pid]["status"]}) '
              f't={time.time() - t0:.0f}s', flush=True)
        # Small children only: full-range probe of the operand tables
        # (finds grandchildren the walk cannot reach).  Large children
        # are walk-only: eager probing materializes huge garbage
        # descriptor tables that stay cached (memory blow-up).
        if live['group'][0] == 'dz':
            total_slots = 0
            for tab in live['group'][1:]:
                sub = tab.d.get(fz.num_key(-2))
                if isinstance(sub, fz.LT):
                    total_slots += max(
                        (kk for kk in sub.d if isinstance(kk, int)),
                        default=0) + 1
            if total_slots <= 1500:
                rt.pctx.append((tag, None, None))
                for ti2, tab in enumerate(live['group'][1:]):
                    sub = tab.d.get(fz.num_key(-2))
                    if not isinstance(sub, fz.LT):
                        continue
                    maxk = max((kk for kk in sub.d
                                if isinstance(kk, int)), default=0)
                    for k in range(0, maxk + 1):
                        if fz.num_key(k) in tab.d:
                            continue
                        guarded_tget(rt, tab, k, 400_000)
                rt.pctx.pop()
                for j in range(children_before, len(rt.children)):
                    if j not in queue:
                        queue.append(j)
            else:
                exec_results[pid]['probe'] = \
                    f'skipped-large ({total_slots} slots)'
        ex.write_state(rt, status)
        if qi % 10 == 0:
            print(f'[sweep] child exec {qi}/{len(queue)} children='
                  f'{len(rt.children)} t={time.time() - t0:.0f}s',
                  flush=True)
    print(f'[sweep] child execution done: {len(exec_results)} executed, '
          f'children total {len(rt.children)}', flush=True)
    ex.write_state(rt, status)

    # ---------- 4b. retry the 434 referenced constants in context ----
    mining = jload(os.path.join(STAGE2, 'children.json'))[
        'eager_error_mining']['referenced_by_executed_code']
    ref_total = 0
    ref_resolved = 0
    ref_detail = {}
    rt.pctx.append(('proto0', None, None))
    for tname, tinfo in mining.items():
        ti = int(tname.replace('table', ''))
        keys = tinfo['keys']
        ref_total += len(keys)
        ok = 0
        for k in keys:
            if fz.num_key(k) in root_tables[ti].d:
                ok += 1
                continue
            outcome, _ = guarded_tget(rt, root_tables[ti], k, 800_000)
            if outcome.startswith('value') or outcome == 'child-built':
                ok += 1
        ref_resolved += ok
        ref_detail[tname] = {'total': len(keys), 'resolved': ok}
    rt.pctx.pop()
    print(f'[sweep] referenced constants: {ref_resolved}/{ref_total}; '
          f'children now {len(rt.children)}', flush=True)
    ex.write_state(rt, status)

    # ---------- 5. walks (root + children) ----------
    structs = {}
    walk_infos = {}
    # Root structs: the C1/C2 static walk is the validated ground truth
    # for the root (its stream state starts pre-decryption, which the
    # disasm2 walk requires; the live post-execution streams would be
    # double-decrypted by the walk's own decryptor simulation).
    structs['root'] = jload(os.path.join(STAGE2, 'proto_structs.json'))[
        'root']
    walk_infos['root'] = {'source': 'stage2 proto_structs (C1/C2 walk)',
                          'visited': len(structs['root']['instructions'])}
    for idx, live in enumerate(rt.children_live):
        pid = f'child{idx + 1}'
        if live['group'][0] != 'dz':
            walk_infos[pid] = {'error': 'bz proto: single-table group; '
                               'disasm2 dz-walk not applicable'}
            print(f'[sweep] walk {pid} skipped (bz)', flush=True)
            continue
        if not live.get('factory_args'):
            walk_infos[pid] = {'error': 'no factory args captured; '
                               'entry/mode unknown'}
            print(f'[sweep] walk {pid} skipped (no factory args)',
                  flush=True)
            continue
        try:
            dis, info = wc.walk_child(rt, live)
            structs[pid] = dis_to_struct(
                dis, live['factory_args'][0], live, rt)
            walk_infos[pid] = info
        except Exception as e:
            walk_infos[pid] = {'error': f'{type(e).__name__}: {e}'[:200]}
            print(f'[sweep] walk {pid} FAILED: {e}', flush=True)
    with open(os.path.join(HERE, 'proto_structs.json'), 'w') as fo:
        json.dump(structs, fo, indent=1, default=str)

    # childrenD.json: closure wiring for the lifter
    access_results = {}
    for rec in rt.children:
        acc = rec.get('access') or {}
        parent = pid_of_tag(acc.get('proto'))
        ttag = acc.get('table') or ''
        ti = None
        if ':operand' in ttag:
            ti = int(ttag.rsplit(':operand', 1)[1])
        if ti is None or acc.get('key') is None:
            continue
        access_results.setdefault(parent, []).append(
            {'table': ti, 'key': acc['key'], 'children': [rec['pid']]})
    with open(os.path.join(HERE, 'childrenD.json'), 'w') as fo:
        json.dump({'root': {}, 'children': rt.children,
                   'access_results': access_results}, fo, indent=1,
                  default=str)

    # ---------- 6. accounting ----------
    # (434 referenced constants were retried in phase 4b, above.)

    # 9 dynamic-seed DECRYPTSTR strings: the executor's own DECRYPTSTR
    # executions (concrete V/L) rewrote the field headers and decrypted
    # the chunk regions in place; recover plaintexts from the
    # field-write watcher + post-execution chunk (disasm2
    # decrypt_string's length-prefix format).
    old_structs = jload(os.path.join(STAGE2, 'proto_structs.json'))
    old_ds = old_structs['root']['decrypted_strings']
    dyn_sites = []
    for ins in old_structs['root']['instructions']:
        if ins['name'].startswith('DECRYPTSTR'):
            site = f"{ins['mode']}:{ins['pc']}"
            if site not in old_ds:
                dyn_sites.append(site)

    def read_plaintext(data, uY):
        pos = uY + 1
        if pos < 0 or pos >= len(data):
            return None
        b0 = data[pos]
        if b0 < 128:
            length, xy = b0, pos + 1
        else:
            b1 = data[pos + 1]
            if b1 < 128:
                length, xy = (b0 - 128) * 128 + b1, pos + 2
            else:
                b2 = data[pos + 2]
                if b2 < 128:
                    length = (b0 - 128) + (b1 - 128) * 128 + b2 * 16384
                    xy = pos + 3
                else:
                    b3 = data[pos + 3]
                    length = ((b0 - 128) * 128 + (b1 - 128) * 2097152 +
                              (b2 - 128) * 16384 + b3 % 128 +
                              (b3 - b3 % 128) * 2097152)
                    xy = pos + 4
        return bytes(data[xy:xy + length])

    chunk_now = bytes(rt.chunk.data)
    mode_int = {'A': 114, 'B': 49, 'C': 210, 'D': 113}

    def parse_len(data, uY):
        pos = uY + 1
        if pos < 0 or pos >= len(data):
            return None
        b0 = data[pos]
        if b0 < 128:
            return b0, pos + 1
        b1 = data[pos + 1]
        if b1 < 128:
            return (b0 - 128) * 128 + b1, pos + 2
        b2 = data[pos + 2]
        if b2 < 128:
            return (b0 - 128) + (b1 - 128) * 128 + b2 * 16384, pos + 3
        b3 = data[pos + 3]
        return ((b0 - 128) * 128 + (b1 - 128) * 2097152 +
                (b2 - 128) * 16384 + b3 % 128 +
                (b3 - b3 % 128) * 2097152), pos + 4

    def brute_key(field):
        """Try all 256 byte keys for the DECRYPTSTR string at `field`
        against the PRISTINE chunk; return [(key, plaintext)] with
        >=95% printable bytes."""
        hdr = pristine_fields.get(field)
        if not isinstance(hdr, (int, float)):
            return []
        uY = fz.bit32_bxor(int(hdr), 404445383)
        lp = parse_len(pristine_chunk, uY)
        if lp is None:
            return []
        length, xy = lp
        if length <= 0 or length > 8192 or xy + length > len(
                pristine_chunk):
            return []
        region = pristine_chunk[xy:xy + length]
        out_candidates = []
        yY = length - (length % 4)
        for key in range(256):
            kw = (key * 16843009) & 0xFFFFFFFF
            out = bytearray(region)
            for off in range(0, yY, 4):
                cur = int.from_bytes(out[off:off + 4], 'little')
                out[off:off + 4] = (cur ^ kw).to_bytes(4, 'little')
            for off in range(yY, length):
                out[off] ^= key
            good = sum(1 for b in out
                       if 32 <= b < 127 or b in (9, 10, 13))
            if good / length >= 0.95:
                out_candidates.append((key, bytes(out)))
        return out_candidates

    strings_outcome = {}
    for site in dyn_sites:
        mode, pc = site.split(':')
        fields_at_site = []
        for w in field_writes:
            proto, wm, wpc = w['pctx']
            if proto in ('proto0', 'root') and wm == mode_int[mode] \
                    and str(wpc) == pc and \
                    w['field'] not in fields_at_site:
                fields_at_site.append(w['field'])
        trace_hit = any(t[0] in ('proto0', 'root') and
                        t[1] == mode_int[mode] and str(t[2]) == pc
                        for t in rt.trace)
        found = []
        for fidx in fields_at_site:
            for key, pt in brute_key(fidx):
                found.append((fidx, key, pt))
        # Executor in-place result: the region was XOR-decrypted by
        # the interpreter's own DECRYPTSTR execution under concrete
        # V/L.  NOTE: C2's 19 static "plaintexts" are mostly
        # non-printable binary blobs — DECRYPTSTR protects binary
        # data, not just text.  Report bytes + printability honestly.
        inplace = None
        inplace_ratio = None
        if fields_at_site:
            hdr_now = rt.fields.d.get(fields_at_site[0])
            if isinstance(hdr_now, (int, float)):
                pt = read_plaintext(chunk_now, int(hdr_now))
                if pt is not None:
                    inplace = pt
                    good = sum(1 for b in pt
                               if 32 <= b < 127 or b in (9, 10, 13))
                    inplace_ratio = (good / len(pt)) if pt else 1.0
        entry = {
            'executor_executed': bool(fields_at_site) or trace_hit,
            'field': fields_at_site,
            'brute_printable_keys': [
                (f, k, pt.decode('utf-8', 'backslashreplace'))
                for f, k, pt in found],
            'blob_decrypted': inplace is not None,
            'blob_len': len(inplace) if inplace is not None else None,
            'blob_printable_ratio': inplace_ratio,
            'blob_hex_head': inplace[:64].hex()
            if inplace is not None else None,
            'blob_text': inplace.decode('utf-8', 'backslashreplace')
            if inplace is not None and inplace_ratio is not None
            and inplace_ratio >= 0.95 and len(inplace) <= 4096
            else None}
        entry['recovered_text'] = entry['blob_text'] is not None
        strings_outcome[site] = entry
    n_str = sum(1 for v in strings_outcome.values()
                if v['blob_decrypted'])
    n_txt = sum(1 for v in strings_outcome.values()
                if v['recovered_text'])
    print(f'[sweep] dynamic strings: {n_str}/{len(dyn_sites)} blobs '
          f'decrypted in context, {n_txt} readable text', flush=True)

    # child-proto DECRYPTSTR writes (bonus): same verification
    child_string_writes = []
    for w in field_writes:
        proto, wm, wpc = w['pctx']
        if proto in ('proto0', 'root'):
            continue
        cands = brute_key(w['field'])
        child_string_writes.append({
            'proto': proto, 'mode': wm, 'pc': wpc,
            'field': w['field'],
            'candidates': [(k, pt.decode('utf-8', 'backslashreplace'))
                           for k, pt in cands]})

    state = {
        'organic_status': status,
        'gate': gate,
        'census_outcomes': {f'{t}:{k}': v for (t, k), v in
                            census_outcomes.items()},
        'census_built': n_built,
        'exec_results': exec_results,
        'walk_infos': walk_infos,
        'referenced_constants': {'total': ref_total,
                                 'resolved': ref_resolved,
                                 'detail': ref_detail},
        'dynamic_strings': strings_outcome,
        'child_string_writes': child_string_writes,
        'field_writes': field_writes,
        'children_total': len(rt.children),
        'steps_total': rt.steps_total,
        'trace_count': len(rt.trace),
        'decisions_count': len(rt.decisions),
        'wall_seconds': round(time.time() - t0, 1),
    }
    with open(os.path.join(HERE, 'sweep_state.json'), 'w') as fo:
        json.dump(state, fo, indent=1, default=str)
    ex.write_state(rt, status)
    print(f'[sweep] DONE in {time.time() - t0:.0f}s: children='
          f'{len(rt.children)} census={n_built}/47 consts='
          f'{ref_resolved}/{ref_total} strings={n_str}/'
          f'{len(dyn_sites)}', flush=True)
    return state


def dis_to_struct(dis, fargs, live, rt):
    factory = {'u': fargs[3], 'A': fargs[4], 'R2': fargs[14],
               'P1': fz.tget_raw(fargs[1], 1),
               'P2': fz.tget_raw(fargs[1], 2)}
    visited = list(dis.visited.keys())
    return {
        'factory': factory,
        'parent': None,
        'site': None,
        'entry': [MODE_LETTER.get(factory['A'], 'A'), factory['R2']],
        'regfile_size': factory['u'],
        'n_slots': dis.n_slots,
        'instructions': [dis.struct[(m, p)] for (m, p) in visited],
        'mode_switches': dis.mode_switches,
        'decrypted_strings': {f'{m}:{p}': v for (m, p), v in
                              dis.decrypted_strings.items()},
        'notes': dis.notes,
    }


def write_gate_report(rt, status, gate, census):
    acc178 = [a for a in rt.accesses if a['entered_178']]
    lines = []
    lines.append('# Phase D1 — proof gate report (StealAnEggs)')
    lines.append('')
    lines.append('Executor: stageD/executor.py (AST interpreter over '
                 'live fz_sim objects; slot-15209 factory/middle/inner '
                 'executed from stage2/factory_ast.json). Python-side '
                 'simulation only — the target was never run in a Luau '
                 'runtime.')
    lines.append('')
    lines.append('## Organic in-context execution of the root payload')
    lines.append('')
    lines.append(f'- root run status: `{status.get("status")}` '
                 f'({status.get("detail", "")})')
    lines.append(f'- interpreter steps: {rt.steps_total}; distinct '
                 f'(proto, mode, pc) executed: {len(rt.trace)}')
    lines.append(f'- materializer accesses (operand-table __index '
                 f'fires): {len(rt.accesses)}; state-178 entries: '
                 f'{rt.entered_178}')
    lines.append(f'- children harvested organically: '
                 f'{len(rt.children)}')
    lines.append(f'- mock-dependent decisions taken: '
                 f'{len(rt.decisions)} (defaults: objects truthy, '
                 'distinct mocks unequal, ordered comparisons false, '
                 '#mock = 0)')
    lines.append('')
    lines.append('## First child — end to end')
    lines.append('')
    if rt.children:
        c0 = rt.children[0]
        f0 = c0['factory'][0] if c0['factory'] else {}
        acc = c0.get('access') or {}
        lines.append(f'- descriptor: parent access table '
                     f'`{acc.get("table")}`, key `{acc.get("key")}`, '
                     f'stream (descriptor code) value at access: '
                     f'`{acc.get("stream")}`; Fz entry field M = '
                     f'{c0["descriptor_M"]}')
        lines.append(f'- reached from proto `{acc.get("proto")}` at '
                     f'mode {acc.get("mode")} pc {acc.get("pc")} '
                     '(executor access log, stageD/executor_state.json)')
        lines.append(f'- factory call captured: u (register file) = '
                     f'{f0.get("u")}, entry mode = {f0.get("mode")} '
                     f'(A), entry pc = {f0.get("entry")}, header '
                     f'(L, V) = {f0.get("hdr")}')
        lines.append(f'- in-context Fz build completed: PROTO_TABLES '
                     f'grew by a new dz operand group (4 tables + '
                     f'streams snapshot in children_recovered.json, '
                     f'child #1).')
    if gate.get('ok'):
        info = gate['info']
        lines.append(f'- disasm2 walk of child #1 (live constants): '
                     f'entry mode {info["mode"]} pc {info["entry"]}; '
                     f'{info["visited"]} instructions visited, '
                     f'{info["consts_resolved"]} constants resolved '
                     f'({info["const_errors"]} errors), '
                     f'{info["unresolved_jmpr"]} unresolved JMPR, '
                     f'{info["decrypted_strings"]} decrypted strings.')
        lines.append('')
        lines.append('Sample structured records from the walk:')
        lines.append('')
        lines.append('```json')
        lines.append(json.dumps(gate['sample_records'], indent=1,
                                default=str)[:1800])
        lines.append('```')
    else:
        lines.append(f'- GATE WALK FAILED: {gate.get("error")}')
    lines.append('')
    lines.append('## Why in-context terminates where out-of-context '
                 'diverged')
    lines.append('')
    lines.append('C2 (stage2/STAGE2C2-REPORT.md §1.5) probed the 47 '
                 'descriptors in the post-build state: the recursive '
                 'Fz build fell into the `_z`/`v` walker cycle '
                 '(P[3] += P[2] never crossing P[5]; buffer oplog '
                 'frozen; PROTO_TABLES never grew) for every key. The '
                 'missing ingredient was the interpreter\'s own '
                 'in-place decryption: the descriptor codes the '
                 'materializer reads come from the operand tables\' '
                 '[-2] streams, and those streams are ENCRYPTED until '
                 'the payload interpreter executes its DECRYPTBLOCK / '
                 'DECRYPTINSN ops over them (root trace: the mode-B '
                 'segment mass-decrypts slots 41..10269, covering all '
                 '47 census keys 390..9812). DECRYPTSTR ops additionally '
                 'rewrite structure[6] field headers in place. The '
                 'executor runs the interpreter on the same live LT/Buf '
                 'objects the materializer closure captures, so when '
                 'payload code (or the sweep\'s in-context probe) reads '
                 'a descriptor key, the closure sees the DECRYPTED '
                 'descriptor code and the correct field graph; the '
                 'recursive Fz(PY, M, 20) build then walks a finite, '
                 'well-formed descriptor subtree and completes — as '
                 'witnessed by the harvested dz groups above. The '
                 'captures that matter are exactly cap[\'A\'] (the '
                 'shared structure) and cap[\'p\'] (its fields table) '
                 'plus the chunk buffer in structure[5]; all three are '
                 'mutated by execution before the accesses fire.')
    lines.append('')
    with open(os.path.join(HERE, 'PHASE-D1-REPORT.md'), 'w') as fo:
        fo.write('\n'.join(lines) + '\n')


if __name__ == '__main__':
    import faulthandler
    import threading
    faulthandler.enable()
    sys.setrecursionlimit(200000)

    def _run():
        try:
            main()
        except Exception:
            traceback.print_exc()

    try:
        threading.stack_size(1024 * 1024 * 1024)
    except (ValueError, RuntimeError):
        threading.stack_size(256 * 1024 * 1024)
    th = threading.Thread(target=_run)
    th.start()
    th.join()
