#!/usr/bin/env python3
"""lift2.py — StealAnEggs stage-2 phase C2 lifter.

Input : proto_structs.json + children.json (children2.py output),
        opcode_map.json (C1 opcode bodies/semantics).
Output: lifted.luau + lift_stats.json.

Model (per STAGE2C1-REPORT): each proto is a graph of mode segments
(loops A/B/C/D of the slot-15209 interpreter factory). A segment is a
nested local function with a `while true` pc-loop; each visited
instruction becomes an if/elseif case on pc. SWITCHMODE is a tail
call `return seg_<mode>(entry)`. Control flow is driven by the C1/C2
walk's successor edges (ground truth for the proto's stream state);
handler bodies from opcode_map.json are translated verbatim with
stream/table reads replaced by the record's concrete values:
  y/i/S/f[P]  -> the record's stream values
  E/z/X/B[P]  -> the record's materialized constants (dz tables
                 0/1/2/3 = inner E/z/X/B)
  [P+k] reads -> group-slot records (group ops) or sibling slot
                 records in the same proto/mode
  n[...]      -> the register file (kept as `n`, the interpreter's
                 own name); V/L/K/G/h/b/e/O and the middle-scope
                 aliases (p,Z,T,N,s,d,m,q,Y,Q,j,c,D,k,o,I,M) are
                 proto-level locals shared by the segments.
P-assignments in bodies are stripped: pc is driven by the walk CFG.
Branch conditions are derived from the body's own P=if/if-then-else
form and validated against the walk's successor set.

Decryptor ops are folded: DECRYPTSTR/DECRYPTBLOCK emit annotations
only (their effect is the post-decryption stream state the walk
already used); DECRYPTINSN renders its re-dispatched final op.
Strings whose seed was dynamic stay marked ENCRYPTED — never guessed.
UNKNOWN ops become UNIMPL(mode, pc, op) stubs with the verbatim
body/semantics in comments; the output compiles but does not run
through those nodes.
"""
import ast
import json
import os
import re
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
LOOP_IDX = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
MODE_LETTER = {114: 'A', 49: 'B', 210: 'C', 113: 'D'}
CATCHALL = {0: (80, 78), 1: (93, 91), 2: (140, 138), 3: (134, 132)}
TI_NAME = {0: 'E', 1: 'z', 2: 'X', 3: 'B'}

OM = json.load(open(os.path.join(HERE, '..', 'stage2',
                                 'opcode_map.json')))
OPMAP = {}
for li, lp in enumerate(OM['loops']):
    for e in lp['opcodes']:
        OPMAP[(li, e['opcode'])] = e

STRUCTS = json.load(open(os.path.join(HERE, 'proto_structs.json')))
CHILD = json.load(open(os.path.join(HERE, 'childrenD.json')))

# (proto, table, key) -> child proto id, from children2 access results
CLOSURE_MAP = {}
for pid, results in CHILD.get('access_results', {}).items():
    for r in results:
        for cid in r.get('children', []):
            CLOSURE_MAP[(pid, r['table'], r['key'])] = cid

STATS = Counter()
UNIMPL_OPS = Counter()
NOTES = []


def luau_str(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif ch == '\t':
            out.append('\\t')
        elif o < 32 or o == 127:
            out.append('\\%03d' % o)
        else:
            out.append(ch)
    return '"' + ''.join(out) + '"'


def render_const(enc, proto=None, ti=None, key=None):
    """enc (children.py enc() form) -> (luau_text, note_or_None)."""
    if enc is None:
        return 'nil', None
    if isinstance(enc, bool):
        return ('true' if enc else 'false'), None
    if isinstance(enc, (int, float)):
        if isinstance(enc, float) and enc == int(enc) and abs(enc) < 2 ** 53:
            return str(int(enc)), None
        return repr(enc), None
    if isinstance(enc, str):
        return luau_str(enc), None
    if isinstance(enc, dict):
        if 'int' in enc:
            return str(enc['int']), None
        if 'float' in enc:
            v = enc['float']
            return (str(int(v)) if v == int(v) and abs(v) < 2 ** 53
                    else repr(v)), None
        if 'bool' in enc:
            return ('true' if enc['bool'] else 'false'), None
        if 'tuple' in enc:
            parts = [render_const(x, proto, ti, key)[0] for x in enc['tuple']]
            return '{' + ', '.join(parts) + '}', 'multi-value constant, ' \
                'rendered as a table'
        if 'table' in enc:
            return '{}', f"table constant #{enc['table']}"
        if 'buf' in enc:
            return f"__buffer_{enc['buf']}", f"buffer value #{enc['buf']}"
        if 'fn' in enc:
            cid = CLOSURE_MAP.get((proto, ti, key))
            if cid:
                return f'proto_{cid}', f'child proto {cid}'
            return (f"__closure_{enc['fn']}",
                    f"closure value #{enc['fn']} (not a recovered "
                    'child proto)')
        if 'other' in enc:
            txt = enc['other']
            if txt.startswith("b'") or txt.startswith('b"'):
                try:
                    b = ast.literal_eval(txt)
                    if isinstance(b, bytes):
                        return luau_str(b.decode('latin-1')), None
                except Exception:
                    pass
            return '__unrendered', f'unrenderable constant {txt[:60]}'
    return '__unrendered', f'unrenderable constant {str(enc)[:60]}'


def num(v):
    if v is None:
        return 'nil'
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, float) and v == int(v) and abs(v) < 2 ** 53:
        return str(int(v))
    return str(v)


class Ctx:
    """Per-proto translation context: sibling slot records for [P+k]."""

    def __init__(self, pid, pstruct):
        self.pid = pid
        self.by_mode_pc = {}
        for r in pstruct['instructions']:
            self.by_mode_pc[(r['mode'], r['pc'])] = r
        ds = pstruct.get('decrypted_strings') or {}
        self.decrypted = {}
        for k, v in ds.items():
            m = re.match(r'([A-D]):(\d+)', str(k))
            if m:
                self.decrypted[(m.group(1), int(m.group(2)))] = v
        fac = pstruct.get('factory') or {}
        self.u = fac.get('u')

    def slot(self, mode, pc):
        return self.by_mode_pc.get((mode, pc))


SEG_MODE_NO = {'A': 114, 'B': 49, 'C': 210, 'D': 113}


def _eval_cmp(a, op, b):
    a, b = int(a), int(b)
    return {'==': a == b, '~=': a != b, '>=': a >= b, '<=': a <= b,
            '>': a > b, '<': a < b}[op]


def eval_guards(text, mode, u):
    """Evaluate constant dual-mode guards (A = segment mode number,
    u = regfile size) and literal comparisons in if-expr conditions."""
    mno = SEG_MODE_NO[mode]
    def rep(m):
        return 'true' if _eval_cmp(mno, m.group(1), m.group(2)) else 'false'
    text = re.sub(r'\bA\s*(>=|<=|~=|==|>|<)\s*(\d+)', rep, text)
    if u is not None:
        def repu(m):
            return 'true' if _eval_cmp(u, m.group(1), m.group(2)) else 'false'
        text = re.sub(r'\bu\s*(>=|<=|~=|==|>|<)\s*(\d+)', repu, text)
    def repl(m):
        return 'true' if _eval_cmp(m.group(1), m.group(2), m.group(3)) \
            else 'false'
    text = re.sub(r'\b(\d+)\s*(>=|<=|~=|==|>|<)\s*(\d+)', repl, text)
    return text


def _scan_leaf(s, i):
    """Scan a non-if expression leaf: stop at a top-level ' else ',
    ';', ' end' or end of string. Returns (text, stop_index)."""
    depth = 0
    j = i
    while j < len(s):
        ch = s[j]
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        elif depth == 0:
            if s.startswith(' else ', j) or s.startswith(';', j) or \
                    s.startswith(' end', j) or ch == '\n':
                break
        j += 1
    return s[i:j], j


def collapse_const_ifs(text):
    """Collapse `if true/false then X else Y` expressions (X/Y may be
    nested if-expressions). Used after guard evaluation for the
    dual-mode dispatch bodies."""
    for _ in range(12):
        m = re.search(r'if (true|false) then ', text)
        if not m:
            return text
        start = m.start()
        # parse the full if-expr with a small recursive parser
        parsed = _parse_ifexpr_full(text, start)
        if parsed is None:
            return text
        cond, then_txt, else_txt, end = parsed
        pick = then_txt if cond == 'true' else else_txt
        text = text[:start] + pick + text[end:]
    return text


def _parse_ifexpr_full(s, i):
    """Parse if-expr at i; returns (cond, then_text, else_text, end)
    where then/else_text are the raw branch source slices."""
    assert s.startswith('if ', i)
    depth = 0
    j = i + 3
    cond = None
    while j < len(s):
        if s[j] in '([{':
            depth += 1
        elif s[j] in ')]}':
            depth -= 1
        elif depth == 0 and s.startswith(' then ', j):
            cond = s[i + 3:j]
            break
        j += 1
    if cond is None:
        return None
    j += 6
    t0 = j
    if s.startswith('if ', j):
        sub = _parse_ifexpr_full(s, j)
        if sub is None:
            return None
        j = sub[3]
        then_txt = s[t0:j]
    else:
        then_txt, j = _scan_leaf(s, j)
    if not s.startswith(' else ', j):
        return None
    j += 6
    e0 = j
    if s.startswith('if ', j):
        sub = _parse_ifexpr_full(s, j)
        if sub is None:
            return None
        j = sub[3]
        else_txt = s[e0:j]
    else:
        else_txt, j = _scan_leaf(s, j)
    return cond, then_txt, else_txt, j


STREAM_RE = re.compile(r'\b(y|i|S|f)\[P(?:([+-])(\d+))?\]')
TABLE_RE = re.compile(r'\b(E|z|X|B)\[P(?:([+-])(\d+))?\]')


def translate_body(body, rec, ctx):
    """Substitute stream/table reads in a handler body.
    Returns (text, notes)."""
    notes = []
    mode, pc = rec['mode'], rec['pc']

    # R = P snapshot pattern (loops B/C): handlers copy P into R, use
    # R-indexed stream/table reads, then restore P = R (net pc effect
    # zero). Treat [R] reads as current-slot reads and drop the
    # snapshot/restore statements.
    if re.search(r'\bR\s*=\s*P\b', body):
        rec['_r_snapshot'] = True
        body = re.sub(r'\b(y|i|S|f|E|z|X|B)\[R\]',
                      lambda m: f'{m.group(1)}[P]', body)
        body = re.sub(r'\blocal R\s*=\s*P\s*;', '', body)
        body = re.sub(r'(?<!local )\bR\s*=\s*P\s*;', '', body)

    def slot_rec(off):
        if off == 0:
            return rec
        if rec.get('group_slots') and 1 <= off <= len(rec['group_slots']):
            return rec['group_slots'][off - 1]
        return ctx.slot(mode, pc + off)

    def table_sub(m):
        ti = {'E': 0, 'z': 1, 'X': 2, 'B': 3}[m.group(1)]
        off = int(m.group(3)) if m.group(3) else 0
        if m.group(2) == '-':
            off = -off
        sr = slot_rec(off)
        if sr is None:
            notes.append(f'{m.group(1)}[P{off:+d}] slot not in walk records')
            return '__unmaterialized'
        if 'K' in sr and sr['K'] is not None:
            enc = sr['K'][ti] if sr['K'] else None
            if sr.get('K_err') and sr['K_err'][ti]:
                notes.append(f'{TI_NAME[ti]}[{pc + off}] materialization '
                             'errored in the sim; rendered as a '
                             'placeholder')
                return '__unmaterialized'
            txt, note = render_const(enc, ctx.pid, ti, pc + off)
            if note:
                notes.append(f'{TI_NAME[ti]}[{pc + off}]: {note}')
            return txt
        notes.append(f'{m.group(1)}[P{off:+d}] has no constant record')
        return '__unmaterialized'

    def stream_sub(m):
        letter = m.group(1)
        off = int(m.group(3)) if m.group(3) else 0
        if m.group(2) == '-':
            off = -off
        sr = slot_rec(off)
        if sr is None:
            notes.append(f'{letter}[P{off:+d}] slot not in walk records')
            return 'nil'
        return num(sr[letter])

    text = TABLE_RE.sub(table_sub, body)
    text = STREAM_RE.sub(stream_sub, text)
    # a literal in callee position is a syntax error in Luau; the sim
    # value there cannot be the runtime callee (context-dependent
    # materialization) — substitute a placeholder name.
    def callee_sub(m):
        notes.append(f'constant callee {m.group(1)[:30]} replaced by a '
                     'placeholder (the sim value cannot be the runtime '
                     'callee)')
        return '__unmaterialized('
    text = re.sub(r'("(?:[^"\\]|\\.)*"|\d[\d.]*|nil)\s*\(', callee_sub,
                  text)
    if mode == 'A':
        # loop A handlers name the operands a=i[P], b=S[P], c=f[P]
        if re.search(r'\bc\s*\(', text):
            notes.append('ambiguous bare c (operand vs buffer.readu32 '
                         'alias) in loop A body')
        avals = {'a': num(rec['i']), 'b': num(rec['S']),
                 'c': num(rec['f'])}

        def _sub_ops(seg):
            for nm, val in avals.items():
                seg = re.sub(rf'\b{nm}\b', val, seg)
            return seg

        # A handler may ASSIGN to a/b/c as scratch locals (e.g.
        # CALL_RES: `l,a,x = ...`).  Substituting a number there is a
        # syntax error; a/b/c are declared locals in the lifted
        # proto, so protect plain-name assignment targets and
        # substitute only in the RHS / other statements.
        parts = re.split(r'(;)', text)
        for pi, part in enumerate(parts):
            m = re.match(r'^(\s*(?:local\s+)?)([A-Za-z_][\w,\s]*?)'
                         r'(\s*=(?![=~<>]))', part)
            if m and any(t.strip() in avals
                         for t in m.group(2).split(',')):
                notes.append('operand name(s) assigned as scratch '
                             'local(s) in body; target kept as the '
                             'proto local')
                parts[pi] = (m.group(1) + m.group(2) + m.group(3) +
                             _sub_ops(part[m.end():]))
            else:
                parts[pi] = _sub_ops(part)
        text = ''.join(parts)
    # bare stream letters used as VALUES are the stream tables
    # themselves (e.g. B op 69 `n[y[R]] = S`): not available as values
    # in the lift — placeholder + note. String literals (rendered
    # constants) are masked out first.
    parts = re.split(r'(\"(?:[^\"\\]|\\.)*\")', text)
    for idx in range(0, len(parts), 2):
        seg = parts[idx]
        for letter in ('y', 'i', 'S', 'f'):
            def _bs(m, letter=letter):
                notes.append(f'bare {letter} is the {letter} stream '
                             'table itself; rendered as a placeholder')
                return f'__stream_{letter}'
            seg = re.sub(rf'\b{letter}\b(?!\s*[\[(])', _bs, seg)
        parts[idx] = seg
    text = ''.join(parts)
    return text, notes


# ---------------------------------------------------------------- control
def _target_of(expr, pc):
    """A P-target expression after substitution -> next pc or None."""
    expr = expr.strip()
    if expr == 'P':
        return pc + 1
    if re.fullmatch(r'-?\d+', expr):
        return int(expr) + 1
    return None


def extract_control(text, rec):
    """Split a translated body into (effects, ctrl, notes).
    ctrl: ('goto', pc) | ('branch', cond, t, f) | ('switch', no, entry)
          | ('return',) | ('dynamic', succ0)"""
    notes = []
    pc = rec['pc']
    if rec.get('switch'):
        sw = rec['switch']
        text = re.sub(r'P\s*=\s*[^;\n]+;?', '', text)
        text = re.sub(r'\bbreak\s*;?', '', text)
        return text, ('switch', sw['mode_no'], sw['entry']), notes
    if rec.get('_r_snapshot'):
        # P = R restore after an R = P snapshot: net pc effect zero
        text = re.sub(r'\bP\s*=\s*R\s*;?', '', text)
        notes.append('R = P snapshot pattern: R-indexed reads lifted '
                     'as current-slot reads; P = R restore is a no-op')
    # P, G = expr, expr  (context-swap ops: P takes the first value)
    m = re.search(r'\bP\s*,\s*([A-Za-z_][\w,\s]*?)\s*=\s*([^;]+);?', text)
    if m:
        others = [x.strip() for x in m.group(1).split(',') if x.strip()]
        rhs = [x.strip() for x in m.group(2).split(',')]
        if len(rhs) == len(others) + 1:
            kept = ', '.join(others) + ' = ' + ', '.join(rhs[1:]) + ';'
            text = text[:m.start()] + kept + text[m.end():]
            t = _target_of(rhs[0], pc)
            if t is not None:
                return text, ('goto', t), notes
            return text, ('dynamic', None), notes + [
                'multi-assign P target not derivable']
    # P += k / P = P + k (multi-slot ops): body is ground truth
    m = re.search(r'P\s*\+=\s*(\d+)\s*;?|P\s*=\s*P\s*\+\s*(\d+)\s*;?',
                  text)
    if m:
        k = int(m.group(1) or m.group(2))
        text = text[:m.start()] + text[m.end():]
        return text, ('goto', pc + k + 1), notes + [
            f'body advances P by {k} (consumes {k} extra slots); walk '
            'successor overridden by the transcribed body']
    # P = if cond then X else Y ;
    m = re.search(r'P\s*=\s*if\s+(.+?)\s*then\s+(.+?)\s*else\s+(.+?);',
                  text, re.S)
    if m:
        cond, x, y = m.group(1), m.group(2), m.group(3)
        text = text[:m.start()] + text[m.end():]
        t1, t2 = _target_of(x, pc), _target_of(y, pc)
        if t1 is not None and t2 is not None:
            return text, ('branch', cond.strip(), t1, t2), notes
        return text, ('dynamic', None), notes + [
            'branch target not statically derivable from body']
    # if cond then ... P = X ... else ... P = Y ... end
    m = re.search(r'if\s+(.+?)\s*then\s+(.*?)\s*else\s+(.*?)\s*end\s*;?',
                  text, re.S)
    if m and re.search(r'\bP\s*=', m.group(2) + m.group(3)):
        cond, bt, be = m.group(1), m.group(2), m.group(3)
        tt = re.search(r'P\s*=\s*([^;]+);?', bt)
        te = re.search(r'P\s*=\s*([^;]+);?', be)
        if tt and te:
            t1, t2 = _target_of(tt.group(1), pc), _target_of(te.group(1), pc)
            bt2 = (bt[:tt.start()] + bt[tt.end():]).strip(' \n;')
            be2 = (be[:te.start()] + be[te.end():]).strip(' \n;')
            kept = ''
            if bt2 or be2:
                kept = (f'if {cond} then {bt2} else {be2} end;')
            text = text[:m.start()] + kept + text[m.end():]
            if t1 is not None and t2 is not None:
                return text, ('branch', cond.strip(), t1, t2), notes
            return text, ('dynamic', None), notes + [
                'if-branch target not statically derivable']
    # if cond then ... P = X ... end  (single-branch jump)
    m = re.search(r'if\s+(.+?)\s*then\s+(.*?)\s*end\s*;?', text, re.S)
    if m and re.search(r'\bP\s*=', m.group(2)):
        cond, bt = m.group(1), m.group(2)
        tt = re.search(r'P\s*=\s*([^;]+);?', bt)
        if tt:
            t1 = _target_of(tt.group(1), pc)
            bt2 = (bt[:tt.start()] + bt[tt.end():]).strip(' \n;')
            kept = f'if {cond} then {bt2} end;' if bt2 else ''
            text = text[:m.start()] + kept + text[m.end():]
            if t1 is not None:
                return text, ('branch', cond.strip(), t1, pc + 1), notes
            return text, ('dynamic', None), notes + [
                'single-branch jump target not derivable']
    # plain P = expr ;
    m = re.search(r'P\s*=\s*([^;\n]+);?', text)
    if m:
        t = _target_of(m.group(1), pc)
        text = text[:m.start()] + text[m.end():]
        if t is not None:
            return text, ('goto', t), notes
        return text, ('dynamic', None), notes + [
            f"dynamic jump (P = {m.group(1).strip()}); target taken "
            'from the walk']
    return text, None, notes


def clean_lines(text):
    lines = [ln.rstrip() for ln in text.split('\n')]
    lines = [ln for ln in lines if ln.strip(' ;') != '']
    # drop pure-empty statements
    out = []
    for ln in lines:
        s = ln.strip()
        if s in (';', ''):
            continue
        out.append(ln.strip())
    return out


# ---------------------------------------------------------------- emission
def emit_instruction(rec, ctx, ind):
    """Returns (lines, kind) where kind in
    {'ok','unimpl','folded','catchbranch'}."""
    mode, pc = rec['mode'], rec['pc']
    li = LOOP_IDX[mode]
    op_raw, op_fin = rec['op'], rec['op_final']
    succ = rec['succ'] or []
    succ_pcs = [s[1] for s in succ]
    lines = []
    notes = []
    header = (f"-- {mode} {pc} {rec['name']} "
              f"(y={rec['y']} i={rec['i']} S={rec['S']} f={rec['f']})")
    ksum = []
    for ti in range(4):
        enc = rec['K'][ti] if rec.get('K') else None
        if enc is not None:
            txt, _ = render_const(enc, ctx.pid, ti, pc)
            ksum.append(f'{TI_NAME[ti]}={txt[:44]}')
        elif rec.get('K_err') and rec['K_err'][ti]:
            ksum.append(f'{TI_NAME[ti]}=<err>')
    if ksum:
        header += '  K: ' + ' '.join(ksum)
    lines.append(ind + header)

    entry = OPMAP.get((li, op_fin))
    catchall_note = None
    if entry is None:
        thr, hop = CATCHALL[li]
        if op_fin >= thr:
            entry = OPMAP.get((li, hop))
            catchall_note = (f'catch-all: op {op_fin} dispatched to the '
                             f'op-{hop} handler')
    name_fin = entry['name'] if entry else 'UNKNOWN'

    def ctrl_lines(ctrl, extra_notes):
        out = []
        if ctrl is None:
            if succ_pcs:
                out.append(f'{ind}pc = {succ_pcs[0]}')
            else:
                out.append(f'{ind}return')
            return out
        kind = ctrl[0]
        if kind == 'goto':
            t = ctrl[1]
            if succ_pcs and t != succ_pcs[0] and \
                    not any('overridden' in n for n in extra_notes):
                out.append(f'{ind}-- note: body-derived next pc {t} != '
                           f'walk successor {succ_pcs[0]}; body kept')
            out.append(f'{ind}pc = {t}')
        elif kind == 'branch':
            _, cond, t1, t2 = ctrl
            if succ_pcs and {t1, t2} != set(succ_pcs):
                out.append(f'{ind}-- note: branch targets ({t1},{t2}) '
                           f'!= walk successors {succ_pcs}; walk '
                           'order used')
                t1, t2 = succ_pcs[0], succ_pcs[-1]
            out.append(f'{ind}if {cond} then pc = {t1} '
                       f'else pc = {t2} end')
        elif kind == 'switch':
            _, mno, entry_pc = ctrl
            letter = MODE_LETTER.get(mno)
            if letter and letter in ctx.modes:
                out.append(f'{ind}return seg_{letter}({entry_pc}, ...)')
            else:
                out.append(f'{ind}-- SWITCHMODE to mode {mno}: no such '
                           'mode loop exists (dead switch)')
                out.append(f'{ind}return')
        elif kind == 'dynamic':
            if succ_pcs:
                out.append(f'{ind}pc = {succ_pcs[0]}')
            else:
                out.append(f'{ind}return')
        elif kind == 'return':
            out.append(f'{ind}return')
        return out

    # ---- decryptor folding
    if name_fin.startswith('DECRYPTSTR'):
        prev = ctx.decrypted.get((mode, pc))
        if prev is not None:
            preview = luau_str(prev[:72]) + ('...' if len(prev) > 72 else '')
            lines.append(f'{ind}-- DECRYPTSTR folded: string decrypted '
                         f'in place by the interpreter; plaintext '
                         f'recovered by the static walk: {preview}')
        else:
            lines.append(f'{ind}-- DECRYPTSTR folded: string remains '
                         'ENCRYPTED (dynamic seed or unresolved '
                         'header) — not guessed')
        lines.append(f'{ind}-- (no statement: post-decryption state '
                     'is what the walk used)')
        STATS['folded_decryptstr'] += 1
        lines += ctrl_lines(('goto', succ_pcs[0]) if succ_pcs
                            else ('return',), notes)
        return lines, 'folded'
    if name_fin.startswith('DECRYPTBLOCK'):
        lines.append(f'{ind}-- DECRYPTBLOCK folded: stream region '
                     'decrypted in place; the walk already used the '
                     'post-decryption stream state')
        STATS['folded_decryptblock'] += 1
        lines += ctrl_lines(('goto', succ_pcs[0]) if succ_pcs
                            else ('return',), notes)
        return lines, 'folded'
    if name_fin.startswith('DECRYPTINSN') and op_fin == op_raw:
        lines.append(f'{ind}-- DECRYPTINSN with dynamic seed: slot '
                     'state unknown, left unimplemented')
        lines.append(f'{ind}UNIMPL("{mode}", {pc}, {op_fin})')
        STATS['unimpl'] += 1
        UNIMPL_OPS[(mode, op_fin, name_fin)] += 1
        lines += ctrl_lines(('goto', succ_pcs[0]) if succ_pcs
                            else ('return',), notes)
        return lines, 'unimpl'

    if entry is not None and entry.get('body') and \
            entry['body'].lstrip().startswith(('elseif', 'else')):
        lines.append(f'{ind}-- UNIMPLEMENTED: {rec["name"]} — body is '
                     'a fragment of a dispatcher if/elseif chain and '
                     'cannot be lifted standalone')
        lines.append(f'{ind}UNIMPL("{mode}", {pc}, {op_fin})')
        STATS['unimpl'] += 1
        UNIMPL_OPS[(mode, op_fin, name_fin)] += 1
        lines += ctrl_lines(('goto', succ_pcs[0]) if succ_pcs
                            else ('return',), notes)
        return lines, 'unimpl'
    if entry is None or not entry.get('body'):
        why = 'no transcribed body' if entry else 'opcode not in map'
        lines.append(f'{ind}-- UNIMPLEMENTED: {rec["name"]} ({why})')
        if entry and entry.get('semantics'):
            lines.append(f'{ind}-- semantics: {entry["semantics"][:140]}')
        lines.append(f'{ind}UNIMPL("{mode}", {pc}, {op_fin})')
        STATS['unimpl'] += 1
        UNIMPL_OPS[(mode, op_fin, name_fin)] += 1
        lines += ctrl_lines(('goto', succ_pcs[0]) if succ_pcs
                            else ('return',), notes)
        return lines, 'unimpl'

    if op_raw != op_fin:
        notes.append(f'slot self-decrypted in place: op {op_raw} -> '
                     f'{op_fin} ({name_fin}); decrypted form lifted')
        STATS['decryptinsn_folded'] += 1
    if catchall_note:
        notes.append(catchall_note)
    if rec['name'].startswith('UNKNOWN'):
        notes.append('semantics unclassified in phase C1; transcribed '
                     'body lifted verbatim')

    body = eval_guards(entry['body'], mode, ctx.u)
    body = collapse_const_ifs(body)
    text, tnotes = translate_body(body, rec, ctx)
    notes += tnotes
    text, ctrl, cnotes = extract_control(text, rec)
    notes += cnotes
    eff = clean_lines(text)
    has_return = any(re.match(r'return\b', ln) for ln in eff)
    for n in notes:
        lines.append(f'{ind}-- note: {n}')
    for ln in eff:
        lines.append(ind + ln)
    if rec.get('group_slots'):
        for gs in rec['group_slots']:
            gk = []
            for ti in range(4):
                enc = gs['K'][ti] if gs.get('K') else None
                if enc is not None:
                    txt, _ = render_const(enc, ctx.pid, ti, gs['pc'])
                    gk.append(f'{TI_NAME[ti]}={txt[:40]}')
            lines.append(f"{ind}-- group slot {gs['pc']}: y={gs['y']} "
                         f"i={gs['i']} S={gs['S']} f={gs['f']}"
                         + ('  K: ' + ' '.join(gk) if gk else ''))
    if has_return:
        STATS['ok'] += 1
        return lines, 'ok'
    lines += ctrl_lines(ctrl, notes)
    STATS['ok'] += 1
    return lines, 'ok'


ALIASES = ('local p, Z, T, N, s, d, m, q, Y, Q, j, c, D, k, o, I, M = '
           'table.create, table.move, bit32.rshift, bit32.band, '
           'bit32.bxor, bit32.lshift, table.pack, select, bit32.bor, '
           'buffer.readu8, buffer.writeu32, buffer.readu32, '
           'buffer.writeu8, unpack, next, coroutine.wrap, bit32.bnot')


def emit_stub(pid, reason):
    out = []
    out.append(f'-- ===== proto {pid} =====')
    out.append(f'-- STUB — not lifted: {reason}')
    out.append(f'proto_{pid} = function(H, capE, capO, ...)')
    out.append(f'  error("proto {pid} not lifted: {reason}")')
    out.append('end')
    out.append('')
    return out


def emit_bz(pid, pstruct):
    """bz-constant proto (Phase E, walk_bz): no interpreter
    instruction stream exists; the materialized constant IS the
    Fz-slot utility closure, emitted verbatim from the raw file."""
    out = []
    out.append(f'-- ===== proto {pid} =====')
    out.append(f"-- bz-constant proto (descriptor M={pstruct.get('M')}, "
               f"build frame {pstruct.get('frame')}): single-table "
               f"group, an empty shell (keys -2/-1 only).")
    out.append(f"-- No interpreter instruction stream exists for bz "
               f"protos; the payload-visible materialized value is "
               f"the Fz slot-{pstruct.get('slot')} utility closure "
               f"below, verbatim from the raw file "
               f"(span {pstruct.get('closure_span')}).")
    src = pstruct.get('closure_source')
    if src:
        out.append(f'proto_{pid} = {src}')
    else:
        out.append(f'proto_{pid} = function(H, capE, capO, ...)')
        out.append(f'  error("proto {pid}: bz closure source '
                   f'unavailable")')
        out.append('end')
    out.append('')
    return out


def emit_proto(pid, pstruct):
    fac = pstruct.get('factory') or {}
    ctx = Ctx(pid, pstruct)
    modes = []
    for r in pstruct['instructions']:
        if r['mode'] not in modes:
            modes.append(r['mode'])
    ctx.modes = set(modes)
    out = []
    site = pstruct.get('site')
    out.append(f'-- ===== proto {pid} =====')
    if pid == 'root':
        out.append('-- root proto (bootstrap entry)')
    elif site:
        out.append(f"-- parent: {pstruct.get('parent')}; creation site: "
                   f"proto {site.get('proto')} table {site.get('table')} "
                   f"key {site.get('key')} (materializer state 178; "
                   f"instr {site.get('instr_mode')} "
                   f"{site.get('instr_pc')})")
    out.append(f"-- factory: mode={fac.get('A')} entry={fac.get('R2')} "
               f"regfile={fac.get('u')} slots={pstruct.get('n_slots')}")
    fn = f'proto_{pid}'
    out.append(f'{fn} = function(H, capE, capO, ...)')
    out.append(f"  local n = table.create({fac.get('u') or 0})")
    out.append(f"  local V, L = {num(fac.get('P2'))}, {num(fac.get('P1'))}")
    out.append('  local K, G, h, b, F, C, r, W, g, l, x, a, A, J, U, u')
    out.append('  local e, O = capE, capO')
    out.append('  ' + ALIASES)
    out.append('  local t, v -- factory captures (environment table / '
               'H.sY): not statically known')
    by_mode = {}
    for r in pstruct['instructions']:
        by_mode.setdefault(r['mode'], []).append(r)
    present = [m for m in 'ABCD' if m in by_mode]
    if present:
        out.append('  local ' + ', '.join(f'seg_{m}' for m in present))
    for mode in 'ABCD':
        if mode not in by_mode:
            continue
        out.append(f'  seg_{mode} = function(pc, ...)')
        out.append('    while true do')
        first = True
        for r in by_mode[mode]:
            kw = 'if' if first else 'elseif'
            first = False
            out.append(f'      {kw} pc == {r["pc"]} then')
            ilines, _kind = emit_instruction(r, ctx, '        ')
            out += ilines
        out.append('      else')
        out.append('        break')
        out.append('      end')
        out.append('    end')
        out.append('  end')
    entry = pstruct.get('entry') or ['A', fac.get('R2')]
    out.append(f'  return seg_{entry[0]}({entry[1]}, ...)')
    out.append('end')
    out.append('')
    return out


def main():
    order = [pid for pid in STRUCTS if pid != 'root'] + \
        (['root'] if 'root' in STRUCTS else [])
    # stub protos for children referenced by closure wiring but not
    # walked (bz groups / uncaptured factory args)
    stub_reasons = {}
    try:
        sw = json.load(open(os.path.join(HERE, 'sweep_state.json')))
        for pid, w in sw.get('walk_infos', {}).items():
            if 'error' in w:
                stub_reasons[pid] = w['error']
    except Exception:
        pass
    referenced = set()
    for lst in CHILD.get('access_results', {}).values():
        for e in lst:
            referenced.update(e.get('children', []))
    stubs = sorted(referenced - set(STRUCTS))
    for pid in stubs:
        if pid not in order:
            order.insert(order.index('root') if 'root' in order
                         else len(order), pid)
    lines = []
    lines.append('-- StealAnEggs (Luraph v15.1 sub-variant, virtualized '
                 'bootstrap) — Phase E full lifted source (v2)')
    lines.append('-- Generated by stageD/liftD.py: root from the C1/C2 '
                 'static walk; child protos recovered by the Phase D/E '
                 'payload-phase executor (in-context materialization) '
                 'and walked with disasm2 machinery from their '
                 'build-time state (stageD/proto_structs.json). bz '
                 'protos are constant artifacts (verbatim slot '
                 'closures, see walk_bz.py).')
    lines.append('-- Interpreter-faithful lift: register file `n`, seed '
                 'registers V/L, capture boxes e/O,')
    lines.append('-- iterator state G/h/b and context K are proto-level '
                 'locals shared by the mode')
    lines.append('-- segments; SWITCHMODE is a tail call between '
                 'segments. Decryptor ops are folded')
    lines.append('-- (annotations only). Dynamic-seed strings remain '
                 'marked ENCRYPTED. UNIMPL nodes')
    lines.append('-- mark opcodes whose effects could not be lifted; '
                 'the file compiles but errors if')
    lines.append('-- execution reaches one.')
    lines.append('')
    lines.append('local function UNIMPL(mode, pc, op)')
    lines.append('  error("unimplemented opcode " .. tostring(op) .. '
                 '" in mode " .. mode .. " at pc " .. tostring(pc))')
    lines.append('end')
    lines.append('')
    for pid in order:
        lines.append(f'local proto_{pid}')
    lines.append('')
    for pid in order:
        if pid in stubs:
            lines += emit_stub(
                pid, stub_reasons.get(pid, 'not walked'))
        elif (STRUCTS.get(pid) or {}).get('kind') == 'bz-constant':
            lines += emit_bz(pid, STRUCTS[pid])
        else:
            lines += emit_proto(pid, STRUCTS[pid])
    lines.append('return proto_root')
    with open(os.path.join(HERE, 'full.luau'), 'w') as fo:
        fo.write('\n'.join(lines) + '\n')
    total = sum(len(p['instructions']) for p in STRUCTS.values())
    stats = {'instructions_visited': total, **dict(STATS),
             'unimpl_ops': {f'{m}/{o}/{n}': c for (m, o, n), c
                            in UNIMPL_OPS.items()}}
    with open(os.path.join(HERE, 'lift_stats.json'), 'w') as fo:
        json.dump(stats, fo, indent=1)
    print(json.dumps(stats, indent=1))


if __name__ == '__main__':
    main()
