#!/usr/bin/env python3
"""clean_lib.py — shared machinery for the StealAnEggs source-cleaning pass.

Pipeline position: sits on top of liftD.py (the verified raw lifter).
For every walked instruction record in proto_structs.json it reproduces
liftD.emit_instruction's classification exactly (folded decryptors /
UNIMPL / translated body + control), then adds:

  * per-record placeholder naming (__unmaterialized & friends become
    CONST_UNRESOLVED_<proto>_<mode><pc> locals),
  * intra-body scratch constant folding (C/_/g assigned literals are
    propagated into register indices: MOVE2's n[C], n[C+1] etc.),
  * special-form rewrites for the vararg/capture/call-res ops whose
    table.move over the register file can be unrolled statically
    (LOADVARARG / SPILLVARARG / CAPTURE / CALL_RES),
  * a per-proto CFG plus a recursive structural analyser that renders
    natural Luau control flow (sequence / if-else / while / numeric
    and generic for where provable), raising StructFail -> the caller
    falls back to a cleaned dispatch form for that proto,
  * a slot-value abstract interpretation used for register naming and
    for the method-call / dot-index idiom conversions.

Nothing here invents values: every constant in the output comes from
liftD's own translation of the walk records.
"""
import re
import sys
from collections import defaultdict

import liftD as L

STRUCTS = L.STRUCTS
OPMAP = L.OPMAP
CLOSURE_MAP = L.CLOSURE_MAP
LOOP_IDX = L.LOOP_IDX
CATCHALL = L.CATCHALL

FOLD_NAMES = {'C', '_', 'g', 'l', 'x', 'q'}
SCRATCH_RENAMES = {}  # filled by clean.py (shared-state renames)


# ---------------------------------------------------------------- records
class Rec:
    __slots__ = ('pid', 'mode', 'pc', 'name', 'raw_name', 'op', 'op_final',
                 'kind', 'effects', 'ctrl', 'notes', 'risk', 'succ',
                 'group_span', 'rec', 'placeholders', 'transforms',
                 'fold_failed_dyn', 'bare_n_value', 'dyn_index',
                 'in_state', 'key', 'for_conv', 'step_effects',
                 'elided_into')

    def __init__(self, pid, rec):
        self.pid = pid
        self.rec = rec
        self.mode = rec['mode']
        self.pc = rec['pc']
        self.key = (self.mode, self.pc)
        self.raw_name = rec['name']
        self.op = rec['op']
        self.op_final = rec['op_final']
        self.name = rec['name']
        self.kind = 'ok'
        self.effects = []
        self.ctrl = None
        self.notes = []
        self.risk = []
        self.succ = rec['succ'] or []
        self.group_span = rec.get('group_span') or 0
        self.placeholders = set()
        self.transforms = []
        self.fold_failed_dyn = False
        self.bare_n_value = False
        self.dyn_index = False
        self.in_state = None
        self.for_conv = None
        self.step_effects = None
        self.elided_into = None


def _entry_for(rec):
    li = LOOP_IDX[rec['mode']]
    e = OPMAP.get((li, rec['op_final']))
    catchall = False
    if e is None:
        thr, hop = CATCHALL[li]
        if rec['op_final'] >= thr:
            e = OPMAP.get((li, hop))
            catchall = e is not None
    return e, catchall


_PLACEHOLDER_RES = [
    (re.compile(r'__unmaterialized'), 'main'),
    (re.compile(r'__unrendered'), 'main'),
    (re.compile(r'__stream_([A-Za-z])'), 'stream'),
    (re.compile(r'__closure_(\d+)'), 'closure'),
    (re.compile(r'__buffer_(\d+)'), 'buffer'),
]


def _rename_placeholders(text, rec):
    """Replace liftD's placeholder tokens with per-record named locals."""
    name = f'CONST_UNRESOLVED_{rec.pid}_{rec.mode}{rec.pc}'
    out = []
    i = 0
    # simple sequential substitution (tokens never overlap)
    def sub_one(text, kind, extra=None):
        if kind == 'main':
            rec.placeholders.add(name)
            return name
        if kind == 'stream':
            n2 = f'STREAM_{extra}'
            rec.placeholders.add(n2)
            return n2
        if kind == 'closure':
            n2 = f'UNRESOLVED_CLOSURE_{extra}'
            rec.placeholders.add(n2)
            return n2
        if kind == 'buffer':
            n2 = f'UNRESOLVED_BUFFER_{extra}'
            rec.placeholders.add(n2)
            return n2
        return text
    for pat, kind in _PLACEHOLDER_RES:
        def _r(m, kind=kind):
            return sub_one(m.group(0), kind,
                           m.group(1) if m.groups() else None)
        text = pat.sub(_r, text)
    return text


# ------------------------------------------------------- statement utils
def split_statements(line):
    """Split a body line on top-level ';' (string/comment aware)."""
    parts, depth, cur, i = [], 0, [], 0
    in_str = None
    while i < len(line):
        ch = line[i]
        if in_str:
            cur.append(ch)
            if ch == '\\' and i + 1 < len(line):
                cur.append(line[i + 1])
                i += 2
                continue
            if ch == in_str:
                in_str = None
            i += 1
            continue
        if ch in '"\'':
            in_str = ch
            cur.append(ch)
        elif ch in '([{':
            depth += 1
            cur.append(ch)
        elif ch in ')]}':
            depth -= 1
            cur.append(ch)
        elif ch == ';' and depth == 0:
            parts.append(''.join(cur))
            cur = []
        else:
            cur.append(ch)
        i += 1
    if cur:
        parts.append(''.join(cur))
    return [p.strip() for p in parts if p.strip()]


def split_top_commas(text):
    parts, depth, cur, in_str = [], 0, [], None
    i = 0
    while i < len(text):
        ch = text[i]
        if in_str:
            cur.append(ch)
            if ch == '\\' and i + 1 < len(text):
                cur.append(text[i + 1])
                i += 2
                continue
            if ch == in_str:
                in_str = None
            i += 1
            continue
        if ch in '"\'':
            in_str = ch
            cur.append(ch)
        elif ch in '([{':
            depth += 1
            cur.append(ch)
        elif ch in ')]}':
            depth -= 1
            cur.append(ch)
        elif ch == ',' and depth == 0:
            parts.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    if cur:
        parts.append(''.join(cur).strip())
    return parts


_INT_EXPR_RE = re.compile(r'^[\d\s\+\-\*\(\)]+$')


def _eval_int_expr(expr, env):
    """Evaluate an integer expression of literals + folded names."""
    e = expr.strip()
    if not e:
        return None
    def rep(m):
        w = m.group(0)
        if w in env:
            return str(env[w])
        raise KeyError(w)
    try:
        e2 = re.sub(r'[A-Za-z_]\w*', rep, e)
    except KeyError:
        return None
    if not _INT_EXPR_RE.match(e2):
        return None
    try:
        return int(eval(e2, {}, {}))
    except Exception:
        return None


def _match_bracket(text, i):
    """text[i] == '['; return index of matching ']' or -1."""
    depth = 0
    in_str = None
    j = i
    while j < len(text):
        ch = text[j]
        if in_str:
            if ch == '\\':
                j += 2
                continue
            if ch == in_str:
                in_str = None
            j += 1
            continue
        if ch in '"\'':
            in_str = ch
        elif ch == '[':
            depth += 1
        elif ch == ']':
            depth -= 1
            if depth == 0:
                return j
        j += 1
    return -1


_LOCAL_FOLDABLE = {'B', 'R', 'q', 'PY', 'EY', 'HY', 'AY', 'XY', 'uY',
                   'yY'}


def _split_chunks(line):
    """Split a body line into (separator_before, chunk) pieces on
    top-level ';', ' then ' and ' do ' boundaries, so assignments
    nested after a keyword become visible to the folder."""
    pieces = []
    depth = 0
    in_str = None
    cur = []
    sep = ''
    i = 0
    while i < len(line):
        ch = line[i]
        if in_str:
            cur.append(ch)
            if ch == '\\' and i + 1 < len(line):
                cur.append(line[i + 1])
                i += 2
                continue
            if ch == in_str:
                in_str = None
            i += 1
            continue
        if ch in '"\'':
            in_str = ch
            cur.append(ch)
            i += 1
            continue
        if ch in '([{':
            depth += 1
            cur.append(ch)
            i += 1
            continue
        if ch in ')]}':
            depth -= 1
            cur.append(ch)
            i += 1
            continue
        if depth == 0 and ch == ';':
            pieces.append((sep, ''.join(cur)))
            cur = []
            sep = '; '
            i += 1
            continue
        if depth == 0 and (line.startswith(' then ', i) or
                           line.startswith(' do ', i)):
            kw = ' then ' if line.startswith(' then ', i) else ' do '
            pieces.append((sep, ''.join(cur)))
            cur = []
            sep = kw
            i += len(kw)
            continue
        cur.append(ch)
        i += 1
    pieces.append((sep, ''.join(cur)))
    return [(s, c) for s, c in pieces if c.strip()]


_OPENERS = ('if', 'for', 'while', 'repeat', 'function')
_LOCAL_ASSIGN_RE = re.compile(
    r'\blocal\s+([A-Za-z_][\w\s,]*?)\s*=(?![=~<>])')
_PLAIN_ASSIGN_RE = re.compile(
    r'\s*([A-Za-z_][\w\s,]*?)\s*=(?![=~<>])')


def _find_assignment(chunk):
    m = _LOCAL_ASSIGN_RE.search(chunk)
    if m:
        return m
    return _PLAIN_ASSIGN_RE.match(chunk)


def fold_effects(effects, rec):
    """Propagate literal scratch assignments into n[...] indices.

    Works on keyword chunks with a block-scope stack: a folded value
    is only used for an index when the assignment's block is an
    ancestor-or-self of the use's block (sibling branches get fresh
    block ids; inline-function params clear their names). Returns
    (new_effects, dyn_left)."""
    dyn = 0
    out_lines = []
    foldable = set(FOLD_NAMES) | (body_locals(effects) & _LOCAL_FOLDABLE)
    env = {}            # name -> (value, block_path_tuple)
    block_stack = [0]  # block instance ids; 0 = body top level
    next_bid = [1]

    def visible_env():
        path = tuple(block_stack)
        return {k: v for k, (v, p) in env.items()
                if path[:len(p)] == p}

    for ln in effects:
        out = []
        for sep, chunk in _split_chunks(ln):
            text = chunk.strip()
            # a chunk starting with a closer pops a scope before use
            if re.match(r'^(end|until)\b', text) and \
                    len(block_stack) > 1:
                block_stack.pop()
            # sibling branch: else/elseif starts a fresh block id
            if re.match(r'^(else|elseif)\b', text) and \
                    len(block_stack) > 1:
                block_stack[-1] = next_bid[0]
                next_bid[0] += 1
            # inline function params clear folded names
            fm = re.search(r'function\s*\(([^)]*)\)', text)
            if fm:
                for t in fm.group(1).split(','):
                    env.pop(t.strip(), None)
            vis = visible_env()
            # substitute n[<expr>]
            res = []
            i = 0
            while i < len(chunk):
                m = re.match(r'\bn\[', chunk[i:])
                if m:
                    j = _match_bracket(chunk, i + 1)
                    if j > 0:
                        inner = chunk[i + 2:j]
                        if '[' not in inner and ']' not in inner:
                            v = _eval_int_expr(inner, vis)
                            if v is not None:
                                res.append(f'n[{v}]')
                                i = j + 1
                                continue
                            if not re.fullmatch(r'-?\d+',
                                                 inner.strip()):
                                dyn += 1
                        else:
                            dyn += 1
                        res.append(chunk[i:j + 1])
                        i = j + 1
                        continue
                res.append(chunk[i])
                i += 1
            chunk2 = ''.join(res)
            # record an assignment in this chunk (first plausible one)
            am = _find_assignment(chunk2)
            if am and not re.match(r'^\s*(if|while|return)\b',
                                   chunk2):
                targets = [t.strip() for t in am.group(1).split(',')]
                rhs_text = chunk2[am.end():]
                rhs = split_top_commas(rhs_text)
                if len(rhs) <= len(targets):
                    rhs = rhs + ['nil'] * (len(targets) - len(rhs))
                    path = tuple(block_stack)
                    for t, r in zip(targets, rhs):
                        if t in foldable:
                            v = _eval_int_expr(r, vis)
                            if v is not None:
                                env[t] = (v, path)
                            else:
                                env.pop(t, None)
                else:
                    for t in targets:
                        if t in foldable:
                            env.pop(t, None)
            # block openers at chunk start push a scope for later
            # chunks
            first = text.split(None, 1)[0] if text else ''
            if first in _OPENERS:
                block_stack.append(next_bid[0])
                next_bid[0] += 1
            elif re.search(r'\bfunction\s*\(', text):
                block_stack.append(next_bid[0])
                next_bid[0] += 1
            out.append(sep + chunk2.strip())
        out_lines.append(''.join(out) + ';')
    return out_lines, dyn


_ASSIGN_RE = re.compile(
    r'^(?:local\s+)?([A-Za-z_][\w\s,]*?)\s*=(?![=~<>])\s*(.*)$', re.S)


def _update_env(stmt, env, foldable=None):
    foldable = foldable if foldable is not None else FOLD_NAMES
    m = _ASSIGN_RE.match(stmt.strip())
    if not m:
        # compound assign kills the name
        m2 = re.match(r'^([A-Za-z_]\w*)\s*[+\-*/%]=', stmt.strip())
        if m2 and m2.group(1) in foldable:
            env.pop(m2.group(1), None)
        return
    targets = [t.strip() for t in m.group(1).split(',')]
    rhs = split_top_commas(m.group(2))
    if len(rhs) > len(targets):
        for t in targets:
            if t in foldable:
                env.pop(t, None)
        return
    # fewer RHS values than targets: trailing targets get nil
    rhs = rhs + ['nil'] * (len(targets) - len(rhs))
    for t, r in zip(targets, rhs):
        if t in foldable:
            v = _eval_int_expr(r, env)
            if v is not None:
                env[t] = v
            else:
                env.pop(t, None)


def _fold_env_at(effects):
    """Fold env after processing the given statement lines, plus the
    per-statement snapshots: returns list of envs (env BEFORE stmt)."""
    env = {}
    snaps = []
    for ln in effects:
        for st in split_statements(ln):
            snaps.append(dict(env))
            _update_env(st, env)
    return snaps


BARE_N_VALUE_RES = [
    re.compile(r'[(,]\s*n\s*[,)]'),          # argument / move source
    re.compile(r'=\s*n\s*(?:;|$)'),          # assigned as value
    re.compile(r'\{\s*\[\s*6\s*\]\s*=\s*n\b'),  # box {[6]=n}
    re.compile(r'\breturn\s+n\s*(?:;|$)'),
]


def classify_bare_n(effects):
    """True if the register file itself is used as a value (aliases)."""
    for ln in effects:
        masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)
        masked = re.sub(r'\bn\[', 'n[', masked)  # keep register reads
        for pat in BARE_N_VALUE_RES:
            if pat.search(masked):
                return True
        # table.move / Z over n: covered by arg pattern; {n = ...} is a
        # constructor KEY (CAPTURE), not a value use -> excluded above.
    return False


# ------------------------------------------------------- special rewrites
def _stmts(effects):
    out = []
    for ln in effects:
        out += split_statements(ln)
    return out


def _join(stmts):
    return ['; '.join(stmts) + ';'] if stmts else []


def special_rewrite(rec):
    """Attempt the static unrolls. Returns True if the rewrite applied
    (or the op needs none). On False the caller must treat any verbatim
    table-over-n body as register-file-aliasing (-> REGS proto)."""
    nm = rec.name
    eff = rec.effects
    stmts = _stmts(eff)
    if nm == 'LOADVARARG':
        if len(stmts) != 2:
            return False
        m1 = re.fullmatch(r'C,_=\{\.\.\.},(\d+)', stmts[0])
        m2 = re.fullmatch(r'Z\(C,1,(\d+),_,n\)', stmts[1])
        if not m1 or not m2:
            return False
        dest, cnt = int(m1.group(1)), int(m2.group(1))
        if cnt > 12:
            return False
        new = [stmts[0] + ';']
        if cnt > 0:
            lhs = ','.join(f'n[{dest + k}]' for k in range(cnt))
            rhs = ','.join(f'C[{k + 1}]' for k in range(cnt))
            new.append(f'{lhs}={rhs};')
        rec.effects = new
        rec.transforms.append('loadvararg-unroll')
        return True
    if nm == 'SPILLVARARG':
        if len(stmts) != 3:
            return False
        m1 = re.fullmatch(r'C,_,g=(\d+),\{\.\.\.},(\d+)', stmts[0])
        if not m1:
            return False
        cval, gval = int(m1.group(1)), int(m1.group(2))
        if stmts[1] != 'Z(_,1,C-1,g,n)':
            return False
        cnt = cval - 1
        if cnt < 0 or cnt > 16:
            return False
        m3 = re.fullmatch(r'n\[(\d+)\]=(.+)', stmts[2])
        if not m3 or int(m3.group(1)) != gval + cnt:
            return False
        new = [stmts[0] + ';']
        for k in range(cnt):
            new.append(f'n[{gval + k}]=_[{k + 1}];')
        new.append(f'n[{gval + cnt}]={m3.group(1)};')
        rec.effects = new
        rec.transforms.append('spillvararg-unroll')
        return True
    if nm == 'CAPTURE':
        if len(stmts) != 4:
            return False
        m1 = re.fullmatch(r'C,_=(\d+),(\d+)', stmts[0])
        if not m1:
            return False
        lo, hi = int(m1.group(1)), int(m1.group(2))
        length = hi - lo + 1
        if length > 128:
            return False
        if stmts[1] != 'g={n=_-C+1}' or stmts[2] != 'Z(n,C,_,1,g)':
            return False
        m4 = re.fullmatch(r'n\[(\d+)\]=g', stmts[3])
        if not m4:
            return False
        new = [stmts[0] + ';', f'g={{n={length}}};']
        for k in range(max(length, 0)):
            new.append(f'g[{k + 1}]=n[{lo + k}];')
        new.append(f'n[{m4.group(1)}]=g;')
        rec.effects = new
        rec.transforms.append('capture-unroll')
        return True
    if nm == 'CALL_RES':
        if len(stmts) != 3 or stmts[2] != 'Z(x,1,g,C,n)':
            return False
        m1 = re.fullmatch(r'C,_,g=(\d+),(\d+),(\d+)', stmts[0])
        if not m1:
            return False
        base, nargs, nres = (int(m1.group(1)), int(m1.group(2)),
                             int(m1.group(3)))
        # post-folding, the callee read n[C] has become n[<base>]
        m2 = re.fullmatch(
            r'l,a,x=C\+g-1,C\+_,m\(n\[(\d+)\]'
            r'\(k\(n,C\+1,C\+_\)\)\)', stmts[1])
        if not m2 or int(m2.group(1)) != base:
            return False
        if nargs > 12 or nres > 12:
            return False
        callee = f'n[{base}]'
        args = ','.join(f'n[{base + 1 + k}]' for k in range(nargs))
        # preserve every interpreter-visible state write of the
        # original: C/_/g (stmt 0), l/a (frame bookkeeping), x (the
        # packed results) and the result registers themselves.
        new = [stmts[0] + ';',
               f'l,a={base + nres - 1},{base + nargs};',
               f'x=m({callee}({args}));']
        for k in range(nres):
            new.append(f'n[{base + k}]=x[{k + 1}];')
        rec.effects = new
        rec.transforms.append('call-res-unroll')
        return True
    return True  # no special form needed


def translate_proto(pid, pstruct):
    """Reproduce liftD's per-record decisions; return (recs, ctx)."""
    ctx = L.Ctx(pid, pstruct)
    ctx.modes = set(r['mode'] for r in pstruct['instructions'])
    recs = []
    for r0 in pstruct['instructions']:
        rec = Rec(pid, r0)
        recs.append(rec)
        entry, catchall = _entry_for(r0)
        name_fin = entry['name'] if entry else 'UNKNOWN'
        rec.name = name_fin
        succ_pcs = [s[1] for s in rec.succ]
        goto = ('goto', succ_pcs[0]) if succ_pcs else ('return',)

        if name_fin.startswith('DECRYPTSTR'):
            rec.kind = 'folded'
            prev = ctx.decrypted.get((rec.mode, rec.pc))
            rec.notes.append('decryptstr-plaintext' if prev is not None
                             else 'decryptstr-encrypted')
            rec.ctrl = goto
            continue
        if name_fin.startswith('DECRYPTBLOCK'):
            rec.kind = 'folded'
            rec.ctrl = goto
            continue
        if name_fin.startswith('DECRYPTINSN') and \
                rec.op_final == rec.op:
            rec.kind = 'unimpl'
            rec.effects = [f'UNIMPL("{rec.mode}", {rec.pc}, '
                           f'{rec.op_final})']
            rec.ctrl = goto
            continue
        if entry is not None and entry.get('body') and \
                entry['body'].lstrip().startswith(('elseif', 'else')):
            rec.kind = 'unimpl'
            rec.effects = [f'UNIMPL("{rec.mode}", {rec.pc}, '
                           f'{rec.op_final})']
            rec.notes.append('dispatcher-fragment body')
            rec.ctrl = goto
            continue
        if entry is None or not entry.get('body'):
            rec.kind = 'unimpl'
            rec.effects = [f'UNIMPL("{rec.mode}", {rec.pc}, '
                           f'{rec.op_final})']
            rec.notes.append('no transcribed body' if entry else
                             'opcode not in map')
            rec.ctrl = goto
            continue
        # normal path: identical transforms to liftD.emit_instruction
        if rec.op != rec.op_final:
            rec.transforms.append('decryptinsn-folded')
        if catchall:
            rec.notes.append('catch-all dispatch')
        body = L.eval_guards(entry['body'], rec.mode, ctx.u)
        body = L.collapse_const_ifs(body)
        text, tnotes = L.translate_body(body, r0, ctx)
        text, ctrl, cnotes = L.extract_control(text, r0)
        notes = tnotes + cnotes
        eff = L.clean_lines(text)
        # switch records: the `u = <mode>` statement is the mode-switch
        # mechanism itself, not payload logic (extract_control already
        # consumed the P assignment); drop it.
        if r0.get('switch'):
            mno = r0['switch']['mode_no']
            eff = [ln for ln in eff
                   if not re.fullmatch(rf'u\s*=\s*{mno}\s*;?', ln.strip())]
            eff = [ln for ln in eff if ln.strip() != 'break;']
        has_return = any(re.match(r'return\b', ln) for ln in eff)
        rec.effects = eff
        for n in notes:
            if 'walk successor' in n or 'walk order' in n or \
                    'body-derived' in n:
                rec.risk.append(n)
            elif 'not statically derivable' in n or \
                    'not derivable' in n or 'dynamic jump' in n:
                rec.risk.append(n)
            else:
                rec.notes.append(n)
        if has_return:
            rec.ctrl = ('return',)
            if ctrl is not None and ctrl[0] in ('goto', 'branch'):
                rec.risk.append('body contains a return; lift treats '
                                'the node as terminating')
        elif ctrl is None:
            rec.ctrl = goto
        else:
            rec.ctrl = ctrl
            if ctrl[0] == 'dynamic':
                rec.risk.append('dynamic jump target taken from the '
                                'walk')
        # placeholder naming (per record)
        rec.effects = [_rename_placeholders(ln, rec)
                       for ln in rec.effects]
        # scratch folding
        rec.effects, dyn = fold_effects(rec.effects, rec)
        rec.dyn_index = dyn > 0
        if rec.name in ('LOADVARARG', 'SPILLVARARG', 'CAPTURE',
                        'CALL_RES'):
            if not special_rewrite(rec):
                rec.risk.append('special-form unroll failed; verbatim '
                                'body kept')
        rec.bare_n_value = classify_bare_n(rec.effects)
    return recs, ctx


# ------------------------------------------------------------------- CFG
class StructFail(Exception):
    pass


class CFG:
    def __init__(self, pid, recs, entry_key):
        self.pid = pid
        self.recs = {r.key: r for r in recs}
        self.entry = entry_key
        self.succ = {}
        self.pred = defaultdict(set)
        for r in recs:
            self.succ[r.key] = self._succ_of(r)
            for s in self.succ[r.key]:
                self.pred[s].add(r.key)
        self.reachable = set()
        stack = [entry_key]
        while stack:
            n = stack.pop()
            if n in self.reachable or n not in self.recs:
                continue
            self.reachable.add(n)
            stack += self.succ.get(n, [])
        self.dom = {}
        self._dominators()

    def _succ_of(self, r):
        c = r.ctrl
        if c is None or c[0] == 'return':
            return []
        if c[0] == 'goto':
            k = (r.mode, c[1])
            return [k] if k in self.recs else []
        if c[0] == 'branch':
            out = []
            for t in (c[2], c[3]):
                k = (r.mode, t)
                if k in self.recs and k not in out:
                    out.append(k)
            return out
        if c[0] == 'switch':
            from liftD import MODE_LETTER
            letter = MODE_LETTER.get(c[1])
            k = (letter, c[2]) if letter else None
            return [k] if k in self.recs else []
        if c[0] == 'dynamic':
            if r.succ:
                k = (r.succ[0][0], r.succ[0][1])
                return [k] if k in self.recs else []
            return []
        return []

    def _dominators(self):
        nodes = self.reachable
        dom = {n: set(nodes) for n in nodes}
        if self.entry in nodes:
            dom[self.entry] = {self.entry}
        changed = True
        while changed:
            changed = False
            for n in nodes:
                if n == self.entry:
                    continue
                ps = [p for p in self.pred.get(n, ()) if p in nodes]
                if not ps:
                    new = {n}
                else:
                    inter = set(nodes)
                    for p in ps:
                        inter &= dom[p]
                    new = inter | {n}
                if new != dom[n]:
                    dom[n] = new
                    changed = True
        self.dom = dom

    def dominates(self, a, b):
        return a in self.dom.get(b, set())

    def back_edges(self):
        out = []
        for u, ss in self.succ.items():
            if u not in self.reachable:
                continue
            for v in ss:
                if v in self.reachable and self.dominates(v, u):
                    out.append((u, v))
        return out

    def natural_loop(self, tail, header):
        loop = {header}
        stack = [tail]
        while stack:
            n = stack.pop()
            if n not in loop:
                loop.add(n)
                stack += [p for p in self.pred.get(n, ())
                          if p in self.reachable]
        return loop

    def reach_sets(self):
        """reach[n] = set of nodes reachable from n (including n)."""
        reach = {}
        for n in self.reachable:
            seen = set()
            stack = [n]
            while stack:
                u = stack.pop()
                if u in seen or u not in self.reachable:
                    continue
                seen.add(u)
                stack += self.succ.get(u, ())
            reach[n] = seen
        return reach

    def postdominators(self):
        """ipdom over the reachable graph with a virtual EXIT."""
        EXIT = ('EXIT', -1)
        nodes = set(self.reachable) | {EXIT}
        succ = {}
        for n in self.reachable:
            ss = [s for s in self.succ.get(n, ()) if s in self.reachable]
            succ[n] = ss if ss else [EXIT]
        succ[EXIT] = []
        pdom = {n: set(nodes) for n in nodes}
        pdom[EXIT] = {EXIT}
        changed = True
        while changed:
            changed = False
            for n in nodes:
                if n == EXIT:
                    continue
                ss = succ[n]
                inter = set(nodes)
                for s in ss:
                    inter &= pdom[s]
                new = inter | {n}
                if new != pdom[n]:
                    pdom[n] = new
                    changed = True
        ipdom = {}
        for n in nodes:
            strict = pdom[n] - {n}
            # ipdom = strict postdominator that is postdominated by all
            # other strict postdominators (deepest in the pdom tree)
            best = None
            for c in strict:
                if all(c in pdom[o] for o in strict if o != c):
                    best = c
                    break
            ipdom[n] = best
        return ipdom, EXIT


def invert_cond(cond):
    """Invert a simple comparison condition; else wrap in not (...)."""
    c = cond.strip()
    # strip redundant outer parens
    pairs = {'==': '~=', '~=': '==', '<': '>=', '>': '<=',
             '<=': '>', '>=': '<'}
    depth = 0
    in_str = None
    for i, ch in enumerate(c):
        if in_str:
            if ch == in_str:
                in_str = None
            continue
        if ch in '"\'':
            in_str = ch
        elif ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        elif depth == 0:
            for op in ('==', '~=', '<=', '>=', '<', '>'):
                if c.startswith(op, i):
                    return (c[:i].strip() + ' ' + pairs[op] + ' ' +
                            c[i + len(op):].strip())
    if c.startswith('not '):
        return c[4:]
    return f'not ({c})'


# ------------------------------------------------------------- structurer
class ELine:
    __slots__ = ('indent', 'text', 'owner', 'cat')

    def __init__(self, indent, text, owner, cat):
        self.indent = indent
        self.text = text
        self.owner = owner      # (mode, pc) of owning record or None
        self.cat = cat          # 'effect' | 'construct' | 'comment'

    def __repr__(self):
        return f'ELine({self.indent}, {self.text!r}, {self.owner}, {self.cat})'


class Structurer:
    """Recursive structural analysis over a proto CFG.

    effects_fn(key) -> list[str]: the record's rendered effect lines
    (control already extracted). Raises StructFail on any shape that
    cannot be structured safely; the caller then falls back to a
    dispatch rendering for the whole proto.
    """

    def __init__(self, cfg, effects_fn):
        self.cfg = cfg
        self.effects_fn = effects_fn
        self.done = set()
        self.ipdom, self.EXIT = cfg.postdominators()
        self.reach = cfg.reach_sets()
        self.EXITJOIN = ('EXITJOIN', -1)
        self.loops = {}
        for tail, head in cfg.back_edges():
            lp = self.loops.setdefault(head, {'header': head,
                                              'tails': set(),
                                              'nodes': set()})
            lp['tails'].add(tail)
            lp['nodes'] |= cfg.natural_loop(tail, head)
        for lp in self.loops.values():
            lp['exits'] = {s for u in lp['nodes']
                           for s in cfg.succ.get(u, ())
                           if s not in lp['nodes']}
            # entries from outside must target the header only
            for u in lp['nodes']:
                for p in cfg.pred.get(u, ()):
                    if p not in lp['nodes'] and u != lp['header']:
                        raise StructFail(
                            f'loop at {lp["header"]} entered mid-body '
                            f'at {u} from {p}')
            # continuation exit: the one exit every other exit
            # either reaches or terminates independently of. Other
            # exits become "exit regions" emitted inside the branch
            # arm that targets them (followed by break, unless the
            # region itself returns).
            exits = lp['exits']
            reach = self.reach

            def closed(x):
                rx = reach.get(x, set())
                return all(not cfg.succ.get(w) or
                           all(s in rx for s in cfg.succ.get(w, ()))
                           for w in rx)
            cont = None
            if len(exits) == 1:
                cont = next(iter(exits))
            elif exits:
                for e in exits:
                    if all(o == e or e in reach.get(o, set()) or
                           closed(o) for o in exits):
                        if cont is not None:
                            cont = 'AMBIG'
                            break
                        cont = e
                if cont == 'AMBIG' or cont is None:
                    if all(closed(x) for x in exits):
                        cont = None
                    else:
                        raise StructFail(
                            f'loop at {lp["header"]} has '
                            f'{len(exits)} exits with no unique '
                            f'continuation {sorted(exits)}')
            lp['cont_exit'] = cont
        self.loop_stack = []

    # -- helpers
    def _effects(self, key, indent):
        rec = self.cfg.recs[key]
        cat = 'comment' if rec.kind == 'folded' else 'effect'
        return [ELine(indent, t, key, cat)
                for t in self.effects_fn(key)]

    def _active_loop(self):
        return self.loop_stack[-1] if self.loop_stack else None

    def run(self):
        lines, cont = self._seq(self.cfg.entry, set(), 0)
        if cont is not None:
            raise StructFail(f'program continues past end at {cont}')
        missing = self.cfg.reachable - self.done
        if missing:
            raise StructFail(f'{len(missing)} reachable nodes never '
                             f'emitted, e.g. {sorted(missing)[:4]}')
        return lines

    def _seq(self, start, stops, indent):
        lines = []
        node = start
        while node is not None and node not in stops:
            if node in self.done:
                raise StructFail(f'node {node} emitted twice '
                                 f'(cross-region jump)')
            l2, node = self._node(node, stops, indent)
            lines += l2
        return lines, node

    def _node(self, node, stops, indent):
        if node in self.loops and \
                node not in [lp['header'] for lp in self.loop_stack]:
            return self._loop(node, stops, indent)
        self.done.add(node)
        rec = self.cfg.recs[node]
        ctrl = rec.ctrl
        eff = self._effects(node, indent)
        if ctrl is None or ctrl[0] == 'return':
            return eff, None
        if ctrl[0] in ('goto', 'dynamic', 'switch'):
            ss = self.cfg.succ.get(node, [])
            if not ss:
                return eff, None
            s = ss[0]
            if s in stops or s in [lp['header']
                                   for lp in self.loop_stack]:
                return eff, None
            lp = self._active_loop()
            if lp and s in lp['exits'] and \
                    s != lp.get('cont_exit'):
                # unconditional fall out of the loop into a
                # non-continuation exit region: emit the region,
                # then break (unless the region itself returns)
                region_stops = set(stops) | {lp['header']}
                if lp.get('cont_exit') is not None:
                    region_stops.add(lp['cont_exit'])
                lines, cont = self._seq(s, region_stops, indent)
                out = eff + lines
                if cont is None:
                    return out, None
                out.append(ELine(indent, 'break', node, 'construct'))
                return out, None
            return eff, s
        if ctrl[0] == 'branch':
            return self._branch(node, stops, indent, eff)
        raise StructFail(f'unknown ctrl {ctrl}')

    # -- loops
    def _loop(self, header, stops, indent):
        cfg = self.cfg
        lp = self.loops[header]
        rec = cfg.recs[header]
        exit_node = lp.get('cont_exit')
        self.done.add(header)
        body_stops = set(stops) | {header}
        if exit_node is not None:
            body_stops.add(exit_node)

        # generic-for conversion (approved by the caller via rec flag)
        conv = getattr(rec, 'for_conv', None)
        if conv is not None:
            kind, dsts = conv
            bsucc = [s for s in cfg.succ.get(header, ())
                     if s in lp['nodes']]
            if len(bsucc) != 1:
                raise StructFail('for-loop header has != 1 body entry')
            self.loop_stack.append(lp)
            body, cont = self._seq(bsucc[0], body_stops, indent + 1)
            self.loop_stack.pop()
            if cont is not None and cont not in (header, exit_node):
                raise StructFail(f'for-loop body leaks to {cont}')
            names = ', '.join(dsts)
            if kind == 'generic':
                head = (f'for {names} in iterFn, iterState, iterCtrl '
                        f'do')
            else:
                head = f'for {names[0]} = {dsts[1]} do'
            out = [ELine(indent, head, header, 'construct')] + body + \
                [ELine(indent, 'end', header, 'construct')]
            return out, exit_node

        ctrl = rec.ctrl
        # header-tested while: branch header, empty effects, one succ
        # inside the loop, the other is the exit
        if ctrl and ctrl[0] == 'branch' and \
                not self.effects_fn(header):
            k1 = (rec.mode, ctrl[2])
            k2 = (rec.mode, ctrl[3])
            in_succ = [k for k in (k1, k2) if k in lp['nodes']]
            out_succ = [k for k in (k1, k2) if k not in lp['nodes']]
            if len(in_succ) == 1 and len(out_succ) == 1 and \
                    (out_succ[0] == exit_node or
                     out_succ[0] not in cfg.recs):
                cond = ctrl[1]
                if in_succ[0] == k2:
                    cond = invert_cond(cond)
                self.loop_stack.append(lp)
                body, cont = self._seq(in_succ[0], body_stops,
                                       indent + 1)
                self.loop_stack.pop()
                if cont is not None and cont not in (header, exit_node):
                    raise StructFail(f'while body leaks to {cont}')
                out = [ELine(indent, f'while {cond} do', header,
                             'construct')] + body + \
                    [ELine(indent, 'end', header, 'construct')]
                return out, exit_node

        # general while-true form: emit the loop region starting at
        # the header itself, with break/continue classification inside
        self.loop_stack.append(lp)
        self.done.discard(header)
        body, cont = self._node(header, body_stops, indent + 1)
        if cont is not None and cont not in (header, exit_node):
            more, cont = self._seq(cont, body_stops, indent + 1)
            body += more
        self.loop_stack.pop()
        if cont is not None and cont not in (header, exit_node):
            raise StructFail(f'while-true body leaks to {cont}')
        unconsumed = lp['nodes'] - self.done
        if unconsumed:
            raise StructFail(f'loop at {header}: nodes not consumed '
                             f'{sorted(unconsumed)[:4]}')
        out = [ELine(indent, 'while true do', header, 'construct')] + \
            body + [ELine(indent, 'end', header, 'construct')]
        return out, exit_node

    def _common_join(self, node, k1, k2):
        """Join of a branch = the unique minimal common descendant
        of its two successors (minimal under reachability)."""
        cfg = self.cfg
        if k1 not in cfg.recs or k2 not in cfg.recs:
            return None
        common = self.reach.get(k1, set()) & self.reach.get(k2, set())
        common.discard(node)
        if not common:
            return None
        minimal = [c for c in common
                   if not any(c != o and c in self.reach.get(o, set())
                              for o in common)]
        if len(minimal) == 1:
            return minimal[0]
        return None

    # -- branches
    def _branch(self, node, stops, indent, eff):
        cfg = self.cfg
        rec = cfg.recs[node]
        _, cond, t1, t2 = rec.ctrl
        k1 = (rec.mode, t1)
        k2 = (rec.mode, t2)
        lp = self._active_loop()
        join = self._common_join(node, k1, k2)
        if join is not None and (join in self.done or join == node):
            join = None
        if join is None:
            if k1 in stops:
                join = k1
            elif k2 in stops:
                join = k2
            elif k1 not in cfg.recs:
                join = k2
            elif k2 not in cfg.recs:
                join = k1
            elif lp and (k1 == lp['header'] or k1 in lp['exits']):
                join = k2
            elif lp and (k2 == lp['header'] or k2 in lp['exits']):
                join = k1
            elif not (self.reach.get(k1, set()) &
                      self.reach.get(k2, set())):
                # disjoint arms: they never reconverge. The join is
                # the stop one side flows to, or the proto exit when
                # both sides run to their own end.
                s1 = self.reach.get(k1, set()) & stops
                s2 = self.reach.get(k2, set()) & stops
                if not s1 and not s2:
                    join = self.EXITJOIN
                elif len(s1) == 1 and not s2:
                    join = next(iter(s1))
                elif len(s2) == 1 and not s1:
                    join = next(iter(s2))
                else:
                    raise StructFail(
                        f'branch at {node}: disjoint arms reach '
                        f'multiple stops {s1} / {s2}')
            else:
                raise StructFail(f'branch at {node}: no join found '
                                 f'(ipdom {self.ipdom.get(node)})')

        def classify(k):
            if k == join and not (lp and (k == lp['header'] or
                                          k in lp['exits'])):
                return 'fall'
            if lp and k == lp['header']:
                return 'continue'
            if lp and k in lp['exits']:
                if k == lp.get('cont_exit'):
                    return 'break'
                return 'exitregion'
            if k not in cfg.recs:
                return 'return'
            return 'seq'

        def arm(k, cls):
            if cls == 'fall':
                return [], join
            if cls == 'continue':
                return [ELine(indent + 1, 'continue', node,
                              'construct')], 'loopctl'
            if cls == 'break':
                return [ELine(indent + 1, 'break', node,
                              'construct')], 'loopctl'
            if cls == 'return':
                return [ELine(indent + 1, 'return', node,
                              'construct')], 'term'
            if cls == 'exitregion':
                # a loop exit that is not the continuation: emit the
                # exit region inside this arm; it must terminate
                # (return) or rejoin at the continuation/join, in
                # which case a break follows it.
                region_stops = stops | {join}
                if lp.get('cont_exit') is not None:
                    region_stops.add(lp['cont_exit'])
                region_stops.add(lp['header'])
                lines, cont = self._seq(k, region_stops, indent + 1)
                if cont is None:
                    return lines, 'term'
                lines = lines + [ELine(indent + 1, 'break', node,
                                       'construct')]
                return lines, 'loopctl'
            lines, cont = self._seq(k, stops | {join}, indent + 1)
            if cont is not None and cont != join and cont not in stops:
                raise StructFail(f'branch arm from {node} leaks to '
                                 f'{cont} (join {join})')
            return lines, cont

        c1, c2 = classify(k1), classify(k2)
        out = list(eff)
        if c1 == 'fall' and c2 == 'fall':
            return out, join
        if c2 == 'fall':
            a1, _ = arm(k1, c1)
            out.append(ELine(indent, f'if {cond} then', node,
                             'construct'))
            out += a1
            out.append(ELine(indent, 'end', node, 'construct'))
            return out, join
        if c1 == 'fall':
            a2, _ = arm(k2, c2)
            out.append(ELine(indent, f'if {invert_cond(cond)} then',
                             node, 'construct'))
            out += a2
            out.append(ELine(indent, 'end', node, 'construct'))
            return out, join
        # both arms real: if the branch is an ITERSTEP-style loop tail
        # (one side continues the loop, the other breaks out), render
        # as a break-guard + the continue-side step effect
        if {c1, c2} == {'continue', 'break'}:
            if c1 == 'break':
                guard = cond
                step_key = k2
            else:
                guard = invert_cond(cond)
                step_key = k1
            out.append(ELine(indent, f'if {guard} then', node,
                             'construct'))
            out.append(ELine(indent + 1, 'break', node, 'construct'))
            out.append(ELine(indent, 'end', node, 'construct'))
            extra = getattr(rec, 'step_effects', None)
            if extra:
                out += [ELine(indent, t, node, 'effect')
                        for t in extra]
            return out, None
        a1, _ = arm(k1, c1)
        a2, _ = arm(k2, c2)
        out.append(ELine(indent, f'if {cond} then', node, 'construct'))
        out += a1
        out.append(ELine(indent, 'else', node, 'construct'))
        out += a2
        out.append(ELine(indent, 'end', node, 'construct'))
        # if both arms terminate (return/break), join is not reached
        a1t = a1 and a1[-1].text in ('return', 'break', 'continue')
        a2t = a2 and a2[-1].text in ('return', 'break', 'continue')
        if a1t and a2t:
            return out, None
        if join == self.EXITJOIN:
            return out, None
        return out, join


# --------------------------------------------------------- value analysis
UNKNOWN_V = ('unknown',)
NIL_V = ('nil',)


def _unescape_luau(s):
    out = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch == '\\' and i + 1 < len(s):
            n = s[i + 1]
            if n.isdigit():
                j = i + 1
                while j < len(s) and j < i + 4 and s[j].isdigit():
                    j += 1
                out.append(chr(int(s[i + 1:j])))
                i = j
                continue
            out.append({'n': '\n', 't': '\t', 'r': '\r', '\\': '\\',
                        '"': '"', "'": "'"}.get(n, n))
            i += 2
            continue
        out.append(ch)
        i += 1
    return ''.join(out)


_STR_LIT_RE = re.compile(r'^"((?:[^"\\]|\\.)*)"$', re.S)
_NUM_LIT_RE = re.compile(r'^-?\d+(?:\.\d+)?$')
_NIDX_RE = re.compile(r'^n\[(\d+)\]$')
_NIDX2_RE = re.compile(r'^n\[(\d+)\]\[(.+)\]$', re.S)
_U_RE = re.compile(r'^U\[(\d+)\]$')
_H_RE = re.compile(r'^H\[(\d+)\]$')
_BOX_DEREF_RE = re.compile(r'^C\[6\]\[C\[5\]\]$')


def eval_expr(expr, state, cval):
    """Abstract value of a rendered expression under slot state."""
    e = expr.strip()
    m = _STR_LIT_RE.match(e)
    if m:
        return ('str', _unescape_luau(m.group(1)))
    if _NUM_LIT_RE.match(e):
        return ('num', float(e) if '.' in e else int(e))
    if e in ('true', 'false'):
        return ('bool', e == 'true')
    if e == 'nil':
        return NIL_V
    m = _NIDX_RE.match(e)
    if m:
        return state.get(int(m.group(1)), NIL_V)
    m = _NIDX2_RE.match(e)
    if m:
        base = int(m.group(1))
        kv = eval_expr(m.group(2), state, cval)
        if kv[0] in ('str', 'num'):
            return ('index', base, kv)
        if m.group(2).strip().startswith('n['):
            return ('index', base, ('slotexpr', m.group(2).strip()))
        return ('index', base, ('expr',))
    m = _U_RE.match(e)
    if m:
        return ('box', int(m.group(1)))
    if _BOX_DEREF_RE.match(e):
        if cval and cval[0] == 'box':
            return ('upvval', cval[1])
        return UNKNOWN_V
    if e == 'H':
        return ('hv',)
    m = _H_RE.match(e)
    if m:
        return ('hslot', int(m.group(1)))
    if e == 'J':
        return ('jv',)
    if e in ('V', 'L'):
        return ('seed', e)
    m = re.match(r'^proto_(child\d+|root)$', e)
    if m:
        return ('child', m.group(1))
    if e.startswith('{'):
        return ('table',)
    # call expression: find top-level '(' whose callee we can resolve
    ci = _call_split(e)
    if ci is not None:
        callee, args = ci
        cv = eval_expr(callee, state, cval)
        if cv[0] == 'index' and cv[2][0] == 'str':
            argvals = [eval_expr(a, state, cval)
                       for a in split_top_commas(args)] if args else []
            if cv[2][1] == 'GetService' and argvals and \
                    argvals[0][0] == 'str':
                return ('service', argvals[0][1])
            return ('callres', cv[2][1])
        return ('callres', None)
    return UNKNOWN_V


def _call_split(e):
    """If e is exactly `callee(args)`, return (callee, args)."""
    depth = 0
    in_str = None
    for i, ch in enumerate(e):
        if in_str:
            if ch == in_str:
                in_str = None
            continue
        if ch in '"\'':
            in_str = ch
        elif ch in '([{':
            if ch == '(' and depth == 0:
                if e.rstrip().endswith(')'):
                    return e[:i], e[i + 1:].rstrip()[:-1]
                return None
            depth += 1
        elif ch in ')]}':
            depth -= 1
    return None


SHARED_NAMES = {'C', '_', 'g', 'l', 'x', 'q', 'u', 'A', 'K', 'G', 'h',
                'b', 'V', 'L', 'U', 'H', 'J', 'e', 'O', 't', 'v', 'F',
                'r', 'W', 'a', 'B', 'R', 'Y', 'X', 'E', 'z', 'S', 'f',
                'y', 'i', 'P', 'w', 'c', 'D', 'N', 'T', 'Z', 'p', 's',
                'd', 'm', 'j', 'k', 'o', 'M', 'Q'}


def body_locals(effects):
    """Names declared `local` (or as inline function params) inside a
    body — these shadow proto-level names for that body."""
    names = set()
    for ln in effects:
        masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)
        for m in re.finditer(r'\blocal\s+((?:[A-Za-z_]\w*\s*,?\s*)+?)(?==|in\b|;|$)',
                             masked):
            for t in m.group(1).split(','):
                t = t.strip()
                if t:
                    names.add(t)
        for m in re.finditer(r'function\s*\(([^)]*)\)', masked):
            for t in m.group(1).split(','):
                t = t.strip()
                if t and t != '...':
                    names.add(t)
        for m in re.finditer(r'\bfor\s+([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)\s*[=,]',
                             masked):
            for t in m.group(1).split(','):
                names.add(t.strip())
    return names


def shared_refs(effects, skip_locals=True):
    """(reads, writes) of shared names in a body, first-touch aware."""
    reads, writes = set(), set()
    seen = set()
    locals_ = body_locals(effects) if skip_locals else set()
    for ln in effects:
        masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)
        masked = re.sub(r'--.*$', '', masked)
        for st in split_statements(masked):
            st = st.strip()
            # assignment targets
            targets = []
            m = re.match(r'^(?:local\s+)?([A-Za-z_][\w\s,]*?)\s*=(?![=~<>])',
                         st)
            if m and not st.startswith(('if ', 'while ', 'return')):
                targets = [t.strip() for t in m.group(1).split(',')]
            m2 = re.match(r'^([A-Za-z_]\w*)\s*[+\-*/%]=', st)
            if m2:
                targets = [m2.group(1)]
            idents = re.findall(r'[A-Za-z_]\w*', st)
            for w in idents:
                if w in SHARED_NAMES and w not in locals_:
                    if w in targets and w not in seen:
                        pass  # write-first: not a read
                    elif w not in writes or w in seen:
                        if w not in targets:
                            reads.add(w)
                    seen.add(w)
            for t in targets:
                if t in SHARED_NAMES and t not in locals_:
                    writes.add(t)
            seen |= set(targets)
    return reads, writes


_NASSIGN_RE = re.compile(
    r'^((?:n\[\d+\]|[A-Za-z_]\w*)\s*'
    r'(?:,\s*(?:n\[\d+\]|[A-Za-z_]\w*)\s*)*?)'
    r'\s*=(?![=~<>])\s*(.*)$', re.S)


def analyze_values(cfg):
    """Fixpoint slot-value analysis. Returns {key: in_state} where
    in_state maps slot -> abstract value at the record's entry."""
    keys = [k for k in cfg.recs if k in cfg.reachable]
    in_state = {k: {} for k in keys}
    out_state = {k: {} for k in keys}

    def transfer(key, state):
        rec = cfg.recs[key]
        st = dict(state)
        cval = None
        for ln in rec.effects:
            for stmt in split_statements(ln):
                s = stmt.strip()
                m = _ASSIGN_RE.match(s)
                if m is None and not s.startswith(
                        ('if ', 'while ', 'return', 'for ')):
                    m = _NASSIGN_RE.match(s)
                handled = False
                if m and not s.startswith(('if ', 'while ', 'return',
                                           'for ')):
                    targets = [t.strip() for t in m.group(1).split(',')]
                    rhs = split_top_commas(m.group(2))
                    if len(rhs) == len(targets):
                        handled = True
                        for t, r in zip(targets, rhs):
                            mm = _NIDX_RE.match(t)
                            if mm:
                                st[int(mm.group(1))] = eval_expr(
                                    r, st, cval)
                            elif t == 'C':
                                cval = eval_expr(r, st, cval)
                            elif t.startswith('n['):
                                pass
                    else:
                        for t in targets:
                            mm = _NIDX_RE.match(t)
                            if mm:
                                st[int(mm.group(1))] = UNKNOWN_V
                if not handled:
                    # any other write through n[k][...] mutates the
                    # value, not the binding: slot value degrades if
                    # it was a tracked index/method value
                    mm = re.match(r'^n\[(\d+)\]\[', s)
                    if mm:
                        cur = st.get(int(mm.group(1)))
                        if cur and cur[0] in ('index',):
                            st[int(mm.group(1))] = UNKNOWN_V
        return st

    changed = True
    rounds = 0
    while changed and rounds < 60:
        changed = False
        rounds += 1
        for k in keys:
            merged = {}
            preds = [p for p in cfg.pred.get(k, ()) if p in out_state]
            if k == cfg.entry or not preds:
                merged = {}
            else:
                allslots = set()
                for p in preds:
                    allslots |= set(out_state[p])
                for s in allslots:
                    vals = [out_state[p].get(s, NIL_V) for p in preds]
                    merged[s] = vals[0] if all(v == vals[0]
                                                for v in vals) \
                        else UNKNOWN_V
            if merged != in_state[k]:
                in_state[k] = merged
                changed = True
            new_out = transfer(k, in_state[k])
            if new_out != out_state[k]:
                out_state[k] = new_out
                changed = True
    return in_state
