#!/usr/bin/env python3
"""executor.py — Phase D payload-phase executor for StealAnEggs.

Executes the Luraph v15.1 bootstrap-VM payload interpreter IN CONTEXT:
the slot-15209 factory/middle/inner are run by a Python AST interpreter
(luau_interp.py) over the LIVE fz_sim objects (operand tables, streams,
fields, chunk), so the oracle-validated materializer closure fires with
its real captures at the moment payload code accesses each key — the
condition under which state-178 child builds terminate (Phase C2 showed
out-of-context builds diverge in the _z/v walker cycle).

Python-side simulation only; the target is never run in a Luau runtime.

Outputs (stageD/):
  executor_state.json   — run summary (trace, accesses, children)
  children_recovered.json — harvested child protos (descriptor, factory
                            args, operand-group snapshot)
  exec_log.txt          — human-readable event log
"""
import importlib.util
import json
import math
import os
import sys
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
STAGE2 = os.path.join(CASE, 'stage2')
RAW = os.environ.get('BVM_RAW') or \
    '/home/hatch/luau-deobf/work/stealaneggs/stealaneggs_raw.luau'
sys.path.insert(0, HERE)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


fz = load('fz_sim', os.path.join(STAGE2, 'fz_sim.py'))
import luau_interp as li
import mocks

LuaError = fz.LuaError
li.LuaError = LuaError  # unify: interp raises fz.LuaError


class ProbeTimeout(LuaError):
    """Materializer/Fz chain step-guard abort.  A LuaError so payload
    pcall blocks and activation error handling treat it as a runtime
    error instead of crashing the sweep."""
    pass

# ------------------------------------------------------------------ sY
class SyFn:
    """Marker for the VM table's sY coroutine-iterator helper."""
    def __repr__(self):
        return '<sY>'


SY = SyFn()


def sy_gen(rt, H, P, E, u):
    """Faithful transcription of the sY source:
        function(H,P,E,u) local A=H[95]; A();
            for H,X in P,E,u do A(true,H,X); end; end
    A is coroutine.yield: the first yield returns no values, then each
    generic-for step yields (true, k, v).  P is the iterator function,
    E the state, u the control variable."""
    yield []
    ctl = u
    while True:
        res = rt.call_value(P, [E, ctl], None)
        if not res or res[0] is None:
            return
        ctl = res[0]
        yield [True, res[0], res[1] if len(res) > 1 else None]


# ------------------------------------------------------------------ stdlib
class Stdlib:
    def __init__(self, rt):
        self.rt = rt
        fz_ = fz

        def pack(*a):
            t = fz.LT()
            for i, v in enumerate(a):
                t.d[i + 1] = v
            t.d[b'n'] = len(a)
            return t

        def select_(n, *a):
            if n == b'#':
                return li.Multi([len(a)])
            n = int(n)
            if n < 0:
                n = len(a) + n + 1
            return li.Multi(list(a[n - 1:]))

        def unpack_(t, i=None, j=None):
            if isinstance(t, fz.LT):
                if i is None:
                    i = 1
                if j is None:
                    j = 0
                    while t.d.get(j + 1) is not None:
                        j += 1
                return li.Multi([t.d.get(k) for k in
                                 range(int(i), int(j) + 1)])
            if isinstance(t, (list, tuple)):
                return li.Multi(list(t))
            raise LuaError('unpack on non-table')

        def next_(t, k=None):
            if not isinstance(t, fz.LT):
                raise LuaError('next on non-table')
            items = list(t.d.items())
            if k is None:
                if items:
                    return li.Multi([items[0][0], items[0][1]])
                return li.Multi([])
            kk = fz.num_key(k)
            for idx, (key, val) in enumerate(items):
                if key == kk:
                    if idx + 1 < len(items):
                        nk, nv = items[idx + 1]
                        return li.Multi([nk, nv])
                    return li.Multi([])
            return li.Multi([])

        def pairs_(t):
            return li.Multi([next_, t, None])

        def ipairs_iter(t, i):
            i = int(i) + 1
            v = fz.tget(t, i) if isinstance(t, fz.LT) else None
            if v is None:
                return li.Multi([])
            return li.Multi([i, v])

        def ipairs_(t):
            return li.Multi([ipairs_iter, t, 0])

        def table_move(t, a, b, dst, dstt=None):
            dstt = dstt if dstt is not None else t
            vals = [fz.tget_raw(t, k) for k in range(int(a), int(b) + 1)]
            for i, v in enumerate(vals):
                fz.tset_raw(dstt, int(dst) + i, v)
            return dstt

        def table_concat(t, sep=b'', i=1, j=None):
            if j is None:
                j = 0
                while fz.tget_raw(t, j + 1) is not None:
                    j += 1
            parts = []
            for k in range(int(i), int(j) + 1):
                parts.append(li.lua_tostring(fz.tget_raw(t, k)))
            s = sep if isinstance(sep, bytes) else li.lua_tostring(sep)
            return s.join(parts)

        def table_insert(t, *a):
            n = 0
            while t.d.get(n + 1) is not None:
                n += 1
            if len(a) == 1:
                t.d[n + 1] = a[0]
            else:
                pos = int(a[0])
                for k in range(n, pos - 1, -1):
                    t.d[k + 1] = t.d.get(k)
                t.d[pos] = a[1]

        def table_remove(t, pos=None):
            n = 0
            while t.d.get(n + 1) is not None:
                n += 1
            if pos is None:
                pos = n
            v = t.d.get(int(pos))
            for k in range(int(pos), n):
                t.d[k] = t.d.get(k + 1)
            t.d.pop(n, None)
            return v

        def pcall_(fn, *a):
            try:
                vals = rt.call_value(fn, list(a), None)
                return li.Multi([True] + vals)
            except li.BudgetExceeded:
                raise
            except LuaError as ex:
                return li.Multi([False, str(ex).encode()])
            except Exception as ex:
                rt.log_event('pcall-pyerror',
                             f'{type(ex).__name__}: {ex}'[:200])
                return li.Multi([False, f'{type(ex).__name__}: {ex}'
                                 .encode()])

        def xpcall_(fn, handler, *a):
            try:
                vals = rt.call_value(fn, list(a), None)
                return li.Multi([True] + vals)
            except LuaError as ex:
                try:
                    hv = rt.call_value(handler, [str(ex).encode()], None)
                    return li.Multi([False] + hv)
                except LuaError:
                    return li.Multi([False, str(ex).encode()])

        def error_(v=None, level=None):
            raise LuaError(li.lua_tostring(v).decode('utf-8', 'replace')
                           if v is not None else 'error')

        def assert_(v, msg=None):
            if not li.truthy(v):
                raise LuaError(li.lua_tostring(msg).decode(
                    'utf-8', 'replace') if msg is not None
                    else 'assertion failed!')
            return v

        def tostring_(v):
            if isinstance(v, mocks.Mock):
                return v._name.encode()
            if isinstance(v, mocks._Vec):
                return repr(v).encode()
            return li.lua_tostring(v)

        def tonumber_(v, base=None):
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                return v
            if isinstance(v, bytes):
                s = v.strip()
                try:
                    if base:
                        return int(s, int(base))
                    try:
                        return int(s)
                    except ValueError:
                        return float(s)
                except (ValueError, TypeError):
                    return None
            return None

        def type_(v):
            return li.lua_type(v).encode()

        def typeof_(v):
            if isinstance(v, mocks.Mock):
                rt.log_event('typeof-mock', v._name)
                return b'Instance'
            if isinstance(v, mocks._Vec):
                return v.kind.encode()
            return li.lua_type(v).encode()

        def co_wrap(fn):
            if isinstance(fn, SyFn):
                return li.WrappedCo(lambda *a: sy_gen(rt, *a), 'sY')
            if isinstance(fn, li.AstClosure):
                def _gen(*a):
                    vals = rt.call_value(fn, list(a), None)
                    yield list(vals)
                return li.WrappedCo(_gen, getattr(fn, 'tag', 'closure'))
            if callable(fn):
                def _gen2(*a):
                    r = fn(*a)
                    yield [] if r is None else [r]
                return li.WrappedCo(_gen2, 'pyfn')
            raise LuaError('coroutine.wrap on non-function')

        def co_yield(*a):
            raise LuaError('coroutine.yield outside a coroutine (executor)')

        def co_status(co):
            if isinstance(co, li.WrappedCo):
                return b'dead' if co.dead else b'suspended'
            return b'normal'

        def tick_():
            return rt.virtual_clock()

        def task_spawn(fn, *a):
            rt.task_queue.append(('spawn', fn, a))
            return mocks.Mock('thread')

        def task_defer(fn, *a):
            rt.task_queue.append(('defer', fn, a))
            return mocks.Mock('thread')

        def task_delay(sec, fn, *a):
            rt.task_queue.append(('delay', fn, a))
            return mocks.Mock('thread')

        def task_wait(sec=None):
            rt.log_event('task.wait', sec)
            return 0.0

        # string library (functions take the string as arg 1)
        def s_len(s):
            return len(s)

        def s_sub(s, i, j=None):
            return fz.string_sub(s, i, j)

        def s_byte(s, i=1, j=None):
            if j is None:
                j = i
            out = [s[k - 1] if 1 <= k <= len(s) else None
                   for k in range(int(i), int(j) + 1)]
            out = [o for o in out if o is not None]
            return li.Multi(out)

        def s_char(*a):
            return bytes(int(x) & 0xFF for x in a)

        def s_rep(s, n, sep=b''):
            if int(n) * max(1, len(s)) > 8_388_608:
                raise LuaError('string.rep result over executor cap')
            return sep.join([s] * int(n)) if sep else s * int(n)

        def s_reverse(s):
            return s[::-1]

        def s_upper(s):
            return s.upper()

        def s_lower(s):
            return s.lower()

        def s_find(s, pat, init=1, plain=False):
            if not plain:
                rt.log_event('string.find-pattern', pat)
            i = s.find(pat, int(init) - 1)
            if i < 0:
                return li.Multi([])
            return li.Multi([i + 1, i + len(pat)])

        def s_format(fmt, *a):
            rt.log_event('string.format', fmt)
            try:
                out = []
                ai = 0
                i = 0
                fb = fmt
                while i < len(fb):
                    c = fb[i:i + 1]
                    if c == b'%' and i + 1 < len(fb):
                        spec = fb[i + 1:i + 2]
                        if spec == b'%':
                            out.append(b'%')
                            i += 2
                            continue
                        if ai < len(a):
                            v = a[ai]
                            ai += 1
                            if spec in (b'd', b'i', b'u'):
                                out.append(str(int(v)).encode())
                            elif spec == b'q':
                                out.append(b'"' + li.lua_tostring(v) + b'"')
                            elif spec == b's':
                                out.append(li.lua_tostring(v))
                            else:
                                out.append(li.lua_tostring(v))
                            i += 2
                            continue
                    out.append(c)
                    i += 1
                return b''.join(out)
            except Exception:
                return fmt

        def s_split(s, sep=b','):
            if sep == b'':
                return _mk_lt(rt, [bytes([c]) for c in s])
            return _mk_lt(rt, s.split(sep))

        def s_gsub(s, pat, rep, n=None):
            rt.log_event('string.gsub-pattern', pat)
            if isinstance(rep, bytes):
                cnt = s.count(pat)
                return li.Multi([s.replace(pat, rep), cnt])
            return li.Multi([s, 0])

        string_lib = {
            b'len': s_len, b'sub': s_sub, b'byte': s_byte,
            b'char': s_char, b'rep': s_rep, b'reverse': s_reverse,
            b'upper': s_upper, b'lower': s_lower, b'find': s_find,
            b'format': s_format, b'split': s_split, b'gsub': s_gsub,
        }

        math_fns = {
            'floor': lambda x: math.floor(x), 'ceil': lambda x: math.ceil(x),
            'abs': abs, 'sqrt': math.sqrt, 'sin': math.sin,
            'cos': math.cos, 'tan': math.tan, 'asin': math.asin,
            'acos': math.acos, 'atan': math.atan,
            'atan2': math.atan2, 'exp': math.exp, 'log': math.log,
            'log10': math.log10, 'huge': math.inf, 'pi': math.pi,
            'max': lambda *a: max(a), 'min': lambda *a: min(a),
            'fmod': lambda a, b: a - math.floor(a / b) * b,
            'pow': lambda a, b: float(a) ** float(b),
            'deg': math.degrees, 'rad': math.radians,
            'sign': lambda x: (x > 0) - (x < 0),
            'clamp': lambda x, lo, hi: max(lo, min(hi, x)),
            'lerp': lambda a, b, t: a + (b - a) * t,
            'round': lambda x: math.floor(x + 0.5),
            'noise': lambda *a: 0.0,
            'random': rt.math_random,
            'randomseed': lambda *a: None,
        }

        def _u32(v):
            return int(v) & 0xFFFFFFFF

        def _arshift(v, n):
            v = _u32(v)
            if v & 0x80000000:
                v -= 0x100000000
            return _u32(v >> int(n)) if n >= 0 else _u32(v << -int(n))

        def _extract(v, f, w=1):
            return (_u32(v) >> int(f)) & ((1 << int(w)) - 1)

        def _replace(v, r, f, w=1):
            mask = ((1 << int(w)) - 1) << int(f)
            return _u32((_u32(v) & ~mask) | ((_u32(r) << int(f)) & mask))

        def _byteswap(v):
            v = _u32(v)
            return int.from_bytes(v.to_bytes(4, 'little'), 'big')

        bit32_fns = {
            'band': _variadic(fz.bit32_band), 'bor': _variadic(fz.bit32_bor),
            'bxor': _variadic(fz.bit32_bxor), 'bnot': fz.bit32_bnot,
            'lshift': fz.bit32_lshift, 'rshift': fz.bit32_rshift,
            'arshift': _arshift, 'lrotate': fz.bit32_lrotate,
            'rrotate': fz.bit32_rrotate, 'countlz': fz.bit32_countlz,
            'countrz': fz.bit32_countrz, 'extract': _extract,
            'replace': _replace, 'byteswap': _byteswap,
        }

        buffer_fns = {
            'create': lambda n: fz.buf_create(int(n)),
            'fromstring': lambda s: fz.buf_fromstring(bytes(s)),
            'tostring': fz.buf_tostring, 'len': fz.buf_len,
            'readu8': fz.buf_readu8, 'readi8': fz.buf_readi8,
            'readu16': fz.buf_readu16, 'readi16': fz.buf_readi16,
            'readu32': fz.buf_readu32, 'readi32': fz.buf_readi32,
            'readf32': fz.buf_readf32, 'readf64': fz.buf_readf64,
            'writeu8': fz.buf_writeu8, 'writei8': fz.buf_writei8,
            'writeu16': fz.buf_writeu16, 'writei16': fz.buf_writei16,
            'writeu32': fz.buf_writeu32, 'writei32': fz.buf_writei32,
            'writef32': fz.buf_writef32, 'writef64': fz.buf_writef64,
            'readstring': fz.buf_readstring,
            'writestring': fz.buf_writestring,
            'copy': fz.buf_copy, 'fill': fz.buf_fill,
            'readbits': fz.buf_readbits, 'writebits': fz.buf_writebits,
        }

        table_fns = {
            'create': fz.table_create, 'pack': pack, 'unpack': unpack_,
            'move': table_move, 'concat': table_concat,
            'insert': table_insert, 'remove': table_remove,
            'find': lambda t, v: next((k for k in _lt_keys(t)
                                       if t.d.get(k) is v), None),
            'freeze': lambda t: t, 'isfrozen': lambda t: False,
            'clear': lambda t: t.d.clear(),
            'clone': lambda t: _clone_lt(rt, t),
            'getn': lambda t: sum(1 for k in t.d if isinstance(k, int)),
        }

        coroutine_fns = {
            'wrap': co_wrap, 'yield': co_yield, 'status': co_status,
            'create': co_wrap, 'resume': lambda co, *a: li.Multi(
                [True] + rt.call_value(co, list(a), None)),
            'running': lambda: li.Multi([None, True]),
            'isyieldable': lambda: False, 'close': lambda co: True,
        }

        task_fns = {'spawn': task_spawn, 'defer': task_defer,
                    'delay': task_delay, 'wait': task_wait,
                    'cancel': lambda *a: None}

        os_fns = {'time': tick_, 'clock': tick_,
                  'date': lambda *a: mocks.Mock('os.date'),
                  'difftime': lambda a, b: a - b}

        self.globals = {
            'pack': pack, 'select': select_, 'unpack': unpack_,
            'next': next_, 'pairs': pairs_, 'ipairs': ipairs_,
            'pcall': pcall_, 'xpcall': xpcall_, 'error': error_,
            'assert': assert_, 'tostring': tostring_,
            'tonumber': tonumber_, 'type': type_, 'typeof': typeof_,
            'setmetatable': fz.setmetatable,
            'getmetatable': fz.getmetatable,
            'rawget': fz.tget_raw, 'rawset': fz.tset_raw,
            'rawequal': lambda a, b: li.lua_eq(a, b),
            'rawlen': lambda v: li.lua_len(rt, v),
            'print': lambda *a: rt.log_event('print', a),
            'warn': lambda *a: rt.log_event('warn', a),
            'tick': tick_, 'time': tick_,
            'getfenv': lambda *a: rt.env,
            'setfenv': lambda f, e: f,
            'require': lambda *a: mocks.Mock('require'),
            'loadstring': lambda *a: li.Multi([None, b'loadstring disabled '
                                               b'in executor']),
            'gcinfo': lambda: 0,
        }
        self.namespaces = {
            'string': {k.decode(): v for k, v in string_lib.items()},
            'math': math_fns, 'bit32': bit32_fns,
            'buffer': buffer_fns, 'table': table_fns,
            'coroutine': coroutine_fns, 'task': task_fns, 'os': os_fns,
        }
        self.string_lib = string_lib

    def ns_lt(self, name):
        t = fz.LT()
        for k, v in self.namespaces[name].items():
            t.d[k.encode()] = v
        return t

    def resolve_dotted(self, text):
        if '.' in text:
            ns, member = text.rsplit('.', 1)
            table = self.namespaces.get(ns)
            if table is not None and member in table:
                return table[member]
            return mocks.Mock(text)
        if text in self.globals:
            return self.globals[text]
        return mocks.Mock(text)


def _variadic(fn):
    def _f(*a):
        if not a:
            return 0
        r = a[0]
        for v in a[1:]:
            r = fn(r, v)
        return r
    return _f


def _lt_keys(t):
    return [k for k in t.d if isinstance(k, int)]


def _mk_lt(rt, vals):
    t = fz.LT()
    for i, v in enumerate(vals):
        t.d[i + 1] = v
    return t


def _clone_lt(rt, t):
    n = fz.LT()
    n.d.update(t.d)
    n.mt = t.mt
    return n


# ------------------------------------------------------------------ runtime
class Runtime:
    def __init__(self):
        self.fz = fz
        self.abort_counts = {}
        # always-on guard against divergent materializer/Fz chains:
        # walk steps allowed per outermost materialization chain
        self.mat_chain = {'depth': 0, 'count': 0,
                          'limit': int(os.environ.get(
                              'EXEC_MAT_GUARD', '3000000'))}
        self.buf_chain_bytes = 0
        self.interp = li.Interp(self)
        self.stdlib = Stdlib(self)
        self.string_lib = self.stdlib.string_lib
        self.env = None
        self.simH = None
        self.HLT = None
        self.structure = None
        self.fields = None
        self.chunk = None
        self.factory_closure = None
        self.traceinfo = None
        # logs / coverage
        self.events = []            # (kind, detail)
        self.decisions = []         # mock-dependent branch decisions
        self.accesses = []          # materializer __index fires
        self.trace = []             # (proto, mode, pc) executed
        self.trace_seen = set()
        self.factory_calls = []     # slot-15209 invocations (dz/bz)
        self.children = []          # harvested child records
        self.fz_frames = []         # mc Fz frame log
        self.task_queue = []
        self.pending_access = None  # innermost materializer access
        self.entered_178 = 0
        self.act_stack = []         # [tag, step_count]
        self.pctx = []              # (proto, mode, pc) context stack
        self.global_budget = int(os.environ.get('EXEC_BUDGET', '60000000'))
        self.act_budget = int(os.environ.get('EXEC_ACT_BUDGET', '8000000'))
        self.steps_total = 0
        self.table_tags = {}        # id(LT) -> label
        self._rng = [987654321]
        self.suppress_access_log = [False]

    # ---------- utilities ----------
    def log_event(self, kind, detail=None):
        self.events.append((kind, _short(detail)))
        return None

    def virtual_clock(self):
        return 1700000000.0 + self.steps_total * 0.001

    def math_random(self, *a):
        x = self._rng[0]
        x = (x * 1103515245 + 12345) & 0x7FFFFFFF
        self._rng[0] = x
        if not a:
            return x / 0x80000000
        if len(a) == 1:
            return 1 + x % int(a[0])
        lo, hi = int(a[0]), int(a[1])
        return lo + x % (hi - lo + 1)

    def tag_table(self, t, label):
        if isinstance(t, fz.LT):
            self.table_tags[id(t)] = label

    def cur_pctx(self):
        return self.pctx[-1] if self.pctx else ('<none>', None, None)

    # ---------- interpreter hooks ----------
    def step(self, fr, node):
        self.steps_total += 1
        if self.act_stack:
            self.act_stack[-1][1] += 1
            if self.act_stack[-1][1] > self.act_budget:
                raise li.BudgetExceeded(
                    f'activation budget in {self.act_stack[-1][0]}')
        if self.steps_total > self.global_budget:
            raise li.BudgetExceeded('global budget')

    def loop_iter(self, fr, node):
        self.step(fr, node)
        clo = fr.closure
        ti = getattr(clo, 'traceinfo', None) if clo is not None else None
        if ti is not None and id(node) in ti['loops']:
            pc = fr.get_local(ti['locP'])
            mode = fr.get_local(ti['locU'])
            key = (clo.tag, mode, pc)
            if key not in self.trace_seen:
                self.trace_seen.add(key)
                self.trace.append(key)
            if self.pctx and self.pctx[-1][0] == clo.tag:
                self.pctx[-1] = (clo.tag, mode, pc)

    # ---------- materializer chain guard ----------
    import contextlib as _cl

    @_cl.contextmanager
    def mat_scope(self):
        if self.mat_chain['depth'] == 0:
            self.mat_chain['count'] = 0
            self.buf_chain_bytes = 0
        self.mat_chain['depth'] += 1
        try:
            yield
        finally:
            self.mat_chain['depth'] -= 1

    # ---------- table access (materializer logging) ----------
    def tget(self, t, k):
        fz_ = fz
        kk = fz_.num_key(k) if k is not None else None
        miss = kk not in t.d
        fired = False
        if miss and t.mt is not None and \
                t.mt.d.get('__index') is not None:
            fired = True
        if fired and not self.suppress_access_log[0]:
            proto, mode, pc = self.cur_pctx()
            stream_val = None
            mt2 = t.d.get(fz_.num_key(-2))
            if isinstance(mt2, fz.LT):
                stream_val = mt2.d.get(kk)
            rec = {'table': self.table_tags.get(id(t), f't#{id(t) % 100000}'),
                   'key': kk if not isinstance(kk, bytes) else
                   kk.decode('utf-8', 'replace'),
                   'stream': stream_val, 'proto': proto, 'mode': mode,
                   'pc': pc, 'entered_178': False, 'result': None}
            self.accesses.append(rec)
            prev = self.pending_access
            self.pending_access = rec
            try:
                with self.mat_scope():
                    v = fz_.tget(t, k)
            finally:
                self.pending_access = prev
            rec['result'] = _typename(v)
            return v
        if miss:
            with self.mat_scope():
                return fz_.tget(t, k)
        return fz_.tget(t, k)

    def tset(self, t, k, v):
        return fz.tset(t, k, v)

    # ---------- decisions on mock-dependent control flow ----------
    def decide(self, kind, info):
        proto, mode, pc = self.cur_pctx()
        val = None
        handled = False
        if kind == 'cmpeq' and isinstance(info, tuple) \
                and len(info) == 2:
            # identity spoofing: an IdSentinel compared against a
            # scalar adopts it (self-calibration); later comparisons
            # answer consistently with the adopted value and log
            # contradictions (multiple gates demanding different
            # values for the same field).
            _a, _b = info
            _s = _a if isinstance(_a, mocks.IdSentinel) else \
                (_b if isinstance(_b, mocks.IdSentinel) else None)
            if _s is not None:
                other = _b if _s is _a else _a
                if (isinstance(other, (int, float))
                        and not isinstance(other, bool)) \
                        or isinstance(other, (bytes, str)):
                    handled = True
                    if _s.adopted is None:
                        _s.adopt(other, (proto, mode, pc))
                        val = True
                    else:
                        val = _s.adopted == other
                        if not val:
                            mocks.ilog('contradiction', _s.field,
                                       _s.adopted, other,
                                       (proto, mode, pc))
        if handled:
            pass
        elif kind == 'truthy':
            val = True            # Luau: any object is truthy
        elif kind == 'cmpeq':
            val = False           # distinct mocks are distinct objects
        elif kind.startswith('cmp'):
            val = False
        elif kind == 'len':
            val = 0
        elif kind == 'fornum':
            val = 0
        elif kind == 'arith':
            val = mocks.Mock('arith')
        else:
            val = None
        self.decisions.append({'kind': kind, 'proto': proto, 'mode': mode,
                               'pc': pc, 'info': _short(info),
                               'default': _short(val)})
        return val

    # ---------- calls ----------
    child_abort = True      # budget-abort in a nested activation -> mock
    abort_counts = None     # per-tag abort counter (set in __init__)
    call_depth = 0
    probe = None            # {'count': int, 'limit': int} during probes

    def call_value(self, fn, args, fr):
        fz_ = fz
        if isinstance(fn, li.AstClosure):
            tag = fn.tag or 'closure'
            self.act_stack.append([tag, 0])
            self.pctx.append((tag, None, None))
            self.call_depth += 1
            try:
                vals = self.interp.call_closure(fn, list(args), fr)
            except li.BudgetExceeded:
                # A nested activation that exhausts its budget (e.g. a
                # payload main-loop child) returns a mock to its caller
                # so coverage of the caller can continue.  The outermost
                # activation's budget still aborts the run.
                if self.child_abort and self.call_depth > 1 and \
                        self.abort_counts.get(tag, 0) < 3:
                    self.abort_counts[tag] = \
                        self.abort_counts.get(tag, 0) + 1
                    self.log_event('activation-abort', tag)
                    vals = [mocks.Mock(f'aborted:{tag}')]
                else:
                    raise
            finally:
                self.call_depth -= 1
                self.act_stack.pop()
                self.pctx.pop()
            # propagate proto tag/traceinfo factory->middle->inner
            for v in vals:
                if isinstance(v, li.AstClosure):
                    if not v.tag:
                        v.tag = tag
                    if v.traceinfo is None and fn.traceinfo is not None:
                        v.traceinfo = fn.traceinfo
            return vals
        if isinstance(fn, li.WrappedCo):
            return fn.resume(self, list(args))
        if isinstance(fn, SyFn):
            raise LuaError('sY called outside coroutine.wrap')
        if isinstance(fn, mocks.Mock):
            return [fn.call(*args)]
        if isinstance(fn, mocks._Namespace):
            raise LuaError('attempt to call a namespace')
        if isinstance(fn, fz.LuaFn):
            if fn.name == 'slot15209':
                return [self.invoke_factory(list(args))]
            clo = self.resolve_luafn(fn.name)
            if clo is not None:
                return self.call_value(clo, list(args), fr)
            raise LuaError(f'opaque LuaFn {fn.name} called')
        if callable(fn):
            r = fn(*args)
            if isinstance(r, li.Multi):
                return list(r.items)
            if r is None:
                return []
            return [r]
        raise LuaError(f'attempt to call a {li.lua_type(fn)} value')

    def invoke_factory(self, args):
        """Run the slot-15209 factory AST with H := HLT; returns the
        middle closure."""
        if args:
            args = [self.HLT] + list(args[1:])
        vals = self.interp.call_closure(self.factory_closure, args, None)
        return vals[0] if vals else None

    # ---------- luafn resolution (plain table functions) ----------
    _luafn_cache = {}

    def resolve_luafn(self, name):
        """Map a LuaFn name ('slot14' / field name) to an AstClosure by
        parsing its source span from the raw file with luau-ast."""
        if name in self._luafn_cache:
            return self._luafn_cache[name]
        self._luafn_cache[name] = None
        entry = self.table_map_index.get(name)
        if entry is None:
            return None
        try:
            clo = parse_function_at(self, entry, name)
            self._luafn_cache[name] = clo
            return clo
        except Exception as ex:
            self.log_event('luafn-parse-fail', (name, str(ex)[:120]))
            return None

    table_map_index = {}

    # ---------- fz frame / harvest hooks ----------
    def note_walk(self, scope, state):
        if self.probe is not None:
            self.probe['count'] += 1
            if self.probe['count'] > self.probe['limit']:
                raise ProbeTimeout(
                    f'probe step guard at {self.probe["count"]}')
        if self.mat_chain['depth'] > 0:
            self.mat_chain['count'] += 1
            if self.mat_chain['count'] > self.mat_chain['limit']:
                raise ProbeTimeout(
                    f'materializer chain guard at '
                    f'{self.mat_chain["count"]} walk steps')
        if scope == 'idx' and state == 178:
            self.entered_178 += 1
            if self.pending_access is not None:
                self.pending_access['entered_178'] = True


def _short(v):
    r = repr(v)
    return r if len(r) <= 80 else r[:77] + '...'


def _typename(v):
    if isinstance(v, li.AstClosure):
        return 'closure'
    if isinstance(v, fz.LuaFn):
        return 'luafn'
    if isinstance(v, tuple) and v and v[0] in li.TAGS:
        return str(v[0])
    return li.lua_type(v)


# ------------------------------------------------------------------ AST snippet parsing
def parse_function_at(rt, entry, tag):
    """Parse one table-literal function (raw span) into an AstClosure via
    the luau-ast CLI; cached under stageD/ast_cache/."""
    import hashlib
    import subprocess
    raw = rt.raw_text
    src = raw[int(entry['start']):int(entry['end'])]
    digest = hashlib.sha256(src.encode('utf-8', 'surrogateescape')
                            ).hexdigest()[:16]
    os.makedirs(os.path.join(HERE, 'ast_cache'), exist_ok=True)
    cache_path = os.path.join(HERE, 'ast_cache', f'{digest}.json')
    if os.path.exists(cache_path):
        doc = json.load(open(cache_path))
    else:
        wrapped = f'local f = {src}\nreturn f\n'
        tmp = os.path.join(HERE, 'ast_cache', f'{digest}.luau')
        with open(tmp, 'w', encoding='utf-8',
                  errors='surrogateescape') as fo:
            fo.write(wrapped)
        out = subprocess.run(
            [os.path.expanduser(os.environ.get(
                'BVM_LUAU_AST',
                '~/luau-deobf/tools/Luraph-Deobf-Tool-v5/bin/luau-ast')),
             tmp], capture_output=True, text=True, timeout=60)
        if out.returncode != 0:
            raise LuaError(f'luau-ast failed: {out.stderr[:200]}')
        doc = json.loads(out.stdout)
        with open(cache_path, 'w') as fo:
            json.dump(doc, fo)
    root = doc['root']
    fn_node = root['body'][0]['values'][0]
    return li.AstClosure(fn_node, [], rt.env, f'snip:{tag}', tag=tag)


# ------------------------------------------------------------------ value serialization (for JSON artifacts)
def ser_value(v, depth=0):
    if v is None or isinstance(v, (bool, int, float)):
        return v
    if isinstance(v, bytes):
        return {'$bytes': v.decode('latin-1')}
    if isinstance(v, str):
        return {'$str': v}
    if isinstance(v, fz.LT):
        return {'$lt': len(v.d)}
    if isinstance(v, fz.Buf):
        return {'$buf': v.id, 'len': len(v.data)}
    if isinstance(v, li.AstClosure):
        return {'$closure': v.tag or v.node.get('location')}
    if isinstance(v, fz.LuaFn):
        return {'$luafn': v.name}
    if isinstance(v, mocks.Mock):
        return {'$mock': v._name}
    if isinstance(v, mocks._Vec):
        return {'$vec': [v.kind] + list(v.comps)}
    if isinstance(v, tuple):
        return {'$tuple': [ser_value(x, depth + 1) for x in v]}
    return {'$other': repr(v)[:80]}


def snapshot_table(t):
    """Plain-data snapshot of an operand table + its [-2]/[-1] subtables."""
    def plain(lt):
        return {str(k): ser_value(v) for k, v in lt.d.items()}
    out = {'keys': plain(t)}
    for meta in (-2, -1):
        sub = t.d.get(fz.num_key(meta))
        if isinstance(sub, fz.LT):
            out[str(meta)] = plain(sub)
    return out


RT = None  # module-level runtime singleton (hooks reference it)


def install_hooks(rt):
    global RT
    RT = rt
    # walk_note: detect state-178 entries (children2.py pattern)
    _orig_walk_note = fz.walk_note

    def walk_note_wrap(scope, state):
        rt.note_walk(scope, state)
        return _orig_walk_note(scope, state)
    fz.walk_note = walk_note_wrap

    # mc: Fz frame log + child harvest
    _orig_mc = fz.mc

    def mc_wrap(H, name, *args):
        if name != 'Fz':
            return _orig_mc(H, name, *args)
        frame = {'id': len(rt.fz_frames),
                 'y': args[1] if len(args) > 1 else None,
                 'structure': args[0] if args else None,
                 'groups_before': len(fz.PROTO_TABLES),
                 'factory_before': len(rt.factory_calls),
                 'access': rt.pending_access}
        rt.fz_frames.append(frame)
        try:
            with rt.mat_scope():
                res = _orig_mc(H, name, *args)
            frame['error'] = None
            return res
        except Exception as ex:
            frame['error'] = f'{type(ex).__name__}: {ex}'[:200]
            raise
        finally:
            frame['groups'] = fz.PROTO_TABLES[frame['groups_before']:]
            frame['factory'] = rt.factory_calls[frame['factory_before']:]
            if frame['id'] > 0 and frame['groups']:
                harvest_frame(rt, frame)
    fz.mc = mc_wrap

    # LuaFn.__call__: slot 15209 -> run the factory AST (returns the
    # middle closure); other LuaFns resolve to their AstClosure value.
    def luafn_call(self, *args):
        fz.FN_CALLS.append((self.name, len(args)))
        if self.name == 'slot15209':
            rt.factory_calls.append({'args': args})
            mid = rt.invoke_factory(list(args))
            if isinstance(mid, li.AstClosure):
                mid.tag = f'proto{len(rt.factory_calls) - 1}'
                mid.traceinfo = rt.traceinfo
            return mid
        clo = rt.resolve_luafn(self.name)
        if clo is not None:
            return clo
        return fz.LuaFn(f'{self.name}()')
    fz.LuaFn.__call__ = luafn_call


def harvest_frame(rt, frame):
    for group in frame['groups']:
        gid = id(group[1]) if len(group) > 1 else id(group)
        seen = getattr(rt, 'harvested_group_ids', None)
        if seen is None:
            seen = rt.harvested_group_ids = set()
        if gid in seen:
            continue  # outer frames re-report inner groups; harvest once
        seen.add(gid)
        kind = group[0]
        rec = {'frame': frame['id'], 'descriptor_M': frame['y'],
               'kind': kind,
               'access': frame['access'],
               'factory': []}
        for fc in frame['factory']:
            a = fc['args']
            frec = {'nargs': len(a)}
            if len(a) >= 15:
                hdr = a[1]
                frec.update({
                    'u': a[3], 'mode': a[4], 'entry': a[14],
                    'hdr': [ser_value(fz.tget_raw(hdr, 1)),
                            ser_value(fz.tget_raw(hdr, 2))]
                    if isinstance(hdr, fz.LT) else None})
            rec['factory'].append(frec)
        if kind == 'dz':
            rec['tables'] = [snapshot_table(t) for t in group[1:]]
            # walk snapshot: the child's INITIAL state (streams /
            # fields / chunk as of its build).  The disasm2 walk
            # simulates decryptors itself, so it must start from the
            # pre-execution state, not the live post-execution one.
            snap = {'streams': [], 'fields': None, 'chunk': None}
            for t in group[1:]:
                sub = t.d.get(fz.num_key(-2))
                snap['streams'].append(
                    {int(k): v for k, v in sub.d.items()
                     if isinstance(k, int)} if isinstance(sub, fz.LT)
                    else {})
            st = frame.get('structure')
            if isinstance(st, fz.LT):
                f6 = st.d.get(6)
                c5 = st.d.get(5)
                if isinstance(f6, fz.LT):
                    snap['fields'] = {int(k): v for k, v in f6.d.items()
                                      if isinstance(k, int)}
                if isinstance(c5, fz.Buf):
                    snap['chunk'] = bytes(c5.data)
            rt.children_live.append(
                {'group': group, 'factory_args':
                 [fc['args'] for fc in frame['factory']],
                 'frame': frame['id'], 'M': frame['y'],
                 'walk_snapshot': snap})
        else:
            rec['tables'] = [snapshot_table(group[1])]
            rt.children_live.append(
                {'group': group, 'factory_args':
                 [fc['args'] for fc in frame['factory']],
                 'frame': frame['id'], 'M': frame['y']})
        rt.children.append(rec)
        pid = f'child{len(rt.children)}'
        rec['pid'] = pid
        if kind == 'dz':
            for i, t in enumerate(group[1:]):
                rt.tag_table(t, f'{pid}:operand{i}')
                sub = t.d.get(fz.num_key(-2))
                if isinstance(sub, fz.LT):
                    rt.tag_table(sub, f'{pid}:stream{i}')
        rt.log_event('child-harvested',
                     (rec['frame'], kind, frame['y'],
                      rec['factory'][0].get('entry')
                      if rec['factory'] else None))


class _BoundedLog(list):
    """OPLOG replacement: fz appends one string per buffer op; over a
    long probing sweep that is an unbounded memory sink.  Keep a
    bounded tail (the oracle comparison that used OPLOG is a stage-2
    concern, not phase D)."""

    def append(self, x):
        if len(self) < 250_000:
            super().append(x)


def build_runtime():
    rt = Runtime()
    rt.children_live = []
    fz.OPLOG = _BoundedLog()
    # Allocation guard: descriptor decodes can request buffer.create
    # with garbage sizes (single multi-GB bytearray -> OOM kill before
    # any step guard can fire).  Legit buffers in this case are <= the
    # 617KB stage-1 work buffer; cap materializer creations at 8MB.
    _orig_buf_create = fz.buf_create
    _alloc_total = [0]

    def buf_create_capped(n, log=True):
        n = int(n)
        if n > 8_388_608 or n < 0:
            raise LuaError(f'buffer.create size {n} over executor cap')
        _alloc_total[0] += n
        if _alloc_total[0] > 1_500_000_000:
            raise LuaError('buffer allocation global cap (1.5GB)')
        if rt.mat_chain['depth'] > 0:
            rt.buf_chain_bytes += n
            if rt.buf_chain_bytes > 67_108_864:
                raise LuaError('buffer allocation chain cap (64MB)')
        return _orig_buf_create(n, log=log)
    fz.buf_create = buf_create_capped
    _orig_buf_fromstring = fz.buf_fromstring

    def buf_fromstring_capped(s, log=True):
        if len(s) > 8_388_608:
            raise LuaError('buffer.fromstring over executor cap')
        _alloc_total[0] += len(s)
        return _orig_buf_fromstring(s, log=log)
    fz.buf_fromstring = buf_fromstring_capped
    # fz.buf_copy has NO bounds check: slice assignment at a garbage
    # descriptor offset pads the destination bytearray to that offset
    # (instant multi-GB allocation -> OOM kill).  Real Luau buffers are
    # fixed-size and buffer.copy errors out of bounds; wrap it.
    _orig_buf_copy = fz.buf_copy

    def buf_copy_safe(dst, doff, src, soff, count=None, log=True):
        doff = int(doff)
        soff = int(soff)
        cnt = (len(src.data) - soff) if count is None else int(count)
        if doff < 0 or soff < 0 or cnt < 0 or \
                doff + cnt > len(dst.data) or soff + cnt > len(src.data):
            raise LuaError(
                f'buffer.copy OOB (dst #{dst.id} @{doff} +{cnt} of '
                f'{len(dst.data)}; src #{src.id} @{soff} of '
                f'{len(src.data)})')
        return _orig_buf_copy(dst, doff, src, soff, count, log=log)
    fz.buf_copy = buf_copy_safe
    # ---- stage-1 inputs (oracle-validated sim) ----
    cap_in = fz.build_inputs()
    E_real = cap_in['E']
    simH = fz.build_H()
    simH.cz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['cz'].items()})
    simH.gz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['gz'].items()})
    rt.simH = simH
    # buffers aligned with the real run: #1 oz, #2 work, #3 chunk
    simH.oz = fz.buf_create(16, log=False)
    work_src = open(os.path.join(CASE, 'static', 'src.bin'), 'rb').read()
    work = fz.buf_fromstring(work_src, log=False)
    chunk = fz._new_buf(bytearray(E_real[5]))
    assert (simH.oz.id, work.id, chunk.id) == (1, 2, 3)
    simH.w = work
    rt.chunk = chunk
    # structure
    A = fz.LT()
    fz.tset(A, 4, E_real[4])
    fz.tset(A, 5, chunk)
    fields = fz.LT()
    for k, v in E_real[6].items():
        fz.tset(fields, k, v)
    fz.tset(A, 6, fields)
    rt.structure = A
    rt.fields = fields
    rt.tag_table(A, 'structure')
    rt.tag_table(fields, 'fields')
    # ---- environment (getfenv table) ----
    globs = dict(rt.stdlib.globals)
    for ns in ('math', 'string', 'table', 'bit32', 'buffer', 'coroutine',
               'task', 'os'):
        globs[ns] = rt.stdlib.ns_lt(ns)
    env = mocks.build_env(fz, globs)
    rt.env = env
    rt.tag_table(env, 'env')
    # ---- raw text + table map index (for LuaFn resolution) ----
    rt.raw_text = open(RAW, encoding='utf-8',
                       errors='surrogateescape').read()
    tm = json.load(open(os.path.join(STAGE2, 'table_map.json')))
    idx = {}
    for e in tm['entries']:
        if e.get('kind') != 'function':
            continue
        if e['key_type'] == 'slot':
            idx[f'slot{e["key"]}'] = e
        else:
            idx[e['key']] = e
            idx[e['key'].capitalize()] = e
            idx[e['key'].title()] = e
    rt.table_map_index = idx
    rt.table_map = tm
    # ---- HLT: the payload-visible VM table as a real LT ----
    HLT = fz.LT()
    rt.HLT = HLT
    rt.tag_table(HLT, 'H')
    std = rt.stdlib
    slot_override = {
        27: std.globals['pack'], 86: std.globals['select'],
        32: std.globals['pairs'], 127: std.globals['ipairs'],
        47: std.globals['pcall'], 45: std.globals['xpcall'],
        115: std.namespaces['table']['unpack'],
        125: std.globals['next'], 92: std.namespaces['table']['move'],
        13: std.globals['type'], 90: std.globals['type'],
        16: std.globals['tonumber'], 54: std.globals['tostring'],
        40: std.namespaces['table']['concat'],
        68: std.namespaces['string']['find'],
        87: std.namespaces['string']['gsub'],
        88: std.namespaces['string']['format'],
        57: std.namespaces['string']['find'],
        95: std.namespaces['coroutine']['yield'],
        79: std.namespaces['coroutine']['create'],
        66: std.namespaces['coroutine']['close'],
        98: std.namespaces['coroutine']['status'],
        101: std.namespaces['coroutine']['isyieldable'],
        123: std.globals['setfenv'],
        12: lambda *a: mocks.Mock('Instance.new'),
    }
    for k, v in simH.slot.items():
        HLT.d[k] = slot_override.get(k, v)
    # dotted / expr / table / string entries from the table literal
    for e in tm['entries']:
        kind = e.get('kind')
        if e['key_type'] == 'slot' or isinstance(e['key'], int):
            key = int(e['key'])
        else:
            key = e['key'].encode()
        if key in HLT.d:
            continue
        if kind == 'dotted':
            HLT.d[key] = std.resolve_dotted(e['text'])
        elif kind == 'function':
            name = f'slot{e["key"]}' if e['key_type'] == 'slot' else e['key']
            HLT.d[key] = fz.LuaFn(name)
        elif kind == 'string':
            HLT.d[key] = e['text'].encode('latin-1', 'surrogateescape')
        elif kind == 'expr':
            txt = e['text'].strip()
            try:
                HLT.d[key] = int(txt)
            except ValueError:
                try:
                    HLT.d[key] = float(txt)
                except ValueError:
                    HLT.d[key] = mocks.Mock(f'H.expr:{txt[:24]}')
        elif kind == 'table':
            HLT.d[key] = fz.LT()
    # method fields (Fz family) as bound mc wrappers returning Multi
    for name in fz.METHODS:
        def _bound(*a, _name=name):
            return li.Multi(fz.mc(simH, _name, *a))
        HLT.d.setdefault(name.encode(), _bound)
    for name in fz.FUNC_FIELDS:
        if name.encode() not in HLT.d and name not in fz.METHODS:
            HLT.d[name.encode()] = fz.LuaFn(name)
    # data fields the Fz-phase sim keeps as attributes
    dec = load('dec1', os.path.join(CASE, 'static', 'decode_stage1.py'))
    MY, yy, _tbl = dec.extract_vm_fields(rt.raw_text)
    HLT.d[b'MY'] = MY
    HLT.d[b'YY'] = yy
    y_lt = fz.LT()
    _Y = _tbl
    if isinstance(_Y, dict):
        for k, v in _Y.items():
            y_lt.d[k if isinstance(k, bytes) else str(k).encode()] = \
                v if isinstance(v, bytes) else str(v).encode(
                    'latin-1', 'surrogateescape')
    HLT.d[b'_Y'] = y_lt
    HLT.d[b'bY'] = env
    HLT.d[b'sY'] = SY
    HLT.d[b'U'] = simH.U
    HLT.d[b'I'] = simH.I
    HLT.d[b'cz'] = simH.cz
    HLT.d[b'gz'] = simH.gz
    HLT.d[b'oz'] = simH.oz
    HLT.d[b'w'] = work
    HLT.d[99] = 0
    rt.tag_table(simH.U, 'H.U')
    rt.tag_table(simH.I, 'H.I')
    # ---- factory AST + traceinfo ----
    fac_doc = json.load(open(os.path.join(STAGE2, 'factory_ast.json')))
    fac_node = fac_doc['root']['body'][0]['values'][0]

    def returned_fn(fn_node):
        for st in fn_node['body']['body']:
            if st['type'] == 'AstStatReturn':
                return st['list'][0]
        return None
    mid_node = returned_fn(fac_node)
    inner_node = returned_fn(mid_node)
    locP = locU = None
    for st in inner_node['body']['body']:
        if st['type'] == 'AstStatLocal' and not st['values']:
            names = {v['name'] for v in st['vars']}
            if {'P', 'u'} <= names:
                for v in st['vars']:
                    if v['name'] == 'P':
                        locP = v['location']
                    if v['name'] == 'u':
                        locU = v['location']
    loops = set()

    def collect(x):
        if isinstance(x, dict):
            if x.get('type') == 'AstStatWhile':
                loops.add(id(x))
            for v in x.values():
                collect(v)
        elif isinstance(x, list):
            for v in x:
                collect(v)
    collect(inner_node)
    rt.traceinfo = {'locP': locP, 'locU': locU, 'loops': loops}
    rt.factory_closure = li.AstClosure(fac_node, [], env, 'factory',
                                       tag='factory15209')
    rt.factory_closure.traceinfo = rt.traceinfo
    install_hooks(rt)
    return rt


def run_root(rt):
    res = fz.mc(rt.simH, 'Fz', rt.structure, 201, 20)
    rootZ = res[0] if isinstance(res, tuple) else res
    rt.log_event('root-build-done', ('groups', len(fz.PROTO_TABLES),
                                     'Z', _typename(rootZ)))
    if len(fz.PROTO_TABLES) >= 1 and fz.PROTO_TABLES[0][0] == 'dz':
        for i, t in enumerate(fz.PROTO_TABLES[0][1:]):
            rt.tag_table(t, f'root:operand{i}')
            sub = t.d.get(fz.num_key(-2))
            if isinstance(sub, fz.LT):
                rt.tag_table(sub, f'root:stream{i}')
    status = {}
    try:
        inner_vals = rt.call_value(rootZ, [None, rt.simH.U, None], None)
        inner = inner_vals[0] if inner_vals else None
        rt.log_event('root-inner-created', _typename(inner))
        out = rt.call_value(inner, [], None)
        status = {'status': 'returned',
                  'values': [_typename(v) for v in out]}
    except li.BudgetExceeded as ex:
        status = {'status': 'budget', 'detail': str(ex)}
    except LuaError as ex:
        status = {'status': 'luaerror', 'detail': str(ex)[:400],
                  'pctx': rt.cur_pctx(),
                  'trace_tail': rt.trace[-5:]}
    except Exception as ex:
        status = {'status': 'pyerror',
                  'detail': f'{type(ex).__name__}: {ex}'[:400],
                  'tb': traceback.format_exc()[-3000:]}
    # drain deferred task queue (bounded)
    drained = 0
    while rt.task_queue and drained < 64:
        kind, fn, a = rt.task_queue.pop(0)
        drained += 1
        try:
            rt.call_value(fn, list(a), None)
            rt.log_event('task-drained', kind)
        except li.BudgetExceeded as ex:
            rt.log_event('task-budget', str(ex))
            break
        except Exception as ex:
            rt.log_event('task-error', f'{type(ex).__name__}: {ex}'[:160])
    status['tasks_drained'] = drained
    return status


def write_state(rt, status):
    state = {
        'status': status,
        'steps_total': rt.steps_total,
        'trace_count': len(rt.trace),
        'trace': [list(t) for t in rt.trace],
        'accesses_count': len(rt.accesses),
        'accesses_178': sum(1 for a in rt.accesses if a['entered_178']),
        'entered_178': rt.entered_178,
        'decisions_count': len(rt.decisions),
        'decisions': rt.decisions[:4000],
        'factory_calls': [
            {'nargs': len(fc['args']),
             'u': fc['args'][3] if len(fc['args']) > 3 else None,
             'mode': fc['args'][4] if len(fc['args']) > 4 else None,
             'entry': fc['args'][13] if len(fc['args']) > 13 else None}
            for fc in rt.factory_calls],
        'proto_tables': len(fz.PROTO_TABLES),
        'children_count': len(rt.children),
        'events_tail': rt.events[-400:],
        'mock_log_tail': mocks.MOCKLOG[-400:],
    }
    with open(os.path.join(HERE, 'executor_state.json'), 'w') as fo:
        json.dump(state, fo, indent=1, default=str)
    with open(os.path.join(HERE, 'children_recovered.json'), 'w') as fo:
        json.dump(rt.children, fo, indent=1, default=str)
    with open(os.path.join(HERE, 'exec_log.txt'), 'w') as fo:
        for kind, detail in rt.events:
            fo.write(f'{kind}: {detail}\n')
        fo.write(f'\n-- mock log ({len(mocks.MOCKLOG)}) --\n')
        for entry in mocks.MOCKLOG:
            fo.write(f'{entry}\n')


def main():
    t0 = time.time()
    rt = build_runtime()
    print(f'[executor] setup done in {time.time() - t0:.1f}s; '
          f'building root...', flush=True)
    status = run_root(rt)
    print(f'[executor] root run: {status.get("status")} '
          f'({time.time() - t0:.1f}s) steps={rt.steps_total} '
          f'trace={len(rt.trace)} accesses={len(rt.accesses)} '
          f'children={len(rt.children)}', flush=True)
    if status.get('tb'):
        print(status['tb'], flush=True)
    write_state(rt, status)
    print('[executor] state written', flush=True)


if __name__ == '__main__':
    sys.setrecursionlimit(200000)

    def _run():
        try:
            main()
        except Exception:
            traceback.print_exc()

    th = threading.Thread(target=_run)
    try:
        threading.stack_size(1024 * 1024 * 1024)
    except (ValueError, RuntimeError):
        threading.stack_size(256 * 1024 * 1024)
    th = threading.Thread(target=_run)
    th.start()
    th.join()
