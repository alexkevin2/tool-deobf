#!/usr/bin/env python3
"""identity.py — automatic game-ID spoofing, bootstrap route
(--spoof-id auto).  THIN ADAPTER over the shared spoof engine
(spoof_engine.py, vendored in this directory; canonical copy at the
v6 tool root).  All portable semantics — co-occurrence extraction,
presence scan, seed resolution, sweep-log shaping, report shapes —
live in the engine; this module keeps only the bootstrap route's
calling conventions and docstring contract.

Static half: gate-site extraction over the stage-2 walk records
(proto_structs.json — per-instruction resolved operand constants K)
plus a field-presence scan over the eager materialization
(protos.json).  An instruction whose K operands contain an identity
field name (PlaceId / JobId / CreatorId / PlaceVersion / GameId)
together with numeric operands yields those numbers as candidates
for the field (kind 'same-instruction').

Execution half: mocks.py serves the game mock's identity fields
from the seed (only when a field has exactly one static candidate)
or as an IdSentinel; executor.Runtime.decide captures the first
scalar a sentinel is compared against and adopts it (the Python
interpreter routes mock equality through decide('cmpeq'), so —
unlike the Luau sandbox, where == never fires __eq for
table-vs-number — true comparison capture works here).  All seeds,
reads, captures and contradictions are logged (mocks.IDENTITYLOG)
and harvested by sweepE into sweepE_state.json; luraph_bvm.py
assembles identity_report.json from the static + sweep halves.

No game ID is hardcoded here or in the engine: every served value
comes from extract_structs over the analysed script, from a
comparison capture, or from the caller-supplied seed file (which
luraph_bvm.py derives from extraction, never types in).
"""
import os

try:
    import spoof_engine as _engine
except ImportError:  # isolated copy: load the vendored/root engine
    import importlib.util as _ilu
    _here = os.path.dirname(os.path.abspath(__file__))
    _engine = None
    for _p in (os.path.join(_here, 'spoof_engine.py'),
               os.path.join(_here, '..', '..', '..', '..',
                            'spoof_engine.py')):
        if os.path.isfile(_p):
            _spec = _ilu.spec_from_file_location('spoof_engine', _p)
            _engine = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_engine)
            break
    if _engine is None:
        raise

IDENTITY_FIELDS = _engine.IDENTITY_FIELDS

# Re-exported engine functions (same names/signatures as before,
# so luraph_bvm.py, sweepE.py and tests need no changes).
extract_structs = _engine.extract_cooccurrence
extract_materialized = _engine.extract_field_presence
build_seed = _engine.build_seed
log_to_state = _engine.log_to_state


def build_report(static_cands, static_seen, mat_seen, sweep_state,
                 notes):
    return _engine.build_report_legacy_bootstrap(
        static_cands, static_seen, mat_seen, sweep_state, notes)


def report_section(rep):
    return _engine.report_section_legacy_bootstrap(rep)
