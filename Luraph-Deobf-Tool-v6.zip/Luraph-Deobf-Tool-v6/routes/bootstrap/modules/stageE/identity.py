#!/usr/bin/env python3
"""identity.py — automatic game-ID spoofing, bootstrap route
(--spoof-id auto).

Static half: gate-site extraction over the stage-2 walk records
(proto_structs.json — per-instruction resolved operand constants K)
plus a field-presence scan over the eager materialization
(protos.json).  An instruction whose K operands contain an identity
field name (PlaceId / JobId / CreatorId / PlaceVersion / GameId)
together with numeric operands yields those numbers as candidates
for the field (kind 'same-instruction').

Execution half: mocks.py serves the game mock's identity fields
from the seed (only when a field has exactly one static candidate)
or as an IdSentinel; executor.Runtime.decide captures the first
scalar a sentinel is compared against and adopts it (the Python
interpreter routes mock equality through decide('cmpeq'), so —
unlike the Luau sandbox, where == never fires __eq for
table-vs-number — true comparison capture works here).  All seeds,
reads, captures and contradictions are logged (mocks.IDENTITYLOG)
and harvested by sweepE into sweepE_state.json; luraph_bvm.py
assembles identity_report.json from the static + sweep halves.
"""
import ast

IDENTITY_FIELDS = ('PlaceId', 'JobId', 'CreatorId', 'PlaceVersion',
                   'GameId')


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _decode_other(entry):
    """proto_structs K entries encode byte strings as
    {'other': "b'...'"}; materialized constants may carry the
    bare repr string "b'...'".  Return the decoded str or None."""
    if isinstance(entry, dict) and 'other' in entry:
        return _decode_other(entry['other'])
    if isinstance(entry, str):
        if entry.startswith(("b'", 'b"')):
            try:
                b = ast.literal_eval(entry)
            except Exception:
                return None
            if isinstance(b, bytes):
                return b.decode('utf-8', 'replace')
            return None
        return entry
    return None


def extract_structs(structs):
    """structs: {pid: {'instructions': [{mode, pc, name, K}]}}.
    Returns (candidates, fields_seen) — candidates maps field ->
    [{value, kind, evidence:[{proto, mode, pc, op}]}]."""
    candidates = {}
    fields_seen = {}

    def add(field, value, pid, ins):
        lst = candidates.setdefault(field, [])
        for c in lst:
            if c['value'] == value:
                c['evidence'].append({'proto': pid,
                                      'mode': ins.get('mode'),
                                      'pc': ins.get('pc'),
                                      'op': ins.get('name')})
                return
        lst.append({'value': value, 'kind': 'same-instruction',
                    'evidence': [{'proto': pid,
                                  'mode': ins.get('mode'),
                                  'pc': ins.get('pc'),
                                  'op': ins.get('name')}]})

    for pid, st in (structs or {}).items():
        if not isinstance(st, dict):
            continue
        for ins in st.get('instructions') or []:
            K = ins.get('K') or []
            names = [s for s in (_decode_other(e) for e in K) if s]
            nums = [e for e in K if _is_num(e)]
            for name in names:
                if name in IDENTITY_FIELDS:
                    fields_seen.setdefault(name, [])
                    loc = f"{pid} {ins.get('mode')}:{ins.get('pc')}"
                    if loc not in fields_seen[name]:
                        fields_seen[name].append(loc)
                    for n in nums:
                        add(name, n, pid, ins)
    return candidates, fields_seen


def extract_materialized(protos_doc):
    """Scan stage-2 protos.json (eager materialization) for identity
    field names among materialized constants.  Returns
    {field: [locations]} — presence evidence only (the materializer
    resolves constants out of instruction context, so co-occurring
    numbers are NOT treated as candidates)."""
    seen = {}

    def walk(o, path):
        if isinstance(o, dict):
            for k, v in o.items():
                walk(v, f'{path}/{k}')
        elif isinstance(o, list):
            for i, v in enumerate(o):
                walk(v, f'{path}/{i}')
        elif isinstance(o, str):
            s = _decode_other(o) if o.startswith("b'") else o
            if s in IDENTITY_FIELDS:
                seen.setdefault(s, []).append(path)

    if isinstance(protos_doc, dict):
        walk(protos_doc, '')
    return seen


def build_seed(candidates):
    """Seed only unambiguous fields (exactly one distinct static
    candidate value).  Ambiguous fields stay sentinel-served so the
    executor's comparison capture can calibrate them."""
    seed = {}
    for f, lst in (candidates or {}).items():
        vals = []
        for c in lst:
            if c['value'] not in vals:
                vals.append(c['value'])
        if len(vals) == 1:
            seed[f] = vals[0]
    return seed


def log_to_state(entries):
    """mocks.IDENTITYLOG tuples -> JSON-able state dict."""
    st = {'seeded': [], 'reads': [], 'captures': [],
          'contradictions': []}
    for e in entries or []:
        kind = e[0]
        if kind == 'seed':
            st['seeded'].append({'field': e[1], 'value': e[2],
                                 'source': e[3]})
        elif kind == 'read':
            st['reads'].append({'field': e[1], 'value': e[2],
                                'source': e[3]})
        elif kind == 'capture':
            st['captures'].append({'field': e[1], 'value': e[2],
                                   'site': list(e[3])})
        elif kind == 'contradiction':
            st['contradictions'].append(
                {'field': e[1], 'adopted': e[2], 'compared': e[3],
                 'site': list(e[4])})
    return st


def build_report(static_cands, static_seen, mat_seen, sweep_state,
                 notes):
    fields_seen = {}
    for src in (static_seen, mat_seen):
        for f, locs in (src or {}).items():
            fields_seen.setdefault(f, [])
            for loc in locs:
                if loc not in fields_seen[f]:
                    fields_seen[f].append(loc)
    return {
        'feature': 'spoof-id',
        'mode': 'auto',
        'route': 'bootstrap',
        'fields_seen': fields_seen,
        'candidates': {f: static_cands[f]
                       for f in sorted(static_cands or {})},
        'seed': (sweep_state or {}).get('seeded', []),
        'captures': (sweep_state or {}).get('captures', []),
        'contradictions': (sweep_state or {}).get('contradictions',
                                                 []),
        'identity_reads_total': len((sweep_state or {})
                                    .get('reads', [])),
        'identity_reads': (sweep_state or {}).get('reads', [])[:200],
        'notes': notes,
    }


def report_section(rep):
    L = []
    L.append('')
    L.append('## Identity spoofing (--spoof-id auto)')
    L.append('')
    seen = rep.get('fields_seen') or {}
    cands = rep.get('candidates') or {}
    if not seen and not cands:
        L.append('- no game-identity field names found among the '
                 'materialized constants or walked instructions; '
                 'no spoofing was applied.')
    for f in sorted(seen):
        L.append(f'- `{f}` seen at: {", ".join(seen[f][:4])}'
                 + (' ...' if len(seen[f]) > 4 else ''))
    for f in sorted(cands):
        vals = ', '.join(f"{c['value']!r} ({c['kind']})"
                         for c in cands[f])
        L.append(f'- `{f}` candidates: {vals}')
    for s in rep.get('seed') or []:
        L.append(f"- seeded {s['field']} = {s['value']!r} "
                 f"({s['source']})")
    for c in rep.get('captures') or []:
        L.append(f"- captured {c['field']} = {c['value']!r} at "
                 f"{c['site']} (self-calibrating comparison)")
    for c in rep.get('contradictions') or []:
        L.append(f"- contradiction on {c['field']}: adopted "
                 f"{c['adopted']!r} but compared against "
                 f"{c['compared']!r} at {c['site']}")
    L.append(f"- identity reads during the sweep: "
             f"{rep.get('identity_reads_total', 0)}")
    for n in rep.get('notes') or []:
        L.append(f'- note: {n}')
    L.append('- full detail: identity_report.json')
    return '\n'.join(L) + '\n'
