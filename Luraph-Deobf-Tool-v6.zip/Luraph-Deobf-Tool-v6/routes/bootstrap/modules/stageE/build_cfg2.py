#!/usr/bin/env python3
"""build_cfg2.py — build COMPLETED control-flow graphs for every
proto from the disasm2 walk records, restoring the dynamic edges
that proto_structs.json's first-visit `succ` serialization drops:

  edges = recorded succ            (provenance 'walk-succ')
        + mode-switch targets      (provenance 'walk-switch')
        + jmpr_followed unions     (provenance 'walk-jmpr': every
          target the symbolic walk ever followed from a JMPR node,
          harvested by stage2/children2.py into jmpr_harvest.json)

Writes stageE/cfg2.json (consumed by clean2_lib.py).  Tool copy of
the case file (stageD/build_cfg2.py) with the harvest source
switched to the in-tree jmpr_harvest.json.
"""
import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

U2MODE = {114: 'A', 49: 'B', 210: 'C', 113: 'D'}
JMPR_OP = {'A': 9, 'B': 57, 'C': 128}


def load_jmpr():
    jmpr = {}     # pid -> {(mode,pc): [targets]}
    unres = {}
    path = os.path.join(HERE, '..', 'stage2', 'jmpr_harvest.json')
    harvest = {}
    if os.path.isfile(path):
        harvest = json.load(open(path))
    for pid, d in harvest.items():
        jmpr[pid] = {}
        for key, targets in d.get('jmpr_followed', {}).items():
            m, p = key.split(':')
            jmpr[pid][(m, int(p))] = [(m, t) for t in targets]
        unres[pid] = {}
        for key, reg in d.get('unresolved_jmpr', {}).items():
            m, p = key.split(':')
            unres[pid][(m, int(p))] = reg
    return jmpr, unres


def completed_edges(pstruct, pid, jmpr, unres):
    """dict key -> list of (target_key, provenance); plus node set."""
    nodes = {(i['mode'], i['pc']) for i in pstruct['instructions']}
    edges = {}
    for i in pstruct['instructions']:
        src = (i['mode'], i['pc'])
        out = []
        seen = set()
        for s in i.get('succ') or []:
            t = (s[0], s[1])
            if t in nodes and t not in seen:
                seen.add(t)
                out.append((t, 'walk-succ'))
        sw = i.get('switch')
        if sw and sw['mode_no'] in U2MODE:
            t = (U2MODE[sw['mode_no']], sw['entry'])
            if t in nodes and t not in seen:
                seen.add(t)
                out.append((t, 'walk-switch'))
        for t in jmpr.get(pid, {}).get(src, []):
            if t in nodes and t not in seen:
                seen.add(t)
                out.append((t, 'walk-jmpr'))
        edges[src] = out
    return nodes, edges


def sccs(nodes, succ):
    """Tarjan SCC over the reachable graph."""
    index = {}
    low = {}
    onstack = set()
    stack = []
    result = []
    counter = [0]
    sys.setrecursionlimit(100000)

    def strongconnect(v):
        index[v] = low[v] = counter[0]
        counter[0] += 1
        stack.append(v)
        onstack.add(v)
        for w in succ.get(v, []):
            if w not in nodes:
                continue
            if w not in index:
                strongconnect(w)
                low[v] = min(low[v], low[w])
            elif w in onstack:
                low[v] = min(low[v], index[w])
        if low[v] == index[v]:
            comp = []
            while True:
                w = stack.pop()
                onstack.discard(w)
                comp.append(w)
                if w == v:
                    break
            result.append(comp)

    for v in sorted(nodes):
        if v not in index:
            strongconnect(v)
    return result


def main():
    structs = json.load(open(os.path.join(HERE, 'proto_structs.json')))
    jmpr, unres = load_jmpr()
    out = {'protos': {}}
    for pid, p in structs.items():
        if not p.get('instructions'):
            out['protos'][pid] = {'nodes': 0, 'kind': p.get('kind')}
            continue
        nodes, edges = completed_edges(p, pid, jmpr, unres)
        entry = tuple(p['entry'])
        seen = set()
        stack = [entry]
        while stack:
            n = stack.pop()
            if n in seen or n not in nodes:
                continue
            seen.add(n)
            stack += [t for t, _ in edges.get(n, [])]
        scc = sccs(nodes, {k: [t for t, _ in v]
                           for k, v in edges.items()})
        multi = [sorted(c) for c in scc if len(c) > 1]
        selfloops = [k for k in nodes
                     if k in [t for t, _ in edges.get(k, [])]]
        out['protos'][pid] = {
            'nodes': len(nodes),
            'reachable': len(seen),
            'entry': list(entry),
            'edges': {f'{m}:{pc}': [[t[0], t[1], prov]
                                    for t, prov in v]
                      for (m, pc), v in edges.items()},
            'scc_multi': [[f'{m}:{pc}' for m, pc in c]
                          for c in multi],
            'self_loops': [f'{m}:{pc}' for m, pc in selfloops],
            'unresolved_jmpr': {
                f'{m}:{pc}': r
                for (m, pc), r in unres.get(pid, {}).items()},
        }
        print(f'{pid}: nodes={len(nodes)} reachable={len(seen)} '
              f'edges={sum(len(v) for v in edges.values())} '
              f'scc_multi={len(multi)} selfloops={len(selfloops)} '
              f'unres_jmpr={len(unres.get(pid, {}))}')
    with open(os.path.join(HERE, 'cfg2.json'), 'w') as fo:
        json.dump(out, fo, indent=1)
    print('wrote cfg2.json')


if __name__ == '__main__':
    main()
