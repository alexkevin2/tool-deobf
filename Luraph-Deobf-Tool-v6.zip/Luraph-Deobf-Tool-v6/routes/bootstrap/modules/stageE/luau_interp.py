#!/usr/bin/env python3
"""luau_interp.py — a tree-walking Luau interpreter over luau-ast JSON.

Built for Phase D of the StealAnEggs case: it executes the payload
interpreter (slot 15209 factory/middle/inner) and any plain table
functions, on the LIVE fz_sim objects (LT tables / Buf buffers), so the
real materializer closure fires in context exactly as it does in the
real VM.

Value model (shared with fz_sim):
  nil=None, bool, int/float, string=bytes, table=fz.LT, buffer=fz.Buf,
  function = Python callable | AstClosure | WrappedCo | Mock | LuaFn.
Multi-values: eval_expr returns a Python list of values.  Python
callables signal multi-return by returning a Multi(...) wrapper; any
other return value is a single value (fz tagged tuples like
('Vector3', ...) stay single values).

Scoping: locals are keyed by their AstLocal declaration location, so
shadowing/machine-generated names need no scope stack.  Closures
capture the chain of frame slot-dicts (upvalue frames).
"""
import math

import mocks


class LuaError(Exception):
    pass


class _Return(Exception):
    def __init__(self, values):
        self.values = values


class _Break(Exception):
    pass


class _Continue(Exception):
    pass


class BudgetExceeded(Exception):
    def __init__(self, what):
        self.what = what


class Multi:
    __slots__ = ('items',)

    def __init__(self, items):
        self.items = list(items)


class WrappedCo:
    """coroutine.wrap result: first call starts the generator with the
    call's args; each call returns the yielded values as a list."""

    __slots__ = ('factory', 'gen', 'dead', 'name')

    def __init__(self, factory, name='coroutine'):
        self.factory = factory      # callable(*args) -> generator
        self.gen = None
        self.dead = False
        self.name = name

    def resume(self, rt, args):
        if self.dead:
            rt.log_event('coroutine-dead', self.name)
            return []
        if self.gen is None:
            self.gen = self.factory(*args)
            args = ()
        try:
            vals = next(self.gen)
            return list(vals) if vals is not None else []
        except StopIteration:
            self.dead = True
            return []
        except TypeError:
            raise


class AstClosure:
    __slots__ = ('node', 'upframes', 'globals_table', 'ns', 'tag',
                 'traceinfo')

    def __init__(self, node, upframes, globals_table, ns, tag=''):
        self.node = node                    # AstExprFunction
        self.upframes = upframes            # list[dict], nearest first
        self.globals_table = globals_table  # LT env for AstExprGlobal
        self.ns = ns
        self.tag = tag
        self.traceinfo = None

    def __repr__(self):
        return f'<closure {self.tag or self.node.get("location", "?")}>'


class Frame:
    __slots__ = ('closure', 'slots', 'upframes', 'varargs',
                 'globals_table', 'ns', 'rt', 'depth')

    def __init__(self, closure, upframes, varargs, globals_table, ns,
                 rt, depth):
        self.closure = closure
        self.slots = {}
        self.upframes = upframes
        self.varargs = varargs
        self.globals_table = globals_table
        self.ns = ns
        self.rt = rt
        self.depth = depth

    def get_local(self, loc):
        v = self.slots.get(loc, _MISS)
        if v is not _MISS:
            return v
        for d in self.upframes:
            v = d.get(loc, _MISS)
            if v is not _MISS:
                return v
        return None

    def set_local(self, loc, value):
        if loc in self.slots:
            self.slots[loc] = value
            return
        for d in self.upframes:
            if loc in d:
                d[loc] = value
                return
        self.slots[loc] = value


_MISS = object()
TAGS = ('Vector3', 'Vector2', 'UDim', 'UDim2', 'Rect', 'vector',
        'Color3', 'CFrame', 'BrickColor', 'DateTime', 'Random')


def truthy(v):
    return v is not None and v is not False


def is_mock(v):
    return isinstance(v, mocks.Mock)


def fmt_num(v):
    if isinstance(v, int):
        return str(v)
    f = float(v)
    if f == int(f) and abs(f) < 1e15:
        return ('%.14g' % f)
    return repr(f)


def lua_tostring(v):
    if v is None:
        return b'nil'
    if v is True:
        return b'true'
    if v is False:
        return b'false'
    if isinstance(v, bytes):
        return v
    if isinstance(v, str):
        return v.encode('utf-8', 'replace')
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return fmt_num(v).encode()
    return repr(v).encode('utf-8', 'replace')


def lua_len(rt, v):
    fz = rt.fz
    if isinstance(v, bytes):
        return len(v)
    if isinstance(v, fz.Buf):
        return len(v.data)
    if isinstance(v, fz.LT):
        n = 0
        d = v.d
        while d.get(n + 1) is not None:
            n += 1
        return n
    if is_mock(v):
        return rt.decide('len', v)
    raise LuaError(f'attempt to get length of a {lua_type(v)} value')


def lua_type(v):
    if v is None:
        return 'nil'
    if isinstance(v, bool):
        return 'boolean'
    if isinstance(v, (int, float)):
        return 'number'
    if isinstance(v, (bytes, str)):
        return 'string'
    if isinstance(v, mocks._Vec):
        return 'vector'
    try:
        import fzmod  # never; placeholder to keep linters quiet
    except Exception:
        pass
    if v.__class__.__name__ in ('LT',):
        return 'table'
    if v.__class__.__name__ in ('Buf',):
        return 'buffer'
    if callable(v) or isinstance(v, (AstClosure, WrappedCo)):
        return 'function'
    if isinstance(v, mocks.Mock):
        return 'userdata'
    return type(v).__name__


def lua_eq(a, b):
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a == b
    if isinstance(a, bytes) and isinstance(b, bytes):
        return a == b
    return a is b


# ------------------------------------------------------------------ eval
class Interp:
    def __init__(self, rt):
        self.rt = rt
        self.fz = rt.fz

    # ---------- helpers ----------
    def single(self, vals):
        return vals[0] if vals else None

    def eval1(self, node, fr):
        return self.single(self.eval_expr(node, fr))

    def eval_list(self, nodes, fr):
        """Luau expression-list semantics: all but the last collapse to
        one value; the last expands."""
        out = []
        for i, nd in enumerate(nodes):
            vals = self.eval_expr(nd, fr)
            if i == len(nodes) - 1:
                out.extend(vals)
            else:
                out.append(vals[0] if vals else None)
        return out

    # ---------- expressions ----------
    def eval_expr(self, node, fr):
        t = node['type']
        m = self._EXPR.get(t)
        if m is None:
            raise LuaError(f'unsupported expr {t} at {node.get("location")}')
        return m(self, node, fr)

    def _e_local(self, node, fr):
        return [fr.get_local(node['local']['location'])]

    def _e_global(self, node, fr):
        name = node['global']
        gt = fr.globals_table
        if gt is not None:
            v = self.rt.tget(gt, name.encode())
            return [v]
        return [None]

    def _e_const_num(self, node, fr):
        v = node['value']
        if isinstance(v, float) and v == int(v) and abs(v) < 2 ** 62:
            v = int(v)
        return [v]

    def _e_const_str(self, node, fr):
        v = node['value']
        if isinstance(v, str):
            v = v.encode('latin-1', 'surrogateescape')
        return [v]

    def _e_const_bool(self, node, fr):
        return [bool(node['value'])]

    def _e_const_nil(self, node, fr):
        return [None]

    def _e_varargs(self, node, fr):
        return list(fr.varargs)

    def _e_group(self, node, fr):
        return [self.eval1(node['expr'], fr)]

    def _e_type_assert(self, node, fr):
        return self.eval_expr(node['expr'], fr)

    def _e_function(self, node, fr):
        chain = [fr.slots] + fr.upframes
        return [AstClosure(node, chain, fr.globals_table, fr.ns)]

    def _e_index_expr(self, node, fr):
        obj = self.eval1(node['expr'], fr)
        key = self.eval1(node['index'], fr)
        return [self.index(obj, key)]

    def _e_index_name(self, node, fr):
        obj = self.eval1(node['expr'], fr)
        return [self.index(obj, node['index'].encode())]

    def index(self, obj, key):
        rt = self.rt
        fz = self.fz
        if obj is None:
            raise LuaError(f'attempt to index nil with {key!r}')
        if isinstance(obj, fz.LT):
            return rt.tget(obj, key)
        if isinstance(obj, bytes):
            fn = rt.string_lib.get(key)
            if fn is not None:
                return fn
            raise LuaError(f'attempt to index string with {key!r}')
        if isinstance(obj, mocks._Vec):
            return obj.get(key)
        if isinstance(obj, tuple) and obj and obj[0] in ('Vector3',
                                                          'Vector2'):
            return mocks._Vec(obj[0], obj[1:]).get(key)
        if isinstance(obj, mocks._Namespace):
            return obj.get(key)
        if is_mock(obj):
            return obj.get(key)
        if isinstance(obj, dict):      # KSDict keystream
            k = fz.num_key(key)
            v = obj.get(k)
            if v is None:
                raise LuaError(f'keystream[{key!r}] is nil')
            return v
        raise LuaError(f'attempt to index {lua_type(obj)} value')

    def index_assign(self, obj, key, value):
        rt = self.rt
        fz = self.fz
        if isinstance(obj, fz.LT):
            rt.tset(obj, key, value)
            return
        if is_mock(obj):
            obj.set(key, value)
            return
        if isinstance(obj, mocks._Namespace):
            raise LuaError('attempt to assign into a namespace')
        raise LuaError(f'attempt to index {lua_type(obj)} value (set)')

    def _e_call(self, node, fr):
        rt = self.rt
        fnode = node['func']
        args = self.eval_list(node['args'], fr)
        if node.get('self'):
            recv = self.eval1(fnode['expr'], fr)
            if fnode['type'] == 'AstExprIndexName':
                fn = self.index(recv, fnode['index'].encode())
            else:
                fn = self.index(recv, self.eval1(fnode['index'], fr))
            args = [recv] + args
        else:
            fn = self.eval1(fnode, fr)
        return rt.call_value(fn, args, fr)

    def _e_binary(self, node, fr):
        op = node['op']
        if op == 'And':
            lv = self.eval1(node['left'], fr)
            if is_mock(lv):
                if not self.rt.decide('truthy', lv):
                    return [lv]
            elif not truthy(lv):
                return [lv]
            return [self.eval1(node['right'], fr)]
        if op == 'Or':
            lv = self.eval1(node['left'], fr)
            if is_mock(lv):
                if self.rt.decide('truthy', lv):
                    return [lv]
            elif truthy(lv):
                return [lv]
            return [self.eval1(node['right'], fr)]
        a = self.eval1(node['left'], fr)
        b = self.eval1(node['right'], fr)
        return [self.binop(op, a, b)]

    def binop(self, op, a, b):
        rt = self.rt
        if op == 'CompareEq':
            if is_mock(a) or is_mock(b):
                if a is b:
                    return True
                return rt.decide('cmpeq', (a, b))
            return lua_eq(a, b)
        if op == 'CompareNe':
            if is_mock(a) or is_mock(b):
                if a is b:
                    return False
                return not rt.decide('cmpeq', (a, b))
            return not lua_eq(a, b)
        if op in ('CompareLt', 'CompareLe', 'CompareGt', 'CompareGe'):
            if is_mock(a) or is_mock(b):
                return rt.decide('cmp' + op[-2:].lower(), (op, a, b))
            if isinstance(a, (int, float)) and isinstance(b, (int, float)) \
                    and not isinstance(a, bool) and not isinstance(b, bool):
                if op == 'CompareLt':
                    return a < b
                if op == 'CompareLe':
                    return a <= b
                if op == 'CompareGt':
                    return a > b
                return a >= b
            if isinstance(a, bytes) and isinstance(b, bytes):
                if op == 'CompareLt':
                    return a < b
                if op == 'CompareLe':
                    return a <= b
                if op == 'CompareGt':
                    return a > b
                return a >= b
            raise LuaError(f'attempt to compare {lua_type(a)} with '
                           f'{lua_type(b)}')
        # arithmetic / concat
        if isinstance(a, mocks._Vec) or isinstance(b, mocks._Vec):
            va = a if isinstance(a, mocks._Vec) else None
            vb = b if isinstance(b, mocks._Vec) else None
            src = va or vb
            other = b if va else a
            r = src.binop(op, other) if va else None
            if r is not None:
                return r
            if vb and va is None and op in ('Add', 'Mul'):
                return vb.binop(op, a)
        if isinstance(a, tuple) and a and a[0] in ('Vector3', 'Vector2'):
            return self.binop(op, mocks._Vec(a[0], a[1:]), b)
        if isinstance(b, tuple) and b and b[0] in ('Vector3', 'Vector2'):
            return self.binop(op, a, mocks._Vec(b[0], b[1:]))
        if is_mock(a) or is_mock(b):
            return rt.decide('arith', (op, a, b))
        if op == 'Concat':
            if isinstance(a, (bytes, int, float)) and \
                    isinstance(b, (bytes, int, float)) and \
                    not isinstance(a, bool) and not isinstance(b, bool):
                return lua_tostring(a) + lua_tostring(b)
            raise LuaError(f'attempt to concatenate {lua_type(a)} / '
                           f'{lua_type(b)}')
        if isinstance(a, bool) or isinstance(b, bool) or a is None \
                or b is None or isinstance(a, (str,)) or \
                isinstance(b, (str,)):
            raise LuaError(f'attempt to perform arithmetic ({op}) on '
                           f'{lua_type(a)} / {lua_type(b)}')
        if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
            raise LuaError(f'attempt to perform arithmetic ({op}) on '
                           f'{lua_type(a)} / {lua_type(b)}')
        if op == 'Add':
            return a + b
        if op == 'Sub':
            return a - b
        if op == 'Mul':
            return a * b
        if op == 'Div':
            return a / b
        if op == 'FloorDiv':
            return math.floor(a / b)
        if op == 'Mod':
            return a - math.floor(a / b) * b if b != 0 else _mod_err()
        if op == 'Pow':
            return float(a) ** float(b)
        raise LuaError(f'unsupported binary op {op}')

    def _e_unary(self, node, fr):
        op = node['op']
        v = self.eval1(node['expr'], fr)
        if op == 'Not':
            if is_mock(v):
                return [not self.rt.decide('truthy', v)]
            return [not truthy(v)]
        if op == 'Len':
            return [lua_len(self.rt, v)]
        if op == 'Minus':
            if is_mock(v):
                return [self.rt.decide('arith', ('Minus', v, None))]
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                return [-v]
            raise LuaError(f'attempt to negate {lua_type(v)}')
        raise LuaError(f'unsupported unary op {op}')

    def _e_table(self, node, fr):
        fz = self.fz
        t = fz.LT()
        pos = 1
        items = node['items']
        for i, item in enumerate(items):
            last = i == len(items) - 1
            kind = item.get('kind')
            if kind == 'item':
                if last:
                    vals = self.eval_expr(item['value'], fr)
                else:
                    vals = [self.eval1(item['value'], fr)]
                for v in vals:
                    self.rt.tset(t, pos, v)
                    pos += 1
            elif kind == 'general':
                k = self.eval1(item['key'], fr)
                v = self.eval1(item['value'], fr)
                self.rt.tset(t, k, v)
            elif kind == 'record':
                k = item['key']
                if isinstance(k, dict):
                    k = self.eval1(k, fr)
                elif isinstance(k, str):
                    k = k.encode()
                v = self.eval1(item['value'], fr)
                self.rt.tset(t, k, v)
            else:
                raise LuaError(f'table item kind {kind!r}')
        return [t]

    def _e_ifelse(self, node, fr):
        c = self.eval1(node['condition'], fr)
        if is_mock(c):
            take = self.rt.decide('truthy', c)
        else:
            take = truthy(c)
        return self.eval_expr(node['trueExpr'] if take
                              else node['falseExpr'], fr)

    def _e_interp(self, node, fr):
        parts = node.get('parts') or node.get('strings') or []
        exprs = node.get('expressions') or node.get('exprs') or []
        out = []
        for i, p in enumerate(parts):
            out.append(p.encode('latin-1', 'surrogateescape')
                       if isinstance(p, str) else p)
            if i < len(exprs):
                out.append(lua_tostring(self.eval1(exprs[i], fr)))
        return [b''.join(out)]

    _EXPR = {}

    # ---------- statements ----------
    def exec_block(self, block, fr):
        if isinstance(block, dict):
            if block.get('type') == 'AstStatBlock':
                for st in block['body']:
                    self.exec_stat(st, fr)
            else:
                # e.g. an `elseif` chain: elsebody is a bare AstStatIf
                self.exec_stat(block, fr)
        elif isinstance(block, list):
            for st in block:
                self.exec_stat(st, fr)

    def exec_stat(self, node, fr):
        self.rt.step(fr, node)
        t = node['type']
        m = self._STAT.get(t)
        if m is None:
            raise LuaError(f'unsupported stat {t} at {node.get("location")}')
        m(self, node, fr)

    def _s_block(self, node, fr):
        self.exec_block(node, fr)

    def _s_local(self, node, fr):
        vals = self.eval_list(node['values'], fr) if node['values'] else []
        for i, var in enumerate(node['vars']):
            fr.slots[var['location']] = vals[i] if i < len(vals) else None

    def _s_global_assign(self, fr, name, value):
        gt = fr.globals_table
        if gt is not None:
            self.rt.tset(gt, name.encode(), value)

    def _assign_target(self, node, fr, value):
        t = node['type']
        if t == 'AstExprLocal':
            fr.set_local(node['local']['location'], value)
        elif t == 'AstExprGlobal':
            self._s_global_assign(fr, node['global'], value)
        elif t == 'AstExprIndexExpr':
            obj = self.eval1(node['expr'], fr)
            key = self.eval1(node['index'], fr)
            self.index_assign(obj, key, value)
        elif t == 'AstExprIndexName':
            obj = self.eval1(node['expr'], fr)
            self.index_assign(obj, node['index'].encode(), value)
        else:
            raise LuaError(f'bad assignment target {t}')

    def _read_target(self, node, fr):
        t = node['type']
        if t == 'AstExprLocal':
            return fr.get_local(node['local']['location'])
        if t == 'AstExprGlobal':
            return self._e_global(node, fr)[0]
        if t == 'AstExprIndexExpr':
            obj = self.eval1(node['expr'], fr)
            return self.index(obj, self.eval1(node['index'], fr))
        if t == 'AstExprIndexName':
            obj = self.eval1(node['expr'], fr)
            return self.index(obj, node['index'].encode())
        raise LuaError(f'bad read target {t}')

    def _s_assign(self, node, fr):
        vals = self.eval_list(node['values'], fr)
        for i, var in enumerate(node['vars']):
            self._assign_target(var, fr, vals[i] if i < len(vals) else None)

    def _s_compound(self, node, fr):
        var = node['var']
        cur = self._read_target(var, fr)
        rhs = self.eval1(node['value'], fr)
        self._assign_target(var, fr, self.binop(node['op'], cur, rhs))

    def _s_if(self, node, fr):
        c = self.eval1(node['condition'], fr)
        if is_mock(c):
            take = self.rt.decide('truthy', c)
        else:
            take = truthy(c)
        if take:
            self.exec_block(node['thenbody'], fr)
        elif node.get('elsebody') is not None:
            self.exec_block(node['elsebody'], fr)

    def _s_while(self, node, fr):
        rt = self.rt
        while True:
            rt.loop_iter(fr, node)
            c = self.eval1(node['condition'], fr)
            if is_mock(c):
                take = rt.decide('truthy', c)
            else:
                take = truthy(c)
            if not take:
                break
            try:
                self.exec_block(node['body'], fr)
            except _Continue:
                continue
            except _Break:
                break

    def _s_repeat(self, node, fr):
        while True:
            self.rt.loop_iter(fr, node)
            try:
                self.exec_block(node['body'], fr)
            except _Continue:
                pass
            except _Break:
                break
            c = self.eval1(node['condition'], fr)
            if is_mock(c):
                take = self.rt.decide('truthy', c)
            else:
                take = truthy(c)
            if take:
                break

    def _s_for(self, node, fr):
        loc = node['var']['location']
        start = self.eval1(node['from'], fr)
        stop = self.eval1(node['to'], fr)
        stepv = self.eval1(node['step'], fr) if node.get('step') else 1
        for name, v in (('from', start), ('to', stop), ('step', stepv)):
            if is_mock(v):
                v = self.rt.decide('fornum', (name, v))
                if name == 'from':
                    start = v
                elif name == 'to':
                    stop = v
                else:
                    stepv = v
        if not all(isinstance(v, (int, float)) and not isinstance(v, bool)
                   for v in (start, stop, stepv)):
            raise LuaError('numeric for bounds must be numbers')
        i = start
        while True:
            self.rt.loop_iter(fr, node)
            if stepv > 0 and i > stop:
                break
            if stepv < 0 and i < stop:
                break
            if stepv == 0:
                raise LuaError('numeric for step is zero')
            fr.slots[loc] = i
            try:
                self.exec_block(node['body'], fr)
            except _Continue:
                pass
            except _Break:
                break
            i = i + stepv

    def _s_forin(self, node, fr):
        vals = self.eval_list(node['values'], fr)
        it = vals[0] if len(vals) > 0 else None
        state = vals[1] if len(vals) > 1 else None
        ctl = vals[2] if len(vals) > 2 else None
        varlocs = [v['location'] for v in node['vars']]
        while True:
            self.rt.loop_iter(fr, node)
            res = self.rt.call_value(it, [state, ctl], fr)
            if not res or res[0] is None:
                break
            ctl = res[0]
            for i, loc in enumerate(varlocs):
                fr.slots[loc] = res[i] if i < len(res) else None
            try:
                self.exec_block(node['body'], fr)
            except _Continue:
                continue
            except _Break:
                break

    def _s_break(self, node, fr):
        raise _Break()

    def _s_continue(self, node, fr):
        raise _Continue()

    def _s_return(self, node, fr):
        raise _Return(self.eval_list(node['list'], fr))

    def _s_expr(self, node, fr):
        self.eval_expr(node['expr'], fr)

    def _s_function(self, node, fr):
        fn = self._e_function(node['func'], fr)[0]
        name = node['name']
        # name is an index chain / global / local expression
        if name['type'] == 'AstExprGlobal':
            self._s_global_assign(fr, name['global'], fn)
        elif name['type'] in ('AstExprIndexName', 'AstExprIndexExpr'):
            if node.get('self'):
                fn = _SelfClosure(fn)
            self._assign_target(name, fr, fn)
        elif name['type'] == 'AstExprLocal':
            fr.set_local(name['local']['location'], fn)
        else:
            raise LuaError(f'unsupported function stat name {name["type"]}')

    def _s_do(self, node, fr):
        self.exec_block(node['body'], fr)

    _STAT = {}

    # ---------- calls ----------
    def call_closure(self, clo, args, caller_fr):
        node = clo.node
        params = node.get('args') or []
        varargs = []
        if node.get('vararg'):
            varargs = list(args[len(params):])
        fr = Frame(clo, clo.upframes, varargs, clo.globals_table,
                   clo.ns, self.rt,
                   (caller_fr.depth + 1) if caller_fr is not None else 0)
        for i, p in enumerate(params):
            fr.slots[p['location']] = args[i] if i < len(args) else None
        try:
            self.exec_block(node['body'], fr)
        except _Return as r:
            return r.values
        return []


class _SelfClosure:
    """Wraps a method-style AstClosure defined via `function t:m()`."""
    __slots__ = ('inner',)

    def __init__(self, inner):
        self.inner = inner


def _mod_err():
    raise LuaError('attempt to perform modulo by zero')


Interp._EXPR = {
    'AstExprLocal': Interp._e_local,
    'AstExprGlobal': Interp._e_global,
    'AstExprConstantNumber': Interp._e_const_num,
    'AstExprConstantString': Interp._e_const_str,
    'AstExprConstantBool': Interp._e_const_bool,
    'AstExprConstantNil': Interp._e_const_nil,
    'AstExprVarargs': Interp._e_varargs,
    'AstExprGroup': Interp._e_group,
    'AstExprTypeAssertion': Interp._e_type_assert,
    'AstExprFunction': Interp._e_function,
    'AstExprIndexExpr': Interp._e_index_expr,
    'AstExprIndexName': Interp._e_index_name,
    'AstExprCall': Interp._e_call,
    'AstExprBinary': Interp._e_binary,
    'AstExprUnary': Interp._e_unary,
    'AstExprTable': Interp._e_table,
    'AstExprIfElse': Interp._e_ifelse,
    'AstExprInterpString': Interp._e_interp,
}

Interp._STAT = {
    'AstStatBlock': Interp._s_block,
    'AstStatLocal': Interp._s_local,
    'AstStatAssign': Interp._s_assign,
    'AstStatCompoundAssign': Interp._s_compound,
    'AstStatIf': Interp._s_if,
    'AstStatWhile': Interp._s_while,
    'AstStatRepeat': Interp._s_repeat,
    'AstStatFor': Interp._s_for,
    'AstStatForIn': Interp._s_forin,
    'AstStatBreak': Interp._s_break,
    'AstStatContinue': Interp._s_continue,
    'AstStatReturn': Interp._s_return,
    'AstStatExpr': Interp._s_expr,
    'AstStatFunction': Interp._s_function,
    'AstStatDo': Interp._s_do,
}
