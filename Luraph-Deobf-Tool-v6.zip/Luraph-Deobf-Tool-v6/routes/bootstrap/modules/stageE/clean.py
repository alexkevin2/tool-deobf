#!/usr/bin/env python3
"""clean.py — StealAnEggs source-cleaning pass.

Reads the verified raw lift's data (proto_structs.json via liftD) and
renders full_clean.luau: the same 796 walked instructions, presented
as idiomatic Luau — structured control flow where the jump graph is
safely structurable, promoted + renamed registers, method-call and
dot-index idioms where provable, CONFIRMED stdlib inlining for the
interpreter factory's alias locals, and clearly-named placeholders
for the constants the recovery could not resolve.

The raw lift (stageD/full.luau) remains the ground truth; cleaning
never invents values and never drops an instruction: every record is
accounted for in clean_map.json.

Rerun:  python3 clean.py            (writes full_clean.luau,
                                     clean_map.json, clean_stats.json)
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import clean_lib as CL
import liftD as L

STRUCTS = CL.STRUCTS

MODE_NUM = {'A': 114, 'B': 49, 'C': 210, 'D': 113}
# ------------------------------------------------------------ naming data
# Function names for the recovered protos. All INFERRED (the original
# names were never present in the file); evidence per name is listed
# in CLEAN-REPORT.md's naming table.
FN_NAMES = {
    'root': 'main',
    'child1': 'calcFn01',
    'child2': 'branchFn02',
    'child3': 'closureFn03',
    'child4': 'branchFn04',
    'child5': 'thunkFn05',
    'child6': 'closureFn06',
    'child7': 'closureFn07',
    'child8': 'closureFn08',
    'child9': 'bezierCurveFn',
    'child10': 'phaseFn10',
    'child11': 'closureFn11',
    'child12': 'dataPackerFn',
    'child13': 'calcFn13',
    'child15': 'enumHelperFn',
    'child17': 'unitVectorFn',
    'child14': 'bzClosure41_14',
    'child16': 'bzClosure41_16',
    'child19': 'bzClosure41_19',
    'child20': 'bzClosure67_20',
    'child18': 'unbuiltFn18',
}

# Middle-scope factory aliases with CONFIRMED stdlib identities
# (STAGE2C1-REPORT factory bindings, via liftD.ALIASES).
ALIASES = {
    'p': 'table.create', 'Z': 'table.move', 'T': 'bit32.rshift',
    'N': 'bit32.band', 's': 'bit32.bxor', 'd': 'bit32.lshift',
    'm': 'table.pack', 'q': 'select', 'Y': 'bit32.bor',
    'Q': 'buffer.readu8', 'j': 'buffer.writeu32', 'c': 'buffer.readu32',
    'D': 'buffer.writeu8', 'k': 'unpack', 'o': 'next',
    'I': 'coroutine.wrap', 'M': 'bit32.bnot',
}

KNOWN_GLOBALS = {
    'game', 'workspace', 'script', 'Enum', 'task', 'Instance',
    'Vector3', 'Vector2', 'CFrame', 'Color3', 'UDim2', 'UDim',
    'BrickColor', 'DateTime', 'Random', 'utf8', 'math', 'string',
    'table', 'bit32', 'buffer', 'coroutine', 'pairs', 'ipairs',
    'next', 'select', 'unpack', 'tostring', 'tonumber', 'typeof',
    'pcall', 'error', 'print', 'warn', 'tick', 'os', 'debug',
}

STATS = Counter()
NAMING = []          # (scope, old, new, label, evidence)
RISKS = []           # global risk notes for the report


def is_ident(s):
    return bool(re.fullmatch(r'[A-Za-z_]\w*', s or ''))


# ------------------------------------------------------------ proto prep
class Proto:
    def __init__(self, pid, pstruct):
        self.pid = pid
        self.pstruct = pstruct
        self.kind = pstruct.get('kind')
        if self.kind == 'bz-constant' or \
                not pstruct.get('instructions'):
            self.recs, self.ctx = [], None
        else:
            self.recs, self.ctx = CL.translate_proto(pid, pstruct)
        self.by_key = {r.key: r for r in self.recs}
        fac = pstruct.get('factory') or {}
        self.factory = fac
        entry = pstruct.get('entry') or ['A', fac.get('R2')]
        self.entry_key = (entry[0], entry[1])
        self.cfg = (CL.CFG(pid, self.recs, self.entry_key)
                    if self.recs else None)
        self.regime = 'PROMOTE'
        self.form = None
        self.form_reason = None
        self.in_state = {}
        self.slot_names = {}
        self.slot_evidence = {}
        self.shared_map = {}
        self.alias_mode = {}   # alias -> 'inline' | 'keep'
        self.placeholders = set()
        self.rendered = {}     # key -> final raw lines (pre file-rename)
        self.for_proto = self

    def regime_check(self):
        bad = []
        for r in self.recs:
            if r.dyn_index:
                bad.append((r.key, 'dynamic register index'))
            if r.bare_n_value:
                bad.append((r.key, 'register file used as a value'))
        if bad:
            self.regime = 'REGS'
            self.regs_reasons = bad
        return bad


# ------------------------------------------------------- slot write/read
_NTARGET_RE = re.compile(r'^n\[(\d+)\]$')


def rec_writes(rec):
    out = set()
    for ln in rec.effects:
        for st in CL.split_statements(ln):
            s = st.strip()
            m = CL._ASSIGN_RE.match(s)
            if m and not s.startswith(('if ', 'while ', 'return',
                                       'for ')):
                targets = [t.strip() for t in m.group(1).split(',')]
                rhs = CL.split_top_commas(m.group(2))
                if len(rhs) == len(targets):
                    for t in targets:
                        mm = _NTARGET_RE.match(t)
                        if mm:
                            out.add(int(mm.group(1)))
    return out


def rec_reads(rec):
    out = set()
    targets = set()
    for ln in rec.effects:
        masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)
        for m in re.finditer(r'\bn\[(\d+)\]', masked):
            out.add(int(m.group(1)))
    for ln in rec.effects:
        for st in CL.split_statements(ln):
            s = st.strip()
            m = CL._ASSIGN_RE.match(s)
            if m and not s.startswith(('if ', 'while ', 'return',
                                       'for ')):
                tg = [t.strip() for t in m.group(1).split(',')]
                rhs = CL.split_top_commas(m.group(2))
                if len(rhs) == len(tg):
                    for t in tg:
                        mm = _NTARGET_RE.match(t)
                        if mm:
                            targets.add(int(mm.group(1)))
    return out - targets


def reaching_defs(cfg, writes):
    keys = [k for k in cfg.recs if k in cfg.reachable]
    din = {k: {} for k in keys}
    dout = {k: {} for k in keys}
    changed = True
    while changed:
        changed = False
        for k in keys:
            merged = {}
            for p in cfg.pred.get(k, ()):
                if p in dout:
                    for s, srcs in dout[p].items():
                        merged.setdefault(s, set()).update(srcs)
            if k == cfg.entry:
                merged = {}
            if merged != din[k]:
                din[k] = merged
                changed = True
            out = dict(din[k])
            for s in writes[k]:
                out[s] = {k}
            if out != dout[k]:
                dout[k] = out
                changed = True
    return din


# ------------------------------------------------------------- idioms
_FETCH_RE = re.compile(r'^n\[(\d+)\]=n\[(\d+)\]\[(.+)\];?$', re.S)
_CALL_DST_RE = re.compile(r'^n\[(\d+)\]=n\[(\d+)\]\((.*)\);?$', re.S)
_CALL_NR_RE = re.compile(r'^n\[(\d+)\]\((.*)\);?$', re.S)


def _key_value(keyexpr, state):
    keyexpr = keyexpr.strip()
    m = re.match(r'^"((?:[^"\\]|\\.)*)"$', keyexpr, re.S)
    if m:
        return ('str', CL._unescape_luau(m.group(1)))
    if re.fullmatch(r'-?\d+', keyexpr):
        return ('num', int(keyexpr))
    m = _NTARGET_RE.match(keyexpr)
    if m:
        return state.get(int(m.group(1)), CL.UNKNOWN_V)
    return CL.UNKNOWN_V


def apply_idioms(proto):
    """Method-call / dot-call conversion with fetch elision, and
    dot-index rendering. Works on raw (n[k]) effect text."""
    if not proto.cfg:
        return
    cfg = proto.cfg
    in_state = proto.in_state
    writes = {r.key: rec_writes(r) for r in proto.recs}
    reads = {r.key: rec_reads(r) for r in proto.recs}
    din = reaching_defs(cfg, writes)

    def fetch_of(key, slot):
        """Return the fetch record if `slot` at `key` comes from a
        single fetch statement whose only successor is `key`."""
        srcs = din.get(key, {}).get(slot, set())
        if len(srcs) != 1:
            return None
        fk = next(iter(srcs))
        frec = proto.by_key[fk]
        if cfg.succ.get(fk) != [key]:
            return None
        if len(frec.effects) != 1:
            return None
        m = _FETCH_RE.match(frec.effects[0].strip())
        if not m or int(m.group(1)) != slot:
            return None
        # slot read nowhere else
        for k2, rr in reads.items():
            if k2 != key and slot in rr:
                return None
        return frec, m

    def callee_index_value(key, slot):
        v = in_state.get(key, {}).get(slot, CL.UNKNOWN_V)
        return v

    for rec in proto.recs:
        if rec.kind != 'ok' or len(rec.effects) != 1:
            continue
        stmt = rec.effects[0].strip()
        m = _CALL_DST_RE.match(stmt)
        nr = _CALL_NR_RE.match(stmt) if not m else None
        if not m and not nr:
            continue
        STATS['call-sites-examined'] += 1
        if m:
            dst, callee, argstr = int(m.group(1)), int(m.group(2)), \
                m.group(3)
        else:
            dst, callee, argstr = None, int(nr.group(1)), nr.group(2)
        v = callee_index_value(rec.key, callee)
        if v[0] != 'index' or v[2][0] != 'str' or not is_ident(v[2][1]):
            if v[0] == 'index':
                STATS['call-left-unconverted'] += 1
            continue
        base, name = v[1], v[2][1]
        args = CL.split_top_commas(argstr) if argstr.strip() else []
        got = fetch_of(rec.key, callee)
        if got is None:
            STATS['call-left-unconverted'] += 1
            continue
        frec, fm = got
        if args and args[0].strip() == f'n[{base}]':
            call = f'n[{base}]:{name}(' + ','.join(args[1:]) + ')'
            tag = 'method-call'
            if name == 'GetService':
                STATS['idiom-getservice'] += 1
        elif args:
            call = f'n[{base}].{name}(' + ','.join(args) + ')'
            tag = 'dot-call'
        else:
            STATS['call-left-unconverted'] += 1
            continue
        new = (f'n[{dst}]={call};' if dst is not None
               else f'{call};')
        rec.effects = [new]
        rec.transforms.append(tag)
        STATS[f'idiom-{tag}'] += 1
        frec.effects = []
        frec.transforms.append('method-fetch-elided')
        frec.elided_into = rec.key
        STATS['idiom-fetch-elided'] += 1

    # CALL_RES packed-call line: method-ify the inner call
    for rec in proto.recs:
        if 'call-res-unroll' not in rec.transforms:
            continue
        for i, ln in enumerate(rec.effects):
            m = re.match(r'^x=m\(n\[(\d+)\]\((.*)\)\);$', ln.strip())
            if not m:
                continue
            STATS['call-sites-examined'] += 1
            callee = int(m.group(1))
            v = callee_index_value(rec.key, callee)
            if v[0] != 'index' or v[2][0] != 'str' or \
                    not is_ident(v[2][1]):
                continue
            base, name = v[1], v[2][1]
            args = CL.split_top_commas(m.group(2))
            got = fetch_of(rec.key, callee)
            if got is None:
                STATS['call-left-unconverted'] += 1
                continue
            frec, fm = got
            if args and args[0].strip() == f'n[{base}]':
                call = f'n[{base}]:{name}(' + ','.join(args[1:]) + ')'
                rec.effects[i] = f'x=m({call});'
                rec.transforms.append('method-call')
                STATS['idiom-method-call'] += 1
                if name == 'GetService':
                    STATS['idiom-getservice'] += 1
                frec.effects = []
                frec.transforms.append('method-fetch-elided')
                frec.elided_into = rec.key
                STATS['idiom-fetch-elided'] += 1

    # dot-index rendering on remaining fetch / settable statements
    for rec in proto.recs:
        if rec.kind != 'ok' or 'method-fetch-elided' in rec.transforms:
            continue
        new_eff = []
        for ln in rec.effects:
            st = ln.strip()

            def dot(m, base_first=True):
                return m
            m = re.match(r'^(n\[\d+\]=n\[\d+\])\[(.+)\];$', st)
            mset = re.match(r'^(n\[\d+\])\[(.+)\](=.*);$', st)
            done = None
            if m:
                kv = _key_value(m.group(2),
                                in_state.get(rec.key, {}))
                if kv[0] == 'str' and is_ident(kv[1]):
                    done = f'{m.group(1)}.{kv[1]};'
            elif mset:
                kv = _key_value(mset.group(2),
                                in_state.get(rec.key, {}))
                if kv[0] == 'str' and is_ident(kv[1]):
                    done = f'{mset.group(1)}.{kv[1]}{mset.group(3)};'
            if done:
                new_eff.append(done)
                if 'dot-index' not in rec.transforms:
                    rec.transforms.append('dot-index')
                STATS['idiom-dot-index'] += 1
            else:
                new_eff.append(ln)
        rec.effects = new_eff


# ------------------------------------------------- for-loop approval
def approve_for_loops(proto):
    if not proto.cfg:
        return
    cfg = proto.cfg
    # records that read g/l read-before-write (conservative scan)
    gl_readers = set()
    for r in proto.recs:
        rd, wr = CL.shared_refs(r.effects)
        if ('g' in rd) or ('l' in rd):
            gl_readers.add(r.key)
    loops = {}
    for tail, head in cfg.back_edges():
        lp = loops.setdefault(head, {'nodes': set(), 'tails': set()})
        lp['nodes'] |= cfg.natural_loop(tail, head)
        lp['tails'].add(tail)
    for rec in proto.recs:
        if rec.name != 'FORNEXT':
            continue
        head = rec.key
        if head not in loops:
            continue
        lp = loops[head]
        ok = True
        # (b) _,g,l side effects must be dead after this record
        if gl_readers - {head}:
            ok = False
        # (c) no G/h/b writes inside the loop except the header
        for k in lp['nodes']:
            if k == head:
                continue
            _, wr = CL.shared_refs(proto.by_key[k].effects)
            if wr & {'G', 'h', 'b'}:
                ok = False
        # (d) iteration slots not read outside the loop
        base = rec.rec['y']
        for k, r2 in proto.by_key.items():
            if k in lp['nodes']:
                continue
            rr = rec_reads(r2)
            if (base + 1) in rr or (base + 2) in rr:
                ok = False
        if ok:
            rec.for_conv = ('generic',
                            [proto.slot_names.get(base + 1,
                                                  f'slot{base + 1}'),
                             proto.slot_names.get(base + 2,
                                                  f'slot{base + 2}')])
            rec.transforms.append('generic-for')
            STATS['idiom-generic-for'] += 1
        else:
            STATS['fornext-not-converted'] += 1
    # ITERSTEP step effects for the structurer's break-guard form:
    # materialize `n[dst] = G` only if the translated body does not
    # already contain that write.
    for rec in proto.recs:
        if rec.name != 'ITERSTEP_J':
            continue
        dst = None
        for ln in rec.effects:
            m = re.search(r'n\[(\d+)\]\s*=\s*G\b', ln)
            if m:
                dst = int(m.group(1))
                break
        if dst is not None:
            rec.step_effects = None
            STATS['iterstep-write-in-body'] += 1
            continue
        entry, _ca = CL._entry_for(rec.rec)
        body = (entry or {}).get('body') or ''
        m = re.search(r'n\[\{(\w)\}\]\s*=\s*G', body)
        if m and isinstance(rec.rec.get(m.group(1)), int):
            dst = rec.rec[m.group(1)]
            rec.step_effects = [f'n[{dst}]=G;']
            rec.transforms.append('iterstep-step-materialized')
            STATS['iterstep-tail'] += 1
        else:
            STATS['iterstep-dst-unknown'] += 1


# ------------------------------------------------------------- naming
def compute_slot_names(proto):
    """Evidence-based register naming. Returns (names, evidence)."""
    names = {}
    evidence = {}
    if not proto.cfg:
        return names, evidence
    in_state = proto.in_state
    # union of values per slot + use facts
    vals = defaultdict(set)
    for key, st in in_state.items():
        for s, v in st.items():
            if v[0] != 'unknown':
                vals[s].add(v)
    # also values produced by the record itself (out values): rerun
    # transfer locally through eval on assignment statements
    bases = defaultdict(Counter)   # slot -> Counter of keys fetched
    callees = Counter()
    for rec in proto.recs:
        for key_state in (in_state.get(rec.key, {}),):
            pass
        for ln in rec.effects:
            for m in re.finditer(r'\bn\[(\d+)\]\[', ln):
                bases[int(m.group(1))]['__fetch__'] += 1
    for key, st in in_state.items():
        for s, v in st.items():
            if v[0] == 'index':
                bases[v[1]][v[2][1] if v[2][0] == 'str' else '?'] += 1
    # vararg destination slots (LOADVARARG / SPILL unrolls)
    arg_slots = {}
    for rec in proto.recs:
        if 'loadvararg-unroll' in rec.transforms:
            for ln in rec.effects:
                m = re.match(r'^((?:n\[\d+\],?)+)=C\[', ln.strip())
                if m:
                    slots = [int(x) for x in
                             re.findall(r'n\[(\d+)\]', m.group(1))]
                    for i, s in enumerate(slots):
                        arg_slots[s] = i + 1
    used_slots = set()
    for rec in proto.recs:
        for ln in rec.effects:
            masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)
            used_slots |= {int(x) for x in
                           re.findall(r'\bn\[(\d+)\]', masked)}
    counters = Counter()
    for s in sorted(used_slots):
        if s > 1024:
            names[s] = f'raw{s}'
            evidence[s] = ('raw stream operand appearing as an '
                           'index inside an uninterpreted body — '
                           'not a designed register (register files '
                           'here have at most 272 slots)', 'INFERRED')
            STATS['slots-raw-operand'] += 1
            continue
        nm, ev, label = None, '', 'INFERRED'
        vs = vals.get(s, set())
        strs = [v[1] for v in vs if v[0] == 'str']
        services = [v[1] for v in vs if v[0] == 'service']
        children = [v[1] for v in vs if v[0] == 'child']
        fetched = bases.get(s, Counter())
        if s in arg_slots:
            nm = f'arg{arg_slots[s]}'
            ev = (f'positional parameter: filled from varargs by '
                  f'LOADVARARG (dest slot {s})')
        elif services:
            nm = services[0]
            ev = f'holds the "{services[0]}" service object ' \
                 f'(GetService result)'
        elif any(k == 'GetService' for k in fetched):
            nm = 'game'
            ev = ('base of a GetService fetch — the game object '
                  '(only game exposes GetService)')
        elif children and len(vs) == 1:
            nm = FN_NAMES[children[0]]
            ev = f'holds child proto {children[0]} (closure constant)'
        elif strs and all(x in KNOWN_GLOBALS for x in strs):
            nm = strs[0] + 'Name'
            ev = f'holds the name string "{strs[0]}"'
        elif any(k == 'Parent' for k in fetched) and \
                any(v[0] == 'index' and v[2] == ('str', 'Parent')
                    for v in vs):
            nm = 'parent'
            ev = 'result of a .Parent fetch'
        elif fetched.get('__fetch__', 0) >= 2 or len(fetched) >= 3:
            counters['inst'] += 1
            nm = 'inst' if counters['inst'] == 1 else \
                f"inst{counters['inst']}"
            ev = ('Instance-like value: field/method vocabulary '
                  'fetched from it: ' +
                  ', '.join(sorted(k for k in fetched
                                   if k != '__fetch__')[:6]))
        elif strs:
            nm = 'text'
            ev = f'holds string constant "{strs[0][:24]}"'
            counters['text'] += 1
            if counters['text'] > 1:
                nm = f"text{counters['text']}"
        elif any(v[0] == 'table' for v in vs):
            counters['list'] += 1
            nm = 'list' if counters['list'] == 1 else \
                f"list{counters['list']}"
            ev = 'holds a fresh table (NEWTABLE / constructor)'
        elif any(v[0] == 'box' for v in vs):
            nm = f'box{s}'
            ev = 'holds an upvalue box (U[...] read)'
        elif any(v[0] == 'upvval' for v in vs):
            nm = f'upv{s}'
            ev = 'holds an upvalue-box content (GETUPVBOX)'
        if nm is None:
            nm = f'slot{s}'
            ev = 'role not determinable from the walked records'
            label = 'INFERRED'
            STATS['slots-neutral'] += 1
        else:
            STATS['slots-named'] += 1
        names[s] = nm
        evidence[s] = (ev, label)
    # dedupe within the proto
    seen = {}
    for s in sorted(names):
        nm = names[s]
        if nm in seen:
            i = 2
            while f'{nm}{i}' in seen:
                i += 1
            names[s] = f'{nm}{i}'
            seen[names[s]] = s
        else:
            seen[nm] = s
    return names, evidence


def compute_shared_map(proto):
    """Renames for proto-level shared interpreter state, and the set
    of original names actually referenced."""
    refs_r, refs_w = set(), set()
    for rec in proto.recs:
        rd, wr = CL.shared_refs(rec.effects)
        refs_r |= rd
        refs_w |= wr
    refs = refs_r | refs_w
    names = {r.name for r in proto.recs}
    smap = {}
    if 'C' in refs:
        smap['C'] = 'tmp'
    if 'g' in refs:
        smap['g'] = 'aux'
    if 'l' in refs:
        smap['l'] = 'aux2'
    if 'x' in refs:
        smap['x'] = 'packedResults'
    if 'V' in refs:
        smap['V'] = 'seedV'
    if 'L' in refs:
        smap['L'] = 'seedL'
    if 'U' in refs:
        smap['U'] = 'upvalues'
    if 'K' in refs:
        smap['K'] = 'ctx'
    if 'W' in refs:
        smap['W'] = 'coWrap'
    if 'H' in refs:
        smap['H'] = 'vm'
    if 'J' in refs:
        smap['J'] = 'chunkInfo'
    if 't' in refs:
        smap['t'] = 'envTable'
    if 'v' in refs:
        smap['v'] = 'pairsIter'
    if 'A' in refs:
        smap['A'] = 'modeNum'
    if 'u' in refs:
        smap['u'] = 'regCount'
    if 'F' in refs:
        smap['F'] = 'fieldF'
    if 'r' in refs:
        smap['r'] = 'envFn'
    # factory captures used as values in bodies: e -> capE, O -> capO
    for w, nw in (('e', 'capE'), ('O', 'capO')):
        pat = re.compile(rf'(?<![\w.]){w}\b')
        for rec in proto.recs:
            loc = CL.body_locals(rec.effects)
            if w in loc:
                continue
            if any(pat.search(re.sub(r'"(?:[^"\\]|\\.)*"', '""',
                                     ln)) for ln in rec.effects):
                smap[w] = nw
                break
    # direct operand-table reads (LOADK family): z / X tables
    for w, nw in (('z', 'streamZ'), ('X', 'streamX')):
        pat = re.compile(rf'(?<![\w.]){w}\[')
        for rec in proto.recs:
            loc = CL.body_locals(rec.effects)
            if w in loc:
                continue
            if any(pat.search(re.sub(r'"(?:[^"\\]|\\.)*"', '""',
                                     ln)) for ln in rec.effects):
                smap[w] = nw
                break
    if refs & {'G', 'h', 'b'}:
        if 'FORNEXT' in names:
            smap.update({'G': 'iterFn', 'h': 'iterState',
                         'b': 'iterCtrl'})
        elif 'ITERSTEP_J' in names:
            smap.update({'G': 'loopCounter', 'h': 'loopStep',
                         'b': 'loopLimit'})
        else:
            smap.update({'G': 'iterG', 'h': 'iterH', 'b': 'iterB'})
    # alias handling per proto: inline when called and never assigned
    alias_mode = {}
    for a in ALIASES:
        called = assigned = False
        for rec in proto.recs:
            locals_ = CL.body_locals(rec.effects)
            if a in locals_:
                continue
            for ln in rec.effects:
                masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)
                if re.search(rf'\b{a}\s*\(', masked):
                    called = True
                for st in CL.split_statements(masked):
                    m = CL._ASSIGN_RE.match(st.strip())
                    if m and a in [t.strip() for t in
                                   m.group(1).split(',')]:
                        assigned = True
        alias_mode[a] = 'inline' if (called and not assigned) else \
            ('used' if (called or assigned) else 'unused')
    return smap, alias_mode, refs


# ------------------------------------------------------------- renamer
_STR_SPLIT_RE = re.compile(r'("(?:[^"\\]|\\.)*")')
_BARE_N_PATTERNS = [
    re.compile(r'([(,]\s*)n(\s*[,)])'),
    re.compile(r'(=\s*)n(\s*(?:;|$))'),
    re.compile(r'(\{\s*6\s*\]\s*=\s*)n(\s*[,}])'),
    re.compile(r'(return\s+)n(\s*;)'),
]


class Renamer:
    def __init__(self, proto):
        self.p = proto
        self.slot_names = proto.slot_names
        self.shared = proto.shared_map
        self.alias_mode = proto.alias_mode
        self.regs_name = 'regs'

    def rename(self, text, rec):
        if text is None:
            return text
        locals_ = CL.body_locals(rec.effects) if rec is not None else set()
        out = []
        for seg in _STR_SPLIT_RE.split(text):
            if seg.startswith('"'):
                out.append(seg)
                continue
            s = seg
            # register slots
            if self.p.regime == 'PROMOTE':
                s = re.sub(r'\bn\[(\d+)\]',
                           lambda m: self.slot_names.get(
                               int(m.group(1)),
                               f'slot{m.group(1)}'), s)
            else:
                s = re.sub(r'\bn\[(\d+)\]', r'regs[\1]', s)
                # dynamic register indices are the same table
                s = re.sub(r'(?<![\w.])n\[', 'regs[', s)
                for pat in _BARE_N_PATTERNS:
                    s = pat.sub(r'\1regs\2', s)
            # child proto references
            s = re.sub(r'\bproto_(child\d+)\b',
                       lambda m: FN_NAMES.get(m.group(1),
                                              m.group(0)), s)
            # factory aliases (inlined stdlib)
            for a, mode in self.alias_mode.items():
                if mode != 'inline' or a in locals_:
                    continue
                if a == 'c' and rec is not None and rec.mode == 'A':
                    continue
                s = re.sub(rf'(?<![\w.]){re.escape(a)}\s*\(',
                           ALIASES[a] + '(', s)
            # shared interpreter state
            for orig, new in self.shared.items():
                if orig in locals_:
                    continue
                s = re.sub(rf'(?<![\w.]){re.escape(orig)}\b', new, s)
            # '_' as bit32.band when it is called but never assigned
            if rec is not None and '_' not in locals_:
                assigned = False
                for ln in rec.effects:
                    for st in CL.split_statements(ln):
                        m = CL._ASSIGN_RE.match(st.strip())
                        if m and '_' in [t.strip() for t in
                                         m.group(1).split(',')]:
                            assigned = True
                if not assigned:
                    s = re.sub(r'(?<![\w.])_\s*\(', 'bit32.band(', s)
            # leftover placeholder spellings
            s = re.sub(r'__unmaterialized\b',
                       'UNRESOLVED_CONST', s)
            s = re.sub(r'__stream_(\w)\b', r'STREAM_\1', s)
            out.append(s)
        return ''.join(out)


# ---------------------------------------------------- effect rendering
UNKNOWN_SET = set()
for _e in L.OPMAP.values():
    if _e.get('confidence') == 'unknown' or \
            (_e.get('body') or '').strip() == '__unknown__':
        UNKNOWN_SET.add(_e['name'])


def note_for(rec):
    """One-line plain-language note for an UNKNOWN-op record."""
    eff = ' '.join(rec.effects)
    bits = []
    if re.search(r'\bn\[\d+\]\s*=', eff):
        bits.append('writes register(s)')
    if re.search(r'\bn\[\d+\]\s*\(', eff) or re.search(r'\)\s*\(', eff):
        bits.append('performs a call')
    if re.search(r'\bn\[\d+\]\[', eff):
        bits.append('table access')
    if re.search(r'\bK\s*=', eff) or 'K[' in eff:
        bits.append('loads call-frame context (K)')
    if re.search(r'\b[GHhb]\s*[+\-]=|\bG\s*=', eff):
        bits.append('touches loop iterator state')
    if not bits:
        return ('semantics not yet interpreted — body kept verbatim')
    return ('uninterpreted opcode; observable effects: ' +
            ', '.join(bits) + ' — body kept verbatim')


def render_effect_lines(proto, rec):
    """Raw (pre-rename) lines for one record's semantics, excluding
    control plumbing. Comments carry cat 'comment'."""
    lines = []   # (text, cat)
    if rec.kind == 'folded':
        if rec.name.startswith('DECRYPTSTR'):
            val = None
            if proto.ctx is not None:
                val = proto.ctx.decrypted.get((rec.mode, rec.pc))
            if isinstance(val, str):
                shown = val if len(val) <= 60 else val[:57] + '...'
                lines.append(
                    (f'-- string decrypted in place by the VM: '
                     f'{json.dumps(shown)} (already applied)',
                     'comment'))
            elif val is not None:
                lines.append(
                    ('-- string decrypted in place by the VM '
                     '(binary content; already applied)', 'comment'))
            else:
                lines.append(
                    ('-- in-place string decryption; plaintext not '
                     'recovered', 'comment'))
        else:
            lines.append(
                ('-- in-place block decryption of the following '
                 'stream range (already applied)', 'comment'))
    elif rec.kind == 'unimpl':
        note = '; '.join(rec.notes) if rec.notes else \
            'opcode body not transcribed'
        lines.append((f'-- unimplemented: {note}', 'comment'))
        for ln in rec.effects:
            lines.append((ln, 'effect'))
    else:
        if (rec.name == 'UNKNOWN' or rec.name in UNKNOWN_SET) and rec.effects:
            lines.append((f'-- {note_for(rec)}', 'comment'))
        for ln in rec.effects:
            lines.append((ln, 'effect'))
    return lines


def dispatch_ctrl_lines(proto, rec):
    """Control lines for dispatch form (raw text, cat 'ctrl').
    ctrl shapes (clean_lib): ('goto', pc) | ('branch', cond, t, f) |
    ('switch', mode_no, entry) | ('dynamic',) | ('return',)."""
    kind = rec.ctrl[0] if rec.ctrl else None
    out = []
    if kind == 'goto':
        out.append(f'pc = {rec.ctrl[1]}')
    elif kind == 'branch':
        _, cond, t1, t2 = rec.ctrl
        out.append(f'if {cond} then pc = {t1} else pc = {t2} end')
    elif kind == 'switch':
        _, mode_no, entry = rec.ctrl
        modes = proto_modes(proto)
        letter = L.MODE_LETTER.get(mode_no)
        if letter and letter in modes:
            out.append(f'return seg_{letter}({entry}, ...)')
        else:
            out.append('-- mode switch to an unvisited mode; '
                       'execution leaves this proto')
            out.append('return')
    elif kind == 'dynamic':
        if rec.succ:
            m2, p2 = rec.succ[0]
            if m2 == rec.mode:
                out.append(f'pc = {p2}')
            else:
                out.append(f'return seg_{m2}({p2}, ...)')
        else:
            out.append('return')
    elif kind == 'return':
        out.append('return')
    else:
        succ = rec.rec.get('succ') or []
        if succ:
            out.append(f'pc = {succ[0][1]}')
        else:
            out.append('return')
    return [(t, 'ctrl') for t in out]


# ------------------------------------------------------------- emitters
# A "tagged line" is (indent, text, owner_key_or_None, cat).
def emit_structured(proto):
    def effects_fn(key):
        rec = proto.by_key[key]
        return [text for text, _cat in
                render_effect_lines(proto, rec)]

    st = CL.Structurer(proto.cfg, effects_fn)
    raw = st.run()
    # cosmetic: drop an 'else' whose arm is empty (the arm was a
    # pure jump); semantics unchanged
    kept = []
    for i, ln in enumerate(raw):
        if ln.text == 'else' and ln.cat == 'construct' and \
                i + 1 < len(raw) and raw[i + 1].text == 'end' and \
                raw[i + 1].indent == ln.indent:
            STATS['empty-else-dropped'] += 1
            continue
        kept.append(ln)
    return [(ln.indent + 1, ln.text, ln.owner, ln.cat) for ln in kept]


def emit_dispatch(proto):
    out = []
    order = proto_modes(proto)
    starts = {}
    for mode in order:
        rs = [r for r in proto.recs if r.mode == mode]
        starts[mode] = min(r.pc for r in rs) if rs else None
        out.append((1, f'-- mode {MODE_NUM[mode]} segment '
                    f'({len(rs)} instructions)', None, 'comment'))
        out.append((1, f'local function seg_{mode}(pc, ...)', None, 'raw'))
        out.append((2, 'while true do', None, 'raw'))
        for i, r in enumerate(rs):
            kw = 'if' if i == 0 else 'elseif'
            out.append((3, f'{kw} pc == {r.pc} then', r.key, 'ctrl'))
            eff = render_effect_lines(proto, r)
            for text, cat in eff:
                out.append((4, text, r.key, cat))
            has_ret = any(t.strip().startswith('return')
                          for t, _ct in eff)
            if not has_ret:
                for text, cat in dispatch_ctrl_lines(proto, r):
                    out.append((4, text, r.key, cat))
        out.append((3, 'else', None, 'raw'))
        out.append((4, 'return', None, 'raw'))
        out.append((3, 'end', None, 'raw'))
        out.append((2, 'end', None, 'raw'))
        out.append((1, 'end', None, 'raw'))
    entry_mode, entry_pc = proto.entry_key
    out.append((1, f'return seg_{entry_mode}({entry_pc}, ...)', None, 'raw'))
    return out


# ------------------------------------------------------- declarations
def scan_word(lines, word):
    pat = re.compile(rf'(?<![\w.]){re.escape(word)}\b')
    return any(pat.search(re.sub(r'"(?:[^"\\]|\\.)*"', '""', t))
               for _, t, _, _ in lines)


def declarations(proto, body_lines):
    """Declaration lines (indent 1) for the names the body actually
    uses, computed from the RENAMED body text."""
    decls = []
    fac = proto.factory
    # placeholders
    ph = sorted(n for n in proto.placeholders
                if scan_word(body_lines, n))
    if ph:
        decls.append((1, '-- constants the recovery could not '
                      'resolve (placeholders — see CLEAN-REPORT)',
                      None, 'comment'))
        decls.append((1, 'local ' + ', '.join(ph), None, 'raw'))
    # shared interpreter state
    shared_vals = {}
    plain = []
    for orig, new in sorted(proto.shared_map.items(),
                            key=lambda kv: kv[1]):
        if new in ('vm', 'capE', 'capO'):
            continue
        if not scan_word(body_lines, new):
            continue
        if new == 'seedV' and fac.get('P2') is not None:
            shared_vals[new] = fac.get('P2')
        elif new == 'seedL' and fac.get('P1') is not None:
            shared_vals[new] = fac.get('P1')
        else:
            plain.append(new)
    for new, val in shared_vals.items():
        decls.append((1, f'local {new} = {val}', None, 'raw'))
    if plain:
        decls.append((1, 'local ' + ', '.join(plain), None, 'raw'))
    # registers / slots
    if proto.regime == 'REGS':
        u = fac.get('u')
        decls.append((1, f'local regs = table.create({u})',
                      None, 'raw'))
    else:
        slots = [proto.slot_names[s] for s in
                 sorted(proto.slot_names)
                 if scan_word(body_lines, proto.slot_names[s])]
        if slots:
            decls.append((1, 'local ' + ', '.join(slots), None,
                          'raw'))
    # factory aliases used as values (rare): declare original letter
    for a, mode in proto.alias_mode.items():
        if mode == 'used':
            if scan_word(body_lines, a):
                decls.append((1, f'local {a} = {ALIASES[a]}', None,
                              'raw'))
                NAMING.append((proto.pid, a, ALIASES[a], 'CONFIRMED',
                               'factory alias bound as a value'))
    return decls


def proto_params(proto, body_lines):
    params = []
    if 'H' in proto_referenced(proto):
        params.append('vm')
    if proto_uses_word(proto, 'e'):
        params.append('capE')
    if proto_uses_word(proto, 'O'):
        params.append('capO')
    params.append('...')
    return params


def proto_referenced(proto):
    refs = set()
    for rec in proto.recs:
        rd, wr = CL.shared_refs(rec.effects)
        refs |= rd | wr
    return refs


def proto_uses_word(proto, w):
    pat = re.compile(rf'(?<![\w.]){w}\b')
    for rec in proto.recs:
        for ln in rec.effects:
            if pat.search(re.sub(r'"(?:[^"\\]|\\.)*"', '""', ln)):
                return True
    return False


def proto_modes(proto):
    have = {r.mode for r in proto.recs}
    return [m for m in ('A', 'B', 'C', 'D') if m in have]


def header_comment(proto):
    n = len(proto.recs)
    modes = proto_modes(proto)
    desc = ', '.join(f'mode {MODE_NUM[m]}: '
                     f'{sum(1 for r in proto.recs if r.mode == m)}'
                     for m in modes)
    fn = FN_NAMES[proto.pid]
    if proto.form == 'structured':
        form = 'structured control flow reconstructed from the ' \
               'walk graph'
    else:
        form = 'dispatch form retained — see CLEAN-REPORT ' \
               '(STRUCTURING_DEFERRED)'
    return [f'-- {fn}: {n} walked instructions ({desc}); {form}.']


# ------------------------------------------------------------- assembly
def build_proto_block(proto):
    rn = Renamer(proto)
    if proto.form == 'structured':
        body = emit_structured(proto)
    else:
        body = emit_dispatch(proto)
    # rename every tagged line with its owner's record context
    renamed = []
    for ind, text, owner, cat in body:
        rec = proto.by_key.get(owner) if owner else None
        renamed.append((ind, rn.rename(text, rec), owner, cat))
    decls = declarations(proto, renamed)
    params = proto_params(proto, renamed)
    fn = FN_NAMES[proto.pid]
    block = [(0, t, None, 'comment') for t in header_comment(proto)]
    block.append((0, f'local function {fn}({", ".join(params)})',
                  None, 'raw'))
    block.extend(decls)
    if not renamed:
        why = ('switches to a mode with no walked segment; '
               'returns immediately')
        block.append((1, f'-- {why}', None, 'comment'))
    block.extend(renamed)
    block.append((0, 'end', None, 'raw'))
    block.append((0, '', None, 'raw'))
    return block


# ------------------------------------------------------- bz / stub
def build_bz_block(pid, pstruct):
    fn = FN_NAMES[pid]
    src = (pstruct.get('closure_source') or '').strip()
    lines = [
        (0, f'-- {fn}: payload utility closure kept verbatim from '
            f'the builder table (constant artifact, not walked '
            f'bytecode).', None, 'comment'),
        (0, f'local {fn} = {src}', None, 'raw'),
        (0, '', None, 'raw'),
    ]
    return lines


def build_stub_block():
    return [
        (0, '-- unbuiltFn18: census descriptor that the payload '
            'factory never builds (phantom — proven in phase D/E; '
            'kept as an explicit stub).', None, 'comment'),
        (0, 'local function unbuiltFn18(...)', None, 'raw'),
        (1, 'error("proto child18 was never built")', None, 'raw'),
        (0, 'end', None, 'raw'),
        (0, '', None, 'raw'),
    ]


# ------------------------------------------------------------- main
def topo_order(protos):
    graph = {}
    for pid, p in protos.items():
        graph[pid] = set()
    for (parent, _t, _k), cid in L.CLOSURE_MAP.items():
        if cid in graph and parent in graph:
            graph[parent].add(cid)
    order = []
    seen = set()

    def visit(pid):
        if pid in seen:
            return
        seen.add(pid)
        for c in sorted(graph.get(pid, ())):
            visit(c)
        order.append(pid)

    visit('root')
    for pid in sorted(graph):
        visit(pid)
    return order


def prepare(pid, pstruct):
    proto = Proto(pid, pstruct)
    if proto.kind == 'bz-constant' or not proto.recs:
        return proto
    proto.regime_check()
    proto.in_state = CL.analyze_values(proto.cfg)
    proto.slot_names, proto.slot_evidence = compute_slot_names(proto)
    smap, amode, refs = compute_shared_map(proto)
    proto.shared_map = smap
    proto.alias_mode = amode
    proto.referenced = refs
    proto.placeholders = set()
    for rec in proto.recs:
        proto.placeholders |= rec.placeholders
    approve_for_loops(proto)
    apply_idioms(proto)
    # structuring attempt
    if len(proto.cfg.reachable) != len(proto.recs):
        proto.form = 'dispatch'
        proto.form_reason = (
            f'recorded walk graph is fragmented: only '
            f'{len(proto.cfg.reachable)}/{len(proto.recs)} records '
            f'are reachable from the entry through recorded '
            f'successors (control flow is dispatched through '
            f'register-held targets the walk observed once each)')
    else:
        try:
            CL.Structurer(
                proto.cfg,
                lambda k: [t for t, _ in
                           render_effect_lines(proto,
                                               proto.by_key[k])]).run()
            proto.form = 'structured'
        except CL.StructFail as e:
            proto.form = 'dispatch'
            proto.form_reason = str(e)
    return proto


FILE_HEADER = [
    '-- StealAnEggs.luau — source-cleaned reconstruction',
    '-- The original file was a Luraph v15.1 virtualized bootstrap; '
    'the original',
    '-- source text was never present in it. This file is the '
    'cleaned presentation',
    '-- of the verified devirtualized lift (full.luau): the same '
    '796 walked',
    '-- instructions, equivalence-mapped one-to-one in '
    'clean_map.json.',
    '-- Names are reconstructed, never recovered: stdlib renames '
    'are CONFIRMED',
    '-- from the interpreter factory bindings; all other names are '
    'INFERRED and',
    '-- listed in CLEAN-REPORT.md. Style: StyLua-like, 4-space '
    'indent.',
    '',
]


def main():
    protos = {}
    for pid, pstruct in STRUCTS.items():
        protos[pid] = prepare(pid, pstruct)
    order = topo_order(protos)

    tagged = []   # (indent, text, owner_pid, owner_key, cat)
    for t in FILE_HEADER:
        tagged.append((0, t, None, None, 'comment'))
    tagged.append((0, 'local function UNIMPL(mode, pc, op)',
                   None, None, 'raw'))
    tagged.append((1, 'error("unimplemented opcode (mode " .. '
                   'tostring(mode) .. ", pc " .. tostring(pc) .. '
                   '", op " .. tostring(op) .. ")")',
                   None, None, 'raw'))
    tagged.append((0, 'end', None, None, 'raw'))
    tagged.append((0, '', None, None, 'raw'))

    for pid in order:
        p = protos[pid]
        if pid == 'root':
            for ind, text, owner, cat in build_stub_block():
                tagged.append((ind, text, 'child18', owner, cat))
        if p.kind == 'bz-constant':
            block = build_bz_block(pid, p.pstruct)
        elif pid == 'child18':
            block = build_stub_block()
        else:
            block = build_proto_block(p)
        for ind, text, owner, cat in block:
            tagged.append((ind, text, pid, owner, cat))
    tagged.append((0, 'return main', None, None, 'raw'))

    # render text + per-record line ranges
    lines_out = []
    first_effect_idx = {}
    ranges = {}
    for i, (ind, text, pid, owner, cat) in enumerate(tagged):
        lines_out.append(('    ' * ind + text) if text else '')
        if owner is not None and cat in ('effect', 'comment',
                                         'ctrl'):
            key = (pid, owner)
            lo, hi = ranges.get(key, (i + 1, i + 1))
            ranges[key] = (min(lo, i + 1), max(hi, i + 1))
            if cat == 'effect' and key not in first_effect_idx:
                first_effect_idx[key] = i + 1
    # elided fetch records point at the call's first effect line
    for pid, p in protos.items():
        for rec in p.recs:
            if getattr(rec, 'elided_into', None):
                tgt = first_effect_idx.get((pid, rec.elided_into))
                if tgt:
                    ranges[(pid, rec.key)] = (tgt, tgt)

    src = '\n'.join(lines_out) + '\n'
    out_path = os.path.join(HERE, 'full_clean.luau')
    with open(out_path, 'w') as f:
        f.write(src)

    # ------------------------------------------------ clean_map.json
    entries = []
    for pid in order:
        p = protos[pid]
        for rec in p.recs:
            lo, hi = ranges.get((pid, rec.key), (None, None))
            entries.append({
                'proto': pid,
                'function': FN_NAMES[pid],
                'mode': rec.mode,
                'pc': rec.pc,
                'op': rec.name,
                'kind': rec.kind,
                'form': p.form,
                'lines': [lo, hi],
                'transforms': rec.transforms,
                'risk': rec.risk,
            })
    total = sum(len(p.recs) for p in protos.values())
    cmap = {
        'file': 'full_clean.luau',
        'raw_file': 'full.luau',
        'total_instructions': total,
        'mapped': len(entries),
        'protos': {
            pid: {
                'function': FN_NAMES[pid],
                'kind': protos[pid].kind,
                'form': protos[pid].form,
                'form_reason': protos[pid].form_reason,
                'regime': protos[pid].regime,
                'instructions': len(protos[pid].recs),
            } for pid in order
        },
        'entries': entries,
    }
    with open(os.path.join(HERE, 'clean_map.json'), 'w') as f:
        json.dump(cmap, f, indent=1)

    # ------------------------------------------------------- audit
    audit = audit_all(protos, ranges)
    stats = {
        'counters': dict(STATS),
        'audit': audit,
        'forms': {pid: protos[pid].form for pid in order},
        'form_reasons': {pid: protos[pid].form_reason
                         for pid in order
                         if protos[pid].form_reason},
        'slot_names': {pid: {str(k): v for k, v in
                             protos[pid].slot_names.items()}
                       for pid in order},
        'slot_evidence': {pid: {str(k): list(v) for k, v in
                                protos[pid].slot_evidence.items()}
                          for pid in order},
        'shared_maps': {pid: protos[pid].shared_map
                        for pid in order},
        'lines': src.count('\n'),
    }
    with open(os.path.join(HERE, 'clean_stats.json'), 'w') as f:
        json.dump(stats, f, indent=1)
    print(f'wrote full_clean.luau ({stats["lines"]} lines), '
          f'clean_map.json ({len(entries)}/{total})')
    print('audit:', json.dumps(audit))
    print('stats:', json.dumps(dict(STATS)))


def stmt_multiset(lines):
    out = Counter()
    for ln in lines:
        for st in CL.split_statements(ln):
            s = re.sub(r'\s+', ' ', st.strip()).rstrip(';')
            if s:
                out[s] += 1
    return out


def audit_all(protos, ranges):
    """Per-record statement comparison: cleaned rendering vs a fresh
    translation renamed with the same renamer. Any differing record
    must carry at least one transform tag."""
    problems = []
    checked = 0
    for pid, p in protos.items():
        if p.kind == 'bz-constant' or not p.recs:
            continue
        fresh, _ = CL.translate_proto(pid, p.pstruct)
        fresh_by = {r.key: r for r in fresh}
        rn = Renamer(p)
        for rec in p.recs:
            checked += 1
            fr = fresh_by[rec.key]
            raw_lines = [rn.rename(ln, fr) for ln in fr.effects]
            clean_lines = [rn.rename(ln, rec) for ln in rec.effects]
            a = stmt_multiset(raw_lines)
            b = stmt_multiset(clean_lines)
            if a != b and not rec.transforms:
                problems.append({
                    'proto': pid, 'key': list(rec.key),
                    'raw': dict(a), 'clean': dict(b)})
    return {'checked': checked, 'problems': problems[:20],
            'problem_count': len(problems)}


if __name__ == '__main__':
    main()
