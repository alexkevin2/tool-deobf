#!/usr/bin/env python3
"""decode_stage1.py — static stage-1 decoder for the StealAnEggs.luau
Luraph v15.1 sub-variant blob (no target code is executed; the vY
decode FSM is re-implemented in Python, see sim_core.py).

Pipeline (all steps verified byte-identically against the oracle
captures in ../tool-out/cap.log):

  1. Extract the VM-table blob field MY (long-bracket string), the
     gsub pattern YY="[ -'}~]" and the gsub replacement TABLE _Y
     from the raw .luau source.
  2. Stage 1a: E = string.gsub(string.sub(MY, 5), YY, _Y)
     (single-char class matches expand through the table)
     -> gsub.bin   (oracle CAP_GSUB / CAP_BUF)
  3. Stage 1b: run the vY FSM simulation: keystream seeding
     (states 10/18), in-place Ascii85 group decode with a 40-bit
     memo table (states 35/9/2/14/1), base-128 field parsing
     (states 21-42), and the single chunk copy (state 33, wY)
     -> src.bin    (source-buffer snapshot at the wY call; oracle CAP_SRC)
     -> dst.bin    (the copied chunk; oracle CAP_DST)

Usage: python3 decode_stage1.py [raw.luau] [cap.log]
Writes gsub.bin / src.bin / dst.bin next to this script. If an oracle
capture log (cap.log) is supplied/found, prints PASS/FAIL per stage
against it; otherwise prints the outputs' sha256 digests.
[tool copy: oracle comparison made optional vs. the case original]
"""
import binascii
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sim_core import VM, run_vy, LuaError  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
DEFAULT_RAW = os.environ.get('BVM_RAW', '')
DEFAULT_CAP = os.path.join(CASE, 'tool-out', 'cap.log')


# ---------- Luau source extraction ----------

def parse_lua_qs(s, i):
    """Parse a Luau double-quoted string literal at s[i] == '"'.
    Returns (value, next_index). Handles Luau escapes incl. \\ddd,
    \\xXX, \\z."""
    assert s[i] == '"'
    i += 1
    out = []
    simple = {'a': '\a', 'b': '\b', 'f': '\f', 'n': '\n', 'r': '\r',
              't': '\t', 'v': '\v', '\\': '\\', '"': '"', "'": "'"}
    while s[i] != '"':
        c = s[i]
        if c == '\\':
            n = s[i + 1]
            if n in simple:
                out.append(simple[n]); i += 2
            elif n.isdigit():
                j = i + 1; num = ''
                while j < len(s) and s[j].isdigit() and len(num) < 3:
                    num += s[j]; j += 1
                out.append(chr(int(num))); i = j
            elif n == 'x':
                out.append(chr(int(s[i + 2:i + 4], 16))); i += 4
            elif n == 'z':
                j = i + 2
                while s[j] in ' \t\n\r':
                    j += 1
                i = j
            else:
                out.append(n); i += 2
        else:
            out.append(c); i += 1
    return ''.join(out), i + 1


def extract_vm_fields(text):
    """Return (MY_bytes, YY_pattern, _Y_table) from the raw source."""
    # _Y replacement table: `_Y={[" "]="...", ...}` inside the VM
    # table literal (well past the blob; search from 1,000,000).
    i = text.find('_Y={', 1000000)
    if i < 0:
        raise ValueError('_Y table not found')
    j = i + 4
    table = {}
    while text[j] != '}':
        k, j = parse_lua_qs(text, j + 1)      # ["key"
        assert text[j] == ']' and text[j + 1] == '='
        v, j = parse_lua_qs(text, j + 2)      # ="value"
        table[k] = v
        if text[j] == ',':
            j += 1
    # YY pattern: YY="[ -'}~]" (the only YY assignment outside code)
    k = text.find('YY="', 1000000)
    yy, _ = parse_lua_qs(text, k + 3)
    # MY blob: MY=[==[ ... ]==]  (long bracket, level 2; first ]==]
    # terminates it — there is exactly one ]==] in the whole file)
    bi = text.find('MY=[==[')
    if bi < 0:
        raise ValueError('MY blob not found')
    content = text[bi + 7:]
    end = content.find(']==]')
    MY = content[:end]
    return MY.encode('latin-1'), yy, table


def lua_gsub(MY, table):
    """string.gsub(string.sub(MY,5), "[ -'}~]", table):
    the pattern is a single-character class (bytes 0x20-0x27, 0x7D,
    0x7E); each match is replaced by the table entry for that char
    (all 10 class chars are present in the table)."""
    body = MY[4:].decode('latin-1')          # string.sub(MY, 5)
    return ''.join(table.get(c, c) for c in body).encode('latin-1')


# ---------- oracles ----------

def load_oracles(path):
    caps = {}
    for ln in open(path, 'rb').read().split(b'\n'):
        if not ln:
            continue
        k, v = ln.rstrip(b'\r').split(b'\t')[:2]
        caps[k.decode()] = binascii.unhexlify(v)
    return caps


def main():
    raw_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_RAW
    if not raw_path:
        print('decode_stage1.py: no input file (pass argv[1] or set '
              'BVM_RAW)', file=sys.stderr)
        return 2
    cap_path = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_CAP
    text = open(raw_path, encoding='utf-8', errors='surrogateescape').read()
    MY, yy, table = extract_vm_fields(text)
    print(f"extracted: MY {len(MY)} chars (magic {MY[:4]!r}), "
          f"YY={yy!r}, _Y {len(table)} entries")

    gsub = lua_gsub(MY, table)

    def gsub_fn(H):
        # called by iz (state 17) exactly as in the source:
        # H[87](H[74](H.MY, 5), H.YY, H._Y)
        return lua_gsub(H.MY, H._Y)

    def fz_stub(E, y, n):
        # Stage 2 (the Fz interpreter) is out of scope for stage 1:
        # its return value only becomes vY's return value *after* the
        # wY chunk copy has been recorded; it cannot affect src/dst.
        return lambda a, b, c: ('FZ_STAGE2', E)

    H = VM(MY, yy, table, fz_stub)
    _, steps = run_vy(H, gsub_fn)
    print(f"vY FSM simulated: {steps} steps, "
          f"cz/gz seeded {len(H.cz)}/{len(H.gz)} entries, "
          f"wY chunk calls: {len(H.wy_calls)}")
    assert len(H.wy_calls) == 1, f"expected exactly 1 chunk call, got {len(H.wy_calls)}"
    call = H.wy_calls[0]
    src = call['src_snapshot']
    dst = call['dst']
    print(f"chunk: size {call['size']} @ cursor {call['cursor']}, "
          f"terminator byte {call['next_byte']}")

    for name, data in [('gsub', gsub), ('src', src), ('dst', dst)]:
        with open(os.path.join(HERE, name + '.bin'), 'wb') as f:
            f.write(data)

    if os.path.exists(cap_path):
        caps = load_oracles(cap_path)
        results = [
            ('stage 1a gsub == CAP_GSUB', gsub == caps['CAP_GSUB']),
            ('stage 1a gsub == CAP_BUF ', gsub == caps['CAP_BUF']),
            ('stage 1b src  == CAP_SRC ', src == caps['CAP_SRC']),
            ('stage 1c dst  == CAP_DST ', dst == caps['CAP_DST']),
        ]
        ok = True
        for label, passed in results:
            print(f"[{'PASS' if passed else 'FAIL'}] {label}")
            ok = ok and passed
        print('ALL STAGES PASS' if ok else 'SOME STAGES FAILED')
        return 0 if ok else 1
    import hashlib
    for name, data in [('gsub', gsub), ('src', src), ('dst', dst)]:
        print(f'{name}.bin: {len(data)} bytes sha256='
              f'{hashlib.sha256(data).hexdigest()}')
    print('no oracle capture log found; capture comparison skipped')
    return 0


if __name__ == '__main__':
    sys.exit(main())
