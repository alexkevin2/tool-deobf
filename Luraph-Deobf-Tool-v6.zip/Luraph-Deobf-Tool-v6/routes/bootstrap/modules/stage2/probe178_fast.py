#!/usr/bin/env python3
"""probe178_fast.py — fast state-178 descriptor census over the WHOLE
eager-error keyspace (tool version of the case's probe178b.py).

The case scanned the 11,318 eager-error keys in slices across two
scripts (probe178.py, non-aborting, ~3 s per 178-hit) and probe178b.py
(abort-on-entry). This version generalizes probe178b: a walk_note hook
raises Abort178 the moment the materializer enters state 178 (the
recursive-Fz child-build state), so a descriptor hit costs
milliseconds instead of a doomed multi-second build, and the scan
covers every eager-error key of all four root operand tables in one
pass, in sorted (table, key) order.

Detection only — no child builds are attempted here (the case proved
out-of-context builds diverge; see children2.py / STAGE2C2 §1.5).

Inputs : protos.json (eager-error keys), fz_sim.py, static/src.bin.
Outputs: census178.json (list of hit records, probe178_all.json
         shape) + census178_meta.json {scanned, hits, seconds}.
Output name overridable with env PROBE_OUT.
"""
import importlib.util
import json
import os
import signal
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)


class Abort178(Exception):
    pass


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


fz = load('fz_sim', os.path.join(HERE, 'fz_sim.py'))

_orig_walk_note = fz.walk_note


def walk_note_wrap(scope, state):
    if scope == 'idx' and state == 178:
        raise Abort178()
    return _orig_walk_note(scope, state)


fz.walk_note = walk_note_wrap

cap_in = fz.build_inputs()
E_real = cap_in['E']
H = fz.build_H()
H.cz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['cz'].items()})
H.gz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['gz'].items()})
H.oz = fz.buf_create(16, log=False)
work = fz.buf_fromstring(open(os.path.join(CASE, 'static', 'src.bin'), 'rb').read(), log=False)
chunk = fz._new_buf(bytearray(E_real[5]))
A = fz.LT()
fz.tset(A, 4, E_real[4])
fz.tset(A, 5, chunk)
fields = fz.LT()
for k, v in E_real[6].items():
    fz.tset(fields, k, v)
fz.tset(A, 6, fields)
Z, T = fz.pad(fz.mc(H, 'Fz', A, 201, 20), 2)
tables = list(fz.PROTO_TABLES[0][1:5])
print('build ok', flush=True)

pj = json.load(open(os.path.join(HERE, 'protos.json')))
eager_err = {(ti, int(k)) for ti, t in enumerate(pj['proto_groups'][0]['tables'])
             for k in t.get('errors', {})}
targets = sorted(eager_err)
print(f'targets: {len(targets)}', flush=True)


class KeyTimeout(Exception):
    pass


signal.signal(signal.SIGALRM, lambda s, f: (_ for _ in ()).throw(KeyTimeout()))
hits = []
scanned = 0
t0 = time.time()
for idx, (ti, key) in enumerate(targets):
    if key in tables[ti].d:
        continue
    scanned += 1
    signal.setitimer(signal.ITIMER_REAL, 2)
    try:
        fz.tget(tables[ti], key)
        signal.setitimer(signal.ITIMER_REAL, 0)
    except Abort178:
        signal.setitimer(signal.ITIMER_REAL, 0)
        hits.append({'table': ti, 'key': key, 'entered_178': True,
                     'fz_calls': 1, 'new_groups': 0,
                     'outcome': 'aborted-at-178', 'error': None})
        print('HIT', ti, key, flush=True)
    except KeyTimeout:
        signal.setitimer(signal.ITIMER_REAL, 0)
    except Exception:
        signal.setitimer(signal.ITIMER_REAL, 0)
    if idx % 2000 == 0:
        print(f'  {idx}/{len(targets)} ({time.time() - t0:.0f}s) hits={len(hits)}',
              flush=True)

_out = os.environ.get('PROBE_OUT', 'census178.json')
json.dump(hits, open(os.path.join(HERE, _out), 'w'), indent=1)
meta = {'scanned': scanned, 'targets': len(targets), 'hits': len(hits),
        'seconds': round(time.time() - t0, 1)}
json.dump(meta, open(os.path.join(HERE, 'census178_meta.json'), 'w'), indent=1)
print(f'CENSUS DONE: {len(hits)} hits / {scanned} scanned in '
      f'{time.time() - t0:.0f}s')
