"""Faithful Python transcription of the vY decode FSM from
StealAnEggs.luau (Luraph v15.1 sub-variant), used by decode_stage1.py.

Every method below is a line-by-line transcription of the Luau bodies
extracted from the raw source (see ../analysis/vy_methods.txt).  Luau
semantics reproduced: only nil/false are falsy; tables are 1-based
dicts (missing key == nil); buffers are bytearrays with little-endian
accessors; numbers are Python ints (all values in this FSM are exact
integers well below 2^53, matching Luau doubles).
"""
import struct


class LuaError(Exception):
    pass


def truthy(v):
    return v is not None and v is not False


def land(a, b):   # a and b
    return b if truthy(a) else a


def lua_num(v, what="value"):
    if isinstance(v, bool) or v is None or isinstance(v, (dict, bytearray, list)):
        raise LuaError(f"attempt to perform arithmetic on a {type(v).__name__} ({what})")
    return v


def cmp(op, a, b):
    if a is None or b is None:
        raise LuaError(f"attempt to compare nil with {op}")
    if op == '<':
        return a < b
    if op == '<=':
        return a <= b
    if op == '>':
        return a > b
    if op == '>=':
        return a >= b
    raise AssertionError(op)


# ---- Luau buffer library (little-endian, bounds-checked) ----
def buf_create(n):
    return bytearray(int(n))


def buf_fromstring(b):
    return bytearray(b)


def buf_readu8(buf, off):
    off = int(off)
    if off < 0 or off >= len(buf):
        raise LuaError(f"buffer readu8 out-of-bounds at {off} (len {len(buf)})")
    return buf[off]


def buf_readu32(buf, off):
    off = int(off)
    if off < 0 or off + 4 > len(buf):
        raise LuaError(f"buffer readu32 out-of-bounds at {off} (len {len(buf)})")
    return struct.unpack_from('<I', buf, off)[0]


def buf_writeu32(buf, off, val):
    off = int(off)
    if off < 0 or off + 4 > len(buf):
        raise LuaError(f"buffer writeu32 out-of-bounds at {off} (len {len(buf)})")
    struct.pack_into('<I', buf, off, int(val) & 0xFFFFFFFF)


def buf_copy(dst, doff, src, soff, count):
    doff, soff, count = int(doff), int(soff), int(count)
    if count:
        dst[doff:doff + count] = src[soff:soff + count]


def table_create(n):
    return {}


STORE_LOG = []   # stage2 instrumentation: (site, id(target), key, value-kind)


def _kind(v):
    if isinstance(v, dict):
        return 'table'
    if isinstance(v, bytearray):
        return 'buffer'
    if isinstance(v, bool):
        return 'bool'
    if isinstance(v, (int, float)):
        return 'number'
    if v is None:
        return 'nil'
    return type(v).__name__


class VM:
    """The H table: only the slots/fields the vY FSM touches."""

    def __init__(self, MY, YY, _Y, fz_stub):
        self.MY = MY            # raw blob string (bytes)
        self.YY = YY            # gsub pattern (str)
        self._Y = _Y            # gsub replacement table (dict str->str)
        self.cz = {}            # keystream packed u32 table
        self.gz = {}            # keystream last-byte table
        self.oz = bytearray(16)
        self.U = {}
        self.slot99 = 0         # H[99] — table literal has [99]=(0)
        self.w = None           # H.w
        self.fz_stub = fz_stub  # callable(E, y, n) -> callable
        self.wy_calls = []      # log of wY chunk-copy calls


# ============ FSM methods (transcribed) ============

def m_ez(H):
    return (True, 32, None, None, None, None, None, None, None, None, None, None, None)


def m_Jz(H, P, E, u, A, X, y):
    if cmp('<=', E, 0):
        E2 = buf_readu8(A, lua_num(y) + 2)
        return ((40 if cmp('>', 128, E2) else 30), X, E2)
    p2, p5, p1 = P.get(2), P.get(5), P.get(1)
    y2 = lua_num(p2) + lua_num(p5)
    i = cmp('<=', p5, 0)
    ge = cmp('>=', y2, p1)
    le = cmp('<=', y2, p1)
    A2 = land(i, ge) if truthy(land(i, ge)) else land(not i, le)
    P[2] = y2
    if truthy(A2):
        return (35, y2, u)
    return (22, X, u)


def m_Gz(H, P, E, u, A, X, y, i, J, B, z, S):
    if cmp('<=', y, 2):
        f = 1 * (lua_num(B) - lua_num(X))
        R = 52200625 * (lua_num(P) - 40)
        Pn = (lua_num(A) - 40) * 85 + (lua_num(J) - 40) * 614125 + (f + R + lua_num(i))
        z[E] = Pn
        STORE_LOG.append(('gz2_memo', id(z), E, _kind(Pn)))
        return (14, S, z, Pn)
    if cmp('<=', y, 3):
        return (15, S, lua_num(z, "Gz z+1") + 1, B)
    Pn = table_create(B)
    u[6] = Pn
    STORE_LOG.append(('gz4_segtable', id(u), 6, 'table#%d' % id(Pn)))
    return (28, {1: 1, 2: S, 3: B, 5: 0}, z, Pn)


def m_lz(H, P, E, u, A, X, y, i, J, B):
    if cmp('<=', i, 6):
        if cmp('<=', i, 5):
            z = buf_readu8(P, J)
            return ((27 if z >= 128 else 8), J, 5, z, A, X, y, E)
        z = buf_readu8(P, lua_num(J) + 2)
        return ((34 if 128 <= z else 42), J, u, B, z, X, y, E)
    if cmp('<=', i, 7):
        return (4, lua_num(J) + 1, u, B, A, X, y, E)
    if cmp('<=', i, 8):
        return (33, lua_num(J) + 1, u, B, A, X, y, E)
    Hv = lua_num(u) % 256
    Pv = (lua_num(u) - Hv) // 256
    E2 = Pv % 256
    Pv = (Pv - E2) // 256
    u2 = Pv % 256
    return (2, J, E2, B, u2, (Pv - u2) // 256, 7225 * (Hv - 40), 40)


def m_iz(H, P, E, u, A, X, y, i, J, gsub_fn):
    if cmp('<=', X, 15):
        A[P] = y
        STORE_LOG.append(('iz15_field', id(A), P, _kind(y)))
        return (1, 28, J, i, E, u)
    if cmp('<=', X, 16):
        return (2,)
    Pv = J.get(3)
    Es = gsub_fn(H)
    uv = buf_fromstring(Es)
    Av = len(Es) - 1
    Xv = 5
    Ev = 0 - Xv
    return (1, 1, {1: Av, 2: Ev, 4: Pv, 5: Xv}, 0, {}, uv)


def m_Az(H, P, E, u, A, X, y, i, J, B):
    if cmp('<=', B, 22):
        if cmp('<=', B, 21):
            z = 128 * (lua_num(E) - 128) + lua_num(P)
            return (33, J, u, 2 + lua_num(A), i, X, y, z, P)
        z = J.get(4)
        H.w = i
        S, f = H.w, H.slot99
        R = buf_readu8(S, f)
        return ((12 if R < 128 else 24), z, S, f, {}, R, y, E, P)
    if cmp('<=', B, 23):
        z = buf_readu8(u, A)
        return ((3 if 128 > z else 19), J, u, A, i, X, y, E, z)
    if cmp('<=', B, 24):
        B2 = buf_readu8(u, lua_num(A) + 1)
        return ((31 if B2 >= 128 else 29), J, u, A, i, X, B2, E, P)
    return (5, J.get(2), u, A, i, X, y, E, P)


def m_dY(H, P, E, u, A, X, y, i):
    if cmp('<=', y, 26):
        J = 128 * (lua_num(A) - 128) + lua_num(i)
        return (4, lua_num(P) + 2, J, i, X)
    if cmp('<=', y, 27):
        y2 = buf_readu8(E, 1 + lua_num(P))
        return ((20 if y2 >= 128 else 21), P, A, i, y2)
    Hv, Ev, yv = u.get(5), u.get(1), u.get(3)
    J = lua_num(Hv) + lua_num(Ev)
    Bv = cmp('<=', Ev, 0)
    ge = cmp('>=', J, yv)
    le = cmp('<=', J, yv)
    y2 = land(Bv, ge) if truthy(land(Bv, ge)) else land(not Bv, le)
    u[5] = J
    if truthy(y2):
        return (23, P, A, J, X)
    return (25, P, A, i, X)


def m_KY(H, P, E, u, A, X, y, i, J, B):
    if cmp('<=', y, 29):
        z = 128 * (lua_num(A) - 128) + lua_num(J)
        return (39, lua_num(u) + 2, z, i, E)
    if cmp('<=', y, 30):
        yv = buf_readu8(B, lua_num(u) + 3)
        Jv = 128 * (lua_num(E) - 128)
        z = 2097152 * (lua_num(P) - 128)
        S = 16384 * (lua_num(X) - 128)
        f = yv % 128
        R = yv % 128
        Pv = 2097152 * (yv - R)
        R2 = S + (Jv + z) + (f + Pv)
        return (15, 4 + lua_num(u), A, i, R2)
    Pv = buf_readu8(B, 2 + lua_num(u))
    return ((38 if Pv >= 128 else 13), u, A, Pv, E)


def m_wY(H, P, E, u, A, X, y, i, J):
    if cmp('<=', J, 32):
        Jv = 1
        return (10, {1: 0 - Jv, 2: Jv, 3: i, 4: 255}, 41, 41)
    Jb = buf_create(P)
    buf_copy(Jb, 0, X, u, P)
    Bv = lua_num(u) + lua_num(P)
    E[A] = Jb
    STORE_LOG.append(('wy_chunk', id(E), A, 'buffer'))
    Pv = buf_readu8(X, Bv)
    Av = Bv + 1
    E[4] = (0 != Pv)
    STORE_LOG.append(('wy_term', id(E), 4, 'bool'))
    H.slot99 = Av
    H.wy_calls.append({
        'size': P, 'cursor': u,
        'src_snapshot': bytes(X),
        'dst': bytes(Jb),
        'next_byte': Pv,
    })
    fn = H.fz_stub(E, y, 20)
    res = fn(None, H.U, None)
    return (16, i, res, u)


def m_PY(H, P, E, u, A, X, y, i, J, B):
    if cmp('<=', E, 34):
        z = buf_readu8(P, lua_num(u) + 3)
        S = 128 * (lua_num(B) - 128)
        f = 2097152 * (lua_num(i) - 128)
        R = (lua_num(y) - 128) * 16384
        hv = z % 128
        xv = z % 128
        e = 2097152 * (z - xv)
        z2 = f + S + (e + (R + hv))
        return (4, 4 + lua_num(u), J, z2, i)
    if cmp('<=', E, 35):
        Ev = buf_readu32(X, J)
        z = buf_readu8(X, 4 + lua_num(J))
        Xv = 4294967296 * z + Ev
        S = u.get(Xv)
        if truthy(S):
            return (14, u, S, B, i)
        return (9, u, Ev, z, Xv)
    Ev = buf_readu8(P, 3 + lua_num(u))
    Xv = 128 * (lua_num(i) - 128)
    z = 2097152 * (lua_num(y) - 128)
    S = (lua_num(A) - 128) * 16384
    Hv = Ev % 128 + 2097152 * (Ev - Ev % 128) + (z + (S + Xv))
    return (33, 4 + lua_num(u), J, B, Hv)


def m_jY(H, P, E, u, A, X, y):
    if cmp('<=', u, 37):
        iv = buf_readu8(A, lua_num(P) + 1)
        return ((6 if iv >= 128 else 26), P, y, E, iv)
    if cmp('<=', u, 38):
        uv = buf_readu8(A, lua_num(P) + 3)
        iv = (lua_num(y) - 128) * 128
        J = (lua_num(E) - 128) * 2097152
        B = 16384 * (lua_num(X) - 128)
        z = uv % 128
        S = 2097152 * (uv - uv % 128) + z + (iv + B + J)
        return (39, lua_num(P) + 4, S, E, X)
    Ev = lua_num(y) - 5352
    uv = buf_readu8(A, P)
    return ((37 if 128 <= uv else 7), P, Ev, uv, X)


def m_VY(H, hh, P, E, u, A, X, y):
    if cmp('<=', X, 40):
        iv = lua_num(E) - 128
        J = 128 * (lua_num(A) - 128) + (iv + lua_num(hh) * 16384)
        return (15, 3 + lua_num(y), u, J)
    if cmp('<=', X, 41):
        Hv = lua_num(A) + (lua_num(E) - 128) * 128
        return (15, lua_num(y) + 2, u, Hv)
    Hv = lua_num(u) - 128
    Av = (lua_num(P) - 128) * 128
    Pv = Hv + 16384 * lua_num(E) + Av
    return (4, lua_num(y) + 3, Pv, E)


def m_rz(H, P, E, u, A, X):
    if cmp('<=', E, 18):
        yv = (lua_num(X) * lua_num(u) + lua_num(A)) % 256
        iv = (yv * lua_num(u) + lua_num(A)) % 256
        J = (lua_num(A) + iv * lua_num(u)) % 256
        B = (J * lua_num(u) + lua_num(A)) % 256
        z, S, f = H.cz, 256 * iv, J * 65536
        z[X] = S + B * 16777216 + (yv + f)
        H.gz[X] = B
        return (10, P)
    if cmp('<=', E, 19):
        Pv = buf_readu8(u, 1 + lua_num(A))
        return ((0 if 128 <= Pv else 41), Pv)
    Pv = buf_readu8(u, lua_num(A) + 2)
    return ((11 if Pv < 128 else 36), Pv)


def m_xz(H, P, E, u, A, X, y, i, J, B, z):
    if cmp('<=', i, 11):
        if cmp('<=', i, 10):
            S, f, R = X.get(1), X.get(2), X.get(4)
            hv = lua_num(S) + lua_num(f)
            xv = cmp('<=', f, 0)
            ge = cmp('>=', hv, R)
            le = cmp('<=', hv, R)
            Rv = land(xv, ge) if truthy(land(xv, ge)) else land(not xv, le)
            X[1] = hv
            if truthy(Rv):
                return (18, y, u, hv, P, z)
            return (17, y, u, A, P, z)
        Xv = lua_num(z) - 128 + ((lua_num(J) - 128) * 128 + 16384 * lua_num(B))
        return (33, y, lua_num(u) + 3, A, P, Xv)
    if cmp('<=', i, 12):
        return (39, y, 1 + lua_num(u), A, P, z)
    if cmp('<=', i, 13):
        Xv = lua_num(P) - 128
        iv = (lua_num(E) - 128) * 128
        Ev = 16384 * lua_num(z) + iv + Xv
        return (39, y, lua_num(u) + 3, A, Ev, z)
    buf_writeu32(A, y, P)
    return (1, lua_num(y) + 4, u, A, P, z)


# ============ vY driver (transcribed) ============

def run_vy(H, gsub_fn, max_steps=200_000_000, trace=None):
    P, E, u, A, X, y, i, J, B, z, S, f, R = m_ez(H)
    h, x, e, us, a, O, b, l, G, w, L, g = E, u, A, X, y, i, J, B, z, S, f, R
    steps = 0
    while truthy(P):
        steps += 1
        if steps > max_steps:
            raise LuaError(f"step limit {max_steps} exceeded at state {h}")
        if trace is not None:
            trace(steps, h)
        if h <= 20:
            if h <= 9:
                if h <= 4:
                    if h <= 1:
                        h, O, L = m_Jz(H, x, h, L, e, O, us)
                    else:
                        h, x, us, O = m_Gz(H, G, l, a, w, g, h, L, b, O, us, x)
                else:
                    h, us, O, l, G, w, L, g = m_lz(H, e, g, O, G, w, L, h, us, l)
            elif h <= 14:
                h, e, us, a, O, l = m_xz(H, O, b, us, a, x, e, h, G, w, l)
            elif h <= 17:
                r = m_iz(H, l, us, a, O, h, G, e, x, gsub_fn)
                f = r[0]
                if f == 1:
                    _, J, y, E, S, B = r
                    h, x, e, us, a = J, y, E, S, B
                elif f == 2:
                    return e, steps
            else:
                h, w = m_rz(H, w, h, e, us, a)
        elif h <= 31:
            if h <= 25:
                h, x, e, us, a, O, b, l, G = m_Az(H, G, l, e, us, O, b, a, x, h)
            elif h <= 28:
                h, us, b, l, G = m_dY(H, us, e, x, b, G, h, l)
            else:
                h, us, O, l, G = m_KY(H, w, G, us, O, L, h, l, b, e)
        elif h <= 36:
            if h <= 33:
                h, x, e, us = m_wY(H, l, a, us, O, e, b, x, h)
            else:
                h, us, O, b, l = m_PY(H, e, h, us, w, a, G, l, O, b)
        elif h <= 39:
            h, us, O, b, l = m_jY(H, us, b, h, e, l, O)
        else:
            h, us, b, G = m_VY(H, L, l, G, b, w, h, us)
    return e, steps
