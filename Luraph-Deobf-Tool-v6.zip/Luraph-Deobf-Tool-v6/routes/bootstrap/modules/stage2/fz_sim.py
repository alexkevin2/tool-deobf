#!/usr/bin/env python3
"""fz_sim.py — stage-2 phase B: faithful Python transcription of the Fz
builder layer of StealAnEggs.luau (Luraph v15.1 sub-variant).

Method mirrors stage 1 (sim_core.py): line-by-line transcription of
the Luau bodies extracted in fz_source.txt / all_funcs.txt, driven by
the real table E captured from the oracle-verified vY simulator.
No target code is executed in a Luau runtime.

Validation oracle: tool-out/btrace_head.log (first 160,000 mutating
buffer ops of a real run; reads are NOT logged by that runner) and the
materialized buffers in analysis/bufs1/ (state after those 160K ops).
This sim logs every mutating buffer op in the same text format; the
Fz-phase op stream must equal oracle lines 123444..160000.

Luau semantics notes (same conventions as sim_core.py):
- only nil/false are falsy; numbers are Python int/float (doubles);
- buffers are 0-based, little-endian, bounds-checked;
- tables are 1-based dicts; missing key == nil; assigning nil deletes;
- method calls H:m(a, b) pass H first; returns are tuples, padded
  with nil at call sites via pad().
"""
import json
import math
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
RAW = os.environ.get('BVM_RAW') or sys.exit(
    'fz_sim.py: BVM_RAW env var (input .luau path) is not set')


class LuaError(Exception):
    pass


class Untranscribed(Exception):
    """Raised when the walk calls a VM-table function that has not
    been transcribed yet. Carries the name so it can be added."""

    def __init__(self, name):
        super().__init__(f'UNTRANSCRIBED: {name}')
        self.name = name


def truthy(v):
    return v is not None and v is not False


def land(a, b):   # a and b
    return b if truthy(a) else a


def lor(a, b):    # a or b
    return a if truthy(a) else b


def pad(t, n):
    """Pad a return tuple with nils (or truncate) to exactly n."""
    if len(t) >= n:
        return t[:n]
    return t + (None,) * (n - len(t))


def lua_num(v, what='value'):
    if isinstance(v, bool) or v is None or isinstance(v, (LT, Buf, list)):
        raise LuaError(f'arithmetic on {type(v).__name__} ({what})')
    return v


def lua_mod(a, b):
    """Luau %: floored modulo (sign of divisor), works for int/float."""
    a = lua_num(a, 'mod lhs')
    b = lua_num(b, 'mod rhs')
    if isinstance(a, int) and isinstance(b, int):
        return a % b
    return a - math.floor(a / b) * b


def lua_div(a, b):
    return lua_num(a) / lua_num(b)


def num_key(k):
    """Normalize a table key: integral floats become ints."""
    if isinstance(k, float) and k.is_integer() and abs(k) < 2 ** 53:
        return int(k)
    return k


# ----------------------------------------------------------------------
# Buffers with oracle-format op logging
# ----------------------------------------------------------------------

OPLOG = []           # Fz-phase op lines (oracle format)
BUFFER_REGISTRY = []  # index = id-1


def fmt_num(v):
    """Format a number the way the runner's trace does (tostring)."""
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if v.is_integer() and abs(v) < 1e15:
            return str(int(v))
        return repr(v)
    raise LuaError(f'fmt_num on {type(v).__name__}')


def fmt_arg(v):
    if isinstance(v, Buf):
        return f'#{v.id}'
    if isinstance(v, (bytes, bytearray)):
        return f'S{len(v)}'
    if v is None:
        return 'nil'
    if isinstance(v, (int, float, bool)):
        return fmt_num(v)
    return type(v).__name__


class Buf:
    __slots__ = ('data', 'id')

    def __init__(self, data, bid):
        self.data = bytearray(data)
        self.id = bid

    def __len__(self):
        return len(self.data)

    def __repr__(self):
        return f'<buffer #{self.id} len={len(self.data)}>'


def _new_buf(data):
    _check_buf_size(len(data), 'buffer')
    b = Buf(data, len(BUFFER_REGISTRY) + 1)
    # [tool copy] the registry only assigns ids; nothing ever reads
    # buffers back from it. The case original pinned every Buf,
    # which OOM-kills eager materialization on memory-capped hosts:
    # descriptor walks repeatedly reconstruct ~2.5 MB stream buffers
    # (transient in the real VM) and pinning them all grows RSS by
    # gigabytes. Ids are unchanged; live buffers stay alive through
    # their real references exactly as before.
    BUFFER_REGISTRY.append(None)
    return b


BUF_CAP = int(os.environ.get('BVM_BUF_CAP', str(32 * 1024 * 1024)))


def _check_buf_size(n, what):
    # [tool copy] Exhaustive eager materialization walks descriptors
    # the real execution never touches; a few decode a size field
    # from the encrypted region and call buffer.create(~511 MB),
    # and the results accumulate in a sim table — tens of GB over a
    # full keyspace pass (the case absorbed this on a large host).
    # Legit buffers in this build family are <= ~1 MB (work buffer
    # 617,190 B). The cap turns those walks into ordinary per-key
    # errors instead of host OOM kills. Adjustable via BVM_BUF_CAP.
    if n > BUF_CAP:
        raise LuaError(f'{what} size {n} exceeds tool cap {BUF_CAP} '
                       f'(BVM_BUF_CAP)')


def buf_create(n, log=True):
    n = int(lua_num(n, 'buffer.create'))
    _check_buf_size(n, 'buffer.create')
    b = _new_buf(bytearray(n))
    if log:
        OPLOG.append(f'B create {fmt_num(n)} -> #{b.id}')
    return b


def buf_fromstring(s, log=True):
    if isinstance(s, str):
        s = s.encode('latin-1')
    _check_buf_size(len(s), 'buffer.fromstring')
    b = _new_buf(bytearray(s))
    if log:
        OPLOG.append(f'B fromstring S{len(s)} -> #{b.id}')
    return b


def _off(buf, off):
    off = int(lua_num(off, 'offset'))
    if off < 0:
        raise LuaError(f'negative buffer offset {off}')
    return off


def buf_len(b):
    return len(b.data)


def buf_tostring(b):
    return bytes(b.data)


def buf_readu8(b, off):
    off = _off(b, off)
    if off >= len(b.data):
        raise LuaError(f'readu8 OOB @{off} len {len(b.data)} (#{b.id})')
    return b.data[off]


def buf_readi8(b, off):
    v = buf_readu8(b, off)
    return v - 256 if v >= 128 else v


def buf_readu16(b, off):
    off = _off(b, off)
    if off + 2 > len(b.data):
        raise LuaError(f'readu16 OOB @{off} len {len(b.data)} (#{b.id})')
    return struct.unpack_from('<H', b.data, off)[0]


def buf_readi16(b, off):
    v = buf_readu16(b, off)
    return v - 65536 if v >= 32768 else v


def buf_readu32(b, off):
    off = _off(b, off)
    if off + 4 > len(b.data):
        raise LuaError(f'readu32 OOB @{off} len {len(b.data)} (#{b.id})')
    return struct.unpack_from('<I', b.data, off)[0]


def buf_readi32(b, off):
    v = buf_readu32(b, off)
    return v - 4294967296 if v >= 2147483648 else v


def buf_readf32(b, off):
    off = _off(b, off)
    if off + 4 > len(b.data):
        raise LuaError(f'readf32 OOB @{off} len {len(b.data)} (#{b.id})')
    return struct.unpack_from('<f', b.data, off)[0]


def buf_readf64(b, off):
    off = _off(b, off)
    if off + 8 > len(b.data):
        raise LuaError(f'readf64 OOB @{off} len {len(b.data)} (#{b.id})')
    return struct.unpack_from('<d', b.data, off)[0]


def buf_readstring(b, off, count):
    off = _off(b, off)
    count = int(lua_num(count, 'readstring count'))
    if off + count > len(b.data):
        raise LuaError(f'readstring OOB @{off}+{count} len {len(b.data)} (#{b.id})')
    return bytes(b.data[off:off + count])


def buf_readbits(b, off, nbits):
    off = _off(b, off)
    nbits = int(lua_num(nbits, 'readbits'))
    val = 0
    for i in range(nbits):
        bitpos = off * 8 + i  # Luau readbits: offset is in BYTES? no - bits are
        # addressed from byte offset*8 upward, LSB-first per Luau docs:
        byte_i = (off * 8 + i) // 8
        bit_i = (off * 8 + i) % 8
        if byte_i >= len(b.data):
            raise LuaError('readbits OOB')
        if (b.data[byte_i] >> bit_i) & 1:
            val |= (1 << i)
    return val


def buf_writeu8(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writeu8 value')
    if log:
        OPLOG.append(f'B writeu8 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off >= len(b.data):
        raise LuaError(f'writeu8 OOB @{off} len {len(b.data)} (#{b.id})')
    b.data[off] = int(raw) & 0xFF


def buf_writei8(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writei8 value')
    if log:
        OPLOG.append(f'B writei8 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off >= len(b.data):
        raise LuaError(f'writei8 OOB @{off} len {len(b.data)} (#{b.id})')
    b.data[off] = int(raw) & 0xFF


def buf_writeu16(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writeu16 value')
    if log:
        OPLOG.append(f'B writeu16 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off + 2 > len(b.data):
        raise LuaError(f'writeu16 OOB @{off} len {len(b.data)} (#{b.id})')
    struct.pack_into('<H', b.data, off, int(raw) & 0xFFFF)


def buf_writei16(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writei16 value')
    if log:
        OPLOG.append(f'B writei16 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off + 2 > len(b.data):
        raise LuaError(f'writei16 OOB @{off} len {len(b.data)} (#{b.id})')
    struct.pack_into('<H', b.data, off, int(raw) & 0xFFFF)


def buf_writeu32(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writeu32 value')
    if log:
        OPLOG.append(f'B writeu32 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off + 4 > len(b.data):
        raise LuaError(f'writeu32 OOB @{off} len {len(b.data)} (#{b.id})')
    struct.pack_into('<I', b.data, off, int(raw) & 0xFFFFFFFF)


def buf_writei32(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writei32 value')
    if log:
        OPLOG.append(f'B writei32 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off + 4 > len(b.data):
        raise LuaError(f'writei32 OOB @{off} len {len(b.data)} (#{b.id})')
    v = int(raw) & 0xFFFFFFFF
    if v >= 2147483648:
        v -= 4294967296
    struct.pack_into('<i', b.data, off, v)


def buf_writef32(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writef32 value')
    if log:
        OPLOG.append(f'B writef32 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off + 4 > len(b.data):
        raise LuaError(f'writef32 OOB @{off} len {len(b.data)} (#{b.id})')
    struct.pack_into('<f', b.data, off, float(raw))


def buf_writef64(b, off, val, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'writef64 value')
    if log:
        OPLOG.append(f'B writef64 #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    if off + 8 > len(b.data):
        raise LuaError(f'writef64 OOB @{off} len {len(b.data)} (#{b.id})')
    struct.pack_into('<d', b.data, off, float(raw))


def buf_writestring(b, off, s, log=True):
    off = _off(b, off)
    if isinstance(s, str):
        s = s.encode('latin-1')
    if log:
        OPLOG.append(f'B writestring #{b.id} {fmt_num(off)} S{len(s)} -> ')
    if off + len(s) > len(b.data):
        raise LuaError(f'writestring OOB @{off} len {len(b.data)} (#{b.id})')
    b.data[off:off + len(s)] = s


def buf_writebits(b, off, nbits, val, log=True):
    off = _off(b, off)
    nbits = int(lua_num(nbits, 'writebits'))
    raw = int(lua_num(val, 'writebits value'))
    if log:
        OPLOG.append(f'B writebits #{b.id} {fmt_num(off)} {fmt_num(nbits)} {fmt_num(raw)} -> ')
    for i in range(nbits):
        byte_i = (off * 8 + i) // 8
        bit_i = (off * 8 + i) % 8
        if byte_i >= len(b.data):
            raise LuaError('writebits OOB')
        if (raw >> i) & 1:
            b.data[byte_i] |= (1 << bit_i)
        else:
            b.data[byte_i] &= ~(1 << bit_i) & 0xFF


def buf_fill(b, off, val, count=None, log=True):
    off = _off(b, off)
    raw = lua_num(val, 'fill value')
    if count is None:
        cnt = len(b.data) - off
        if log:
            OPLOG.append(f'B fill #{b.id} {fmt_num(off)} {fmt_num(raw)} -> ')
    else:
        cnt = int(lua_num(count, 'fill count'))
        if log:
            OPLOG.append(f'B fill #{b.id} {fmt_num(off)} {fmt_num(raw)} {fmt_num(cnt)} -> ')
    v = int(raw) & 0xFF
    end = min(off + cnt, len(b.data))
    if off < len(b.data):
        b.data[off:end] = bytes([v]) * (end - off)


def buf_copy(dst, doff, src, soff, count=None, log=True):
    doff = _off(dst, doff)
    soff = _off(src, soff)
    if count is None:
        cnt = len(src.data) - soff
        if log:
            OPLOG.append(f'B copy #{dst.id} {fmt_num(doff)} #{src.id} {fmt_num(soff)} -> ')
    else:
        cnt = int(lua_num(count, 'copy count'))
        if log:
            OPLOG.append(f'B copy #{dst.id} {fmt_num(doff)} #{src.id} {fmt_num(soff)} {fmt_num(cnt)} -> ')
    if cnt:
        dst.data[doff:doff + cnt] = src.data[soff:soff + cnt]


# ----------------------------------------------------------------------
# Tables
# ----------------------------------------------------------------------

class LT:
    """Luau table: dict-backed, with optional metatable."""
    __slots__ = ('d', 'mt')

    def __init__(self):
        self.d = {}
        self.mt = None

    def __repr__(self):
        return f'<table {len(self.d)} keys>'


def tget(t, k):
    """Index a table with full __index semantics."""
    if t is None:
        raise LuaError(f'attempt to index nil with {k!r}')
    if isinstance(t, (bytes, bytearray)):
        raise LuaError('attempt to index a string/buffer value')
    if not isinstance(t, LT):
        raise LuaError(f'attempt to index {type(t).__name__}')
    k = num_key(k)
    v = t.d.get(k)
    if v is not None:
        return v
    mt = t.mt
    seen = 0
    while mt is not None and seen < 100:
        seen += 1
        idx = mt.d.get('__index') if isinstance(mt, LT) else None
        if idx is None:
            return None
        if callable(idx):
            return idx(t, k)
        if isinstance(idx, LT):
            t = idx
            v = t.d.get(k)
            if v is not None:
                return v
            mt = t.mt
            continue
        return None
    return None


def tget_raw(t, k):
    if not isinstance(t, LT):
        raise LuaError(f'rawget on {type(t).__name__}')
    return t.d.get(num_key(k))


def tset(t, k, v):
    if not isinstance(t, LT):
        raise LuaError(f'attempt to index {type(t).__name__} with set')
    k = num_key(k)
    if k is None:
        raise LuaError('table index is nil')
    if v is None:
        t.d.pop(k, None)
    else:
        t.d[k] = v


def tset_raw(t, k, v):
    tset(t, k, v)


def setmetatable(t, mt):
    if not isinstance(t, LT):
        raise LuaError('setmetatable on non-table')
    t.mt = mt
    return t


def getmetatable(t):
    if isinstance(t, LT):
        return t.mt
    return None


def table_create(n=0, v=None, *_extra):
    t = LT()
    if v is not None:
        for i in range(1, int(lua_num(n, 'table.create')) + 1):
            t.d[i] = v
    return t


class KSDict(dict):
    """Keystream table (cz/gz): [] access normalizes keys, nil -> error."""

    def __getitem__(self, k):
        v = self.get(num_key(k))
        if v is None:
            raise LuaError(f'keystream[{k!r}] is nil')
        return v


# ----------------------------------------------------------------------
# bit32 / string / misc stdlib
# ----------------------------------------------------------------------

def _u32(v):
    return int(lua_num(v, 'bit32 arg')) & 0xFFFFFFFF


def bit32_bxor(*args):
    r = 0
    for a in args:
        r ^= _u32(a)
    return r


def bit32_band(*args):
    r = 0xFFFFFFFF
    for a in args:
        r &= _u32(a)
    return r


def bit32_bor(*args):
    r = 0
    for a in args:
        r |= _u32(a)
    return r


def bit32_bnot(v):
    return (~_u32(v)) & 0xFFFFFFFF


def bit32_rshift(v, n):
    n = int(lua_num(n, 'shift'))
    x = _u32(v)
    if n >= 32:
        return 0
    if n < 0:
        return bit32_lshift(v, -n)
    return x >> n


def bit32_lshift(v, n):
    n = int(lua_num(n, 'shift'))
    x = _u32(v)
    if n >= 32:
        return 0
    if n < 0:
        return bit32_rshift(v, -n)
    return (x << n) & 0xFFFFFFFF


def bit32_rrotate(v, n):
    n = int(lua_num(n, 'rotate')) % 32
    x = _u32(v)
    return ((x >> n) | (x << ((32 - n) % 32))) & 0xFFFFFFFF


def bit32_lrotate(v, n):
    n = int(lua_num(n, 'rotate')) % 32
    x = _u32(v)
    return ((x << n) | (x >> ((32 - n) % 32))) & 0xFFFFFFFF


def bit32_countlz(v):
    x = _u32(v)
    if x == 0:
        return 32
    return 32 - x.bit_length()


def bit32_countrz(v):
    x = _u32(v)
    if x == 0:
        return 32
    return (x & -x).bit_length() - 1


def string_sub(s, i, j=None):
    if isinstance(s, str):
        s = s.encode('latin-1')
    n = len(s)
    i = int(lua_num(i, 'string.sub i'))
    j = -1 if j is None else int(lua_num(j, 'string.sub j'))
    if i < 0:
        i = n + i + 1
    if j < 0:
        j = n + j + 1
    i = max(i, 1)
    j = min(j, n)
    if i > j:
        return b''
    return s[i - 1:j]


def string_rep(s, n, sep=None):
    if isinstance(s, str):
        s = s.encode('latin-1')
    n = int(lua_num(n, 'string.rep n'))
    if sep is not None:
        if isinstance(sep, str):
            sep = sep.encode('latin-1')
        return sep.join([s] * n) if n > 0 else b''
    return s * max(n, 0)


def string_byte(s, i=1, j=None):
    if isinstance(s, str):
        s = s.encode('latin-1')
    i = int(lua_num(i, 'string.byte i'))
    if i < 0:
        i = len(s) + i + 1
    if j is None:
        if 1 <= i <= len(s):
            return (s[i - 1],)
        return ()
    j = int(lua_num(j, 'string.byte j'))
    if j < 0:
        j = len(s) + j + 1
    return tuple(s[i - 1:j])


def string_char(*args):
    return bytes(int(lua_num(a, 'string.char')) & 0xFF for a in args)


def lua_type(v):
    if v is None:
        return 'nil'
    if isinstance(v, bool):
        return 'boolean'
    if isinstance(v, (int, float)):
        return 'number'
    if isinstance(v, (bytes, str)):
        return 'string'
    if isinstance(v, LT):
        return 'table'
    if isinstance(v, Buf):
        return 'buffer'
    if isinstance(v, tuple) and v and v[0] in ('Vector2', 'Vector3'):
        return 'vector'
    if callable(v):
        return 'function'
    return type(v).__name__


def Vector2_new(x=0, y=0):
    return ('Vector2', lua_num(x, 'Vector2.x'), lua_num(y, 'Vector2.y'))


def Vector3_new(x=0, y=0, z=0):
    return ('Vector3', lua_num(x, 'Vector3.x'), lua_num(y, 'Vector3.y'),
            lua_num(z, 'Vector3.z'))


# ----------------------------------------------------------------------
# VM table (H) for the Fz phase + method dispatch
# ----------------------------------------------------------------------

METHODS = {}       # name -> (fn, arity) ; fn(H, *args) -> tuple


def method(name, arity):
    def deco(fn):
        METHODS[name] = (fn, arity)
        return fn
    return deco


def mc(H, name, *args):
    """Call a transcribed VM-table method; pad args with nil."""
    ent = METHODS.get(name)
    if ent is None:
        raise Untranscribed(name)
    fn, arity = ent
    if len(args) < arity:
        args = args + (None,) * (arity - len(args))
    return fn(H, *args[:arity])


def czget(H, k):
    v = H.cz.get(num_key(k))
    if v is None:
        raise LuaError(f'cz[{k!r}] is nil')
    return v


def gzget(H, k):
    v = H.gz.get(num_key(k))
    if v is None:
        raise LuaError(f'gz[{k!r}] is nil')
    return v


def _stub(name):
    def f(*args):
        raise Untranscribed(f'stdlib:{name}')
    return f


FN_CALLS = []      # (name, nargs) for every opaque LuaFn call
PROTO_TABLES = []  # operand tables finalized by dz/bz/z (proto artifacts)


class LuaFn:
    """An untranscribed VM-table function value (opaque). Calling a
    factory-style slot during the build phase returns a fresh closure
    value; every call is logged in FN_CALLS for the report."""
    __slots__ = ('name',)

    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f'<luafn {self.name}>'

    def __call__(self, *args):
        FN_CALLS.append((self.name, len(args)))
        return LuaFn(self.name + '()')


def _load_func_kinds():
    slots, fields = set(), set()
    try:
        tm = json.load(open(os.path.join(HERE, 'table_map.json')))
        for e in tm['entries']:
            if e.get('kind') == 'function':
                if e.get('key_type') == 'slot':
                    slots.add(e['key'])
                elif e.get('key_type') == 'field':
                    fields.add(e['key'])
    except Exception:
        pass
    return slots, fields


FUNC_SLOTS, FUNC_FIELDS = _load_func_kinds()


class SlotDict(dict):
    """H.slot: known stdlib slots are real callables; function-kind
    slots from the table literal are opaque LuaFn factories; anything
    else (e.g. slot 91) does not exist -> Untranscribed."""

    def __missing__(self, n):
        if n in FUNC_SLOTS:
            v = LuaFn(f'slot{n}')
            self[n] = v
            return v
        raise Untranscribed(f'slot[{n}]')


class VMTable:
    """The H table during the Fz phase."""

    def __init__(self):
        self.slot = SlotDict()
        self.cz = {}
        self.gz = {}
        self.oz = None          # Buf #1
        self.I = LT()
        self.U = LT()
        self.slot99 = 0
        self.w = None

    def m(self, name, *args):
        return mc(self, name, *args)

    def s(self, n):
        v = self.slot.get(n)
        if v is None:
            return self.slot[n]  # SlotDict.__missing__ semantics
        return v

    def fget(self, name):
        if name in METHODS:
            def _bound(H_, *a):
                return mc(H_, name, *a)
            return _bound
        if name in FUNC_FIELDS:
            return LuaFn(name)
        if name == 'I':
            return self.I
        if name == 'U':
            return self.U
        if name == 'cz':
            return self.cz
        if name == 'gz':
            return self.gz
        if name == 'oz':
            return self.oz
        raise Untranscribed(f'field {name!r}')


def build_H():
    H = VMTable()
    s = H.slot
    s[0] = _stub('coroutine.running')
    s[1] = bit32_rshift
    s[2] = bit32_countlz
    s[3] = buf_writef32
    s[4] = buf_len
    s[5] = lambda *a: ('UDim',) + a
    s[6] = buf_writef64
    s[8] = buf_copy
    s[11] = buf_readstring
    s[12] = lambda *a: LT()
    s[13] = lua_type
    s[16] = lambda v: lua_num(v, 'tonumber')
    s[17] = lambda v, *a: v
    s[19] = buf_fill
    s[20] = buf_writeu8
    s[22] = tget_raw
    s[26] = lambda t: t.d.clear() if isinstance(t, LT) else None
    s[27] = lambda *a: LT()
    s[30] = lambda *a: ('Rect',) + a
    s[32] = _stub('pairs')
    s[33] = string_rep
    s[40] = _stub('table.concat')
    s[42] = buf_writei16
    s[44] = bit32_rrotate
    s[45] = _stub('xpcall')
    s[46] = _stub('string.pack')
    s[47] = _stub('pcall')
    s[48] = lambda *a: ('vector',) + a
    s[49] = table_create
    s[50] = buf_writeu16
    s[52] = buf_writeu32
    s[53] = setmetatable
    s[54] = lambda v: fmt_num(v) if isinstance(v, (int, float)) else str(v)
    s[55] = buf_writebits
    s[56] = buf_readbits
    s[57] = _stub('string.match')
    s[60] = bit32_bor
    s[61] = lambda *a: (_ for _ in ()).throw(LuaError(str(a)))
    s[62] = lambda *a: ('UDim2',) + a
    s[63] = tset_raw
    s[65] = bit32_lshift
    s[66] = _stub('coroutine.close')
    s[68] = _stub('string.find')
    s[69] = buf_fromstring
    s[71] = buf_create
    s[73] = buf_writei8
    s[74] = string_sub
    s[75] = _stub('string.unpack')
    s[78] = bit32_band
    s[79] = _stub('coroutine.create')
    s[80] = buf_readu8
    s[83] = string_char
    s[86] = lambda n, *a: a[int(n) - 1] if a else None
    s[87] = _stub('string.gsub')
    s[88] = _stub('string.format')
    s[89] = lambda *a: ('Color3',) + a
    s[90] = lua_type
    s[92] = _stub('table.move')
    s[95] = _stub('coroutine.yield')
    s[96] = bit32_lrotate
    s[98] = _stub('coroutine.status')
    s[99] = 0
    s[100] = bit32_bnot
    s[101] = _stub('coroutine.isyieldable')
    s[102] = buf_readi32
    s[103] = lambda t, v: tset(t, len([k for k in t.d if isinstance(k, int)]) + 1, v)
    s[105] = buf_writei32
    s[106] = buf_readf64
    s[107] = bit32_bxor
    s[108] = string_byte
    s[110] = buf_writestring
    s[111] = buf_readi16
    s[113] = getmetatable
    s[115] = _stub('unpack')
    s[117] = buf_readi8
    s[119] = buf_readf32
    s[120] = buf_readu32
    s[121] = bit32_countrz
    s[122] = buf_readu16
    s[123] = _stub('setfenv')
    s[125] = _stub('next')
    s[126] = buf_tostring
    s[127] = _stub('ipairs')
    s[8700] = Vector2_new
    s[13521] = Vector3_new
    return H


# ----------------------------------------------------------------------
# Fz family methods (transcribed from fz_source.txt)
# ----------------------------------------------------------------------

@method('Zz', 9)
def m_Zz(H, P, E, u, A, X, y, i, J, B):
    if u <= 1:
        if u <= 0:
            z = tget(P, 7)
            if truthy(z):
                return (16, z, B, y, X)
            return (9, A, B, y, X)
        Pn = lua_num(y) - 128
        zv = 128 * (lua_num(J) - 128)
        Jv = Pn + 16384 * lua_num(X) + zv
        return (29, A, lua_num(B) + 3, Jv, X)
    if u <= 2:
        Pv = buf_readu8(E, lua_num(A) + 1)
        return ((23 if Pv < 128 else 20), A, B, y, Pv)
    Hv, Pv, Ev = tget(i, 3), tget(i, 5), tget(i, 2)
    uv = lua_num(Hv) + lua_num(Pv)
    Jv = Pv <= 0
    ge = uv >= Ev
    le = uv <= Ev
    Ev2 = lor(land(Jv, ge), land(not Jv, le))
    tset(i, 3, uv)
    if truthy(Ev2):
        return (34, A, B, uv, X)
    return (19, A, B, y, X)


@method('Nz', 11)
def m_Nz(H, P, E, u, A, X, y, i, J, B, z, S):
    if J <= 5:
        if J <= 4:
            return (29, y, A, z, lua_num(P) + 1, u)
        fv = 128 * (lua_num(u) - 128) + i
        return (11, y, A, 2 + lua_num(z), P, fv)
    if J <= 6:
        buf_writeu32(X, E, bit32_bxor(buf_readu32(B, lua_num(P) + lua_num(E)),
                                      czget(H, A), S))
        return (28, y, gzget(H, A), z, P, u)
    if J <= 7:
        tset(y, A, z)
        E2, J2, S2 = pad(mc(H, 'IY', y, X), 3)
        fv = buf_readu8(X, S2)
        return ((10 if fv < 128 else 18), E2, J2, S2, P, fv)
    E2 = buf_readu8(X, z)
    buf_fill(B, lua_num(P) + lua_num(u), E2, i)
    return (22, y, A, z, P, u)


@method('Xz', 5)
def m_Xz(H, P, E, u, A, X):
    if X <= 11:
        Xv = buf_readu8(E, A)
        return ((14 if 128 > Xv else 2), A, Xv)
    raise LuaError('XZ91: Xz else-branch taken (H[91] is nil in the table)')


@method('Ez', 9)
def m_Ez(H, P, E, u, A, X, y, i, J, B):
    if i <= 14:
        if i <= 13:
            zv = buf_readu8(E, 3 + lua_num(A))
            Ev = (lua_num(J) - 128) * 128
            Sv = (lua_num(X) - 128) * 2097152
            fv = (lua_num(y) - 128) * 16384
            Rv = zv % 128
            hv = Sv + (zv - zv % 128) * 2097152 + fv + (Ev + Rv)
            return (11, 4 + lua_num(A), hv, X, y)
        return (8, lua_num(A) + 1, J, X, y)
    if i <= 15:
        Ev = lua_num(X) - 128
        zv = 128 * (lua_num(y) - 128)
        Sv = 16384 * lua_num(u)
        uv = zv + Ev + Sv
        return (8, 3 + lua_num(A), J, uv, y)
    if i <= 16:
        return (7, A, J, X, y)
    Ev = buf_readu8(B, lua_num(P) + 2)
    return ((1 if Ev < 128 else 31), A, J, X, Ev)


@method('az', 2)
def m_az(H, P, E):
    uv = buf_readu8(P, 1 + lua_num(E))
    return ((5 if uv < 128 else 27), uv)


@method('Lz', 6)
def m_Lz(H, P, E, u, A, X, y):
    if E <= 20:
        Ev = buf_readu8(y, 2 + lua_num(P))
        return ((21 if Ev >= 128 else 15), P, A, Ev)
    Ev = buf_readu8(y, lua_num(P) + 3)
    Hv = 128 * (lua_num(A) - 128)
    yv = 2097152 * (lua_num(X) - 128)
    iv = 16384 * (lua_num(u) - 128)
    Jv = Ev % 128
    Av = yv + (iv + 2097152 * (Ev - Ev % 128) + Hv) + Jv
    return (8, 4 + lua_num(P), Av, u)


@method('zz', 11)
def m_zz(H, P, E, u, A, X, y, i, J, B, z, S):
    if A <= 23:
        if A <= 22:
            return (1,)
        fv = lua_num(S) + 128 * (lua_num(P) - 128)
        return (2, 8, J, 2 + lua_num(u), X, y, E, fv)
    if A <= 24:
        Sv = lua_num(E) - 1
        fv = 1
        Rv = lua_num(i) - fv
        tbl = LT()
        tset(tbl, 2, Sv)
        tset(tbl, 3, Rv)
        tset(tbl, 4, J)
        tset(tbl, 5, fv)
        return (2, 3, tbl, u, X, y, E, P)
    if A <= 25:
        return (2, 24, tget(J, 5), u, X, y, E, P)
    Ev = tget(tget(B, 6), z)
    Av = tget(B, 5)
    Xv = lua_num(Ev) + 1
    Ev2 = buf_readu8(Av, Xv)
    # source reassigns local E to the byte before returning it in this slot
    return (2, (33 if Ev2 >= 128 else 4), J, u, Av, Xv, Ev2, P)


@method('Dz', 12)
def m_Dz(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if A <= 28:
        if A <= 27:
            Rv = buf_readu8(i, lua_num(z) + 2)
            return ((13 if Rv >= 128 else 35), S, f, P, u, y, Rv, i, J, B, X)
        Rv, hv, xv = tget(S, 1), tget(S, 2), tget(S, 4)
        ev = lua_num(Rv) + lua_num(hv)
        _v = hv <= 0
        ge = ev >= xv
        le = ev <= xv
        xv2 = lor(land(_v, ge), land(not _v, le))
        tset(S, 1, ev)
        if truthy(xv2):
            return (6, S, f, P, u, y, E, i, J, B, ev)
        return (25, S, f, P, u, y, E, i, J, B, X)
    if A <= 29:
        Av = lua_mod(lua_num(z) + lua_num(f), 256)
        Rv = buf_create(u)
        hv = 16843009 * lua_num(z)
        xv = lua_num(u) - lua_mod(lua_num(u), 4)
        Hv = xv - 1
        zv = 4
        tbl = LT()
        tset(tbl, 1, 0 - zv)
        tset(tbl, 2, zv)
        tset(tbl, 4, Hv)
        tset(tbl, 5, S)
        return (28, tbl, Av, P, u, 41, 41, Rv, hv, xv, X)
    Hv = lua_num(y) + 128 * (lua_num(u) - 128)
    return (29, S, f, 2 + lua_num(P), Hv, y, E, i, J, B, X)


@method('Wz', 6)
def m_Wz(H, P, E, u, A, X, y):
    if A <= 31:
        Av = buf_readu8(X, lua_num(P) + 3)
        Hv = 128 * (lua_num(u) - 128)
        Xv = 2097152 * (lua_num(E) - 128)
        iv = 16384 * (lua_num(y) - 128)
        Jv = Av % 128
        Ev = (Av - Av % 128) * 2097152 + Hv + iv + (Jv + Xv)
        return (29, lua_num(P) + 4, Ev)
    return (0, P, u)


@method('Oz', 9)
def m_Oz(H, P, E, u, A, X, y, i, J, B):
    if X <= 33:
        zv = buf_readu8(B, lua_num(y) + 1)
        return ((30 if 128 > zv else 17), P, u, E, zv)
    if X <= 34:
        Xv = lua_mod(lua_num(P) * lua_num(i) + lua_num(J), 256)
        buf_writeu8(A, E, bit32_bxor(Xv, buf_readu8(B, lua_num(y) + lua_num(E)), u))
        return (3, Xv, u, E, i)
    Hv = lua_num(E) - 128
    Av = 128 * (lua_num(i) - 128)
    Ev = lua_num(J) * 16384 + (Av + Hv)
    return (11, P, lua_num(u) + 3, Ev, i)


@method('Mz', 8)
def m_Mz(H, H2, P, E, u, A, X, y, i):
    # NOTE: second parameter is also named H in the source (a byte value)
    if E <= 206:
        Ev = lua_num(P) - 128
        Jv = (lua_num(H2) - 128) * 128
        Hv = lua_num(A) * 16384 + Jv + Ev
        return (15, i, y, lua_num(X) + 3, Hv)
    Hv = lua_num(i) - 128
    Ev = (lua_num(y) - 128) * 128
    return (249, Hv + 16384 * lua_num(u) + Ev, 3 + lua_num(X), X, P)


@method('C', 0)
def m_C(H):
    return (True, 89) + (None,) * 20


# ----------------------------------------------------------------------
# IY — proto-construction dispatcher (dispatch tree transcribed;
# callees are transcribed on demand in the callee section below)
# ----------------------------------------------------------------------

@method('IY', 2)
def m_IY(H, P, E):
    # locals from H:C(): u,A,X,y,i,J,B,z,S,f,R,h,x,e,_,a,O,b,l,G,w,L
    (u, A, X, y, i, J, B, z, S, f, R, h, x, e, _u, a, O, b, l, G, w, L) = \
        pad(mc(H, 'C'), 22)
    # registers: g,K,F,C,r,W,V,n,U,p,Z,T,N,s,d,m,q,Y,Q,j,c,D,k
    g, K, F, C, r, W, V, n, U, p, Z, T, N, s, d, m, q, Y, Q, j, c, D, k = \
        A, X, E, P, y, i, J, B, z, S, f, R, h, x, e, _u, a, O, b, l, G, w, L
    steps = 0
    while truthy(u):
        steps += 1
        if steps > 50_000_000:
            raise LuaError('IY step limit')
        walk_note('IY', g)
        if g <= 140:
            if g <= 69:
                if g <= 34:
                    if g <= 16:
                        if g <= 7:
                            if g <= 3:
                                g, F, r, p, D = pad(mc(H, 'b', Z, F, r, V, p, D, n, g), 5)
                            else:
                                g, V, n, U, s = pad(mc(H, 's', r, U, p, g, F, n, s, V), 5)
                        elif g <= 11:
                            g, C, r, p, T, Q = pad(mc(H, 'M', c, g, C, r, p, Q, T, F, V, j), 6)
                        else:
                            g, n, p, N, Y, D = pad(mc(H, 'Y', Y, V, r, g, F, D, N, p, n), 6)
                    elif g <= 25:
                        if g <= 20:
                            g, r, W, V, n = pad(mc(H, '_', V, r, g, W, n, F), 5)
                        else:
                            g, K, p, Y = pad(mc(H, 'v', K, p, r, W, g, F, Y), 4)
                    elif g <= 29:
                        g, K, r, N, s, c = pad(mc(H, 'y', c, V, r, d, K, g, N, D, F, s), 6)
                    else:
                        g, r, V, Z, c = pad(mc(H, 'H', F, k, Y, Z, Q, g, r, c, V, m, D), 5)
                elif g <= 51:
                    if g <= 42:
                        if g <= 38:
                            g, r, V, n, d, q = pad(mc(H, 'h', d, K, r, F, Y, V, n, q, g), 6)
                        elif g <= 40:
                            g, V, Z, s = pad(mc(H, 'f', K, V, T, s, g, N, Z), 4)
                        else:
                            g, Z, d = pad(mc(H, 'p', Z, g, d, r, K, F), 3)
                    elif g <= 46:
                        g, V, q, c, D = pad(mc(H, 'S', D, q, g, F, V, r, c), 5)
                    else:
                        g, K, r, W, V, n = pad(mc(H, 'T', K, g, W, r, F, V, n), 6)
                elif g <= 60:
                    if g <= 55:
                        g, r, V, T, d, c = pad(mc(H, 'q', d, V, k, r, g, F, Y, D, N, T, j, c, q), 6)
                    else:
                        g, r, W, V, n, p, Y = pad(mc(H, 'n', p, V, Z, T, F, g, U, Y, K, W, r, n), 7)
                elif g <= 64:
                    g, K, V, p, d, c = pad(mc(H, 'R', p, K, q, T, d, c, F, Z, r, g, V), 6)
                elif g <= 66:
                    g, Z, Y = pad(mc(H, 'k', V, Z, F, Y, g), 3)
                else:
                    g, K, W, s, q = pad(mc(H, 'u', W, r, g, q, s, F, K), 5)
            elif g <= 104:
                if g <= 86:
                    if g <= 77:
                        if g <= 73:
                            g, K, Y, j = pad(mc(H, 't', Y, g, F, K, r, j), 4)
                        elif g <= 75:
                            g, n, j = pad(mc(H, 'B', n, g, F, K, j, V), 3)
                        else:
                            g, r, V, U, j = pad(mc(H, 'm', V, Z, D, g, F, r, j, U, c, p), 5)
                    elif g <= 81:
                        g, K, r, V, Q = pad(mc(H, 'Q', F, Q, r, K, V, g), 5)
                    else:
                        g, F, r, p, d = pad(mc(H, 'g', T, p, d, Z, N, g, F, V, r), 5)
                elif g <= 95:
                    if g <= 90:
                        g, F, r, W, V, p = pad(mc(H, 'o', D, W, Z, r, V, c, n, F, p, k, g), 6)
                    else:
                        g, K, r, V, p, s, d, q = pad(mc(H, 'c', p, s, V, m, T, Z, K, F, q, r, d, g), 8)
                elif g <= 99:
                    g, F, W, V, Z = pad(mc(H, 'F', g, V, Y, T, j, r, s, c, Z, W, d, F), 5)
                else:
                    g, K, r, V, p, q, j = pad(mc(H, 'Z', g, V, p, K, q, c, j, F, r), 7)
            elif g <= 122:
                if g <= 113:
                    if g <= 108:
                        g, r, W, V, p = pad(mc(H, 'N', p, F, C, g, W, V, n, r), 5)
                    else:
                        g, V, p, N, s, d, Q = pad(mc(H, 'X', d, s, V, p, g, r, Q, N, F), 7)
                elif g <= 117:
                    g, V, T, m, c, k = pad(mc(H, 'E', g, k, m, V, c, r, F, T, N, D), 6)
                elif g <= 119:
                    g, K, r, N, s, m = pad(mc(H, 'a', N, g, K, q, s, m, F, Y, r), 6)
                else:
                    g, K, r, p, Z = pad(mc(H, 'L', T, Z, g, F, r, K, p), 5)
            elif g <= 131:
                if g <= 126:
                    g, F, r, n, p, T = pad(mc(H, 'z', N, U, q, Q, F, p, n, Y, s, C, T, d, m, r, K, V, W, Z, g), 6)
                elif g <= 128:
                    g, V, Z, N = pad(mc(H, 'D', d, r, Z, F, N, s, V, g), 4)
                else:
                    g, r, V, T, d, q = pad(mc(H, 'W', d, N, g, s, T, r, q, F, V), 6)
            elif g <= 135:
                g, r, V, p = pad(mc(H, 'O', V, n, g, F, r, p, W), 4)
            else:
                g, r, W, V, n, N = pad(mc(H, 'e', N, F, W, p, n, r, V, Z, g), 6)
        elif g <= 210:
            if g <= 175:
                if g <= 157:
                    if g <= 148:
                        if g <= 144:
                            if g <= 142:
                                g, F, r, j = pad(mc(H, 'J', p, n, c, r, g, j, D, F), 4)
                            else:
                                g, r, n, T = pad(mc(H, 'G', g, F, K, n, Z, p, T, r), 4)
                        else:
                            g, W, V, Z, q, c = pad(mc(H, 'l', T, c, g, V, U, r, q, F, W, Y, n, Z), 6)
                    elif g <= 152:
                        g, K, r, n, m, q, j = pad(mc(H, 'x', p, q, m, n, r, j, K, g, d, N, F), 7)
                    else:
                        g, K, r, V, n, U, T = pad(mc(H, 'i', U, n, g, r, K, p, V, F, T), 7)
                elif g <= 166:
                    if g <= 161:
                        g, V, n, U, d, Y = pad(mc(H, 'r', d, F, p, n, g, U, Y, V), 6)
                    elif g <= 163:
                        g, r, W, V, d = pad(mc(H, 'A', V, m, d, n, r, g, W), 5)
                    else:
                        g, F, V, n, Y = pad(mc(H, 'dz', N, V, n, Q, Y, Z, W, K, g, C, p, F, m, U, d, q, j, T, s), 5)
                elif g <= 170:
                    g, F, r, n, d, D = pad(mc(H, 'Kz', p, D, V, d, r, n, F, q, Z, g, m), 6)
                elif g <= 172:
                    g, r, W, V, m = pad(mc(H, 'wz', r, V, n, m, W, g, q, Y, F, p), 5)
                else:
                    g, r, Y, k = pad(mc(H, 'Pz', d, Y, r, m, F, q, j, Q, g, k), 4)
            elif g <= 192:
                if g <= 183:
                    if g <= 179:
                        g, F, W, j, c, k = pad(mc(H, 'jz', j, F, W, r, V, K, k, c, g), 6)
                    else:
                        g, K, r, W, V, n, Y = pad(mc(H, 'Vz', k, K, Q, r, W, n, F, V, Y, g), 7)
                elif g <= 187:
                    g, r, V, n, U, q = pad(mc(H, 'Uz', F, n, p, V, r, U, Y, Q, q, g), 6)
                else:
                    g, K, r, V, n, U, j = pad(mc(H, 'Iz', n, F, V, U, r, j, g, K), 7)
            elif g <= 201:
                if g <= 196:
                    g, r, W, V, n, Z = pad(mc(H, 'Cz', W, p, r, Z, F, V, g, n), 6)
                else:
                    g, r, V, n, d = pad(mc(H, 'bz', U, r, W, g, V, C, n, F, d), 5)
            elif g <= 205:
                z, f, h, E, e, x, X = pad(mc(H, 'sz', K, r, Q, T, Y, N, g), 7)
                if z == 2:
                    g, K, r, T, N, Y = f, h, E, e, x, X
                elif z == 1:
                    return (n, F, r)
            elif g <= 207:
                g, C, r, V, T = pad(mc(H, 'Mz', N, T, g, W, s, V, r, C), 5)
            else:
                g, V, U, N = pad(mc(H, 'Yz', K, U, V, g, Z, F, r, p, N), 4)
        elif g <= 245:
            if g <= 227:
                if g <= 218:
                    if g <= 214:
                        g, r, V, Z, d, m = pad(mc(H, '_z', Y, q, g, F, d, T, Z, m, W, V, N, p, r), 6)
                    else:
                        g, K, r, V, Z, N, d, m = pad(mc(H, 'vz', N, d, g, F, K, V, Z, r, s, m), 8)
                elif g <= 222:
                    g, K, r, T, s, Q = pad(mc(H, 'yz', T, r, N, V, s, K, F, Q, g), 6)
                elif g <= 224:
                    g, W, V, q = pad(mc(H, 'Hz', W, V, g, Y, F, q, n, Q), 4)
                else:
                    g, F, r, n, T = pad(mc(H, 'hz', g, r, F, n, T, p, Z), 5)
            elif g <= 236:
                if g <= 231:
                    g, r, W, d, q, Y = pad(mc(H, 'fz', F, d, q, Q, Y, g, j, r, m, W), 6)
                else:
                    g, r, W, V, n, d, Q = pad(mc(H, 'pz', Y, V, r, g, Q, F, m, d, n, W, q), 7)
            elif g <= 240:
                if g <= 238:
                    g, r, n, U, N = pad(mc(H, 'Sz', n, C, g, W, U, N, F, r, s, d), 5)
                else:
                    g, C, r, T = pad(mc(H, 'Tz', F, W, g, C, V, T, r), 4)
            else:
                g, K, r, W, s, j = pad(mc(H, 'qz', W, V, j, g, s, F, K, n, r), 6)
        elif g <= 263:
            if g <= 254:
                if g <= 249:
                    g, K, F, C, r, W, V, p, d = pad(mc(H, 'nz', Y, g, K, r, q, d, C, p, W, F, V), 9)
                else:
                    g, K, r, V, q, Y, Q = pad(mc(H, 'Rz', Y, r, F, p, q, V, g, c, j, K, U, Q), 7)
            elif g <= 258:
                g, r, V, N, m, Y = pad(mc(H, 'kz', s, Q, r, F, m, N, j, q, g, V, d, Y), 6)
            else:
                g, F, r, N, m, Q = pad(mc(H, 'uz', c, j, F, Q, g, s, r, D, N, k, m), 6)
        elif g <= 272:
            if g <= 267:
                g, C, r, s, m = pad(mc(H, 'tz', C, F, d, r, g, Y, s, q, V, m), 5)
            else:
                g, r, V, T, m, c = pad(mc(H, 'Bz', c, g, F, V, T, m, r), 6)
        elif g <= 276:
            g, K, r, N, d, m, Y, Q = pad(mc(H, 'mz', Q, q, N, K, d, F, g, m, r, Y), 8)
        else:
            g, r, V, m, q, c = pad(mc(H, 'Qz', c, n, V, r, g, p, D, F, m, q, k), 6)

WALK_LOG = []      # ring of recent (scope, state) entries
WALK_COUNTS = {}   # (scope, state) -> count
FZ_TRACE = []      # first Fz steps with registers (debug)


def walk_note(scope, state):
    key = (scope, state)
    WALK_COUNTS[key] = WALK_COUNTS.get(key, 0) + 1
    WALK_LOG.append(key)
    if len(WALK_LOG) > 2000:
        del WALK_LOG[:1000]


# ----------------------------------------------------------------------
# Fz main loop + the __index operand-materializer closure
# (transcribed from fz_source.txt; the closure's nested if-tree is
# preserved 1:1 so each leaf maps to the same state range)
# ----------------------------------------------------------------------

def make_index_closure(cap):
    X = cap['X']; y = cap['y']; i_ = cap['i']; J = cap['J']; B = cap['B']
    z = cap['z']; S = cap['S']; f = cap['f']; R = cap['R']; h = cap['h']
    x = cap['x']; e = cap['e']; band = cap['band']; a = cap['a']; O = cap['O']
    b = cap['b']; l = cap['l']; G = cap['G']; w = cap['w']; L = cap['L']
    g = cap['g']; K = cap['K']; F = cap['F']; C = cap['C']; r = cap['r']
    W = cap['W']; V = cap['V']

    def closure(P, k):
        o, t = 102, None
        I, v = P, k
        M = HY = PY = EY = uY = AY = XY = yY = iY = JY = BY = zY = SY = fY = None
        steps = 0
        while True:
            steps += 1
            if steps > 100_000_000:
                raise LuaError('closure step limit')
            walk_note('idx', o)
            RY = hY = xY = eY = None
            A = cap['A']
            p = cap['p']
            if o <= 77:
                if o <= 51:
                    if o <= 25:
                        if o <= 12:
                            if o <= 5:
                                if o <= 2:
                                    if o <= 0:
                                        kk = X(AY, HY + 3)
                                        _Y = (PY - 128) * 128
                                        aY = (EY - 128) * 2097152
                                        OY = (uY - 128) * 16384
                                        bY = kk % 128
                                        lY = kk % 128
                                        GY = OY + (bY + (2097152 * (kk - lY) + (_Y + aY)))
                                        o, HY = 135, 4 + HY
                                        PY = GY
                                    elif o <= 1:
                                        o, M = 2, 1 + M
                                    else:
                                        kk = X(uY, M)
                                        _Y = y(HY)
                                        i_(_Y, 0, kk)
                                        o, HY = 153, _Y
                                elif o <= 3:
                                    ii = J[HY]
                                    kk = 4
                                    P = S(AY, kk + M)
                                    B(z, kk, R(PY, czget_raw(f, ii), P))
                                    kk = J[ii]
                                    o, HY = 153, h(z, uY)
                                elif o <= 4:
                                    o = 131 if AY > 70 else 33
                                else:
                                    Pv, ii, hh = 1 + HY, 41, 41
                                    kk = 0
                                    _Y = (hh + (24 + M) % 256 * ii) % 256
                                    o, M, HY, PY, EY, XY, yY, iY, JY, BY, zY = \
                                        180, Pv, 24, ii, hh, kk, _Y, x, z, X(AY, Pv + kk), R
                            elif o <= 8:
                                if o <= 6:
                                    return HY
                                elif o <= 7:
                                    Pv, ii, hh, kk = HY + 1, (M + 74) % 256, 1246382666, 0
                                    _Y = S(AY, kk + Pv)
                                    B(z, kk, R(czget_raw(f, ii), hh, _Y))
                                    _Y = J[ii]
                                    kk = 4
                                    o, M, HY, PY, EY, XY, yY, iY, JY, BY = \
                                        30, Pv, hh, _Y, kk, B, z, S(AY, kk + Pv), czget_raw(f, _Y), R
                                else:
                                    Pv, ii = PY - 1, 1
                                    hh = LT()
                                    tset(hh, 2, t)
                                    tset(hh, 3, ii)
                                    tset(hh, 4, BY - ii)
                                    tset(hh, 5, Pv)
                                    o, t = 204, hh
                            elif o <= 10:
                                if o <= 9:
                                    o = 117 if 187 <= XY else 99
                                else:
                                    o = 5 if 242 == XY else 175
                            elif o <= 11:
                                o = 82 if 167 >= AY else 49
                            else:
                                Pv, ii = 41, 41
                                RY = (48 + M) % 256
                                hh = y(PY)
                                kk = 808464432
                                _Y = PY - PY % 4
                                aY = _Y - 1
                                OY = 4
                                bY = LT()
                                tset(bY, 1, t)
                                tset(bY, 2, OY)
                                tset(bY, 3, 0 - OY)
                                tset(bY, 5, aY)
                                o, t, M, EY, AY, XY, yY, iY, JY, BY = \
                                    76, bY, RY, 48, e, Pv, ii, hh, kk, _Y
                        elif o <= 18:
                            if o <= 15:
                                if o <= 13:
                                    o = 62 if AY <= 31 else 4
                                elif o <= 14:
                                    o, HY, M = 120, PY + (HY - 128) * 128, M + 2
                                else:
                                    Pv = X(uY, HY + 2)
                                    if 128 > Pv:
                                        o, uY = 27, Pv
                                    else:
                                        o, XY = 122, Pv
                            elif o <= 16:
                                Pv, ii, hh = band(EY, 3), a(EY, 2), 9483
                                if 0 != Pv:
                                    o, EY, uY, AY = 140, Pv, ii, hh
                                else:
                                    o, EY, uY = 18, Pv, ii
                            elif o <= 17:
                                EY = uY + 128 * (EY - 128)
                                o = 95
                            else:
                                Pv = X(iY, HY)
                                o, AY = (81 if 128 <= Pv else 51), Pv
                        elif o <= 21:
                            if o <= 19:
                                Pv = X(AY, HY + 3)
                                ii = 128 * (PY - 128)
                                hh = (uY - 128) * 2097152
                                _v = 16384 * (XY - 128)
                                av = Pv % 128
                                kv = Pv % 128
                                _Y = (Pv - kv) * 2097152 + _v + hh + (av + ii)
                                o, HY = 73, 4 + HY
                                PY = _Y
                            elif o <= 20:
                                Pv, ii, hh = tget(t, 4), tget(t, 3), tget(t, 2)
                                _v = Pv + ii
                                av = ii <= 0
                                Pv2 = _v >= hh
                                ii2 = _v <= hh
                                hh2 = land(av, Pv2) if truthy(land(av, Pv2)) else land(not av, ii2)
                                tset(t, 4, _v)
                                if truthy(hh2):
                                    o, PY = 98, _v
                                else:
                                    o = 156
                            else:
                                o, HY = 188, HY + 1
                        elif o <= 23:
                            if o <= 22:
                                Pv, ii, hh = tget(t, 3), tget(t, 5), tget(t, 1)
                                _v = Pv + ii
                                av = ii <= 0
                                Pv2 = _v >= hh
                                ii2 = _v <= hh
                                hh2 = land(av, Pv2) if truthy(land(av, Pv2)) else land(not av, ii2)
                                tset(t, 3, _v)
                                if truthy(hh2):
                                    o, JY = 83, _v
                                else:
                                    o = 106
                            else:
                                Pv, ii, hh = tget(t, 2), tget(t, 5), tget(t, 1)
                                _v = Pv + ii
                                av = ii <= 0
                                ii2 = _v >= hh
                                Pv2 = _v <= hh
                                hh2 = land(av, ii2) if truthy(land(av, ii2)) else land(not av, Pv2)
                                tset(t, 2, _v)
                                if truthy(hh2):
                                    o, EY = 174, _v
                                else:
                                    o = 159
                        elif o <= 24:
                            Pv = tget(t, 3)
                            o, t = 8, Pv
                        else:
                            Pv = X(AY, 3 + M)
                            ii = (HY - 128) * 128
                            hh = (PY - 128) * 2097152
                            _v = (EY - 128) * 16384
                            av = Pv % 128
                            kv = Pv % 128
                            _Y = (Pv - kv) * 2097152
                            aY = ii + _v
                            OY = aY + (_Y + hh + av)
                            o, M = 120, M + 4
                            HY = OY
                    elif o <= 38:
                        if o <= 31:
                            if o <= 28:
                                if o <= 26:
                                    o, M = 165, M + 1
                                elif o <= 27:
                                    Pv = EY - 128
                                    ii = (AY - 128) * 128
                                    hh = uY * 16384
                                    _v = hh + Pv + ii
                                    o = 105
                                    EY = _v
                                else:
                                    o, HY = 166, 1 + HY
                            elif o <= 29:
                                hY = lua_mod(XY * M + yY, 256)
                                x(iY, PY, R(AY, X(uY, PY + HY), hY))
                                o, M = 87, hY
                            elif o <= 30:
                                XY(yY, EY, BY(HY, iY, JY))
                                Pv = J[PY]
                                ii = 8
                                B(z, ii, R(HY, S(AY, ii + M), czget_raw(f, Pv)))
                                ii2 = J[Pv]
                                o, HY = 153, b(O(z, uY), O(z, 4), O(z, 8))
                            else:
                                o, HY, M = 165, PY + (HY - 128) * 128, M + 2
                        elif o <= 34:
                            if o <= 32:
                                o, PY, HY = 135, 128 * (PY - 128) + EY, 2 + HY
                            elif o <= 33:
                                Pv, ii, hh = HY + 1, (11 + M) % 256, 0
                                B(z, 0, R(185273099, S(uY, 0 + Pv), czget_raw(f, ii)))
                                Pv = J[ii]
                                o, HY = 153, O(z, EY)
                            else:
                                o, PY, HY = 12, EY + 128 * (PY - 128), 2 + HY
                        elif o <= 36:
                            if o <= 35:
                                Pv = X(uY, 1 + HY)
                                o, EY = (34 if 128 > Pv else 182), Pv
                            else:
                                Pv = tget(t, 1)
                                o, t, HY = 153, Pv, M
                        elif o <= 37:
                            Pv, ii, hh, _v = HY + 1, (82 + M) % 256, 1381126738, 0
                            av = S(AY, _v + Pv)
                            B(z, _v, R(hh, czget_raw(f, ii), av))
                            o, M, HY, PY = 3, Pv, ii, hh
                        else:
                            Pv = X(uY, HY)
                            o, EY = (176 if 128 <= Pv else 55), Pv
                    elif o <= 44:
                        if o <= 41:
                            if o <= 39:
                                EY = uY + (EY - 128) * 128
                                o = 105
                            elif o <= 40:
                                Pv = tget(t, 2)
                                ii = uY(iY)
                                hh = PY + HY
                                _v = X(AY, hh)
                                o, t, M, HY, PY, EY = \
                                    (163 if _v < 128 else 46), Pv, ii, l, hh, _v
                            else:
                                Pv = X(iY, 1 + HY)
                                o, uY = (158 if 128 > Pv else 129), Pv
                        elif o <= 42:
                            Pv = G(M, 1 + lua_mod(uY, PY), 2 + lua_mod(uY, PY))
                            ii = uY + 1
                            hh = 1
                            _v = LT()
                            tset(_v, 1, ii - hh)
                            tset(_v, 2, t)
                            tset(_v, 4, EY)
                            tset(_v, 5, hh)
                            o, t, uY = 198, _v, Pv
                        elif o <= 43:
                            o, HY = 153, M + HY * 4294967296
                        else:
                            Pv = HY - 128
                            ii = 128 * (PY - 128)
                            hh = EY * 16384
                            _v = hh + (Pv + ii)
                            o, M = 2, 3 + M
                            HY = _v
                    elif o <= 47:
                        if o <= 45:
                            o, AY, HY = 110, XY + 128 * (AY - 128), HY + 2
                        elif o <= 46:
                            Pv = X(AY, 1 + PY)
                            o, uY = (93 if 128 > Pv else 137), Pv
                        else:
                            Pv = X(AY, M + 2)
                            o, EY = (25 if 128 <= Pv else 184), Pv
                    elif o <= 49:
                        if o <= 48:
                            Pv = PY - 128
                            ii = 128 * (uY - 128)
                            hh = 16384 * XY
                            _v = hh + (ii + Pv)
                            o, HY = 73, 3 + HY
                            PY = _v
                        else:
                            o = 78 if 169 >= AY else 75
                    elif o <= 50:
                        Pv, ii, hh = tget(t, 5), tget(t, 4), tget(t, 1)
                        _v = Pv + ii
                        av = ii <= 0
                        Pv2 = _v >= hh
                        ii2 = _v <= hh
                        hh2 = land(av, Pv2) if truthy(land(av, Pv2)) else land(not av, ii2)
                        tset(t, 5, _v)
                        if truthy(hh2):
                            o, zY = 172, _v
                        else:
                            o = 24
                    else:
                        o, HY = 110, HY + 1
                elif o <= 64:
                    if o <= 57:
                        if o <= 54:
                            if o <= 52:
                                Pv = X(uY, HY + 3)
                                ii = 128 * (EY - 128)
                                hh = (AY - 128) * 2097152
                                _v = 16384 * (XY - 128)
                                av = Pv % 128
                                bv = Pv - Pv % 128
                                Pv2 = _v + 2097152 * bv
                                lv = ii + hh
                                kv = Pv2 + (lv + av)
                                o = 95
                                EY = kv
                            elif o <= 53:
                                Pv, ii = PY - 1, 1
                                hh = BY - ii
                                _v = LT()
                                tset(_v, 1, Pv)
                                tset(_v, 2, t)
                                tset(_v, 3, hh)
                                tset(_v, 5, ii)
                                o, t = 22, _v
                            else:
                                o, HY = 135, 1 + HY
                        elif o <= 55:
                            o = 95 if truthy(True) else 112
                        elif o <= 56:
                            Pv, ii, hh = tget(t, 2), tget(t, 5), tget(t, 1)
                            _v = Pv + ii
                            av = ii <= 0
                            Pv2 = _v >= hh
                            ii2 = _v <= hh
                            hh2 = land(av, Pv2) if truthy(land(av, Pv2)) else land(not av, ii2)
                            tset(t, 2, _v)
                            if truthy(hh2):
                                o, fY = 79, _v
                            else:
                                o = 192
                        else:
                            Pv = S(uY, zY + HY)
                            B(iY, zY, R(czget_raw(f, M), Pv, JY))
                            hY = J[M]
                            o, M = 59, hY
                    elif o <= 60:
                        if o <= 58:
                            Pv = 1 + HY
                            ii = (41 * ((250 + M) % 256) + 41) % 256
                            x(z, 0, R(X(AY, Pv), ii, 250))
                            Pv2 = 173 != X(z, uY)
                            o, HY = 153, Pv2
                        elif o <= 59:
                            Pv, ii, hh = tget(t, 5), tget(t, 4), tget(t, 2)
                            _v = Pv + ii
                            av = ii <= 0
                            ii2 = _v >= hh
                            Pv2 = _v <= hh
                            hh2 = land(av, ii2) if truthy(land(av, ii2)) else land(not av, Pv2)
                            tset(t, 5, _v)
                            if truthy(hh2):
                                o, zY = 57, _v
                            else:
                                o = 190
                        else:
                            Pv = X(iY, 1)
                            o, HY = (154 if 128 <= Pv else 167), Pv
                    elif o <= 62:
                        if o <= 61:
                            Pv = HY - 128
                            ii = (PY - 128) * 128
                            hh = EY * 16384
                            _v = ii + hh + Pv
                            o, M = 165, 3 + M
                            HY = _v
                        else:
                            o = 186 if AY > 1 else 114
                    elif o <= 63:
                        Pv = PY - 128
                        ii = 128 * (AY - 128)
                        hh = XY * 16384
                        _v = hh + (Pv + ii)
                        o, HY = 188, 3 + HY
                        PY = _v
                    else:
                        Pv = X(uY, 1 + HY)
                        o, AY = (152 if Pv < 128 else 197), Pv
                elif o <= 70:
                    if o <= 67:
                        if o <= 65:
                            Pv = S(uY, AY + M)
                            B(z, AY, R(czget_raw(f, PY), HY, Pv))
                            Pv2 = J[PY]
                            o, HY = 153, w(O(z, EY), O(z, 4))
                        elif o <= 66:
                            o, HY = 16, 1 + HY
                        else:
                            Pv = X(uY, HY + 3)
                            ii = (PY - 128) * 128
                            hh = 2097152 * (AY - 128)
                            _v = 16384 * (XY - 128)
                            av = Pv % 128
                            Ov = Pv % 128
                            bv = (Pv - Ov) * 2097152
                            lv = _v + av
                            wv = lv + (hh + (ii + bv))
                            o, HY = 188, 4 + HY
                            PY = wv
                    elif o <= 68:
                        o, HY, M = 2, PY + 128 * (HY - 128), M + 2
                    elif o <= 69:
                        o, HY = 38, HY + 1
                    else:
                        Pv = X(uY, HY + 1)
                        o, EY = (177 if Pv < 128 else 193), Pv
                elif o <= 73:
                    if o <= 71:
                        o = 11 if AY > 108 else 13
                    elif o <= 72:
                        o = 100 if XY > 195 else 113
                    else:
                        Pv = L(AY, HY, PY)
                        tset(EY, M, Pv)
                        o, HY = 153, Pv
                elif o <= 75:
                    if o <= 74:
                        Pv = HY - 4294967296
                        o, HY = 43, Pv
                    else:
                        o = 148 if 183 > AY else 139
                elif o <= 76:
                    Pv, ii, hh = tget(t, 3), tget(t, 2), tget(t, 5)
                    _v = Pv + ii
                    av = ii <= 0
                    ii2 = _v >= hh
                    Pv2 = _v <= hh
                    hh2 = land(av, ii2) if truthy(land(av, ii2)) else land(not av, Pv2)
                    tset(t, 3, _v)
                    if truthy(hh2):
                        o, zY = 133, _v
                    else:
                        o = 157
                else:
                    Pv = 1 + HY
                    ii = X(uY, Pv)
                    o, HY, PY = (141 if 128 <= ii else 21), Pv, ii
            # ---- states 78..242 transcribed in closure_b ----
            else:
                HY, o, t, I, v, M, PY, EY, uY, AY, XY, yY, iY, JY, BY, zY, SY, fY = \
                    closure_b(cap, closure, I, v, M, HY, PY, EY, uY, AY, XY,
                              yY, iY, JY, BY, zY, SY, fY, o, t)
                if o == -1:
                    return HY
    return closure


def czget_raw(tab, k):
    """cz/cz-style dict access inside the closure (f[i], J[i] locals)."""
    v = tab.get(num_key(k)) if isinstance(tab, dict) else None
    if v is None:
        raise LuaError(f'keystream[{k!r}] is nil')
    return v


def _cnt(Pv, iv, hv):
    """The counter-table step shared by many closure states:
    s=P+i; cond = (i<=0 and s>=h) or (i>0 and s<=h); returns (s, cond)."""
    s = Pv + iv
    a = iv <= 0
    ge = s >= hv
    le = s <= hv
    cond = land(a, ge) if truthy(land(a, ge)) else land(not a, le)
    return s, cond


def closure_b(cap, _self, I, v, M, HY, PY, EY, uY, AY, XY, yY, iY, JY, BY,
              zY, SY, fY, o, t):
    """One step of the __index closure for states o >= 78.
    Register order in/out matches the call site in make_index_closure.
    (The P register is not threaded through: states 105/124 clobber it,
    but no state in 78..242 or in part A reads it afterwards — part A
    states shadow P with locals everywhere it matters.)"""
    X = cap['X']; y = cap['y']; i_ = cap['i']; J = cap['J']; B = cap['B']
    z = cap['z']; S = cap['S']; f = cap['f']; R = cap['R']; h = cap['h']
    x = cap['x']; e = cap['e']; O = cap['O']; b = cap['b']; l = cap['l']
    G = cap['G']; w = cap['w']; L = cap['L']; g = cap['g']; K = cap['K']
    F = cap['F']; C = cap['C']; r = cap['r']; W = cap['W']; V = cap['V']
    A = cap['A']
    p = cap['p']
    RY = hY = xY = eY = None
    P = None
    if o <= 103:
        if o <= 90:
            if o <= 83:
                if o <= 80:
                    if o <= 78:
                        Pv, ii = 1 + HY, (4 + M) % 256
                        hh = S(uY, Pv)
                        B(z, 0, R(67372036, czget_raw(f, ii), hh))
                        o, HY = 153, g(z, EY)
                    elif o <= 79:
                        B(BY, fY, R(S(uY, fY + HY), zY, czget_raw(f, AY)))
                        xY = J[AY]
                        o, AY = 56, xY
                    else:
                        Pv = HY(M, EY, PY)
                        o, HY = 153, Pv
                elif o <= 81:
                    Pv = X(iY, HY + 1)
                    o, XY = (94 if 128 <= Pv else 45), Pv
                elif o <= 82:
                    o = 77 if AY <= 125 else 111
                else:
                    RY = lua_mod(yY + XY * M, 256)
                    x(iY, JY, R(EY, X(uY, JY + HY), RY))
                    o, M = 22, RY
            elif o <= 86:
                if o <= 84:
                    Pv = tget(t, 2)
                    o, t = 199, Pv
                elif o <= 85:
                    Pv, ii, hh, _v = HY + 1, (M + 27) % 256, 454761243, 0
                    av = S(uY, _v + Pv)
                    B(z, _v, R(czget_raw(f, ii), hh, av))
                    av = J[ii]
                    _v = 4
                    o, M, HY, PY, AY = 65, Pv, hh, av, _v
                else:
                    Pv = tget(t, 3)
                    tset(HY, PY, uY)
                    o, t = 20, Pv
            elif o <= 88:
                if o <= 87:
                    Pv, ii, hh = tget(t, 4), tget(t, 3), tget(t, 2)
                    _v, cond = _cnt(Pv, ii, hh)
                    tset(t, 4, _v)
                    if truthy(cond):
                        o, PY = 29, _v
                    else:
                        o = 130
                else:
                    o, PY, HY = 188, AY + 128 * (PY - 128), 2 + HY
            elif o <= 89:
                Pv = HY + 1
                ii = X(uY, Pv)
                o, HY, PY = (170 if ii < 128 else 35), Pv, ii
            else:
                o = 155 if XY <= 204 else 183
        elif o <= 96:
            if o <= 93:
                if o <= 91:
                    Pv = X(AY, 1 + HY)
                    o, EY = (32 if 128 > Pv else 108), Pv
                elif o <= 92:
                    Pv = 1 + HY
                    ii = (41 + 41 * ((51 + M) % 256)) % 256
                    x(z, 0, R(51, X(AY, Pv), ii))
                    ii = -X(z, uY)
                    o, HY = 153, ii
                else:
                    o, EY, PY = 80, uY + 128 * (EY - 128), PY + 2
            elif o <= 94:
                Pv = X(iY, HY + 2)
                o, yY = (160 if 128 <= Pv else 101), Pv
            elif o <= 95:
                Pv = K(PY)
                ii = 1
                hh = 1 - ii
                _v = LT()
                tset(_v, 1, t)
                tset(_v, 2, PY)
                tset(_v, 3, ii)
                tset(_v, 4, hh)
                o, t, HY = 20, _v, Pv
            else:
                Pv = X(uY, HY + 3)
                ii = (PY - 128) * 128
                hh = 2097152 * (EY - 128)
                _v = (AY - 128) * 16384
                av = Pv % 128
                Ov = Pv % 128
                bv = 2097152 * (Pv - Ov)
                lv = av + (ii + _v + bv + hh)
                o, HY = 12, HY + 4
                PY = lv
        elif o <= 99:
            if o <= 97:
                tset(uY, AY, R(M, PY * AY))
                o = 162
            elif o <= 98:
                Pv = K(EY)
                ii = 1
                _v = LT()
                tset(_v, 2, 1 - ii)
                tset(_v, 3, t)
                tset(_v, 4, EY)
                tset(_v, 5, ii)
                o, t, uY = 162, _v, Pv
            else:
                Pv = 1 + HY
                ii = X(AY, Pv)
                o, HY, PY = (91 if ii >= 128 else 54), Pv, ii
        elif o <= 101:
            if o <= 100:
                Pv = tget(EY, M)
                if truthy(Pv):
                    o, HY = 153, Pv
                else:
                    o = 147
            else:
                Pv = AY - 128
                ii = 128 * (XY - 128)
                hh = yY * 16384
                _v = hh + (ii + Pv)
                o, HY = 110, 3 + HY
                AY = _v
        elif o <= 102:
            Pv = tget(tget(I, -2), v)
            ii = tget(p, Pv)
            hh = A
            Ov = tget(hh, 5)
            bv = X(Ov, ii)
            lv = 1 + ii
            # source: o,M,HY,PY,EY,uY,AY(,XY) = code,P,i,_,a,O,b where
            # i = field value, _ = I[-1], a = 0, O = structure[5], b = byte
            if bv <= 183:
                o, M, HY, PY, EY, uY, AY = 71, Pv, ii, tget(I, -1), 0, Ov, bv
            else:
                o, M, HY, PY, EY, uY, AY, XY = \
                    90, Pv, ii, hh, tget(I, -1), 0, Ov, bv
        else:
            Pv, ii = PY - 1, 1
            hh = BY - ii
            _v = LT()
            tset(_v, 1, t)
            tset(_v, 2, Pv)
            tset(_v, 3, ii)
            tset(_v, 4, hh)
            o, t = 87, _v
    elif o <= 155:
        if o <= 129:
            if o <= 116:
                if o <= 109:
                    if o <= 106:
                        if o <= 104:
                            ii = X(uY, 2 + M)
                            o, EY = (61 if 128 > ii else 109), ii
                        elif o <= 105:
                            P = 0
                            ii = 1
                            hh = LT()
                            tset(hh, 1, 1 - ii)
                            tset(hh, 2, t)
                            tset(hh, 3, EY)
                            tset(hh, 4, ii)
                            o, t, HY = 199, hh, P
                        else:
                            ii = tget(t, 2)
                            hh = AY(iY)
                            _v = HY + PY
                            av = X(uY, _v)
                            o, t, M, HY, EY = \
                                (202 if av < 128 else 138), ii, hh, _v, av
                    elif o <= 107:
                        ii = X(AY, PY + 3)
                        hh = (EY - 128) * 128
                        _v = (uY - 128) * 2097152
                        av = (XY - 128) * 16384
                        Ov = ii % 128
                        bv = ii % 128
                        lv = Ov + (hh + (ii - bv) * 2097152) + (_v + av)
                        o, PY = 80, 4 + PY
                        EY = lv
                    elif o <= 108:
                        ii = X(AY, HY + 2)
                        o, uY = (0 if 128 <= ii else 146), ii
                    else:
                        ii = X(uY, M + 3)
                        hh = (HY - 128) * 128
                        _v = 2097152 * (PY - 128)
                        av = (EY - 128) * 16384
                        Ov = ii % 128
                        bv = ii % 128
                        lv = (ii - bv) * 2097152
                        wv = av + hh + Ov
                        Lv = lv + (wv + _v)
                        o, M = 165, M + 4
                        HY = Lv
                elif o <= 112:
                    if o <= 110:
                        ii = 1 + AY
                        o, AY = 140, ii
                    elif o <= 111:
                        o = 126 if 165 == AY else 85
                    elif 0 < M:
                        o = 125
                    else:
                        o, HY = 153, F
                elif o <= 114:
                    if o <= 113:
                        ii, hh, _v, av = 1 + HY, (M + 155) % 256, 2610666395, 0
                        B(z, av, R(S(AY, av + ii), _v, czget_raw(f, hh)))
                        Ov = J[hh]
                        av = 4
                        o, M, HY, PY, EY = 144, ii, _v, Ov, av
                    else:
                        ii = HY + 1
                        hh = X(uY, ii)
                        _v = HY + 2
                        ii = X(uY, _v)
                        o, M, HY, PY = (69 if ii < 128 else 70), hh, _v, ii
                elif o <= 115:
                    iY(JY, XY, zY(HY, BY, yY))
                    ii, hh = 1, lua_mod(AY + PY * yY, 256)
                    x(z, ii, R(X(uY, ii + M), HY, hh))
                    o, HY = 153, C(z, EY)
                else:
                    ii = X(uY, M + 2)
                    o, EY = (169 if 128 <= ii else 44), ii
            elif o <= 122:
                if o <= 119:
                    if o <= 117:
                        ii = HY + 1
                        hh = X(AY, ii)
                        o, M, HY = (127 if 128 <= hh else 132), ii, hh
                    elif o <= 118:
                        ii = X(iY, 3)
                        hh = (M - 128) * 128
                        _v = (HY - 128) * 2097152
                        av = (PY - 128) * 16384
                        Ov = ii % 128
                        M, HY = av + ((ii - ii % 128) * 2097152 + (hh + (_v + Ov))), 4
                        o = 112
                    else:
                        ii = tget(t, 2)
                        o, t = 153, ii
                elif o <= 120:
                    ii = y(HY)
                    r(ii, 0, AY, M, HY)
                    o, HY = 153, ii
                elif o <= 121:
                    ii = EY - 128
                    hh = (AY - 128) * 128
                    _v = XY * 16384
                    av = ii + (_v + hh)
                    o, HY = 166, HY + 3
                    EY = av
                else:
                    ii = X(uY, HY + 3)
                    hh = (EY - 128) * 128
                    _v = 2097152 * (AY - 128)
                    av = (XY - 128) * 16384
                    Ov = ii % 128
                    bv = ii % 128
                    lv = (ii - bv) * 2097152
                    wv = _v + Ov
                    Lv = wv + (av + lv + hh)
                    o = 105
                    EY = Lv
            elif o <= 125:
                if o <= 123:
                    ii = PY - 128
                    hh = (EY - 128) * 128
                    _v = AY * 16384
                    av = ii + (_v + hh)
                    o, HY = 12, 3 + HY
                    PY = av
                elif o <= 124:
                    P = 1 + HY
                    o, HY = 198, P
                else:
                    Pv = K(3 * M)
                    ii = 1
                    hh = LT()
                    tset(hh, 1, t)
                    tset(hh, 3, 1 - ii)
                    tset(hh, 4, M)
                    tset(hh, 5, ii)
                    o, t, M = 149, hh, Pv
            elif o <= 127:
                if o <= 126:
                    Pv = HY + 1
                    ii = (41 + (M + 39) % 256 * 41) % 256
                    x(z, 0, R(ii, 39, X(uY, Pv)))
                    o, HY = 153, X(z, EY)
                else:
                    Pv = X(AY, M + 1)
                    o, PY = (47 if Pv >= 128 else 14), Pv
            elif o <= 128:
                o = 124 if uY == G(M, 1 + lua_mod(AY, PY),
                                   lua_mod(AY, PY) + 2) else 198
            else:
                Pv = X(iY, HY + 2)
                o, AY = (173 if 128 <= Pv else 164), Pv
        elif o <= 142:
            if o <= 135:
                if o <= 132:
                    if o <= 130:
                        Pv = tget(t, 1)
                        ii = X(iY, EY)
                        o, t, M = (200 if ii < 128 else 60), Pv, ii
                    elif o <= 131:
                        o = 89 if AY > 104 else 194
                    else:
                        o, M = 120, 1 + M
                elif o <= 133:
                    B(iY, zY, R(S(uY, zY + HY), czget_raw(f, M), JY))
                    RY = J[M]
                    o, M = 76, RY
                elif o <= 134:
                    Pv = X(uY, HY + 2)
                    if Pv >= 128:
                        o, XY = 52, Pv
                    else:
                        o, uY = 151, Pv
                else:
                    Pv, ii = 41, 41
                    eY = (M + 48) % 256
                    hh, _v, av = y(PY), 808464432, PY - PY % 4
                    Ov = av - 1
                    bv = 4
                    lv = 0 - bv
                    Gv = LT()
                    tset(Gv, 1, Ov)
                    tset(Gv, 3, t)
                    tset(Gv, 4, bv)
                    tset(Gv, 5, lv)
                    o, t, M, EY, uY, XY, yY, iY, JY, BY = \
                        50, Gv, eY, 48, e, Pv, ii, hh, _v, av
            elif o <= 138:
                if o <= 136:
                    Pv, ii = EY - 1, 1
                    hh = SY - ii
                    _v = LT()
                    tset(_v, 1, Pv)
                    tset(_v, 2, hh)
                    tset(_v, 3, t)
                    tset(_v, 5, ii)
                    o, t = 23, _v
                elif o <= 137:
                    Pv = X(AY, 2 + PY)
                    if 128 <= Pv:
                        o, XY = 107, Pv
                    else:
                        o, AY = 168, Pv
                else:
                    Pv = X(uY, HY + 1)
                    if Pv >= 128:
                        o, AY = 15, Pv
                    else:
                        o, uY = 39, Pv
            elif o <= 140:
                if o <= 139:
                    Pv = 1 + HY
                    ii = X(uY, Pv)
                    o, M, HY = (143 if ii >= 128 else 1), Pv, ii
                else:
                    tset(M, PY + 3, AY)
                    tset(M, PY + 2, EY)
                    tset(M, 1 + PY, uY)
                    o = 149
            elif o <= 141:
                Pv = X(uY, HY + 1)
                o, AY = (88 if Pv < 128 else 207), Pv
            else:
                Pv = M - 128
                ii = (HY - 128) * 128
                o = 112
                M, HY = Pv + (16384 * PY + ii), 3
        elif o <= 148:
            if o <= 145:
                if o <= 143:
                    Pv = X(uY, M + 1)
                    o, PY = (116 if Pv >= 128 else 68), Pv
                elif o <= 144:
                    B(z, EY, R(S(AY, M + EY), HY, czget_raw(f, PY)))
                    Pv = J[PY]
                    ii = S(z, uY)
                    iv = S(z, 4)
                    if 0 != iv:
                        o, M, HY = 189, ii, iv
                    else:
                        o, HY = 153, ii
                else:
                    o, PY, HY = 73, (PY - 128) * 128 + uY, 2 + HY
            elif o <= 146:
                o, PY, HY = 135, PY - 128 + (128 * (EY - 128) + uY * 16384), HY + 3
            elif o <= 147:
                Pv = 1 + HY
                ii = X(AY, Pv)
                o, HY, PY = (181 if 128 <= ii else 187), Pv, ii
            else:
                Pv = HY + 1
                ii = X(uY, Pv)
                o, M, HY = (26 if 128 > ii else 185), Pv, ii
        elif o <= 151:
            if o <= 149:
                Pv, ii, hh = tget(t, 3), tget(t, 5), tget(t, 4)
                _v, cond = _cnt(Pv, ii, hh)
                tset(t, 3, _v)
                if truthy(cond):
                    o, PY = 205, _v
                else:
                    o = 36
            elif o <= 150:
                Pv = HY + 1
                ii = X(uY, Pv)
                o, HY, EY = (28 if ii < 128 else 64), Pv, ii
            else:
                EY = EY - 128 + ((AY - 128) * 128 + 16384 * uY)
                o = 95
        elif o <= 153:
            if o <= 152:
                o, EY, HY = 166, (EY - 128) * 128 + AY, 2 + HY
            else:
                tset(I, v, HY)
                o = 6
        elif o <= 154:
            Pv = X(iY, 2)
            o, PY = (142 if 128 > Pv else 118), Pv
        else:
            o = 9 if 187 >= XY else 171
    elif o <= 181:
        if o <= 168:
            if o <= 161:
                if o <= 158:
                    if o <= 156:
                        Pv = tget(t, 1)
                        o, t = 153, Pv
                    elif o <= 157:
                        Pv = tget(t, 1)
                        o, t = 53, Pv
                    else:
                        o, EY, HY = 16, uY + (EY - 128) * 128, HY + 2
                elif o <= 159:
                    Pv = tget(t, 3)
                    ii = yY(BY)
                    tset(PY, M, ii)
                    o, t, HY = 153, Pv, ii
                elif o <= 160:
                    Pv = X(iY, HY + 3)
                    ii = 128 * (AY - 128)
                    hh = (XY - 128) * 2097152
                    _v = (yY - 128) * 16384
                    av = Pv % 128
                    Ov = Pv % 128
                    bv = (Pv - Ov) * 2097152
                    lv = ii + (hh + av)
                    Gv = lv + (bv + _v)
                    o, HY = 110, 4 + HY
                    AY = Gv
                else:
                    Pv = X(uY, 3 + HY)
                    ii = 128 * (EY - 128)
                    hh = 2097152 * (AY - 128)
                    _v = (XY - 128) * 16384
                    av = Pv % 128
                    Ov = Pv % 128
                    bv = 2097152 * (Pv - Ov)
                    lv = ii + av
                    Gv = lv + (hh + (_v + bv))
                    o, HY = 166, 4 + HY
                    EY = Gv
            elif o <= 164:
                if o <= 162:
                    Pv, ii, hh = tget(t, 2), tget(t, 5), tget(t, 4)
                    _v, cond = _cnt(Pv, ii, hh)
                    tset(t, 2, _v)
                    if truthy(cond):
                        o, AY = 97, _v
                    else:
                        o = 86
                elif o <= 163:
                    o, PY = 80, PY + 1
                else:
                    o, EY, HY = 16, EY - 128 + ((uY - 128) * 128 + AY * 16384), HY + 3
            elif o <= 166:
                if o <= 165:
                    Pv = K(HY, X(uY, M), 1 + M)
                    o, HY = 153, Pv
                else:
                    Pv, ii = 41, 41
                    xY = (48 + M) % 256
                    hh, _v, av = y(EY), 808464432, EY - EY % 4
                    Ov = av - 1
                    bv = 4
                    lv = 0 - bv
                    Gv = LT()
                    tset(Gv, 1, Ov)
                    tset(Gv, 2, lv)
                    tset(Gv, 3, t)
                    tset(Gv, 5, bv)
                    o, t, AY, XY, yY, iY, JY, BY, zY, SY = \
                        56, Gv, xY, 48, e, Pv, ii, hh, _v, av
            elif o <= 167:
                o, M, HY = 112, HY + 128 * (M - 128), 2
            else:
                Pv = EY - 128
                ii = (uY - 128) * 128
                hh = AY * 16384
                ev = hh + Pv + ii
                o, PY = 80, 3 + PY
                EY = ev
        elif o <= 174:
            if o <= 171:
                if o <= 169:
                    Pv = X(uY, 3 + M)
                    ii = (HY - 128) * 128
                    hh = (PY - 128) * 2097152
                    ev = (EY - 128) * 16384
                    _v = Pv % 128
                    av = Pv % 128
                    Ov = (Pv - av) * 2097152
                    bv = ii + hh
                    lv = bv + (ev + (_v + Ov))
                    o, M = 2, M + 4
                    HY = lv
                elif o <= 170:
                    o, HY = 12, 1 + HY
                else:
                    o = 72 if 192 < XY else 92
            elif o <= 172:
                B(iY, zY, R(S(AY, zY + HY), JY, czget_raw(f, M)))
                eY = J[M]
                o, M = 50, eY
            elif o <= 173:
                Pv = X(iY, 3 + HY)
                ii = 128 * (EY - 128)
                hh = (uY - 128) * 2097152
                ev = 16384 * (AY - 128)
                _v = Pv % 128
                av = Pv % 128
                Ov = ii + (Pv - av) * 2097152 + _v + hh + ev
                o, HY = 16, HY + 4
                EY = Ov
            else:
                xY = lua_mod(iY * AY + JY, 256)
                x(BY, EY, R(X(uY, HY + EY), xY, XY))
                o, AY = 23, xY
        elif o <= 177:
            if o <= 175:
                Pv, ii, hh = 1 + HY, (M + 71) % 256, 0
                B(z, 0, R(S(AY, Pv), czget_raw(f, ii), 1195853639))
                Pv = J[ii]
                o, HY = 153, S(z, uY)
            elif o <= 176:
                Pv = X(uY, 1 + HY)
                if Pv < 128:
                    o, uY = 17, Pv
                else:
                    o, AY = 134, Pv
            else:
                o, PY, HY = 38, EY + 128 * (PY - 128), 2 + HY
        elif o <= 179:
            if o <= 178:
                res = cap['W'](PY, M, 20)
                o, HY = 153, res[0] if isinstance(res, tuple) else res
            else:
                eY = lua_mod(XY * M + yY, 256)
                x(iY, JY, R(EY, X(AY, JY + HY), eY))
                o, M = 204, eY
        elif o <= 180:
            iY(JY, XY, zY(yY, BY, HY))
            Pv = 1
            x(z, Pv, R(HY, lua_mod(EY + PY * yY, 256), X(AY, M + Pv)))
            o, HY = 153, V(z, uY)
        else:
            Pv = X(AY, HY + 1)
            o, uY = (145 if 128 > Pv else 206), Pv
    elif o <= 194:
        if o <= 187:
            if o <= 184:
                if o <= 182:
                    Pv = X(uY, 2 + HY)
                    o, AY = (96 if 128 <= Pv else 123), Pv
                elif o <= 183:
                    o = 191 if XY <= 222 else 203
                else:
                    Pv = HY - 128
                    ii = (PY - 128) * 128
                    Jv = 16384 * EY
                    Bv = Pv + (Jv + ii)
                    o, M = 120, M + 3
                    HY = Bv
            elif o <= 185:
                Pv = X(uY, M + 1)
                o, PY = (104 if 128 <= Pv else 31), Pv
            elif o <= 186:
                Pv, ii, Jv = HY + 1, 41, 41
                Bv = 0
                Sv = (Jv + ii * ((123 + M) % 256)) % 256
                o, M, HY, PY, AY, XY, yY, iY, JY, BY, zY = \
                    115, Pv, 123, ii, Jv, Bv, Sv, x, z, X(uY, Bv + Pv), R
            else:
                o, HY = 73, 1 + HY
        elif o <= 190:
            if o <= 188:
                Pv, ii = 41, 41
                hY = (247 + M) % 256
                Jv = y(PY)
                Bv = 4160223223
                zv = PY - PY % 4
                yv = zv - 1
                Sv = 4
                fv = 0 - Sv
                Rv = LT()
                tset(Rv, 1, t)
                tset(Rv, 2, yv)
                tset(Rv, 4, Sv)
                tset(Rv, 5, fv)
                o, t, M, AY, XY, yY, iY, JY, BY = \
                    59, Rv, hY, 247, Pv, ii, Jv, Bv, zv
            elif o <= 189:
                o = 43 if HY < 2147483648 else 74
            else:
                Pv = tget(t, 1)
                o, t = 103, Pv
        elif o <= 192:
            if o <= 191:
                o = 201 if XY > 211 else 178
            else:
                Pv = tget(t, 3)
                o, t = 136, Pv
        elif o <= 193:
            Pv = X(uY, 2 + HY)
            o, AY = (195 if 128 <= Pv else 196), Pv
        else:
            Pv = tget(PY, M)
            if truthy(Pv):
                o, HY = 153, Pv
            else:
                o = 150
    elif o <= 200:
        if o <= 197:
            if o <= 195:
                Pv = X(uY, 3 + HY)
                yv = (PY - 128) * 128
                ii = (EY - 128) * 2097152
                Jv = (AY - 128) * 16384
                Bv = Pv % 128
                zv = Pv % 128
                Sv = 2097152 * (Pv - zv)
                fv = ii + yv
                Rv = fv + (Bv + Sv + Jv)
                o, HY = 38, 4 + HY
                PY = Rv
            elif o <= 196:
                Pv = PY - 128
                yv = (EY - 128) * 128
                ii = 16384 * AY
                Jv = ii + (yv + Pv)
                o, HY = 38, 3 + HY
                PY = Jv
            else:
                Pv = X(uY, HY + 2)
                o, XY = (161 if Pv >= 128 else 121), Pv
        elif o <= 198:
            Pv, yv, ii = tget(t, 1), tget(t, 5), tget(t, 4)
            Jv = Pv + yv
            Bv = yv <= 0
            Pv2 = Jv >= ii
            yv2 = Jv <= ii
            cond = land(Bv, Pv2) if truthy(land(Bv, Pv2)) else land(not Bv, yv2)
            tset(t, 1, Jv)
            if truthy(cond):
                o, AY = 128, Jv
            else:
                o = 84
        elif o <= 199:
            Pv, yv, ii = tget(t, 1), tget(t, 4), tget(t, 3)
            Jv = Pv + yv
            Bv = yv <= 0
            Pv2 = Jv >= ii
            yv2 = Jv <= ii
            cond = land(Bv, Pv2) if truthy(land(Bv, Pv2)) else land(not Bv, yv2)
            tset(t, 1, Jv)
            if truthy(cond):
                o, uY = 42, Jv
            else:
                o = 119
        else:
            o, HY = 112, 1
    elif o <= 203:
        if o <= 201:
            o = 7 if XY == 218 else 58
        elif o <= 202:
            o = 105
        else:
            o = 10 if XY > 237 else 37
    elif o <= 205:
        if o <= 204:
            Pv, yv, ii = tget(t, 4), tget(t, 3), tget(t, 5)
            Jv = Pv + yv
            Bv = yv <= 0
            yv2 = Jv >= ii
            Pv2 = Jv <= ii
            cond = land(Bv, yv2) if truthy(land(Bv, yv2)) else land(not Bv, Pv2)
            tset(t, 4, Jv)
            if truthy(cond):
                o, JY = 179, Jv
            else:
                o = 40
        else:
            Pv = 3 * (PY - 1)
            yv = X(iY, HY)
            o, PY, EY = (41 if yv >= 128 else 66), Pv, yv
    elif o <= 206:
        Pv = X(AY, HY + 2)
        o, XY = (19 if Pv >= 128 else 48), Pv
    else:
        Pv = X(uY, HY + 2)
        o, XY = (67 if Pv >= 128 else 63), Pv
    return (HY, o, t, I, v, M, PY, EY, uY, AY, XY, yY, iY, JY, BY, zY, SY, fY)


# ----------------------------------------------------------------------
# Fz main loop
# ----------------------------------------------------------------------

@method('Fz', 3)
def m_Fz(H, P, E, u):
    cap = {'H': H}
    X = H.slot[80]; y = H.slot[71]; i = H.slot[19]; J = H.gz
    B = H.slot[52]; z = H.oz; S = H.slot[120]; f = H.cz
    R = H.slot[107]; hh = H.slot[106]; x = H.slot[20]; e = H.slot[126]
    band = H.slot[78]; a = H.slot[1]; O = H.slot[119]; b = H.slot[13521]
    l = H.slot[33]; G = H.slot[74]; w = H.slot[8700]; L = H.slot[11]
    g = H.slot[102]; K = H.slot[49]; F = H.I; C = H.slot[122]
    r = H.slot[8]; V = H.slot[111]
    cap.update(X=X, y=y, i=i, J=J, B=B, z=z, S=S, f=f, R=R, h=hh, x=x, e=e,
               band=band, a=a, O=O, b=b, l=l, G=G, w=w, L=L, g=g, K=K, F=F,
               C=C, r=r, V=V, A=None, p=None)

    def W(*args):
        return mc(H, 'Fz', *args)
    cap['W'] = W
    A = None
    p = None
    n = 26
    U = None
    Z, T, N = P, E, u
    s = d = m = q = Y = Q = j = c = D = None
    steps = 0
    while True:
        steps += 1
        if steps > 200_000_000:
            raise LuaError('Fz step limit')
        walk_note('Fz', n)
        if steps <= 120:
            FZ_TRACE.append((steps, n, Z, T, N, s, d, m, q, Y, Q, j, c, D, U))
        if n <= 17:
            if n <= 8:
                if n <= 3:
                    n, N, d, m, Y = pad(mc(H, 'Zz', A, Q, n, N, Y, m, U, q, d), 5)
                else:
                    n, Z, T, N, d, m = pad(mc(H, 'Nz', d, D, m, T, Q, Z, q, n, s, N, j), 6)
            elif n <= 12:
                if n <= 10:
                    if n <= 9:
                        p = tget(A, 6)
                        cap['A'] = A
                        cap['p'] = p
                        Enew = LT()
                        tset(Enew, '__index', make_index_closure(cap))
                        tset(A, 7, Enew)
                        E = Enew
                        n, N = 16, Enew
                    else:
                        n, N = 11, lua_num(N) + 1
                else:
                    n, N, q = pad(mc(H, 'Xz', q, Q, A, N, n), 3)
            else:
                n, N, m, q, Y = pad(mc(H, 'Ez', d, Q, j, N, q, Y, n, m, s), 5)
        elif n <= 26:
            if n <= 21:
                if n <= 19:
                    if n <= 18:
                        n, q = pad(mc(H, 'az', Q, N), 2)
                    else:
                        u = tget(U, 4)
                        A = Z
                        cap['A'] = A
                        n, U, T = lor(land(tget(A, 4), 12), 32), u, 7
                else:
                    n, N, q, j = pad(mc(H, 'Lz', N, n, j, q, Y, Q), 4)
            else:
                rr = mc(H, 'zz', q, m, N, n, s, d, c, U, Z, T, Y)
                code = rr[0]
                if code == 1:
                    return (Z, T)
                if code == 2:
                    n, U, N, s, d, m, q = pad(rr[1:], 7)
        elif n <= 30:
            n, U, T, d, m, q, Y, Q, j, c, D = \
                pad(mc(H, 'Dz', d, Y, m, n, D, q, Q, j, c, N, U, T), 11)
        elif n <= 32:
            n, d, m = pad(mc(H, 'Wz', d, q, m, n, s, Y), 3)
        else:
            n, T, N, m, q = pad(mc(H, 'Oz', T, m, N, Q, n, d, q, Y, s), 5)


# ----------------------------------------------------------------------
# ----------------------------------------------------------------------

def build_inputs():
    import importlib.util

    def load(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    sim = load('sim2', os.path.join(HERE, 'sim_core.py'))
    dec = load('dec1', os.path.join(CASE, 'static', 'decode_stage1.py'))
    text = open(RAW, encoding='utf-8', errors='surrogateescape').read()
    MY, yy, table = dec.extract_vm_fields(text)

    def gsub_fn(H):
        return dec.lua_gsub(H.MY, H._Y)

    capture = {}
    holder = {}

    def fz_stub(E, yv, nv):
        capture['E'] = E
        capture['y'] = yv
        capture['cz'] = dict(holder['H'].cz)
        capture['gz'] = dict(holder['H'].gz)
        return lambda a, b, c: None

    H = sim.VM(MY, yy, table, fz_stub)
    holder['H'] = H
    sim.run_vy(H, gsub_fn)
    return capture


def main():
    cap_in = build_inputs()
    E_real = cap_in['E']
    H = build_H()
    H.cz = KSDict({num_key(k): v for k, v in cap_in['cz'].items()})
    H.gz = KSDict({num_key(k): v for k, v in cap_in['gz'].items()})
    print(f"cz entries: {len(H.cz)}, gz entries: {len(H.gz)}")

    # buffer registry alignment with the real run: #1 oz, #2 work, #3 chunk
    H.oz = buf_create(16, log=False)
    work_src = open(os.path.join(CASE, 'static', 'src.bin'), 'rb').read()
    work = buf_fromstring(work_src, log=False)
    chunk = _new_buf(bytearray(E_real[5]))
    assert (H.oz.id, work.id, chunk.id) == (1, 2, 3), (H.oz.id, work.id, chunk.id)

    A = LT()
    tset(A, 4, E_real[4])
    tset(A, 5, chunk)
    fields = LT()
    for k, v in E_real[6].items():
        tset(fields, k, v)
    tset(A, 6, fields)

    result = None
    error = None
    try:
        result = pad(mc(H, 'Fz', A, 201, 20), 2)
        print('Fz RETURNED:', type(result[0]), type(result[1]))
    except Untranscribed as ex:
        error = f'UNTRANSCRIBED {ex.name}'
        print(error)
    except LuaError as ex:
        error = f'LUAERROR {ex}'
        print(error)
    print(f'Fz-phase buffer ops logged: {len(OPLOG)}')

    # ---- validation against the oracle trace ----
    oracle = open(os.path.join(CASE, 'tool-out', 'btrace_head.log'),
                  encoding='utf-8', errors='replace').read().splitlines()
    start = next(i for i, ln in enumerate(oracle) if ln.startswith('B create 56956'))
    expect = oracle[start:]
    print(f'oracle Fz-phase ops available: {len(expect)} (from line {start + 1})')
    n_match = 0
    first_div = None
    for idx, (mine, exp) in enumerate(zip(OPLOG, expect)):
        if mine.rstrip() == exp.rstrip():
            n_match += 1
        else:
            first_div = idx
            break
    if first_div is None:
        first_div = min(len(OPLOG), len(expect))
        print(f'op stream: all {n_match} compared ops MATCH '
              f'(sim produced {len(OPLOG)}, oracle window {len(expect)})')
    else:
        print(f'op stream: {n_match} ops match; FIRST DIVERGENCE at '
              f'Fz-phase op #{first_div + 1} (oracle line {start + first_div + 1}):')
        print(f'  mine:   {OPLOG[first_div]}')
        print(f'  oracle: {expect[first_div]}')
        for ctx in range(max(0, first_div - 3), first_div):
            print(f'  ctx[{ctx + 1}]: {OPLOG[ctx]}')

    # ---- byte-compare buffers vs analysis/bufs1 at the oracle horizon ----
    bufs_dir = os.path.join(CASE, 'analysis', 'bufs1')
    horizon = len(expect)
    if len(OPLOG) >= horizon:
        print('NOTE: sim reached the oracle horizon; bufs1 comparison is '
              'only meaningful if buffer states were snapshotted there.')

    with open(os.path.join(HERE, 'fz_oplog.txt'), 'w') as fo:
        fo.write('\n'.join(OPLOG))
    print('FZ_TRACE (step, n, Z, T, N, s, d, m, q, Y, Q, j, c, D, U):')
    for row in FZ_TRACE[:70]:
        print('  ', row)
    print('walk state counts (top):',
          sorted(WALK_COUNTS.items(), key=lambda kv: -kv[1])[:12])
    print('recent walk ring (last 25):', WALK_LOG[-25:])
    return error




# ----------------------------------------------------------------------
# IY callees (transcribed on demand, in walk order)
# ----------------------------------------------------------------------

@method('o', 11)
def m_o(H, P, E, u, A, X, y, i, J, B, z, S):
    if S <= 88:
        if S <= 87:
            fv = lua_num(u) + (lua_num(B) - 128) * 128
            return (65, J, A, E, 2 + lua_num(X), fv)
        uv = buf_readu8(J, lua_num(A) + 3)
        fv = 128 * (lua_num(y) - 128)
        Rv = 2097152 * (lua_num(P) - 128)
        hv = (lua_num(z) - 128) * 16384
        xv = uv % 128
        ev = (uv - uv % 128) * 2097152
        return (164, xv + (Rv + hv + (ev + fv)), 4 + lua_num(A), E, X, B)
    if S <= 89:
        Pv = buf_readu8(J, 0)
        return ((194 if Pv < 128 else 18), J, None, Pv, X, B)
    return (200, 128 * (lua_num(i) - 128) + lua_num(J), lua_num(A) + 2, E, X, B)


# Driver: build the real E via the stage-1 simulator, run Fz, validate



@method('Cz', 8)
def m_Cz(H, P, E, u, A, X, y, i, J):
    if i <= 194:
        if i <= 193:
            Bv = lua_num(E) + 128 * (lua_num(J) - 128)
            return (106, lua_num(u) + 2, P, y, Bv, A)
        return (237, u, P, 1, J, A)
    if i <= 195:
        Ev = buf_readu8(X, lua_num(y) + 2)
        return ((209 if 128 <= Ev else 77), u, P, y, J, Ev)
    return (37, u, 1 + lua_num(P), y, J, A)



@method('Sz', 10)
def m_Sz(H, P, E, u, A, X, y, i, J, B, z):
    if u <= 237:
        Sv = tget(E, 7)
        if A != 0:
            return (21, J, None, Sv, y)
        return (177, Sv, P, X, y)
    Ev = buf_readu8(i, lua_num(J) + 3)
    Hv = (lua_num(y) - 128) * 128
    uv = (lua_num(B) - 128) * 2097152
    Av = 16384 * (lua_num(z) - 128)
    Sv = Ev % 128
    yv = 2097152 * (Ev - Sv)
    Ev2 = Sv + (uv + Av + (yv + Hv))
    return (84, 4 + lua_num(J), P, X, Ev2)



@method('v', 7)
def m_v(H, P, E, u, A, X, y, i):
    if X <= 22:
        if X <= 21:
            return ((246 if A != 2 else 182), P, E, i)
        return (24, tget(P, 3), E, i)
    if X <= 23:
        return (153, tget(P, 3), E, i)
    if X <= 24:
        Av = buf_readu8(y, u)
        return ((140 if Av < 128 else 110), P, E, Av)
    Hv = tget(P, 3)
    uv = tget(P, 2)
    Av = tget(P, 5)
    Xv = lua_num(Hv) + lua_num(uv)
    yv = lua_num(uv) <= 0
    uv2 = Xv >= lua_num(Av)
    Hv2 = Xv <= lua_num(Av)
    Av2 = uv2 if yv else Hv2
    tset(P, 3, Xv)
    if truthy(Av2):
        return (212, P, Xv, i)
    return (244, P, E, i)



@method('Vz', 10)
def m_Vz(H, P, E, u, A, X, y, i, J, B, z):
    if z <= 181:
        if z <= 180:
            return ((88 if 128 <= lua_num(P) else 260), E, A, X, J, y, B)
        Pv = buf_readu8(i, A)
        return ((250 if Pv < 128 else 11), E, A, X, J, Pv, B)
    if z <= 182:
        Pv = buf_readu32(i, J)
        zv = 4 + lua_num(J)
        Sv = 1
        tbl = LT()
        tset(tbl, 1, E)
        tset(tbl, 3, Pv)
        tset(tbl, 4, Sv)
        tset(tbl, 5, 1 - Sv)
        return (37, tbl, zv, 1, LT(), y, B)
    Hv = (lua_num(B) - 128) * 128 + lua_num(u)
    return (276, E, A, X, lua_num(J) + 2, y, Hv)


@method('jz', 9)
def m_jz(H, P, E, u, A, X, y, i, J, B):
    if B <= 177:
        if B <= 176:
            zv = buf_readu8(E, A)
            if zv < 128:
                return (130, zv, u, P, J, i)
            return (167, E, u, P, zv, i)
        zv = buf_readu8(E, X)
        return ((103 if zv < 128 else 235), E, zv, P, J, i)
    if B <= 178:
        Xv, Bv, zv = tget(y, 1), tget(y, 2), tget(y, 3)
        Sv = lua_num(Xv) + lua_num(Bv)
        fv = lua_num(Bv) <= 0
        B2 = Sv >= lua_num(zv)
        X2 = Sv <= lua_num(zv)
        zv2 = B2 if fv else X2
        tset(y, 1, Sv)
        if truthy(zv2):
            return (62, E, u, Sv, J, i)
        return (47, E, u, P, J, i)
    return (180, E, u, P, J, buf_readu8(E, 2 + lua_num(A)))


@method('Uz', 10)
def m_Uz(H, P, E, u, A, X, y, i, J, B, z):
    if z <= 185:
        if z <= 184:
            Sv = buf_readu8(P, lua_num(A) + 3)
            fv = 128 * (lua_num(B) - 128)
            Rv = 2097152 * (lua_num(i) - 128)
            hv = 16384 * (lua_num(J) - 128)
            xv = Sv % 128
            iv = (Sv - Sv % 128) * 2097152 + (hv + (fv + xv + Rv))
            return (160, X, 4 + lua_num(A), E, y, iv)
        return (262, 1 + lua_num(X), A, E, y, B)
    if z <= 186:
        iv = buf_readu8(P, lua_num(A) + 2)
        return ((60 if iv < 128 else 147), X, A, E, iv, B)
    Hv = lua_num(E) - 128
    Pv = (lua_num(y) - 128) * 128
    Ev = 16384 * lua_num(u) + (Pv + Hv)
    return (155, X, 3 + lua_num(A), Ev, y, B)


@method('Iz', 8)
def m_Iz(H, P, E, u, A, X, y, i, J):
    if i <= 189:
        if i <= 188:
            Bv = buf_readu8(E, lua_num(X) + 2)
            return ((231 if Bv < 128 else 175), J, X, u, P, A, Bv)
        Bv = buf_readu8(E, 1 + lua_num(X))
        return ((241 if 128 > Bv else 3), J, X, u, Bv, A, y)
    if i <= 190:
        Ev = table_create(A)
        Bv = 1
        tbl = LT()
        tset(tbl, 1, 1 - Bv)
        tset(tbl, 2, A)
        tset(tbl, 3, J)
        tset(tbl, 4, Bv)
        return (125, tbl, X, u, P, Ev, y)
    if i <= 191:
        return (84, J, lua_num(X) + 1, u, P, A, y)
    return (65, J, X, lua_num(u) + 1, P, A, y)



@method('h', 9)
def m_h(H, P, E, u, A, X, y, i, J, B):
    if B <= 36:
        if B <= 35:
            zv = lua_num(P) - 128
            Sv = 128 * (lua_num(J) - 128)
            fv = lua_num(X) * 16384 + (Sv + zv)
            return (278, u, lua_num(y) + 3, i, fv, J)
        Xv = buf_readu8(A, 2 + lua_num(u))
        return ((214 if Xv >= 128 else 168), u, y, i, P, Xv)
    if B <= 37:
        Hv, Av, Xv = tget(E, 5), tget(E, 4), tget(E, 3)
        Bv = lua_num(Hv) + lua_num(Av)
        zv = lua_num(Av) <= 0
        H2 = Bv >= lua_num(Xv)
        A2 = Bv <= lua_num(Xv)
        X2 = H2 if zv else A2
        tset(E, 5, Bv)
        if truthy(X2):
            return (19, u, y, Bv, P, J)
        return (156, u, y, i, P, J)
    return (98, 1 + lua_num(u), y, i, P, J)


@method('f', 7)
def m_f(H, H2, P, E, u, A, X, y):
    if A <= 39:
        Av, iv, Jv = tget(H2, 4), tget(H2, 3), tget(H2, 2)
        Bv = lua_num(Av) + lua_num(iv)
        zv = lua_num(iv) <= 0
        A2 = Bv >= lua_num(Jv)
        i2 = Bv <= lua_num(Jv)
        J2 = A2 if zv else i2
        tset(H2, 4, Bv)
        if truthy(J2):
            return (111, P, y, Bv)
        return (26, P, y, u)
    Hv = lua_num(y) - 128
    Av = (lua_num(E) - 128) * 128
    iv = lua_num(X) * 16384
    Ev = Av + Hv + iv
    return (271, lua_num(P) + 3, Ev, u)


@method('p', 6)
def m_p(H, P, E, u, A, X, y):
    if E <= 41:
        Ev = buf_readu8(y, lua_num(A) + 2)
        return ((225 if Ev >= 128 else 139), Ev, u)
    Hv, Ev, Av = tget(X, 2), tget(X, 4), tget(X, 1)
    yv = lua_num(Hv) + lua_num(Ev)
    iv = lua_num(Ev) <= 0
    H2 = yv >= lua_num(Av)
    E2 = yv <= lua_num(Av)
    A2 = H2 if iv else E2
    tset(X, 2, yv)
    if truthy(A2):
        return (281, P, yv)
    return (245, P, u)


@method('S', 7)
def m_S(H, P, E, u, A, X, y, i):
    if u <= 44:
        if u <= 43:
            Jv = buf_readu8(A, lua_num(y) + 2)
            return ((8 if 128 <= Jv else 254), X, E, Jv, P)
        Jv = buf_readu8(A, lua_num(y) + 2)
        return ((142 if 128 > Jv else 76), X, E, i, Jv)
    if u <= 45:
        uv = buf_readu8(A, lua_num(X) + 1)
        return ((53 if 128 > uv else 66), X, uv, i, P)
    return (160, lua_num(X) + 1, E, i, P)


@method('T', 7)
def m_T(H, P, E, u, A, X, y, i):
    if E <= 48:
        if E <= 47:
            return (126, tget(P, 5), A, u, y, i)
        Jv = buf_readu32(X, A)
        Bv = lua_num(A) + 4
        zv = buf_readu32(X, Bv)
        Sv = 4 + Bv
        fv = lua_num(u) - lua_mod(u, 1)
        Rv = 1
        tbl = LT()
        tset(tbl, 1, P)
        tset(tbl, 2, Rv)
        tset(tbl, 3, fv - Rv)
        tset(tbl, 5, Jv)
        return (25, tbl, Jv, zv, y, Sv)
    if E <= 49:
        return (15, P, A, u, lua_num(y) + 1, i)
    if E <= 50:
        return (107, tget(P, 5), A, u, y, i)
    Hv = 128 * (lua_num(y) - 128) + lua_num(i)
    return (226, P, 2 + lua_num(A), u, Hv, i)


@method('q', 13)
def m_q(H, P, E, u, A, X, y, i, J, B, z, S, f, R):
    if X <= 53:
        if X <= 52:
            tset(i, S, f)
            return (178, A, E, z, P, f)
        iv = lua_num(R) + (lua_num(P) - 128) * 128
        return (278, A, 2 + lua_num(E), z, iv, f)
    if X <= 54:
        Xv = buf_readu8(y, 3 + lua_num(A))
        Hv = 128 * (lua_num(f) - 128)
        yv = (lua_num(J) - 128) * 2097152
        iv = 16384 * (lua_num(u) - 128)
        Sv = Xv % 128
        uv = 2097152 * (Xv - Xv % 128) + Hv + (yv + Sv) + iv
        return (99, lua_num(A) + 4, E, z, P, uv)
    Hv = 128 * (lua_num(z) - 128) + lua_num(B)
    return (202, 2 + lua_num(A), E, Hv, P, f)



@method('i', 9)
def m_i(H, P, E, u, A, X, y, i, J, B):
    if u <= 154:
        if u <= 153:
            zv = buf_readu8(J, A)
            return ((279 if zv < 128 else 210), X, A, i, E, P, zv)
        zv = lua_num(i) - 128
        Sv = (lua_num(E) - 128) * 128
        fv = lua_num(y) * 16384 + Sv + zv
        return (226, X, 3 + lua_num(A), fv, E, P, B)
    if u <= 155:
        yv = buf_readu8(J, i)
        return ((102 if 128 <= yv else 201), X, A, i, E, yv, B)
    if u <= 156:
        return (230, tget(X, 1), A, i, E, P, B)
    Ev = buf_readu8(J, A)
    return ((16 if 128 <= Ev else 33), X, A, i, Ev, P, B)


@method('_', 6)
def m__(H, P, E, u, A, X, y):
    if u <= 18:
        if u <= 17:
            return (119, E, A, lua_num(P) + 1, X)
        iv = buf_readu8(y, 1)
        return ((59 if 128 <= iv else 96), E, A, iv, X)
    if u <= 19:
        uv = buf_readu32(y, E)
        iv = 4 + lua_num(E)
        Hv = uv / 2
        if lua_mod(uv, 2) == 0:
            return (135, iv, A, P, Hv)
        return (48, iv, Hv, P, X)
    return (176, 1 + lua_num(E), A, P, X)


@method('b', 8)
def m_b(H, P, E, u, A, X, y, i, J):
    if J <= 1:
        if J <= 0:
            Bv = buf_readu8(E, 1 + lua_num(A))
            return ((32 if 128 > Bv else 114), E, u, X, Bv)
        return (249, E, lua_num(A) + 1, X, y)
    if J <= 2:
        Av = buf_readu8(E, lua_num(u) + 3)
        Jv = 128 * (lua_num(i) - 128)
        Bv = (lua_num(X) - 128) * 2097152
        zv = 16384 * (lua_num(P) - 128)
        Sv = Av % 128
        return (200, zv + (Jv + (2097152 * (Av - Av % 128) + Bv) + Sv),
                4 + lua_num(u), X, y)
    Pv = buf_readu8(E, lua_num(u) + 2)
    return ((171 if Pv >= 128 else 105), E, u, Pv, y)


@method('s', 8)
def m_s(H, P, E, u, A, X, y, i, J):
    if A <= 5:
        if A <= 4:
            Bv = buf_readu8(X, 2 + lua_num(P))
            return ((124 if 128 <= Bv else 220), J, y, E, Bv)
        return (149, lua_num(J) + 1, y, E, i)
    if A <= 6:
        Pv = buf_readu8(X, 3 + lua_num(J))
        Av = (lua_num(y) - 128) * 128
        Bv = (lua_num(E) - 128) * 2097152
        zv = 16384 * (lua_num(u) - 128)
        Sv = Pv % 128
        uv = zv + (Pv - Pv % 128) * 2097152 + (Sv + Bv) + Av
        return (155, lua_num(J) + 4, uv, E, i)
    Pv = buf_readu8(X, 1 + lua_num(J))
    return ((247 if Pv >= 128 else 158), J, y, Pv, i)


@method('M', 10)
def m_M(H, P, E, u, A, X, y, i, J, B, z):
    if E <= 9:
        if E <= 8:
            Sv = buf_readu8(J, lua_num(A) + 3)
            fv = (lua_num(y) - 128) * 128
            Rv = (lua_num(z) - 128) * 2097152
            hv = 16384 * (lua_num(P) - 128)
            xv = Sv % 128
            Pv = (Sv - xv) * 2097152
            ev = hv + xv + (fv + Rv + Pv)
            return (31, u, lua_num(A) + 4, X, i, ev)
        Pv = buf_readu8(J, B)
        return ((1 if 128 > Pv else 216), Pv, A, X, i, y)
    if E <= 10:
        Pv = buf_readu8(J, 1 + lua_num(B))
        return ((145 if 128 > Pv else 137), u, A, X, Pv, y)
    Pv = buf_readu8(J, 1 + lua_num(A))
    return ((41 if Pv >= 128 else 193), u, A, Pv, i, y)


@method('Y', 9)
def m_Y(H, P, E, u, A, X, y, i, J, B):
    if A <= 13:
        if A <= 12:
            zv = buf_readu8(X, lua_num(u) + 1)
            return ((174 if zv >= 128 else 29), B, J, i, P, zv)
        zv = buf_readu8(X, 1 + lua_num(u))
        return ((108 if 128 <= zv else 51), zv, J, i, P, y)
    if A <= 14:
        zv = buf_readu8(X, lua_num(E) + 1)
        return ((80 if zv >= 128 else 148), B, J, i, zv, y)
    if A <= 15:
        Av = buf_readu8(X, E)
        return ((17 if Av < 128 else 113), B, J, Av, P, y)
    Ev = buf_readu8(X, lua_num(u) + 1)
    return ((30 if Ev >= 128 else 150), B, Ev, i, P, y)


@method('y', 10)
def m_y(H, P, E, u, A, X, y, i, J, B, z):
    if y <= 27:
        if y <= 26:
            return (219, tget(X, 5), u, i, z, P)
        Sv = buf_readu8(B, lua_num(E) + 1)
        return ((242 if 128 <= Sv else 116), X, u, Sv, z, P)
    if y <= 28:
        return (132, X, u, i, (lua_num(z) - 128) * 128 + lua_num(A), P)
    Hv = lua_num(J) + 128 * (lua_num(P) - 128)
    return (99, X, 2 + lua_num(u), i, z, Hv)


@method('H', 11)
def m_Hf(H, P, E, u, A, X, y, i, J, B, z, S):
    if y <= 31:
        if y <= 30:
            fv = buf_readu8(P, lua_num(i) + 2)
            return ((169 if fv < 128 else 143), i, B, fv, J)
        tset(z, u, X)
        return (56, i, B, A, J)
    if y <= 32:
        Hv = lua_num(S) + 128 * (lua_num(J) - 128)
        return (52, i, lua_num(B) + 2, A, Hv)
    if y <= 33:
        return (134, lua_num(i) + 1, B, A, J)
    Hv = lua_num(J) - 128
    Pv = 128 * (lua_num(S) - 128)
    uv = Hv + 16384 * lua_num(E) + Pv
    return (52, i, 3 + lua_num(B), A, uv)



@method('fz', 10)
def m_fz(H, P, E, u, A, X, y, i, J, B, z):
    if y <= 229:
        if y <= 228:
            Sv = buf_readu8(P, 3 + lua_num(J))
            fv = 128 * (lua_num(E) - 128)
            Rv = 2097152 * (lua_num(B) - 128)
            hv = (lua_num(u) - 128) * 16384
            xv = Sv % 128
            Bv = hv + (2097152 * (Sv - Sv % 128) + (xv + (fv + Rv)))
            return (262, lua_num(J) + 4, z, Bv, u, X)
        Bv = buf_readu8(P, 1 + lua_num(J))
        return ((72 if 128 <= Bv else 273), J, z, E, Bv, X)
    if y <= 230:
        yv = buf_readu8(P, J)
        return ((268 if yv < 128 else 189), J, yv, E, u, X)
    Hv = lua_num(X) - 128
    Pv = 128 * (lua_num(A) - 128) + (lua_num(i) * 16384 + Hv)
    return (252, 3 + lua_num(J), z, E, u, Pv)


@method('pz', 11)
def m_pz(H, P, E, u, A, X, y, i, J, B, z, S):
    if A <= 233:
        if A <= 232:
            return (74, u, lua_num(B) + (lua_num(z) - 128) * 128,
                    2 + lua_num(E), B, J, X)
        fv = lua_num(J) - 128
        Rv = (lua_num(i) - 128) * 128
        hv = lua_num(S) * 16384 + fv + Rv
        return (262, 3 + lua_num(u), z, E, B, hv, X)
    if A <= 234:
        Sv = buf_readu8(y, u)
        return ((205 if 128 > Sv else 73), u, z, E, B, J, Sv)
    if A <= 235:
        Av = buf_readu8(y, 1 + lua_num(E))
        return ((186 if Av >= 128 else 232), u, z, E, Av, J, X)
    tset(i, P, J)
    return (70, u, z, E, B, J, X)


@method('Tz', 7)
def m_Tz(H, P, E, u, A, X, y, i):
    if u <= 239:
        uv = buf_readu8(P, lua_num(X) + 2)
        return ((63 if uv < 128 else 95), A, i, uv)
    uv = buf_readu8(P, 3 + lua_num(X))
    Hv = 128 * (lua_num(A) - 128)
    Pv = 2097152 * (lua_num(i) - 128)
    Jv = (lua_num(E) - 128) * 16384
    Bv = uv % 128
    return (249, (uv - uv % 128) * 2097152 + (Pv + Jv) + (Hv + Bv),
            4 + lua_num(X), y)


@method('qz', 9)
def m_qz(H, P, E, u, A, X, y, i, J, B):
    if A <= 242:
        if A <= 241:
            zv = (lua_num(P) - 128) * 128 + lua_num(J)
            return (69, i, lua_num(B) + 2, zv, X, u)
        zv = buf_readu8(y, 2 + lua_num(E))
        return ((129 if zv >= 128 else 206), i, B, P, zv, u)
    if A <= 243:
        zv = buf_readu8(y, lua_num(E) + 2)
        return ((257 if 128 <= zv else 165), i, B, P, X, zv)
    if A <= 244:
        return (196, tget(i, 1), J, B, X, u)
    return (218, tget(i, 3), B, P, X, u)


@method('nz', 11)
def m_nz(H, P, E, u, A, X, y, i, J, B, z, S):
    if E <= 247:
        if E <= 246:
            if B != 1:
                return (204, u, A, i, S, B, S, J, y)
            return (9, u, z, i, A, B, S, J, y)
        fv = buf_readu8(z, lua_num(S) + 2)
        return ((187 if 128 > fv else 6), u, z, i, A, B, S, fv, y)
    if E <= 248:
        Ev = buf_readu8(z, 3 + lua_num(S))
        fv = 128 * (lua_num(y) - 128)
        Rv = (lua_num(X) - 128) * 2097152
        hv = 16384 * (lua_num(P) - 128)
        xv = Ev % 128
        Pv = 2097152 * (Ev - Ev % 128) + xv + (hv + fv) + Rv
        return (278, u, z, i, A, B, 4 + lua_num(S), J, Pv)
    Pv = table_create(i)
    Ev = table_create(i)
    Xv = 1
    tbl = LT()
    tset(tbl, 1, 1 - Xv)
    tset(tbl, 2, i)
    tset(tbl, 3, Xv)
    tset(tbl, 5, u)
    return (208, tbl, z, Pv, A, Ev, S, J, y)


@method('Rz', 12)
def m_Rz(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if i <= 251:
        if i <= 250:
            return (106, z, 1 + lua_num(E), y, X, P, f)
        Rv = buf_readu8(u, 2 + lua_num(E))
        return ((233 if 128 > Rv else 228), z, E, y, Rv, P, f)
    if i <= 252:
        Rv = lua_num(P) - 56478
        hv = table_create(Rv)
        xv = table_create(Rv)
        ev = 1
        tbl = LT()
        tset(tbl, 1, ev)
        tset(tbl, 3, Rv)
        tset(tbl, 4, z)
        tset(tbl, 5, 1 - ev)
        return (75, tbl, E, y, X, hv, xv)
    if i <= 253:
        tset(S, A, buf_readu32(u, y))
        iv = 4 + lua_num(y)
        return (125, z, E, iv, X, P, f)
    Hv = lua_num(f) - 128
    uv = (lua_num(B) - 128) * 128
    Av = lua_num(J) * 16384
    iv = uv + Hv + Av
    return (31, z, lua_num(E) + 3, y, X, P, iv)



@method('Bz', 7)
def m_Bz(H, P, E, u, A, X, y, i):
    if E <= 269:
        if E <= 268:
            return (69, lua_num(i) + 1, A, X, y, P)
        Jv = buf_readu8(u, lua_num(i) + 2)
        return ((93 if Jv < 128 else 264), i, A, X, Jv, P)
    if E <= 270:
        return (155, i, 1 + lua_num(A), X, y, P)
    if E <= 271:
        Ev = buf_readu8(u, A)
        return ((27 if Ev >= 128 else 49), i, A, Ev, y, P)
    Pv = buf_readu8(u, i)
    return ((12 if Pv >= 128 else 123), i, A, X, y, Pv)


@method('mz', 10)
def m_mz(H, P, E, u, A, X, y, i, J, B, z):
    if i <= 274:
        if i <= 273:
            Sv = lua_num(E) + (lua_num(J) - 128) * 128
            return (151, A, lua_num(B) + 2, u, X, Sv, z, P)
        Ev = buf_readu8(y, 2 + lua_num(B))
        return ((238 if 128 <= Ev else 256), A, B, u, Ev, J, z, P)
    if i <= 275:
        Ev = buf_readu8(y, B)
        return ((191 if Ev < 128 else 68), A, B, Ev, X, J, z, P)
    Pv = lua_num(z) - 56478
    Ev = table_create(Pv)
    yv = table_create(Pv)
    iv = 1
    tbl = LT()
    tset(tbl, 1, 1 - iv)
    tset(tbl, 2, iv)
    tset(tbl, 3, Pv)
    tset(tbl, 5, A)
    return (178, tbl, B, u, X, J, Ev, yv)


@method('Qz', 11)
def m_Qz(H, P, E, u, A, X, y, i, J, B, z, S):
    if X <= 278:
        if X <= 277:
            fv = lua_num(P) - 128
            Rv = (lua_num(i) - 128) * 128 + (lua_num(S) * 16384 + fv)
            return (99, 3 + lua_num(A), u, B, z, Rv)
        iv = buf_readu8(J, u)
        return ((14 if iv >= 128 else 46), A, u, B, iv, P)
    if X <= 279:
        return (202, lua_num(A) + 1, u, B, z, P)
    if X <= 280:
        Xv = buf_readu8(J, lua_num(A) + 3)
        iv = 128 * (lua_num(u) - 128)
        Sv = 2097152 * (lua_num(E) - 128)
        fv = 16384 * (lua_num(y) - 128)
        Rv = Xv % 128
        Ev = 2097152 * (Xv - Rv)
        hv = fv + iv + (Rv + Sv) + Ev
        return (226, lua_num(A) + 4, hv, B, z, P)
    Ev = buf_readu8(J, u)
    return ((101 if 128 <= Ev else 5), A, u, Ev, z, P)


@method('kz', 12)
def m_kz(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if B <= 256:
        if B <= 255:
            Rv = 128 * (lua_num(X) - 128) + lua_num(J)
            return (149, u, lua_num(z) + 2, y, Rv, f)
        Jv = lua_num(y) - 128
        Rv = (lua_num(P) - 128) * 128 + (lua_num(S) * 16384 + Jv)
        return (84, lua_num(u) + 3, z, Rv, X, f)
    if B <= 257:
        Pv = buf_readu8(A, lua_num(z) + 3)
        Jv = (lua_num(f) - 128) * 128
        Bv = 2097152 * (lua_num(E) - 128)
        Sv = 16384 * (lua_num(i) - 128)
        Ev = Bv + (Pv % 128 + (Pv - Pv % 128) * 2097152 + Jv + Sv)
        return (276, u, 4 + lua_num(z), y, X, Ev)
    Pv = buf_readu8(A, lua_num(z) + 2)
    return ((172 if 128 <= Pv else 213), u, z, y, X, Pv)


@method('uz', 11)
def m_uz(H, P, E, u, A, X, y, i, J, B, z, S):
    if X <= 260:
        if X <= 259:
            fv = 128 * (lua_num(A) - 128) + lua_num(E)
            return (31, u, 2 + lua_num(i), B, S, fv)
        Ev = lua_num(P) - 128
        fv = 128 * (lua_num(J) - 128)
        return (164, Ev + (lua_num(z) * 16384 + fv), lua_num(i) + 3, B, S, A)
    if X <= 261:
        return (164, 128 * (lua_num(P) - 128) + lua_num(u), 2 + lua_num(i), B, S, A)
    if X <= 262:
        Pv = buf_readu8(u, i)
        return ((229 if Pv >= 128 else 78), u, i, B, Pv, A)
    Hv = lua_num(y) + (lua_num(B) - 128) * 128
    return (84, u, 2 + lua_num(i), Hv, S, A)


@method('tz', 10)
def m_tz(H, P, E, u, A, X, y, i, J, B, z):
    if X <= 265:
        if X <= 264:
            Sv = buf_readu8(E, 3 + lua_num(A))
            fv = (lua_num(i) - 128) * 128
            Rv = (lua_num(u) - 128) * 2097152
            hv = (lua_num(z) - 128) * 16384
            xv = Sv % 128
            uv = (Sv - xv) * 2097152
            Sv2 = Rv + hv + uv + (fv + xv)
            return (197, P, lua_num(A) + 4, Sv2, z)
        uv = lua_num(z) - 128
        Sv = 128 * (lua_num(J) - 128)
        Jv = lua_num(y) * 16384 + Sv + uv
        return (151, P, 3 + lua_num(A), i, Jv)
    if X <= 266:
        uv = buf_readu8(E, 1 + lua_num(A))
        return ((251 if uv >= 128 else 91), P, A, i, uv)
    return (249, (lua_num(P) - 128) * 128 + lua_num(A), lua_num(B) + 2, i, z)



@method('u', 7)
def m_u(H, P, E, u, A, X, y, i):
    if u <= 67:
        Jv, Bv, zv = tget(i, 1), tget(i, 4), tget(i, 5)
        Sv = lua_num(Jv) + lua_num(Bv)
        fv = lua_num(Bv) <= 0
        B2 = Sv >= lua_num(zv)
        J2 = Sv <= lua_num(zv)
        zv2 = B2 if fv else J2
        tset(i, 1, Sv)
        if truthy(zv2):
            return (131, i, P, X, Sv)
        return (81, i, P, X, A)
    if u <= 68:
        uv = buf_readu8(y, 1 + lua_num(E))
        return ((274 if 128 <= uv else 263), i, P, uv, A)
    Ev = table_create(P)
    uv = 1
    tbl = LT()
    tset(tbl, 1, P)
    tset(tbl, 2, uv)
    tset(tbl, 3, i)
    tset(tbl, 5, 1 - uv)
    return (166, tbl, Ev, X, A)


@method('t', 6)
def m_t(H, P, E, u, A, X, y):
    if E <= 71:
        if E <= 70:
            iv, Jv, Bv = tget(A, 1), tget(A, 4), tget(A, 5)
            zv = lua_num(iv) + lua_num(Jv)
            Sv = lua_num(Jv) <= 0
            i2 = zv >= lua_num(Bv)
            J2 = zv <= lua_num(Bv)
            B2 = i2 if Sv else J2
            tset(A, 1, zv)
            if truthy(B2):
                return (236, A, zv, y)
            return (64, A, P, y)
        return (109, tget(A, 3), P, y)
    if E <= 72:
        Ev = buf_readu8(u, lua_num(X) + 2)
        return ((118 if 128 <= Ev else 265), A, Ev, y)
    Ev = buf_readu8(u, lua_num(X) + 1)
    return ((43 if 128 <= Ev else 259), A, P, Ev)


@method('B', 6)
def m_B(H, P, E, u, A, X, y):
    if E <= 74:
        Ev = buf_readu8(u, y)
        return ((270 if Ev < 128 else 7), Ev, X)
    Hv, Ev, uv = tget(A, 5), tget(A, 1), tget(A, 3)
    yv = lua_num(Hv) + lua_num(Ev)
    iv = lua_num(Ev) <= 0
    E2 = yv >= lua_num(uv)
    H2 = yv <= lua_num(uv)
    uv2 = E2 if iv else H2
    tset(A, 5, yv)
    if truthy(uv2):
        return (272, P, yv)
    return (221, P, X)


@method('m', 10)
def m_m(H, P, E, u, A, X, y, i, J, B, z):
    if A <= 76:
        Av = buf_readu8(X, lua_num(y) + 3)
        Hv = (lua_num(i) - 128) * 128
        Xv = (lua_num(B) - 128) * 2097152
        Sv = (lua_num(u) - 128) * 16384
        fv = Av % 128
        uv = 2097152 * (Av - fv)
        Rv = Sv + Hv + (fv + (Xv + uv))
        return (176, lua_num(y) + 4, P, J, Rv)
    Hv = lua_num(J) - 128 + (128 * (lua_num(z) - 128) + 16384 * lua_num(E))
    return (190, y, lua_num(P) + 3, Hv, i)


@method('Q', 6)
def m_Q(H, P, E, u, A, X, y):
    if y <= 79:
        if y <= 78:
            return (151, A, lua_num(u) + 1, X, E)
        return (278, A, u, lua_num(X) + 1, E)
    if y <= 80:
        yv = buf_readu8(P, lua_num(X) + 2)
        return ((184 if 128 <= yv else 224), A, u, X, yv)
    return (85, tget(A, 2), u, X, E)


@method('g', 9)
def m_g(H, P, E, u, A, X, y, i, J, B):
    if y <= 83:
        if y <= 82:
            return (197, i, 1 + lua_num(B), E, u)
        zv = buf_readu8(i, lua_num(B) + 1)
        if 128 <= zv:
            return (97, i, B, zv, u)
        return (90, zv, B, E, u)
    if y <= 84:
        tset(E, P, X)
        return (144, i, B, E, u)
    if y <= 85:
        Pv = buf_readu8(i, J)
        return ((79 if 128 > Pv else 45), i, B, E, Pv)
    Hv = lua_num(A) + 128 * (lua_num(E) - 128)
    return (121, i, lua_num(B) + 2, Hv, u)



@method('dz', 19)
def m_dz(H, P, E, u, A, X, y, i, J, B, z, S, f, R, h, x, e, _u, a, O):
    if B <= 164:
        b = LT()
        tset(e, -2, R)
        tset(A, -2, X)
        tset(P, -2, a)
        tset(y, -2, S)
        tset(e, -1, b)
        tset(A, -1, b)
        tset(P, -1, b)
        tset(y, -1, b)
        setmetatable(e, h)
        setmetatable(A, h)
        setmetatable(P, h)
        setmetatable(y, h)
        PROTO_TABLES.append(('dz', e, A, P, y))
        fn = H.slot[x] if isinstance(x, (int, float)) else H.fget(x)
        res = fn(H, i, e, f, O, P, X, R, z, y, A, a, S, E, _u)
        if isinstance(res, tuple):
            res = res[0] if res else None
        return (204, u, E, res, X)
    if B <= 165:
        Hv = lua_num(X) - 128
        Pv = (lua_num(A) - 128) * 128
        Av = lua_num(_u) * 16384 + Hv + Pv
        return (276, f, 3 + lua_num(E), u, Av)
    Hv, Pv, Av = tget(J, 5), tget(J, 2), tget(J, 1)
    yv = lua_num(Hv) + lua_num(Pv)
    iv = lua_num(Pv) <= 0
    H2 = yv >= lua_num(Av)
    P2 = yv <= lua_num(Av)
    A2 = H2 if iv else P2
    tset(J, 5, yv)
    if truthy(A2):
        return (198, f, E, yv, X)
    return (104, f, E, u, X)


@method('bz', 9)
def m_bz(H, P, E, u, A, X, y, i, J, B):
    if A <= 198:
        if A <= 197:
            zv = buf_readu8(J, E)
            return ((266 if zv >= 128 else 185), E, X, i, zv)
        tset(u, i, buf_readu32(J, E))
        zv = lua_num(E) + 4
        return (166, zv, X, i, B)
    if A <= 199:
        return (52, E, lua_num(X) + 1, i, B)
    if A <= 200:
        tset(u, -2, y)
        tset(u, -1, LT())
        setmetatable(u, P)
        PROTO_TABLES.append(('bz', u))
        fn = H.slot[X] if isinstance(X, (int, float)) else H.fget(X)
        res = fn(H, None, None, u)
        if isinstance(res, tuple):
            res = res[0] if res else None
        return (204, E, X, res, B)
    return (190, E, lua_num(X) + 1, i, B)


@method('Kz', 11)
def m_Kz(H, P, E, u, A, X, y, i, J, B, z, S):
    if z <= 168:
        if z <= 167:
            fv = buf_readu8(i, 1 + lua_num(X))
            if 128 > fv:
                return (261, fv, X, y, A, E)
            return (179, i, X, y, A, fv)
        fv = lua_num(A) - 128 + (128 * (lua_num(S) - 128) + 16384 * lua_num(J))
        return (98, i, 3 + lua_num(X), y, fv, E)
    if z <= 169:
        Jv = lua_num(y) - 128
        zv = (lua_num(P) - 128) * 128
        Pv = 16384 * lua_num(B) + (Jv + zv)
        return (134, i, lua_num(X) + 3, Pv, A, E)
    Pv = buf_readu8(i, lua_num(u) + 2)
    return ((112 if Pv < 128 else 128), i, X, y, Pv, E)


@method('wz', 10)
def m_wz(H, P, E, u, A, X, y, i, J, B, z):
    if y <= 171:
        yv = buf_readu8(B, 3 + lua_num(P))
        Sv = 128 * (lua_num(X) - 128)
        fv = (lua_num(u) - 128) * 2097152
        Rv = (lua_num(z) - 128) * 16384
        hv = yv % 128
        uv = 2097152 * (yv - hv)
        xv = Sv + (Rv + hv) + (uv + fv)
        return (69, 4 + lua_num(P), xv, E, A)
    uv = buf_readu8(B, lua_num(E) + 3)
    Hv = 128 * (lua_num(A) - 128)
    yv = 2097152 * (lua_num(i) - 128)
    Bv = 16384 * (lua_num(J) - 128)
    zv = uv % 128
    Av = Bv + (yv + (uv - uv % 128) * 2097152) + (zv + Hv)
    return (149, P, X, 4 + lua_num(E), Av)


@method('Pz', 10)
def m_Pz(H, P, E, u, A, X, y, i, J, B, z):
    if B <= 173:
        tset(A, P, lua_num(y) - lua_mod(y, 1))
        return (161, u, E, z)
    if B <= 174:
        Pv = buf_readu8(X, 2 + lua_num(u))
        return ((277 if 128 > Pv else 54), u, E, Pv)
    Pv = buf_readu8(X, lua_num(u) + 3)
    Hv = 128 * (lua_num(E) - 128)
    Av = (lua_num(J) - 128) * 2097152
    Xv = (lua_num(i) - 128) * 16384
    yv = Pv % 128
    Ev = Xv + (2097152 * (Pv - Pv % 128) + yv + Av + Hv)
    return (252, lua_num(u) + 4, Ev, z)


@method('_z', 13)
def m__z(H, P, E, u, A, X, y, i, J, B, z, S, f, R):
    if u <= 212:
        if u <= 211:
            hv = buf_readu8(A, 3 + lua_num(z))
            xv = 128 * (lua_num(i) - 128)
            ev = (lua_num(y) - 128) * 2097152
            _v = 16384 * (lua_num(S) - 128)
            av = hv % 128
            yv = 2097152 * (hv - av)
            hv2 = xv + av + (yv + ev) + _v
            return (271, R, 4 + lua_num(z), hv2, X, J)
        tset(z, f, B)
        return (25, R, z, i, X, J)
    if u <= 213:
        uv = lua_num(J) - 128
        yv = (lua_num(E) - 128) * 128 + (16384 * lua_num(P) + uv)
        return (149, R, lua_num(z) + 3, i, X, yv)
    Pv = buf_readu8(A, 3 + lua_num(R))
    Hv = (lua_num(X) - 128) * 128
    uv = 2097152 * (lua_num(J) - 128)
    Av = 16384 * (lua_num(E) - 128)
    yv = Pv % 128
    Ev = Hv + 2097152 * (Pv - Pv % 128) + (yv + (uv + Av))
    return (98, lua_num(R) + 4, z, i, Ev, J)



@method('Z', 9)
def m_Z(H, P, E, u, A, X, y, i, J, B):
    if P <= 101:
        if P <= 100:
            zv = lua_num(y) + 128 * (lua_num(i) - 128)
            return (176, A, 2 + lua_num(B), E, u, X, zv)
        yv = buf_readu8(J, lua_num(E) + 1)
        return ((258 if yv >= 128 else 255), A, B, E, u, yv, i)
    if P <= 102:
        yv = buf_readu8(J, 1 + lua_num(E))
        return ((195 if yv >= 128 else 159), A, B, E, yv, X, i)
    if P <= 103:
        return (74, A, B, lua_num(E) + 1, u, X, i)
    return (157, tget(A, 3), B, E, u, X, i)


@method('c', 12)
def m_c(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if f <= 92:
        if f <= 91:
            Rv = lua_num(A) + 128 * (lua_num(S) - 128)
            return (262, i, lua_num(z) + 2, u, P, E, Rv, B)
        Rv = buf_readu32(J, u)
        hv = 4 + lua_num(u)
        xv = buf_readu32(J, hv)
        ev = 4 + hv
        _v = lua_num(S) - lua_mod(S, 1)
        av = 1
        tbl = LT()
        tset(tbl, 1, _v - av)
        tset(tbl, 3, i)
        tset(tbl, 4, av)
        tset(tbl, 5, Rv)
        return (70, tbl, z, Rv, P, E, xv, ev)
    if f <= 93:
        Rv = lua_num(E) - 128
        hv = (lua_num(S) - 128) * 128
        xv = Rv + (16384 * lua_num(A) + hv)
        return (197, i, lua_num(z) + 3, u, P, xv, S, B)
    if f <= 94:
        return (121, i, 1 + lua_num(z), u, P, E, S, B)
    Av = buf_readu8(J, lua_num(u) + 3)
    Hv = (lua_num(P) - 128) * 128
    Jv = (lua_num(y) - 128) * 2097152
    fv = 16384 * (lua_num(X) - 128)
    Rv = Av % 128
    Pv = (Av - Rv) * 2097152
    Av2 = Rv + (fv + Jv) + (Pv + Hv)
    return (65, i, z, lua_num(u) + 4, Av2, E, S, B)


@method('F', 12)
def m_F(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if P <= 97:
        if P <= 96:
            return (237, f, (lua_num(z) - 128) * 128 + lua_num(E), 2, B)
        Rv = buf_readu8(f, lua_num(y) + 2)
        if 128 > Rv:
            return (141, Rv, z, E, B)
        return (2, f, z, E, Rv)
    if P <= 98:
        tset(A, i, S)
        return (39, f, z, E, B)
    tset(u, X, J)
    return (75, f, z, E, B)


@method('N', 8)
def m_N(H, P, E, u, A, X, y, i, J):
    if A <= 106:
        if A <= 105:
            Bv = lua_num(X) - 128
            zv = (lua_num(i) - 128) * 128
            Sv = lua_num(P) * 16384 + (zv + Bv)
            return (69, lua_num(J) + 3, Sv, y, P)
        tset(u, y, i)
        return (208, J, X, y, P)
    if A <= 107:
        uv = buf_readu8(E, J)
        return ((13 if uv >= 128 else 58), J, X, uv, P)
    Pv = buf_readu8(E, 2 + lua_num(J))
    return ((280 if Pv >= 128 else 154), J, X, y, Pv)


@method('X', 9)
def m_X(H, P, E, u, A, X, y, i, J, B):
    if X <= 110:
        if X <= 109:
            zv = buf_readu8(B, u)
            return ((215 if zv >= 128 else 192), u, zv, J, E, P, i)
        zv = buf_readu8(B, lua_num(y) + 1)
        return ((203 if 128 > zv else 188), u, A, J, E, P, zv)
    if X <= 111:
        zv = buf_readu8(B, y)
        return ((38 if zv < 128 else 115), u, A, J, E, zv, i)
    if X <= 112:
        Xv = lua_num(J) - 128
        yv = (lua_num(E) - 128) * 128
        zv = 16384 * lua_num(P) + (yv + Xv)
        return (119, 3 + lua_num(u), A, zv, E, P, i)
    Ev = buf_readu8(B, lua_num(u) + 1)
    return ((217 if Ev < 128 else 170), u, A, J, Ev, P, i)


@method('E', 10)
def m_E(H, P, E, u, A, X, y, i, J, B, z):
    if P <= 115:
        if P <= 114:
            Sv = buf_readu8(i, lua_num(A) + 2)
            return ((117 if Sv >= 128 else 34), A, J, u, X, Sv)
        Sv = buf_readu8(i, 1 + lua_num(y))
        return ((163 if Sv < 128 else 36), A, J, Sv, X, E)
    if P <= 116:
        Pv = lua_num(B) + (lua_num(J) - 128) * 128
        return (15, lua_num(A) + 2, Pv, u, X, E)
    Pv = buf_readu8(i, lua_num(A) + 3)
    Hv = 128 * (lua_num(X) - 128)
    yv = (lua_num(z) - 128) * 2097152
    iv = 16384 * (lua_num(E) - 128)
    Bv = Pv % 128
    Xv = 2097152 * (Pv - Bv)
    Pv2 = Bv + iv + (Hv + Xv) + yv
    return (52, lua_num(A) + 4, J, u, Pv2, E)



@method('O', 7)
def m_O(H, P, E, u, A, X, y, i):
    if u <= 133:
        if u <= 132:
            return (197, lua_num(X) + 2, P, y)
        return (276, X, lua_num(P) + 1, y)
    if u <= 134:
        uv = buf_readu8(A, X)
        return ((127 if 128 <= uv else 94), X, P, uv)
    tset(P, i, lua_num(E) - lua_mod(E, 1))
    return (196, X, P, y)


@method('e', 9)
def m_e(H, P, E, u, A, X, y, i, J, B):
    if B <= 137:
        if B <= 136:
            return (271, y, u, 1 + lua_num(i), X, P)
        zv = buf_readu8(E, lua_num(i) + 2)
        return ((40 if zv < 128 else 211), y, u, i, X, zv)
    if B <= 138:
        zv = buf_readu8(E, 2 + lua_num(i))
        return ((240 if 128 <= zv else 207), y, zv, i, X, P)
    if B <= 139:
        Hv = lua_num(X) - 128
        Ev = (lua_num(A) - 128) * 128
        Av = Hv + lua_num(J) * 16384 + Ev
        return (106, lua_num(y) + 3, u, i, Av, P)
    return (252, lua_num(y) + 1, u, i, X, P)


@method('a', 9)
def m_a(H, P, E, u, A, X, y, i, J, B):
    if E <= 118:
        Ev = buf_readu8(i, 3 + lua_num(B))
        zv = 128 * (lua_num(y) - 128)
        Sv = 2097152 * (lua_num(A) - 128)
        Av = 16384 * (lua_num(J) - 128) + \
            (Ev % 128 + (Sv + 2097152 * (Ev - Ev % 128)) + zv)
        return (151, u, lua_num(B) + 4, P, X, Av)
    Ev = lua_num(P) - 56478
    Pv = table_create(Ev)
    Av = table_create(Ev)
    Xv = 1
    tbl = LT()
    tset(tbl, 1, Ev)
    tset(tbl, 2, 1 - Xv)
    tset(tbl, 3, u)
    tset(tbl, 4, Xv)
    return (42, tbl, B, Pv, Av, y)


@method('L', 7)
def m_L(H, P, E, u, A, X, y, i):
    if u <= 120:
        return (200, y, 1 + lua_num(X), i, E)
    if u <= 121:
        uv = lua_num(i) - 56478
        Jv = table_create(uv)
        Bv = table_create(uv)
        zv = 1
        tbl = LT()
        tset(tbl, 2, uv)
        tset(tbl, 3, y)
        tset(tbl, 4, zv)
        tset(tbl, 5, 1 - zv)
        return (144, tbl, X, Jv, Bv)
    uv = buf_readu8(A, lua_num(X) + 3)
    Hv = (lua_num(i) - 128) * 128
    Av = (lua_num(E) - 128) * 2097152
    Jv = 16384 * (lua_num(P) - 128)
    Bv = uv % 128
    Pv = 2097152 * (uv - uv % 128) + (Jv + Bv + Av) + Hv
    return (121, y, 4 + lua_num(X), Pv, E)


@method('D', 8)
def m_D(H, P, E, u, A, X, y, i, J):
    if J <= 127:
        Jv = buf_readu8(A, lua_num(E) + 1)
        return ((86 if 128 > Jv else 227), i, Jv, X)
    Ev = buf_readu8(A, 3 + lua_num(i))
    Hv = (lua_num(X) - 128) * 128
    Av = (lua_num(y) - 128) * 2097152
    Jv = (lua_num(P) - 128) * 16384
    Bv = Ev % 128
    Pv = (Ev - Ev % 128) * 2097152 + (Av + Hv) + (Jv + Bv)
    return (119, lua_num(i) + 4, u, Pv)


@method('W', 9)
def m_W(H, P, E, u, A, X, y, i, J, B):
    if u <= 129:
        zv = buf_readu8(J, lua_num(B) + 3)
        Sv = 128 * (lua_num(X) - 128)
        fv = 2097152 * (lua_num(E) - 128)
        Rv = (lua_num(A) - 128) * 16384
        hv = zv % 128
        Ev = (zv - zv % 128) * 2097152 + Sv + (fv + Rv + hv)
        return (15, y, lua_num(B) + 4, Ev, P, i)
    if u <= 130:
        return (164, lua_num(y) + 1, B, X, P, i)
    Ev = buf_readu32(J, B)
    uv = 4 + lua_num(B)
    Hv = Ev / 2
    if lua_mod(Ev, 2) == 0:
        return (173, y, uv, X, P, Hv)
    return (92, y, uv, X, Hv, i)



@method('hz', 7)
def m_hz(H, P, E, u, A, X, y, i):
    if P <= 225:
        Jv = buf_readu8(u, 3 + lua_num(E))
        Bv = 128 * (lua_num(A) - 128)
        zv = 2097152 * (lua_num(y) - 128)
        Sv = (lua_num(i) - 128) * 16384
        fv = Jv % 128
        yv = (Jv - Jv % 128) * 2097152 + (zv + Bv + Sv) + fv
        return (106, u, 4 + lua_num(E), yv, X)
    if P <= 226:
        Pv = buf_readu8(u, E)
        if 128 <= Pv:
            return (83, u, E, Pv, X)
        return (120, Pv, E, A, X)
    Pv = buf_readu8(u, 2 + lua_num(E))
    return ((122 if Pv >= 128 else 57), u, E, A, Pv)


@method('Hz', 8)
def m_Hz(H, P, E, u, A, X, y, i, J):
    if u <= 223:
        uv = buf_readu8(X, 3)
        Hv = (lua_num(P) - 128) * 128
        Xv = (lua_num(E) - 128) * 2097152
        Bv = (lua_num(i) - 128) * 16384
        zv = uv % 128
        Sv = 2097152 * (uv - uv % 128)
        return (237, Xv + Hv + (Bv + (zv + Sv)), 4, y)
    Hv = lua_num(y) - 128 + ((lua_num(A) - 128) * 128 + lua_num(J) * 16384)
    return (160, P, lua_num(E) + 3, Hv)


@method('yz', 9)
def m_yz(H, P, E, u, A, X, y, i, J, B):
    if B <= 220:
        if B <= 219:
            zv = buf_readu8(i, E)
            return ((61 if 128 <= zv else 82), y, E, P, zv, J)
        zv = lua_num(P) - 128 + ((lua_num(u) - 128) * 128 + 16384 * lua_num(X))
        return (202, y, lua_num(E) + 3, zv, X, J)
    if B <= 221:
        return (152, tget(y, 4), E, P, X, J)
    uv = buf_readu8(i, lua_num(A) + 1)
    return ((183 if uv < 128 else 243), y, E, P, X, uv)


@method('vz', 10)
def m_vz(H, P, E, u, A, X, y, i, J, B, z):
    if u <= 216:
        if u <= 215:
            Sv = buf_readu8(A, 1 + lua_num(y))
            return ((239 if Sv >= 128 else 87), X, J, y, Sv, P, E, z)
        Sv = buf_readu8(A, lua_num(y) + 1)
        return ((267 if Sv < 128 else 138), X, Sv, y, i, P, E, z)
    if u <= 217:
        uv = lua_num(B) + (lua_num(P) - 128) * 128
        return (119, X, J, 2 + lua_num(y), i, uv, E, z)
    Ev = buf_readu32(A, y)
    uv = lua_num(y) + 4
    Bv = 1
    tbl = LT()
    tset(tbl, 1, 1 - Bv)
    tset(tbl, 2, X)
    tset(tbl, 4, Bv)
    tset(tbl, 5, Ev)
    return (67, tbl, J, uv, i, P, 1, LT())


@method('sz', 7)
def m_sz(H, P, E, u, A, X, y, i):
    if i <= 203:
        if i <= 202:
            Jv = lua_num(A) - 56478
            Bv = table_create(Jv)
            zv = table_create(Jv)
            Sv = 1
            tbl = LT()
            tset(tbl, 2, Jv)
            tset(tbl, 3, Sv)
            tset(tbl, 4, 1 - Sv)
            tset(tbl, 5, P)
            return (2, 39, tbl, E, Bv, zv, X)
        Hv = 128 * (lua_num(X) - 128) + lua_num(u)
        return (2, 252, P, lua_num(E) + 2, A, y, Hv)
    if i <= 204:
        return (1,)
    return (2, 31, P, lua_num(E) + 1, A, y, X)


@method('z', 19)
def m_z(H, P, E, u, A, X, y, i, J, B, z, S, f, R, h, x, e, _u, a, O):
    if O <= 124:
        if O <= 123:
            return (99, X, 1 + lua_num(h), i, y, S)
        bv = buf_readu8(X, 3 + lua_num(h))
        lv = 128 * (lua_num(S) - 128)
        Gv = (lua_num(P) - 128) * 2097152
        wv = (lua_num(B) - 128) * 16384
        Lv = bv % 128
        gv = Gv + 2097152 * (bv - bv % 128) + lv + wv + Lv
        return (202, X, 4 + lua_num(h), i, y, gv)
    if O <= 125:
        Ov, bv, lv = tget(x, 1), tget(x, 4), tget(x, 2)
        Gv = lua_num(Ov) + lua_num(bv)
        wv = lua_num(bv) <= 0
        b2 = Gv >= lua_num(lv)
        O2 = Gv <= lua_num(lv)
        lv2 = b2 if wv else O2
        tset(x, 1, Gv)
        if truthy(lv2):
            return (253, X, h, i, Gv, S)
        return (71, X, h, i, y, S)
    Xv = LT()
    tset(A, -2, J)
    tset(B, -2, P)
    tset(A, -1, Xv)
    tset(B, -1, Xv)
    setmetatable(A, h)
    setmetatable(B, h)
    PROTO_TABLES.append(('z', A, B))
    fn = H.slot[a] if isinstance(a, (int, float)) else H.fget(a)
    res = fn(H, J, P, R, A, S, z, i, _u, E, f, B, u)
    if isinstance(res, tuple):
        res = res[0] if res else None
    return (204, y, e, res, y, S)



@method('n', 12)
def m_n(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if y <= 57:
        if y <= 56:
            Rv, hv, xv = tget(B, 5), tget(B, 4), tget(B, 1)
            ev = lua_num(Rv) + lua_num(hv)
            _v = lua_num(hv) <= 0
            h2 = ev >= lua_num(xv)
            R2 = ev <= lua_num(xv)
            xv2 = h2 if _v else R2
            tset(B, 5, ev)
            if truthy(xv2):
                return (234, S, z, E, f, P, ev)
            return (22, S, z, E, f, P, J)
        Bv = lua_num(P) - 128 + ((lua_num(u) - 128) * 128 + 16384 * lua_num(A))
        return (121, lua_num(S) + 3, z, E, f, Bv, J)
    if y <= 58:
        return (226, lua_num(S) + 1, z, E, f, P, J)
    if y <= 59:
        uv = buf_readu8(X, 2)
        return ((162 if 128 > uv else 223), S, z, E, uv, P, J)
    Hv = lua_num(z) - 128
    uv = (lua_num(f) - 128) * 128
    return (74, S, Hv + 16384 * lua_num(i) + uv, 3 + lua_num(E), f, P, J)


@method('R', 11)
def m_R(H, P, E, u, A, X, y, i, J, B, z, S):
    if z <= 62:
        if z <= 61:
            fv = buf_readu8(i, 1 + lua_num(B))
            return ((269 if fv >= 128 else 28), E, S, P, fv, y)
        Bv = buf_readu8(i, S)
        return ((199 if Bv < 128 else 0), E, S, P, X, Bv)
    if z <= 63:
        Hv = lua_num(P) - 128
        iv = (lua_num(J) - 128) * 128
        Jv = Hv + (16384 * lua_num(A) + iv)
        return (65, E, lua_num(S) + 3, Jv, X, y)
    return (161, tget(E, 3), u, P, S, y)


@method('k', 5)
def m_k(H, P, E, u, A, X):
    if X <= 65:
        Xv = buf_readu8(u, P)
        return ((10 if 128 <= Xv else 136), Xv, A)
    Av = buf_readu8(u, 2 + lua_num(P))
    return ((248 if Av >= 128 else 35), E, Av)


@method('J', 8)
def m_J(H, H2, P, E, u, A, X, y, i):
    if A <= 141:
        Av = lua_num(P) - 128
        return (200, (lua_num(H2) - 128) * 128 + 16384 * lua_num(i) + Av,
                lua_num(u) + 3, X)
    Hv = lua_num(X) - 128
    Pv = 128 * (lua_num(E) - 128)
    Ev = 16384 * lua_num(y) + Pv + Hv
    return (176, i, lua_num(u) + 3, Ev)


@method('G', 8)
def m_G(H, P, E, u, A, X, y, i, J):
    if P <= 143:
        Pv = buf_readu8(E, lua_num(J) + 3)
        Hv = 128 * (lua_num(A) - 128)
        Ev = 2097152 * (lua_num(y) - 128)
        Bv = 16384 * (lua_num(X) - 128)
        zv = Pv % 128
        Xv = Bv + (2097152 * (Pv - Pv % 128) + Hv) + (Ev + zv)
        return (134, lua_num(J) + 4, Xv, i)
    Hv, Pv, Ev = tget(u, 5), tget(u, 4), tget(u, 2)
    Xv = lua_num(Hv) + lua_num(Pv)
    yv = lua_num(Pv) <= 0
    P2 = Xv >= lua_num(Ev)
    H2 = Xv <= lua_num(Ev)
    Ev2 = P2 if yv else H2
    tset(u, 5, Xv)
    if truthy(Ev2):
        return (275, J, A, Xv)
    return (23, J, A, i)


@method('l', 12)
def m_l(H, P, E, u, A, X, y, i, J, B, z, S, f):
    if u <= 146:
        if u <= 145:
            Rv = lua_num(P) + 128 * (lua_num(f) - 128)
            return (271, B, 2 + lua_num(A), Rv, i, E)
        Pv = buf_readu8(J, lua_num(y) + 1)
        return ((100 if 128 > Pv else 44), B, A, f, i, Pv)
    if u <= 147:
        Pv = buf_readu8(J, 3 + lua_num(A))
        Hv = 128 * (lua_num(B) - 128)
        uv = (lua_num(S) - 128) * 2097152
        yv = (lua_num(X) - 128) * 16384
        Jv = Pv % 128
        return (74, uv + (2097152 * (Pv - Pv % 128) + Jv + (Hv + yv)),
                4 + lua_num(A), f, i, E)
    Hv = lua_num(z) + 128 * (lua_num(i) - 128)
    return (160, B, lua_num(A) + 2, f, Hv, E)


@method('x', 11)
def m_x(H, P, E, u, A, X, y, i, J, B, z, S):
    if J <= 150:
        if J <= 149:
            tset(z, B, u)
            return (42, i, X, A, u, E, y)
        Bv = lua_num(P) + (lua_num(A) - 128) * 128
        return (134, i, lua_num(X) + 2, Bv, u, E, y)
    if J <= 151:
        Pv = lua_num(u) - 56478
        Jv = table_create(Pv)
        Bv = table_create(Pv)
        zv = 1
        tbl = LT()
        tset(tbl, 1, Pv)
        tset(tbl, 3, i)
        tset(tbl, 4, zv)
        tset(tbl, 5, 1 - zv)
        return (56, tbl, X, A, Jv, Bv, y)
    Pv = buf_readu8(S, X)
    return ((20 if 128 > Pv else 146), i, X, A, u, E, Pv)


@method('r', 8)
def m_r(H, P, E, u, A, X, y, i, J):
    if X <= 159:
        if X <= 158:
            Bv = (lua_num(A) - 128) * 128 + lua_num(y)
            return (155, lua_num(J) + 2, Bv, y, P, i)
        Bv = 128 * (lua_num(y) - 128) + lua_num(u)
        return (190, lua_num(J) + 2, A, Bv, P, i)
    if X <= 160:
        uv = buf_readu8(E, J)
        return ((222 if uv >= 128 else 133), J, A, y, P, uv)
    return (67, J, A, y, lua_num(P) + 1, i)


@method('A', 7)
def m_A(H, H2, P, E, u, A, X, y):
    if X <= 162:
        Xv = lua_num(y) - 128
        iv = 128 * (lua_num(H2) - 128)
        Jv = lua_num(u) * 16384
        return (237, A, Jv + (Xv + iv), 3, E)
    uv = lua_num(P) + 128 * (lua_num(E) - 128)
    return (98, lua_num(A) + 2, y, H2, uv)



@method('Yz', 9)
def m_Yz(H, P, E, u, A, X, y, i, J, B):
    if A <= 208:
        zv, Sv, fv = tget(P, 1), tget(P, 3), tget(P, 2)
        Rv = lua_num(zv) + lua_num(Sv)
        hv = lua_num(Sv) <= 0
        z2 = Rv >= lua_num(fv)
        S2 = Rv <= lua_num(fv)
        fv2 = z2 if hv else S2
        tset(P, 1, Rv)
        if truthy(fv2):
            return (181, Rv, E, B)
        return (50, u, E, B)
    if A <= 209:
        Pv = buf_readu8(y, lua_num(u) + 3)
        Av = (lua_num(E) - 128) * 128
        zv = 2097152 * (lua_num(J) - 128)
        Sv = (lua_num(X) - 128) * 16384
        Xv = Pv % 128 + 2097152 * (Pv - Pv % 128) + (Sv + Av) + zv
        return (190, lua_num(u) + 4, Xv, B)
    Pv = buf_readu8(y, 1 + lua_num(i))
    return ((55 if Pv < 128 else 4), u, E, Pv)


if __name__ == '__main__':
    sys.exit(0 if main() is None else 1)
