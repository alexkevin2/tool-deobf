#!/usr/bin/env python3
"""merge_protos.py — assemble protos.json from eager.py table shards.

Reads protos_shard0.json .. protos_shard3.json (written by eager.py
runs with EAGER_TABLE=<i>) and writes protos.json in exactly the
monolithic format: {'root', 'proto_groups': [{'kind', 'tables'}],
'fn_calls', 'total_ops_after_eager'}. fn_calls is summed across
shards (each shard re-runs the build, so this over-counts build
calls vs. a monolithic run — the field is informational only; no
pipeline stage consumes it). total_ops_after_eager is the max shard
value (the op count is dominated by the shared build prefix).
"""
import json
import os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))

shards = []
for i in range(4):
    with open(os.path.join(HERE, f'protos_shard{i}.json')) as f:
        shards.append(json.load(f))
assert [s['table_index'] for s in shards] == [0, 1, 2, 3]

fn_calls = Counter()
for s in shards:
    fn_calls.update({k: v for k, v in s['fn_calls'].items()})

out = {
    'root': shards[0]['root'],
    'proto_groups': [{'kind': shards[0]['kind'],
                      'tables': [s['table'] for s in shards]}],
    'fn_calls': fn_calls,
    'total_ops_after_eager': max(s['total_ops_after_eager'] for s in shards),
}
with open(os.path.join(HERE, 'protos.json'), 'w') as f:
    json.dump(out, f, indent=1, default=str)
tot_mat = sum(len(s['table']['materialized']) for s in shards)
tot_err = sum(len(s['table']['errors']) for s in shards)
print(f'wrote protos.json from 4 shards: materialized={tot_mat} '
      f'errors={tot_err}')
