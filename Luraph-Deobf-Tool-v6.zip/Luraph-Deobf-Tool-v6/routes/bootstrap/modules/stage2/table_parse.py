#!/usr/bin/env python3
"""table_parse.py — stage-2 phase A, task 2 (support).

Parses the VM table literal at the head of the raw file
(`return setmetatable({...}, {...})`) token by token, so every entry
(numeric slot or named field) is classified authoritatively:
kind (function / dotted / string / number / table / other), source
span and size.  Writes table_map.json and prints a summary.
This replaces the regex slot map in analysis/, whose `[n]=dotted`
matches also fire inside the blob text.
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.environ.get('BVM_RAW') or sys.exit(
    'table_parse.py: BVM_RAW env var (input .luau path) is not set')

TOKEN = re.compile(r"""
    (?P<str>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\[(=*)\[(?:(?!\]\2\]).)*\]\2\])
  | (?P<word>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<num>\d+(?:\.\d+)?)
  | (?P<other>.)
""", re.S | re.X)


def tokens(s):
    for m in TOKEN.finditer(s):
        if m.group('str') is not None:
            yield ('str', m.group(0), m.start(), m.end())
        elif m.group('word') is not None:
            yield ('word', m.group(0), m.start(), m.end())
        elif m.group('num') is not None:
            yield ('num', m.group(0), m.start(), m.end())
        else:
            yield ('other', m.group(0), m.start(), m.end())


EXPR_PREV = {'=', '==', '~=', '<', '>', '<=', '>=', '+', '-', '*', '/',
             '%', '^', '..', ',', '(', '[', '{', ':', 'return', 'and',
             'or', 'not'}


def func_end(toks, i):
    """toks[i] is 'function'; return token index just past its 'end'.

    Luau if-EXPRESSIONS (`x = if c then a else b`) have no 'end', so
    block matching needs to know each if's kind:
      - prev token is an expression introducer (EXPR_PREV) -> expr
      - prev token is 'then'/'else' -> inherits the kind of the
        nearest enclosing if (those branches hold expressions iff
        the owner is an expression)
      - otherwise -> statement
    'end' closes one real block, discarding any ifexpr markers that
    sit on top of it."""
    stack = ['function']
    prev = 'function'
    j = i + 1
    while j < len(toks):
        k, t = toks[j][0], toks[j][1]
        if k == 'word':
            if t in ('while', 'for'):
                stack.append(t)
            elif t == 'do':
                if stack and stack[-1] in ('while', 'for'):
                    stack[-1] = stack[-1] + '+do'
                else:
                    stack.append('do')
            elif t == 'function':
                stack.append('function')
            elif t == 'repeat':
                stack.append('repeat')
            elif t == 'if':
                if prev in EXPR_PREV:
                    stack.append('ifexpr')
                elif prev in ('then', 'else'):
                    kind = 'if'
                    for e in reversed(stack):
                        if e in ('if', 'ifexpr'):
                            kind = e
                            break
                        if e in ('function', 'while', 'for', 'do', 'repeat',
                                 'while+do', 'for+do'):
                            break
                    stack.append(kind)
                else:
                    stack.append('if')
            elif t == 'until':
                while stack and stack[-1] != 'repeat':
                    stack.pop()
                if not stack:
                    raise ValueError('orphan until')
                stack.pop()
            elif t == 'end':
                while stack:
                    e = stack.pop()
                    if e == 'ifexpr':
                        continue
                    break
                if not stack:
                    return j + 1
        if t.strip():
            prev = t
        j += 1
    raise ValueError('unterminated function')


def brace_end(toks, i):
    """toks[i] is '{'; return token index just past its '}'."""
    depth = 0
    j = i
    while j < len(toks):
        k, t = toks[j][0], toks[j][1]
        if k == 'word' and t == 'function':
            j = func_end(toks, j)
            continue
        if k == 'other' and t == '{':
            depth += 1
        elif k == 'other' and t == '}':
            depth -= 1
            if depth == 0:
                return j + 1
        j += 1
    raise ValueError('unterminated table')


def main():
    s = open(RAW, encoding='utf-8', errors='surrogateescape').read()
    # strip the leading comment line so its words can't confuse parsing
    nl = s.index('\n')
    base = nl + 1
    body = s[base:]
    toks = list(tokens(body))
    # locate: setmetatable ( {  -> table open token index
    ti = None
    for i in range(len(toks) - 2):
        if toks[i][1] == 'setmetatable' and toks[i + 1][1] == '(' and toks[i + 2][1] == '{':
            ti = i + 2
            break
    assert ti is not None
    tend = brace_end(toks, ti)
    print(f"table literal: tokens {ti}..{tend}, chars "
          f"{toks[ti][2] + base}..{toks[tend - 1][3] + base}")

    entries = []
    i = ti + 1
    pos = 0
    while i < tend - 1:
        if toks[i][1] == ',':
            i += 1
            continue
        start = i
        key = None
        # [num] =  |  name =  |  positional
        if toks[i][1] == '[' and toks[i + 1][0] == 'num' and toks[i + 2][1] == ']' and toks[i + 3][1] == '=':
            key = ('slot', int(toks[i + 1][1])); i += 4
        elif toks[i][0] == 'word' and toks[i + 1][1] == '=':
            key = ('field', toks[i][1]); i += 2
        else:
            pos += 1
            key = ('pos', pos)
        # value span
        vstart = i
        k0, t0 = toks[i][0], toks[i][1]
        if k0 == 'word' and t0 == 'function':
            try:
                i = func_end(toks, i)
            except ValueError:
                print('FUNC_END FAIL: key', key, 'char', toks[vstart][2] + base)
                print(repr(body[toks[vstart][2]:toks[vstart][2] + 400]))
                raise
            kind = 'function'
        elif k0 == 'other' and t0 == '{':
            i = brace_end(toks, i)
            kind = 'table'
        else:
            # scalar expression: consume until top-level ',' or table end,
            # tracking parens/brackets/braces and function blocks
            depth = 0
            while i < tend - 1:
                k, t = toks[i][0], toks[i][1]
                if k == 'word' and t == 'function':
                    i = func_end(toks, i)
                    continue
                if k == 'other' and t in '({[':
                    depth += 1
                elif k == 'other' and t in ')}]':
                    if depth == 0:
                        break
                    depth -= 1
                elif k == 'other' and t == ',' and depth == 0:
                    break
                i += 1
            text = body[toks[vstart][2]:toks[i - 1][3]] if i > vstart else ''
            if k0 == 'str':
                kind = 'string'
            elif re.fullmatch(r'[A-Za-z_][\w.]*', text.strip()):
                kind = 'dotted'
            elif re.fullmatch(r'-?[\d.]+', text.strip()):
                kind = 'number'
            else:
                kind = 'expr'
            entries[-0:]  # noop
            entries.append({'key_type': key[0], 'key': key[1], 'kind': kind,
                            'start': toks[vstart][2] + base,
                            'end': toks[i - 1][3] + base,
                            'text': text[:120]})
            continue
        vend = i - 1
        entries.append({'key_type': key[0], 'key': key[1], 'kind': kind,
                        'start': toks[vstart][2] + base,
                        'end': toks[vend][3] + base,
                        'text': body[toks[vstart][2]:min(toks[vstart][2] + 60, toks[vend][3])]})

    with open(os.path.join(HERE, 'table_map.json'), 'w') as f:
        json.dump({'table_span': [toks[ti][2] + base, toks[tend - 1][3] + base],
                   'entries': entries}, f, indent=1)
    from collections import Counter
    print('entries:', len(entries), Counter(e['kind'] for e in entries))
    funcs = [e for e in entries if e['kind'] == 'function']
    print('function entries:', len(funcs))
    named = [e for e in entries if e['key_type'] == 'field']
    print('named fields:', [e['key'] for e in named])


if __name__ == '__main__':
    main()
