#!/usr/bin/env python3
"""disasm.py — phase C1, task 3: disassemble the root proto.

Walks the root proto as the slot-15209 inner interpreter executes
it, across the two modes the root actually enters:

- mode 114 (loop A): entry pc = R = 10314. Opcode HY = y[P];
  operands a=i[P], b=S[P], c=f[P]; constants K0..K3 = E/z/X/B[P]
  (materialized). Default next pc = P+1; jump handlers set P and
  the loop tail adds 1 (static targets = operand+1).
- mode 49 (loop B): entered from loop A op 63 (SWITCHMODE:
  u=S[P], P=f[P], break — the break skips the tail increment, so
  loop B starts AT pc f[P]). Opcode A = i[P]; same streams, same
  register file, same seed locals V (init factory P[2]) and L
  (init factory P[1]).

Execution is a DFS over paths with state snapshots at branches:
each path carries the four raw streams, the chunk bytes, the field
table, a symbolic register file (ints where statically known), V/L.
Self-decrypting ops are simulated in place along the path:
DECRYPTSTR rewrites a chunk string + its field header + its own
slot; DECRYPTBLOCK rolling-XORs a forward slot range in all four
streams and rewrites its own opcode (23 in loop A, 15 in loop B);
DECRYPTINSN rewrites its own slot and is re-dispatched at the same
pc; JMPR is followed when its target register holds a known int
(the entry code loads it with LOADRAW just before — a trampoline).

Buffer #4 plays no part: the interpreter never fetches from a
buffer (only the string decryptors write J[5], the chunk).  See
STAGE2C1-REPORT.md for the evidence.

Output: root_disasm.txt + coverage summary on stdout.
"""
import ast as pyast
import json
import os
import re
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
N_SLOTS = 10385
ENTRY_A = 10314
M29 = 536870911  # 0x1FFFFFFF


def bxor(*xs):
    r = 0
    for x in xs:
        r ^= (int(x) & 0xFFFFFFFF)
    return r


def band(*xs):
    r = 0xFFFFFFFF
    for x in xs:
        r &= (int(x) & 0xFFFFFFFF)
    return r


def rshift(x, n):
    return (int(x) & 0xFFFFFFFF) >> n


def lshift(x, n):
    return ((int(x) & 0xFFFFFFFF) << n) & 0xFFFFFFFF


def word29(base):
    """band(bxor(base, band(rshift(base,29),7)), 2^29-1)"""
    return band(bxor(base, band(rshift(base, 29), 7)), M29)


def split_word(base):
    """bxor(base, band(rshift(base,14),262143), band(rshift(base,28),15))"""
    return bxor(base, band(rshift(base, 14), 262143), band(rshift(base, 28), 15))


def xorshift_step(state):
    state = band(bxor(state, lshift(state, 13)), M29)
    state = bxor(state, rshift(state, 13))
    state = band(bxor(state, lshift(state, 14)), M29)
    return state


def fmt_const(v):
    if v is None:
        return None
    if isinstance(v, bool):
        return repr(v)
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, dict):
        o = v.get('other')
        if isinstance(o, str) and (o.startswith("b'") or o.startswith('b"')):
            try:
                b = pyast.literal_eval(o)
                if isinstance(b, bytes):
                    return '"' + b.decode('utf-8', 'backslashreplace') \
                        .replace('\\', '\\\\').replace('"', '\\"') \
                        .replace('\n', '\\n') + '"'
            except Exception:
                pass
        return '<' + str(v)[:40] + '>'
    return repr(v)

def str_extra(s):
    """Display for a decrypted string: quoted, truncated at 96 bytes."""
    disp = fmt_const({'other': repr(s[:96])}) or '?'
    if len(s) > 96:
        disp += f' [+{len(s) - 96} more bytes, {len(s)} total]'
    return ' ; string = ' + disp


class State:
    __slots__ = ('i', 'y', 'S', 'f', 'fields', 'chunk', 'regs', 'V', 'L',
                 'V_dyn', 'L_dyn', 'written')

    def copy(self):
        s = State()
        s.i, s.y, s.S, s.f = list(self.i), list(self.y), list(self.S), list(self.f)
        s.fields = dict(self.fields)
        s.chunk = bytearray(self.chunk)
        s.regs = dict(self.regs)
        s.V, s.L, s.V_dyn, s.L_dyn = self.V, self.L, self.V_dyn, self.L_dyn
        s.written = {k: set(v) for k, v in self.written.items()}
        return s


class Dis:
    def __init__(self):
        st = json.load(open(os.path.join(HERE, 'streams.json')))
        dz = st['streams_dz_order']
        self.factory = st['factory']
        s0 = State()
        s0.i, s0.y = list(dz['e']), list(dz['A'])
        s0.S, s0.f = list(dz['P']), list(dz['y'])
        s0.fields = {int(k): v for k, v in json.load(
            open(os.path.join(HERE, 'E_fields.json'))).items()}
        s0.chunk = bytearray(open(os.path.join(CASE, 'static', 'dst.bin'), 'rb').read())
        s0.regs = {}
        s0.V, s0.L = self.factory['P2'], self.factory['P1']
        s0.V_dyn = s0.L_dyn = False
        s0.written = {k: set() for k in 'iySf'}
        self.init = s0
        pj = json.load(open(os.path.join(HERE, 'protos.json')))
        grp = pj['proto_groups'][0]
        self.mat, self.mat_err = [], []
        for t in grp['tables']:
            self.mat.append({int(k): v for k, v in t.get('materialized', {}).items()})
            self.mat_err.append(set(int(k) for k in t.get('errors', {})))
        om = json.load(open(os.path.join(HERE, 'opcode_map.json')))
        self.names = [{e['opcode']: e['name'] for e in lp['opcodes']}
                      for lp in om['loops']]
        self.bodies_b = {e['opcode']: e['body'] for e in om['loops'][1]['opcodes']}
        self.bodies_c = {e['opcode']: e['body'] for e in om['loops'][2]['opcodes']}
        self.visited = {}           # (mode, pc) -> line tuple
        self.unresolved_jmpr = {}   # (mode, pc) -> reg
        self.jmpr_followed = {}     # (mode, pc) -> set of targets
        self.hist = {'A': Counter(), 'B': Counter(), 'C': Counter()}
        self.total_written = {k: set() for k in 'iySf'}
        self.decrypted_strings = {}
        self.mode_switches = []
        self.notes = []

    # ---------- helpers ----------
    def matint(self, ti, pc):
        v = self.mat[ti].get(pc)
        return v if isinstance(v, int) and not isinstance(v, bool) else None

    def matdisp(self, ti, pc):
        if pc in self.mat_err[ti]:
            return '<mat-error>'
        return fmt_const(self.mat[ti].get(pc))

    @staticmethod
    def R(st, k):
        return st.regs.get(k)

    @staticmethod
    def setR(st, k, v):
        if v is None:
            st.regs.pop(k, None)
        else:
            st.regs[k] = v

    def kdisp(self, pc):
        ks = []
        for ti, lab in ((0, 'K0'), (1, 'K1'), (2, 'K2'), (3, 'K3')):
            v = self.matdisp(ti, pc)
            if v is not None:
                ks.append(f'{lab}={v}')
        return ks

    # ---------- decryptors ----------
    def decrypt_block(self, st, start, count, seed, lanes):
        """lanes: stream name -> bit shift of its 7-bit lane."""
        state = seed
        for k in range(count):
            slot = start + k
            if slot < 1 or slot > N_SLOTS:
                break
            state = xorshift_step(state)
            for nm, sh in lanes.items():
                stream = getattr(st, nm)
                stream[slot - 1] = bxor(stream[slot - 1], band(rshift(state, sh), 127))
                st.written[nm].add(slot)

    def decrypt_string(self, st, pc, field_idx, byte_key, patch):
        """Shared DECRYPTSTR core. patch: {stream name: new value}
        applied to the op's own slot afterwards."""
        hdr = st.fields.get(field_idx)
        if hdr is None:
            return None
        uY = bxor(hdr, 404445383)
        st.fields[field_idx] = uY
        pos = uY + 1
        data = st.chunk
        if pos < 0 or pos >= len(data):
            return None
        b0 = data[pos]
        if b0 < 128:
            length, xy = b0, pos + 1
        else:
            b1 = data[pos + 1]
            if b1 < 128:
                length, xy = (b0 - 128) * 128 + b1, pos + 2
            else:
                b2 = data[pos + 2]
                if b2 < 128:
                    length = (b0 - 128) + (b1 - 128) * 128 + b2 * 16384
                    xy = pos + 3
                else:
                    b3 = data[pos + 3]
                    length = ((b0 - 128) * 128 + (b1 - 128) * 2097152 +
                              (b2 - 128) * 16384 + b3 % 128 +
                              (b3 - b3 % 128) * 2097152)
                    xy = pos + 4
        key_word = (int(byte_key) * 16843009) & 0xFFFFFFFF
        end = xy + length
        yY = end - (length % 4)
        off = xy
        while off < yY:
            cur = int.from_bytes(data[off:off + 4], 'little')
            data[off:off + 4] = bxor(cur, key_word).to_bytes(4, 'little')
            off += 4
        kb = int(byte_key) & 0xFF
        for off in range(yY, end):
            data[off] = bxor(data[off], kb) & 0xFF
        for nm, val in patch.items():
            getattr(st, nm)[pc - 1] = val
            st.written[nm].add(pc)
        return bytes(data[xy:end])

    def decrypt_insn_a(self, st, pc, variant):
        a, b, c = st.i[pc - 1], st.S[pc - 1], st.f[pc - 1]
        if variant == 52:
            lw = split_word(st.V)
            shift = 7 if b < 2097152 else 14
            x = band(b, (1 << shift) - 1)
            F = rshift(b, shift)
            st.f[pc - 1] = bxor(c, 75, band(rshift(lw, 14), 127))
            st.i[pc - 1] = bxor(a, 125, band(rshift(lw, 7), 127))
            st.S[pc - 1] = bxor(x, 69, band(lw, 127))
            st.y[pc - 1] = bxor(F, 103, band(rshift(lw, 21), 127))
        else:
            C = split_word(st.V)
            shift = 7 if c < 16384 else (14 if c < 2097152 else 21)
            x = band(c, (1 << shift) - 1)
            F = rshift(c, shift)
            st.y[pc - 1] = bxor(F, 69, band(rshift(C, 21), 127))
            st.S[pc - 1] = bxor(b, 84, band(C, 127))
            st.i[pc - 1] = bxor(a, 18, band(rshift(C, 7), 127))
            st.f[pc - 1] = bxor(x, 31, band(rshift(C, 14), 127))
        for nm in 'iySf':
            st.written[nm].add(pc)

    def decrypt_insn_b(self, st, pc, variant):
        yv, sv, fv, iv = st.y[pc - 1], st.S[pc - 1], st.f[pc - 1], st.i[pc - 1]
        g = split_word(st.L)
        if variant == 18:
            # C,_,g,l = y[P], S[P], split(L), f[P]; split l at 7/14
            shift = 7 if fv < 2097152 else 14
            x = band(fv, (1 << shift) - 1)
            F = rshift(fv, shift)
            st.i[pc - 1] = bxor(F, 38, band(rshift(g, 21), 127))
            st.f[pc - 1] = bxor(x, 107, band(g, 127))
            st.S[pc - 1] = bxor(sv, 42, band(rshift(g, 7), 127))
            st.y[pc - 1] = bxor(yv, 87, band(rshift(g, 14), 127))
        else:
            # C,_,g,l = f[P], S[P], y[P], split(L); split g=y[P] at 7/14/21
            shift = 7 if yv < 16384 else (14 if yv < 2097152 else 21)
            x = band(yv, (1 << shift) - 1)
            F = rshift(yv, shift)
            st.f[pc - 1] = bxor(fv, 18, band(g, 127))
            st.S[pc - 1] = bxor(sv, 19, band(rshift(g, 7), 127))
            st.i[pc - 1] = bxor(F, 57, band(rshift(g, 21), 127))
            st.y[pc - 1] = bxor(x, 85, band(rshift(g, 14), 127))
        for nm in 'iySf':
            st.written[nm].add(pc)

    # ---------- loop A register effects ----------
    def reg_effects_a(self, st, op, pc, a, b, c):
        R = lambda k: self.R(st, k)
        if op == 1:
            self.setR(st, a, R(b)); self.setR(st, a + 1, R(c))
        elif op == 2:
            self.setR(st, c, None)
        elif op == 4:
            self.setR(st, c, b)
        elif op == 6:
            self.setR(st, a, None if R(c) is None or R(b) is None else R(c) - R(b))
        elif op == 19:
            self.setR(st, c, None if R(b) is None else a + R(b))
        elif op == 25:
            self.setR(st, a, None if R(c) is None else R(c) - b)
        elif op == 29:
            self.setR(st, a, None if st.V_dyn else st.V)
        elif op == 30:
            k0 = self.matint(0, pc)
            self.setR(st, c, None if R(b) is None or k0 is None else R(b) - k0)
        elif op == 34:
            self.setR(st, c, None if R(a) is None or b == 0 else R(a) // b)
        elif op == 37:
            self.setR(st, a, None if st.L_dyn else st.L)
        elif op == 39:
            v = R(a)
            self.setR(st, c, None if v is None else int(v % 4294967296))
        elif op == 40:
            self.setR(st, c, b); self.setR(st, c + 1, R(a))
        elif op == 43:
            k3 = self.matint(3, pc)
            self.setR(st, b, None if R(a) is None or k3 is None else R(a) + k3)
        elif op == 44:
            self.setR(st, b, None if R(a) is None else c * R(a))
        elif op == 47:
            k3 = self.matint(3, pc)
            v = R(b)
            self.setR(st, a, None if v is None or k3 is None else bxor(v, k3))
        elif op == 50:
            v, w = R(c), R(a)
            self.setR(st, b, None if v is None or w is None else bxor(v, w))
        elif op == 54:
            k2, k3 = self.matint(2, pc), self.matint(3, pc)
            self.setR(st, a, None if k2 is None or k3 is None else bxor(k3, k2))
        elif op == 55:
            k0 = self.matint(0, pc)
            v = R(c)
            self.setR(st, b, None if v is None or k0 is None else v * k0)
        elif op == 56:
            v, w = R(a), R(b)
            self.setR(st, c, None if v is None or w is None else band(v, w))
        elif op == 58:
            v, w = R(c), R(a)
            self.setR(st, b, None if v is None or w is None or w == 0 else v // w)
        elif op == 60:
            v = R(c)
            self.setR(st, a, None if v is None or b == 0 else v % b)
        elif op == 62:
            v = R(c)
            if v is None:
                st.L_dyn = True
            else:
                st.L, st.L_dyn = v, False
        elif op == 68:
            self.setR(st, c, R(b))
        elif op == 69:
            v = R(c)
            self.setR(st, b, None if v is None else bxor(v, a))
        elif op == 71:
            v, w = R(a), R(c)
            self.setR(st, b, None if v is None or w is None else v + w)
        elif op == 72:
            v = R(c)
            self.setR(st, b, None if v is None else v + a)
        elif op == 76:
            self.setR(st, b, self.matint(0, pc))
        elif op == 78:
            v = R(c)
            self.setR(st, a, None if v is None else v * b)
        elif op == 0:
            v = R(b)
            self.setR(st, c, None if v is None else lshift(v, a))
        elif op == 11:
            v, w = R(a), R(c)
            self.setR(st, b, None if v is None or w is None else v | w)
        elif op == 45:
            v = R(c)
            self.setR(st, b, None if v is None else band(v, a))
        elif op == 14:
            v = R(c)
            if v is None:
                st.V_dyn = True
            else:
                st.V, st.V_dyn = v, False
        elif op in (5, 8, 10, 13, 18, 48, 49, 59, 61, 75, 77):
            dest = {5: a, 8: c, 10: c, 13: a, 18: b, 48: c, 49: c,
                    59: c, 61: b, 75: a, 77: c}[op]
            self.setR(st, dest, None)
        elif op in (20, 28, 33):
            st.regs.clear()
        elif op == 51:
            for k in range(b, b + max(a, c) + 1):
                self.setR(st, k, None)
        elif op == 31:
            self.setR(st, b, None)

    # ---------- loop B register effects (subset + dest poison) ----------
    _DEST_RE = re.compile(r'n\[((?:[^\[\]]|\[[^\]]*\])+)\]\s*=(?!=)')

    def reg_effects_b(self, st, op, pc):
        yv, sv, fv = st.y[pc - 1], st.S[pc - 1], st.f[pc - 1]
        R = lambda k: self.R(st, k)
        precise = True
        if op == 17:      # V = n[y[P]]
            v = R(yv)
            if v is None:
                st.V_dyn = True
            else:
                st.V, st.V_dyn = v, False
        elif op == 43:    # L = n[y[P]]
            v = R(yv)
            if v is None:
                st.L_dyn = True
            else:
                st.L, st.L_dyn = v, False
        elif op == 51:    # n[S[P]] = L
            self.setR(st, sv, None if st.L_dyn else st.L)
        elif op == 8:     # LOADRAW: n[S[P]] = f[P]
            self.setR(st, sv, fv)
        elif op == 23:    # ADD_RR: n[S] = n[y] + n[f]
            v, w = R(yv), R(fv)
            self.setR(st, sv, None if v is None or w is None else v + w)
        elif op == 40:    # SUB_RR: n[f] = n[y] - n[S]
            v, w = R(yv), R(sv)
            self.setR(st, fv, None if v is None or w is None else v - w)
        elif op == 46:    # ADD_RI: n[S] = f + n[y]
            v = R(yv)
            self.setR(st, sv, None if v is None else fv + v)
        elif op == 58:    # SUB_RI: n[f] = n[y] - S
            v = R(yv)
            self.setR(st, fv, None if v is None else v - sv)
        elif op in (61, 67):  # n[f] = n[y] -/+ X[P] (materialized)
            k2 = self.matint(2, pc)
            v = R(yv)
            self.setR(st, fv, None if v is None or k2 is None
                      else (v - k2 if op == 61 else v + k2))
        elif op == 28:    # TOINT n[f] = toint(n[y])
            v = R(yv)
            self.setR(st, fv, None if v is None else int(v % 4294967296))
        elif op in (9, 10):  # MUL32 -> n[S]
            v, w = R(yv), R(fv)
            self.setR(st, sv, None if v is None or w is None else (v * w) & 0xFFFFFFFF)
        elif op == 66:    # C=f; n[C],n[C+1] = n[S], n[y]
            self.setR(st, fv, R(sv)); self.setR(st, fv + 1, R(yv))
        elif op == 73:    # block: n[S] = V
            self.setR(st, sv, None if st.V_dyn else st.V)
        elif op == 75:    # block: n[S] = B[P] materialized
            self.setR(st, sv, self.matint(3, pc))
        elif op == 79:    # block: n[S] = n[f] + y
            v = R(fv)
            self.setR(st, sv, None if v is None else v + yv)
        elif op == 72:    # block: n[y] = band(n[S], f)
            v = R(sv)
            self.setR(st, yv, None if v is None else band(v, fv))
        elif op == 80:    # block: n[S] = band(n[f], n[y])
            v, w = R(fv), R(yv)
            self.setR(st, sv, None if v is None or w is None else band(v, w))
        else:
            precise = False
        if not precise:
            # poison destination registers whose index is a plain
            # stream ref at this pc (sound for JMPR resolution)
            body = self.bodies_b.get(op, '')
            vals = {'y[P]': yv, 'S[P]': sv, 'f[P]': fv, 'i[P]': st.i[pc - 1]}
            for m in self._DEST_RE.finditer(body):
                idx = m.group(1)
                if idx in vals:
                    self.setR(st, vals[idx], None)
                elif idx.isdigit():
                    self.setR(st, int(idx), None)

    # ---------- per-mode step ----------
    def emit(self, mode, pc, op, a, b, c, extra):
        key = (mode, pc)
        if key in self.visited:
            return
        names = self.names[0] if mode == 'A' else self.names[1]
        name = names.get(op, 'UNKNOWN')
        if mode == 'A' and op >= 80:
            name = 'MUL_RK (catch-all >=80)'
        if mode == 'B' and op >= 93:
            name = names.get(91, 'EQ_RI') + ' (catch-all >=93)'
        self.visited[key] = (name, a, b, c, extra, self.kdisp(pc))
        self.hist[mode][op] += 1

    def run(self):
        stack = [('A', ENTRY_A, self.init)]
        steps = 0
        while stack:
            mode, pc, st = stack.pop()
            while True:
                steps += 1
                if steps > 400000:
                    self.notes.append('walk step cap reached')
                    return
                if pc < 1 or pc > N_SLOTS:
                    self.notes.append(f'[{mode}] path left stream range at pc {pc}')
                    break
                key = (mode, pc)
                first = key not in self.visited
                if not first:
                    opc = {'A': st.y, 'B': st.i, 'C': st.f}[mode][pc - 1]
                    jmpr_op = {'A': 9, 'B': 57, 'C': 128}[mode]
                    if opc == jmpr_op:
                        cc = st.i[pc - 1] if mode == 'C' else st.f[pc - 1]
                        tgt = self.R(st, cc)
                        done = self.jmpr_followed.get(key, set())
                        if tgt is not None and tgt + 1 not in done and len(done) < 64:
                            pass
                        else:
                            break
                    elif key in self.unresolved_jmpr:
                        pass
                    else:
                        break
                if mode == 'A':
                    nxt = self.step_a(pc, st, stack, first)
                elif mode == 'B':
                    nxt = self.step_b(pc, st, stack, first)
                else:
                    nxt = self.step_c(pc, st, stack, first)
                if nxt is None:
                    break
                mode, pc = nxt
        return

    def step_a(self, pc, st, stack, first):
        """Returns (mode, next_pc) or None to end this path."""
        op = st.y[pc - 1]
        a, b, c = st.i[pc - 1], st.S[pc - 1], st.f[pc - 1]
        if op is None:
            if first:
                self.visited[('A', pc)] = ('<nil opcode>', f'a={a} b={b} c={c}', '', [])
            return None
        orig = op
        extra = ''
        succ = None
        switch = None
        for _try in range(4):
            if op in (26, 32, 79):
                if op == 26:
                    seed = None if st.V_dyn else bxor(a, word29(st.V))
                    start, count = b + 1, c
                elif op == 32:
                    seed, start, count = b, c + 1, a
                else:
                    seed = None if st.L_dyn else bxor(a, word29(st.L))
                    start, count = b + 1, c
                if seed is None:
                    extra += ' ; SEED DYNAMIC — region left encrypted'
                else:
                    self.decrypt_block(st, start, count, seed,
                                       {'S': 0, 'i': 7, 'f': 14, 'y': 21})
                    st.y[pc - 1] = 23
                    st.written['y'].add(pc)
                    extra += f' ; decrypts slots {start}..{start + count - 1}'
                succ = [pc + 1]
                break
            if op in (12, 41, 66):
                if op == 12:
                    bkey, patch, ok = c, {'S': 56, 'i': 122, 'f': 172, 'y': 23}, True
                elif op == 41:
                    bkey = None if st.V_dyn else bxor(a, word29(st.V))
                    patch, ok = {'S': 57, 'i': 166, 'f': 98, 'y': 23}, bkey is not None
                else:
                    bkey = None if st.L_dyn else bxor(a, word29(st.L))
                    patch, ok = {'S': 165, 'i': 186, 'f': 245, 'y': 23}, bkey is not None
                if not ok:
                    extra += ' ; SEED DYNAMIC — string left encrypted'
                else:
                    s = self.decrypt_string(st, pc, b, bkey, patch)
                    if s is None:
                        extra += ' ; string header/field missing'
                    else:
                        self.decrypted_strings[('A', pc)] = s
                        extra += str_extra(s)
                succ = [pc + 1]
                break
            if op in (52, 64):
                if st.V_dyn:
                    extra += ' ; SEED DYNAMIC (V) — slot left encrypted'
                    succ = [pc + 1]
                    break
                self.decrypt_insn_a(st, pc, op)
                nop = st.y[pc - 1]
                extra += (f' ; slot decrypted in place -> op {nop} '
                          f'({self.names[0].get(nop, "UNKNOWN")}); re-dispatched')
                op = nop
                a, b, c = st.i[pc - 1], st.S[pc - 1], st.f[pc - 1]
                continue
            break
        if succ is None:
            self.reg_effects_a(st, op, pc, a, b, c)
            if op in (24, 65):
                succ = []
                extra += ' ; return'
            elif op == 63:
                succ = []
                switch = ('B', c, b)
                extra += f' ; SWITCHMODE to mode {b}, loop B starts at pc {c}'
            elif op == 9:
                tgt = self.R(st, c)
                if tgt is not None:
                    succ = [tgt + 1]
                    extra += f' ; pc = R({c})+1 = {tgt + 1} (known)'
                    self.unresolved_jmpr.pop(('A', pc), None)
                    self.jmpr_followed.setdefault(('A', pc), set()).add(tgt + 1)
                else:
                    succ = []
                    extra += f' ; pc = R({c}) + 1 — register unknown here, path ends'
                    if first:
                        self.unresolved_jmpr[('A', pc)] = c
            elif op == 27:
                succ = [c + 1]
                extra += f' ; jump to {c + 1}'
            elif op in (3, 35, 46, 53, 73):
                t = {3: a, 35: b, 46: c, 53: b, 73: b}[op]
                succ = [pc + 1, t + 1]
                extra += f' ; branch: fall {pc + 1} / jump {t + 1}'
            elif op in (57, 70):
                succ = [c + 1, b + 1]
                extra += f' ; branch: true {c + 1} / false {b + 1}'
            else:
                succ = [pc + 1]
        if first:
            nm = self.names[0].get(orig, 'UNKNOWN')
            if orig >= 80:
                nm = 'MUL_RK (catch-all >=80)'
            elif op != orig and orig in (52, 64):
                nm += f' (-> {self.names[0].get(op, "UNKNOWN")})'
            self.visited[('A', pc)] = (nm, f'a={a} b={b} c={c}', extra, self.kdisp(pc))
            self.hist['A'][orig] += 1
            for nm2 in 'iySf':
                self.total_written[nm2] |= st.written[nm2]
        if switch is not None:
            mode_b, entry_b, mode_no = switch
            self.mode_switches.append(('A', pc, mode_no, entry_b))
            stack.append((mode_b, entry_b, st))
            return None
        if not succ:
            return None
        for alt in succ[1:]:
            stack.append(('A', alt, st.copy()))
        return ('A', succ[0])

    def step_b(self, pc, st, stack, first):
        op = st.i[pc - 1]
        yv, sv, fv = st.y[pc - 1], st.S[pc - 1], st.f[pc - 1]
        if op is None:
            if first:
                self.visited[('B', pc)] = ('<nil opcode>', f'op={st.i[pc - 1]} y={yv} S={sv} f={fv}', '', [])
            return None
        orig = op
        extra = ''
        succ = None
        switch = None
        for _try in range(4):
            if op in (24, 63, 81):
                if op == 24:
                    seed = None if st.L_dyn else bxor(sv, word29(st.L))
                    start, count = fv + 1, yv
                elif op == 63:
                    seed = None if st.V_dyn else bxor(sv, word29(st.V))
                    start, count = fv + 1, yv
                else:
                    seed, start, count = fv, sv + 1, yv
                if seed is None:
                    extra += ' ; SEED DYNAMIC — region left encrypted'
                else:
                    self.decrypt_block(st, start, count, seed,
                                       {'f': 0, 'S': 7, 'y': 14, 'i': 21})
                    extra += f' ; decrypts slots {start}..{start + count - 1}'
                st.i[pc - 1] = 15
                st.written['i'].add(pc)
                succ = [pc + 1]
                break
            if op in (37, 55, 78):
                if op == 37:
                    bkey = None if st.L_dyn else bxor(sv, word29(st.L))
                    patch = {'f': 128, 'S': 137, 'y': 85, 'i': 15}
                elif op == 55:
                    bkey = yv
                    patch = {'f': 202, 'y': 52, 'S': 33, 'i': 15}
                else:
                    bkey = None if st.V_dyn else bxor(sv, word29(st.V))
                    patch = {'f': 183, 'S': 110, 'y': 162, 'i': 15}
                if bkey is None:
                    extra += ' ; SEED DYNAMIC — string left encrypted'
                else:
                    s = self.decrypt_string(st, pc, fv, bkey, patch)
                    if s is None:
                        extra += ' ; string header/field missing'
                    else:
                        self.decrypted_strings[('B', pc)] = s
                        extra += str_extra(s)
                succ = [pc + 1]
                break
            if op in (18, 53):
                if st.L_dyn:
                    extra += ' ; SEED DYNAMIC (L) — slot left encrypted'
                    succ = [pc + 1]
                    break
                self.decrypt_insn_b(st, pc, op)
                nop = st.i[pc - 1]
                extra += (f' ; slot decrypted in place -> op {nop} '
                          f'({self.names[1].get(nop, "UNKNOWN")}); re-dispatched')
                op = nop
                yv, sv, fv = st.y[pc - 1], st.S[pc - 1], st.f[pc - 1]
                continue
            break
        if succ is None:
            self.reg_effects_b(st, op, pc)
            if op in (4, 47):
                succ = []
                extra += ' ; return (after upvalue-close preamble)'
            elif op == 74:
                succ = []
                switch = (yv, sv + 1)
                extra += f' ; SWITCHMODE to mode {yv}, entry pc {sv + 1} (leaves loop B)'
            elif op == 7:
                succ = [fv + 1, yv + 1]
                extra += f' ; branch: true {fv + 1} / false {yv + 1}'
            elif op == 14:
                succ = [sv + 1, yv + 1]
                extra += f' ; branch: true {sv + 1} / false {yv + 1}'
            elif op == 16:
                succ = [pc + 1, fv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {fv + 1}'
            elif op == 21:
                succ = [pc + 1, sv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {sv + 1}'
            elif op == 44:
                succ = [sv + 1]
                extra += f' ; jump to {sv + 1}'
            elif op == 45:
                succ = [pc + 1, sv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {sv + 1}'
            elif op == 52:
                succ = [yv + 1, pc + 1]
                extra += f' ; branch: ne {yv + 1} / fall {pc + 1}'
            elif op == 34:
                succ = [sv + 1, fv + 1]
                extra += f' ; iterator branch: step {sv + 1} / exit {fv + 1}'
            elif op == 57:
                tgt = self.R(st, fv)
                if tgt is not None:
                    succ = [tgt + 1]
                    extra += f' ; pc = R({fv})+1 = {tgt + 1} (known)'
                    self.unresolved_jmpr.pop(('B', pc), None)
                    self.jmpr_followed.setdefault(('B', pc), set()).add(tgt + 1)
                else:
                    succ = []
                    extra += f' ; pc = R({fv}) + 1 — register unknown here, path ends'
                    if first:
                        self.unresolved_jmpr[('B', pc)] = fv
            elif op == 88:
                succ = [yv + 1]
                extra += f' ; context swap; jump to {yv + 1}'
            else:
                succ = [pc + 1]
        if first:
            nm = self.names[1].get(orig, 'UNKNOWN')
            if orig >= 93:
                nm = self.names[1].get(91, 'EQ_RI') + ' (catch-all >=93)'
            elif op != orig and orig in (18, 53):
                nm += f' (-> {self.names[1].get(op, "UNKNOWN")})'
            self.visited[('B', pc)] = (nm, f'op={orig} y={yv} S={sv} f={fv}', extra, self.kdisp(pc))
            self.hist['B'][orig] += 1
            for nm2 in 'iySf':
                self.total_written[nm2] |= st.written[nm2]
        if switch is not None:
            mode_no, entry = switch
            self.mode_switches.append(('B', pc, mode_no, entry))
            if mode_no == 210:
                stack.append(('C', entry, st))
            return None
        if not succ:
            return None
        for alt in succ[1:]:
            stack.append(('B', alt, st.copy()))
        return ('B', succ[0])

    # ---------- loop C ----------
    def reg_effects_c(self, st, op, pc):
        yv, iv, sv = st.y[pc - 1], st.i[pc - 1], st.S[pc - 1]
        R = lambda k: self.R(st, k)
        precise = True
        if op == 9:       # V = n[y[P]]
            v = R(yv)
            if v is None:
                st.V_dyn = True
            else:
                st.V, st.V_dyn = v, False
        elif op == 139:   # L = n[y[P]]
            v = R(yv)
            if v is None:
                st.L_dyn = True
            else:
                st.L, st.L_dyn = v, False
        elif op == 82:    # n[S[P]] = L
            self.setR(st, sv, None if st.L_dyn else st.L)
        elif op == 122:   # LOADRAW: n[i[P]] = S[P]
            self.setR(st, iv, sv)
        elif op in (91, 137):  # C=y; n[C]=X[P], n[C+1]=i[P]
            self.setR(st, yv, self.matint(2, pc))
            self.setR(st, yv + 1, iv)
        elif op == 111:   # C=y; n[C]=X[P], n[C+1]=E[P]
            self.setR(st, yv, self.matint(2, pc))
            self.setR(st, yv + 1, self.matint(0, pc))
        elif op == 109:   # C=y; n[C]=X[P], n[C+1]=E[P]
            self.setR(st, yv, self.matint(2, pc))
            self.setR(st, yv + 1, self.matint(0, pc))
        elif op == 98:    # C=i; n[C]=z[P], n[C+1]=X[P]
            self.setR(st, iv, self.matint(1, pc))
            self.setR(st, iv + 1, self.matint(2, pc))
        else:
            precise = False
        if not precise:
            body = self.bodies_c.get(op, '')
            vals = {'y[P]': yv, 'S[P]': sv, 'f[P]': st.f[pc - 1], 'i[P]': iv}
            for m in self._DEST_RE.finditer(body):
                idx = m.group(1)
                if idx in vals:
                    self.setR(st, vals[idx], None)
                elif idx.isdigit():
                    self.setR(st, int(idx), None)

    def step_c(self, pc, st, stack, first):
        op = st.f[pc - 1]
        yv, iv, sv = st.y[pc - 1], st.i[pc - 1], st.S[pc - 1]
        if op is None:
            if first:
                self.visited[('C', pc)] = ('<nil opcode>', f'op={op} y={yv} i={iv} S={sv}', '', [])
            return None
        orig = op
        extra = ''
        succ = None
        switch = None
        for _try in range(4):
            if op in (16, 31, 72):
                if op == 16:
                    seed = None if st.L_dyn else bxor(sv, word29(st.L))
                    start, count = iv + 1, yv
                elif op == 72:
                    seed = None if st.V_dyn else bxor(sv, word29(st.V))
                    start, count = iv + 1, yv
                else:
                    seed, start, count = iv, yv + 1, sv
                if seed is None:
                    extra += ' ; SEED DYNAMIC — region left encrypted'
                else:
                    self.decrypt_block(st, start, count, seed,
                                       {'i': 0, 'S': 7, 'y': 14, 'f': 21})
                    extra += f' ; decrypts slots {start}..{start + count - 1}'
                st.f[pc - 1] = 110
                st.written['f'].add(pc)
                succ = [pc + 1]
                break
            if op in (23, 39, 135):
                if op == 23:
                    fld = iv
                    bkey = None if st.L_dyn else bxor(sv, word29(st.L))
                    patch = {'i': 118, 'S': 52, 'y': 4, 'f': 110}
                elif op == 39:
                    fld = iv
                    bkey = None if st.V_dyn else bxor(sv, word29(st.V))
                    patch = {'i': 190, 'S': 87, 'y': 71, 'f': 110}
                else:
                    fld, bkey = yv, sv
                    patch = {'y': 48, 'S': 187, 'i': 99, 'f': 110}
                if bkey is None:
                    extra += ' ; SEED DYNAMIC — string left encrypted'
                else:
                    s = self.decrypt_string(st, pc, fld, bkey, patch)
                    if s is None:
                        extra += ' ; string header/field missing'
                    else:
                        self.decrypted_strings[('C', pc)] = s
                        extra += str_extra(s)
                succ = [pc + 1]
                break
            if op in (5, 43):
                if st.L_dyn:
                    extra += ' ; SEED DYNAMIC (L) — slot left encrypted'
                    succ = [pc + 1]
                    break
                lw = split_word(st.L)
                if op == 5:
                    shift = 7 if sv < 2097152 else 14
                    x = band(sv, (1 << shift) - 1)
                    F = rshift(sv, shift)
                    st.i[pc - 1] = bxor(iv, 1, band(lw, 127))
                    st.f[pc - 1] = bxor(F, 59, band(rshift(lw, 21), 127))
                    st.y[pc - 1] = bxor(yv, 72, band(rshift(lw, 14), 127))
                    st.S[pc - 1] = bxor(x, 85, band(rshift(lw, 7), 127))
                else:
                    shift = 7 if sv < 16384 else (14 if sv < 2097152 else 21)
                    x = rshift(sv, shift)
                    F = band(sv, (1 << shift) - 1)
                    st.S[pc - 1] = bxor(F, 46, band(rshift(lw, 7), 127))
                    st.y[pc - 1] = bxor(yv, 117, band(rshift(lw, 14), 127))
                    st.f[pc - 1] = bxor(x, 108, band(rshift(lw, 21), 127))
                    st.i[pc - 1] = bxor(iv, 52, band(lw, 127))
                for nm in 'iySf':
                    st.written[nm].add(pc)
                nop = st.f[pc - 1]
                extra += (f' ; slot decrypted in place -> op {nop} '
                          f'({self.names[2].get(nop, "UNKNOWN")}); re-dispatched')
                op = nop
                yv, iv, sv = st.y[pc - 1], st.i[pc - 1], st.S[pc - 1]
                continue
            break
        if succ is None:
            self.reg_effects_c(st, op, pc)
            if op in (70, 74, 96):
                succ = []
                extra += ' ; return'
            elif op == 41:
                succ = []
                switch = (iv, sv + 1)
                extra += f' ; SWITCHMODE to mode {iv}, entry pc {sv + 1} (leaves loop C)'
            elif op == 128:
                tgt = self.R(st, iv)
                if tgt is not None:
                    succ = [tgt + 1]
                    extra += f' ; pc = R({iv})+1 = {tgt + 1} (known)'
                    self.unresolved_jmpr.pop(('C', pc), None)
                    self.jmpr_followed.setdefault(('C', pc), set()).add(tgt + 1)
                else:
                    succ = []
                    extra += f' ; pc = R({iv}) + 1 — register unknown here, path ends'
                    if first:
                        self.unresolved_jmpr[('C', pc)] = iv
            elif op == 6:
                succ = [sv + 1]
                extra += f' ; jump to {sv + 1}'
            elif op == 1:
                succ = [iv + 1, sv + 1]
                extra += f' ; branch: true {iv + 1} / false {sv + 1}'
            elif op == 8:
                succ = [yv + 1, iv + 1]
                extra += f' ; branch: true {yv + 1} / false {iv + 1}'
            elif op == 10:
                succ = [sv + 1, pc + 1]
                extra += f' ; branch: ne {sv + 1} / fall {pc + 1}'
            elif op in (33, 68):
                succ = [pc + 1, iv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {iv + 1}'
            elif op == 85:
                succ = [pc + 1, sv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {sv + 1}'
            elif op == 94:
                succ = [pc + 1, yv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {yv + 1}'
            elif op == 117:
                succ = [pc + 1, sv + 1]
                extra += f' ; branch: fall {pc + 1} / jump {sv + 1}'
            elif op == 78:
                succ = [yv + 1, sv + 1]
                extra += f' ; iterator branch: step {yv + 1} / exit {sv + 1}'
            elif op == 124:
                succ = [iv + 1, sv + 1]
                extra += f' ; for-next: body {iv + 1} / exit {sv + 1}'
            elif op == 103:
                succ = [yv + 1]
                extra += f' ; context swap; jump to {yv + 1}'
            elif op == 92:
                succ = [pc + 5]
                extra += ' ; 4-slot group op; next pc = pc+5'
            elif op == 104:
                succ = [pc + 4]
                extra += ' ; 3-slot group op; next pc = pc+4'
            else:
                succ = [pc + 1]
        if first:
            nm = self.names[2].get(orig, 'UNKNOWN')
            if orig >= 140:
                nm = self.names[2].get(138, 'SETTABLE_RR') + ' (catch-all >=140)'
            elif op != orig and orig in (5, 43):
                nm += f' (-> {self.names[2].get(op, "UNKNOWN")})'
            self.visited[('C', pc)] = (nm, f'op={orig} y={yv} i={iv} S={sv}', extra, self.kdisp(pc))
            self.hist['C'][orig] += 1
            for nm2 in 'iySf':
                self.total_written[nm2] |= st.written[nm2]
        if switch is not None:
            mode_no, entry = switch
            self.mode_switches.append(('C', pc, mode_no, entry))
            return None
        if not succ:
            return None
        for alt in succ[1:]:
            stack.append(('C', alt, st.copy()))
        return ('C', succ[0])


def main():
    d = Dis()
    d.run()
    lines = ['# root proto disassembly — slot-15209 interpreter, modes A(114), B(49), C(210)',
             f'# factory: u={d.factory["u"]} A={d.factory["A"]} R={d.factory["R2"]} '
             f'P[1]={d.factory["P1"]} P[2]={d.factory["P2"]}',
             f'# loop A entry pc {ENTRY_A}; loops B/C entered via SWITCHMODE']
    for mode in ('A', 'B', 'C'):
        pcs = sorted(pc for (m, pc) in d.visited if m == mode)
        lines.append(f'# mode {mode}: {len(pcs)} slots visited')
        for pc in pcs:
            name, ops_str, extra, ks = d.visited[(mode, pc)]
            kstr = ('  ' + ' '.join(ks)) if ks else ''
            lines.append(f'{mode} {pc:6d}  {name:22s} {ops_str}{kstr}{extra}')
    lines.append('')
    for li, mode in enumerate(('A', 'B', 'C')):
        lines.append(f'# opcode histogram mode {mode} (visited):')
        names = d.names[li]
        for op, n in d.hist[mode].most_common():
            lines.append(f'#   {op:3d} {names.get(op, "?"):16s} x{n}')
    lines.append('# mode switches taken:')
    for frm, pc, mode_no, entry in d.mode_switches:
        lines.append(f'#   loop {frm} pc {pc} -> mode {mode_no} at pc {entry}')
    lines.append('# walk notes:')
    for n in dict.fromkeys(d.notes):
        lines.append('#   ' + n)
    for key in sorted(d.unresolved_jmpr):
        lines.append(f'#   {key}: JMPR target register never resolved on any path')
    with open(os.path.join(HERE, 'root_disasm.txt'), 'w') as fo:
        fo.write('\n'.join(lines) + '\n')
    na = sum(1 for (m, _) in d.visited if m == 'A')
    nb = sum(1 for (m, _) in d.visited if m == 'B')
    nc = sum(1 for (m, _) in d.visited if m == 'C')
    print(f'visited: loop A {na} slots ({len(d.hist["A"])} distinct ops), '
          f'loop B {nb} slots ({len(d.hist["B"])} distinct ops), '
          f'loop C {nc} slots ({len(d.hist["C"])} distinct ops)')
    print('mode switches:', d.mode_switches)
    for s in 'iySf':
        print(f'stream {s}: patched by decryptors (union over paths): '
              f'{len(d.total_written[s])} slots')
    print('decrypted strings:', len(d.decrypted_strings))
    print('unresolved JMPR:', sorted(d.unresolved_jmpr))
    print('wrote root_disasm.txt')


if __name__ == '__main__':
    main()
