#!/usr/bin/env python3
"""dump_streams.py — phase C1 support: dump the root proto's 4 raw
operand streams ([-2] tables), the factory.P header table, and the
entry constants (mode A, size u, entry R) to streams.json."""
import importlib.util
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('fz_sim', os.path.join(HERE, 'fz_sim.py'))
fz = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fz)

CAP = {}
orig_call = fz.LuaFn.__call__


def patched(self, *args):
    if self.name == 'slot15209':
        CAP['args'] = args
    return orig_call(self, *args)


fz.LuaFn.__call__ = patched

cap_in = fz.build_inputs()
E_real = cap_in['E']
H = fz.build_H()
H.cz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['cz'].items()})
H.gz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['gz'].items()})
H.oz = fz.buf_create(16, log=False)
work = fz.buf_fromstring(open(os.path.join(fz.CASE, 'static', 'src.bin'), 'rb').read(), log=False)
chunk = fz._new_buf(bytearray(E_real[5]))
A = fz.LT()
fz.tset(A, 4, E_real[4])
fz.tset(A, 5, chunk)
fields = fz.LT()
for k, v in E_real[6].items():
    fz.tset(fields, k, v)
fz.tset(A, 6, fields)

Z, T = fz.pad(fz.mc(H, 'Fz', A, 201, 20), 2)
print('build ops:', len(fz.OPLOG), 'proto groups:', len(fz.PROTO_TABLES))

grp = fz.PROTO_TABLES[0]
names = ['e', 'A', 'P', 'y']  # dz order
streams = {}
for nm, t in zip(names, grp[1:]):
    meta = t.d[-2]
    vals = [meta.d.get(k) for k in range(1, 10386)]
    streams[nm] = vals
    print(f'table {nm}: stream len={sum(1 for v in vals if v is not None)}')

fargs = CAP['args']
# factory param order: H, P, E, u, A, X, y, i, J, B, z, S, f, R, R2
fP = fargs[1]
P1 = fP.d.get(1)
P2 = fP.d.get(2)


def enc(v):
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, fz.LT):
        return {'table_keys': sorted(str(k) for k in v.d.keys())}
    if isinstance(v, fz.LuaFn):
        return {'fn': v.name}
    if isinstance(v, tuple):
        return {'tuple': [enc(x) for x in v]}
    return {'other': repr(v)}


out = {
    'streams_dz_order': streams,   # e, A, P, y operand tables' [-2]
    'factory': {
        'u': fargs[3], 'A': fargs[4], 'R2': fargs[14],
        'P1': enc(P1), 'P2': enc(P2),
    },
}
with open(os.path.join(HERE, 'streams.json'), 'w') as fo:
    json.dump(out, fo)
print('factory u,A,R2:', fargs[3], fargs[4], fargs[14])
print('P[1]:', enc(P1))
print('P[2]:', enc(P2))
print('wrote streams.json')
