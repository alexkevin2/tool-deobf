#!/usr/bin/env python3
"""Eagerly materialize all operand keys of the root proto's 4 operand
tables via the __index closure, and dump protos.json.

[tool copy] EAGER_TABLE=<0..3> shards the run: the process builds
the root as usual but materializes only that one operand table and
writes protos_shard.json instead of protos.json (merge_protos.py
assembles the shards). Materialization retains gigabytes of
decompressed stream state per table in the Python sim; four
sequential shard processes keep the peak within small hosts. The
case original ran monolithically on a larger host."""
import importlib.util
import json
import os
import signal
import sys
import time
from collections import Counter


class KeyTimeout(Exception):
    pass


def _alarm(sig, frm):
    raise KeyTimeout()


signal.signal(signal.SIGALRM, _alarm)
PER_KEY_SECONDS = float(os.environ.get('EAGER_PER_KEY', '3'))

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('fz_sim', os.path.join(HERE, 'fz_sim.py'))
fz = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fz)

SHARD = os.environ.get('EAGER_TABLE')
SHARD = int(SHARD) if SHARD is not None else None

cap_in = fz.build_inputs()
E_real = cap_in['E']
H = fz.build_H()
H.cz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['cz'].items()})
H.gz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['gz'].items()})
H.oz = fz.buf_create(16, log=False)
work = fz.buf_fromstring(open(os.path.join(fz.CASE, 'static', 'src.bin'), 'rb').read(), log=False)
chunk = fz._new_buf(bytearray(E_real[5]))
A = fz.LT()
fz.tset(A, 4, E_real[4])
fz.tset(A, 5, chunk)
fields = fz.LT()
for k, v in E_real[6].items():
    fz.tset(fields, k, v)
fz.tset(A, 6, fields)

Z, T = fz.pad(fz.mc(H, 'Fz', A, 201, 20), 2)
print(f'build done: {len(fz.OPLOG)} ops, proto groups={len(fz.PROTO_TABLES)}')


def enc(v, depth=0):
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, fz.Buf):
        return {'buf': v.id, 'len': len(v.data)}
    if isinstance(v, fz.LuaFn):
        return {'fn': v.name}
    if isinstance(v, tuple):
        return {'tuple': [enc(x, depth + 1) for x in v]}
    if isinstance(v, fz.LT):
        if depth > 1:
            return {'table': '...'}
        return {'table': {str(k): enc(x, depth + 1)
                          for k, x in sorted(v.d.items(),
                                              key=lambda kv: str(kv[0]))}}
    return {'other': repr(v)}


protos = []
processed = set()
seen_groups = 0
t0 = time.time()
while True:
    pending = [g for g in fz.PROTO_TABLES if id(g) not in processed]
    if not pending:
        break
    grp = pending[0]
    processed.add(id(grp))
    seen_groups += 1
    kind = grp[0]
    tables = grp[1:]
    entry = {'kind': kind, 'tables': []}
    for ti, t in enumerate(tables):
        if SHARD is not None and ti != SHARD:
            entry['tables'].append(None)
            continue
        meta = t.d.get(-2)
        n_keys = len(meta.d) if isinstance(meta, fz.LT) else 0
        vals = {}
        errs = {}
        types = Counter()
        for k in range(1, n_keys + 1):
            if k in t.d:
                continue
            signal.setitimer(signal.ITIMER_REAL, PER_KEY_SECONDS)
            try:
                v = fz.tget(t, k)
            except Exception as ex:
                signal.setitimer(signal.ITIMER_REAL, 0)
                errs[k] = f'{type(ex).__name__}: {ex}'[:80]
                continue
            signal.setitimer(signal.ITIMER_REAL, 0)
            if v is None:
                types['nil'] += 1
                continue
            vals[k] = enc(v)
            types[type(v).__name__] += 1
        entry['tables'].append({
            'meta_entries': n_keys,
            'meta_head': [meta.d.get(i) for i in range(1, 9)] if isinstance(meta, fz.LT) else None,
            'materialized': vals,
            'types': dict(types),
            'errors': errs,
        })
        print(f'group {seen_groups} table {ti}: keys={n_keys} '
              f'materialized={len(vals)} errors={len(errs)} types={dict(types)} '
              f'({time.time() - t0:.1f}s)', flush=True)
    protos.append(entry)
    with open(os.path.join(HERE, 'protos_partial.json'), 'w') as fo:
        json.dump({'root': {'Z': enc(Z), 'T': enc(T)}, 'proto_groups': protos},
                  fo, indent=1, default=str)

if SHARD is not None:
    grp0 = protos[0]
    shard_out = {
        'root': {'Z': enc(Z), 'T': enc(T)},
        'kind': grp0['kind'],
        'table_index': SHARD,
        'table': grp0['tables'][SHARD],
        'fn_calls': Counter(n for n, _ in fz.FN_CALLS),
        'total_ops_after_eager': len(fz.OPLOG),
    }
    with open(os.path.join(HERE, 'protos_shard.json'), 'w') as fo:
        json.dump(shard_out, fo, indent=1, default=str)
    print(f'wrote protos_shard.json (table {SHARD})')
else:
    out = {
        'root': {'Z': enc(Z), 'T': enc(T)},
        'proto_groups': protos,
        'fn_calls': Counter(n for n, _ in fz.FN_CALLS),
        'total_ops_after_eager': len(fz.OPLOG),
    }
    with open(os.path.join(HERE, 'protos.json'), 'w') as fo:
        json.dump(out, fo, indent=1, default=str)
    print('wrote protos.json; groups processed:', seen_groups,
          'total groups now:', len(fz.PROTO_TABLES))
