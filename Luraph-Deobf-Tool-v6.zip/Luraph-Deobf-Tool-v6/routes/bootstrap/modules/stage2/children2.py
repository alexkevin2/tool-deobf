#!/usr/bin/env python3
"""children.py — phase C2 task 1: child-proto recovery in payload access
order.

Method:
- Build the root proto with the oracle-validated fz_sim (as eager.py),
  with two hooks: fz.mc is wrapped to log every Fz invocation as a
  frame (structure arg, calling context, PROTO_TABLES growth, slot-15209
  factory args, post-build fields/chunk snapshot), and LuaFn.__call__
  records slot-15209 factory arguments into the current frame.
- The C1 walk (disasm2.py, same inputs as C1 -> identical visited set)
  gives the executed paths. Constants are then materialized in
  FIRST-VISIT order (the walk's insertion order), expanding group-op
  slot ranges at their op, instead of eager numeric key order.
- A materialization that enters materializer state 178 calls Fz
  recursively (via the closure's W) -> a child proto: a new dz operand
  group + a slot-15209 factory call. Each child is walked with
  disasm2 (entry = its factory (mode, R)), its constants materialized
  in its own walk order, recursively (BFS by creation order).
- Eager-error mining: the 11,318 phase-B error keys are intersected
  with the keys the executed root paths reference; each is retried in
  access order above and its outcome recorded.

Outputs: children.json, proto_structs.json (per-proto structured walk
records for the lifter). Python only; the target is never executed in
a Luau runtime.

[tool copy changes vs. the case original — see README.md of
Luraph-BootstrapVM-Deobf]
- Deep-retry builds of state-178 descriptors are DISABLED by default
  (env CHILD_DEEP_RETRY=1 restores the case behavior). The case
  diagnosis (STAGE2C2 §1.5) proved out-of-context builds diverge in
  the _z/v payload-phase cycle, so the retries only burn ~30 s per
  descriptor for a guaranteed timeout.
- The mining pass no longer attempts builds: it merges the fast
  census (census178.json from probe178_fast.py) into children.json
  as `child_descriptor_census` with per-descriptor outcomes
  (env CHILD_MINING_ATTEMPT=1 restores the case's attempt behavior).
"""
import importlib.util
import json
import os
import signal
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
CASE = os.path.dirname(HERE)
PER_KEY_SECONDS = float(os.environ.get('CHILD_PER_KEY', '5'))
MAX_PROTOS = 200
MAX_DEPTH = 6
WALL_BUDGET = float(os.environ.get('CHILD_WALL', '2400'))

t_start = time.time()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


fz = load('fz_sim', os.path.join(HERE, 'fz_sim.py'))
d2 = load('disasm2', os.path.join(HERE, 'disasm2.py'))

# state-178 tracker: the materializer closure's recursive-Fz state.
ENTERED_178 = [0]
_orig_walk_note = fz.walk_note


def _walk_note_wrap(scope, state):
    if scope == 'idx' and state == 178:
        ENTERED_178[0] += 1
    return _orig_walk_note(scope, state)


fz.walk_note = _walk_note_wrap
DEEP_SECONDS = float(os.environ.get('CHILD_DEEP', '300'))
DEEP_RETRY = os.environ.get('CHILD_DEEP_RETRY', '0') == '1'
MINING_ATTEMPT = os.environ.get('CHILD_MINING_ATTEMPT', '0') == '1'

# ---------------------------------------------------------------- hooks
FRAME_LOG = []
FZ_STACK = []
CUR_ACCESS = {'ctx': None}

_orig_mc = fz.mc


def _snap_structure(st):
    out = {'fields': None, 'chunk': None}
    if isinstance(st, fz.LT):
        f6 = st.d.get(6)
        if isinstance(f6, fz.LT):
            out['fields'] = {int(k): v for k, v in f6.d.items()
                             if isinstance(v, (int, float))}
        c5 = st.d.get(5)
        if isinstance(c5, fz.Buf):
            out['chunk'] = bytes(c5.data)
        elif isinstance(c5, (bytes, bytearray)):
            out['chunk'] = bytes(c5)
    return out


def mc_wrap(H, name, *args):
    if name != 'Fz':
        return _orig_mc(H, name, *args)
    frame = {'id': len(FRAME_LOG), 'ctx': CUR_ACCESS['ctx'],
             'parent_frame': FZ_STACK[-1]['id'] if FZ_STACK else None,
             'structure': args[0] if args else None,
             'y': args[1] if len(args) > 1 else None,
             'n': args[2] if len(args) > 2 else None,
             'groups_before': len(fz.PROTO_TABLES), 'factory': [],
             'error': None}
    FRAME_LOG.append(frame)
    FZ_STACK.append(frame)
    try:
        res = _orig_mc(H, name, *args)
        frame['ret0'] = res[0] if isinstance(res, tuple) else res
        return res
    except Exception as ex:
        frame['error'] = f'{type(ex).__name__}: {ex}'[:200]
        raise
    finally:
        FZ_STACK.pop()
        frame['groups'] = fz.PROTO_TABLES[frame['groups_before']:]
        snap = _snap_structure(frame['structure'])
        frame['fields'], frame['chunk'] = snap['fields'], snap['chunk']


fz.mc = mc_wrap

_orig_luafn_call = fz.LuaFn.__call__


def luafn_wrap(self, *args):
    if self.name == 'slot15209' and FZ_STACK:
        FZ_STACK[-1]['factory'].append(args)
    return _orig_luafn_call(self, *args)


fz.LuaFn.__call__ = luafn_wrap

# ---------------------------------------------------------------- build root
cap_in = fz.build_inputs()
E_real = cap_in['E']
H = fz.build_H()
H.cz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['cz'].items()})
H.gz = fz.KSDict({fz.num_key(k): v for k, v in cap_in['gz'].items()})
H.oz = fz.buf_create(16, log=False)
work = fz.buf_fromstring(open(os.path.join(CASE, 'static', 'src.bin'), 'rb').read(), log=False)
chunk_buf = fz._new_buf(bytearray(E_real[5]))
A_root = fz.LT()
fz.tset(A_root, 4, E_real[4])
fz.tset(A_root, 5, chunk_buf)
fields_lt = fz.LT()
for k, v in E_real[6].items():
    fz.tset(fields_lt, k, v)
fz.tset(A_root, 6, fields_lt)

CUR_ACCESS['ctx'] = {'proto': 'root', 'site': 'build'}
Z, T = fz.pad(fz.mc(H, 'Fz', A_root, 201, 20), 2)
CUR_ACCESS['ctx'] = None
print(f'root build done: {len(fz.OPLOG)} ops, frames={len(FRAME_LOG)}, '
      f'groups={len(fz.PROTO_TABLES)}', flush=True)


def enc(v, depth=0):
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, fz.Buf):
        return {'buf': v.id, 'len': len(v.data)}
    if isinstance(v, fz.LuaFn):
        return {'fn': v.name}
    if isinstance(v, tuple):
        return {'tuple': [enc(x, depth + 1) for x in v]}
    if isinstance(v, fz.LT):
        if depth > 1:
            return {'table': '...'}
        return {'table': {str(k): enc(x, depth + 1)
                          for k, x in sorted(v.d.items(), key=lambda kv: str(kv[0]))}}
    if isinstance(v, (bytes, bytearray)):
        return {'other': repr(bytes(v))}
    return {'other': repr(v)}


def enc_type(v):
    if isinstance(v, dict):
        if 'other' in v and isinstance(v['other'], str) and \
                (v['other'].startswith("b'") or v['other'].startswith('b"')):
            return 'string'   # fz_sim models Luau strings as Python bytes
        for k in ('tuple', 'table', 'fn', 'buf', 'other'):
            if k in v:
                return k
        return 'other'
    if isinstance(v, bool):
        return 'bool'
    if isinstance(v, int):
        return 'int'
    if isinstance(v, float):
        return 'float'
    if isinstance(v, str):
        return 'string'
    if v is None:
        return 'nil'
    return type(v).__name__


class KeyTimeout(Exception):
    pass


def _alarm(sig, frm):
    raise KeyTimeout()


signal.signal(signal.SIGALRM, _alarm)

# ---------------------------------------------------------------- proto state
MODE_LETTER = {114: 'A', 49: 'B', 210: 'C', 113: 'D'}
protos = {}          # id -> record dict
proto_order = []     # ids in creation order
structs_out = {}     # id -> structured walk data for the lifter


def factory_info(frame):
    if not frame or not frame['factory']:
        return None
    args = frame['factory'][0]
    fP = args[1] if len(args) > 1 else None
    p1 = fP.d.get(1) if isinstance(fP, fz.LT) else None
    p2 = fP.d.get(2) if isinstance(fP, fz.LT) else None
    return {'u': args[3] if len(args) > 3 else None,
            'A': args[4] if len(args) > 4 else None,
            'R2': args[14] if len(args) > 14 else None,
            'P1': p1, 'P2': p2, 'n_factory_calls': len(frame['factory'])}


def streams_of(tables):
    """tables: dz-order LT list -> (streams dict for disasm2, n_slots, holes)"""
    metas = []
    for t in tables:
        meta = t.d.get(-2)
        metas.append(meta.d if isinstance(meta, fz.LT) else {})
    n = max((max(m.keys()) if m else 0) for m in metas)
    streams = {}
    holes = 0
    for nm, m in zip(('e', 'A', 'P', 'y'), metas):
        vals = []
        for k in range(1, n + 1):
            v = m.get(k)
            if v is None:
                holes += 1
                v = 0
            vals.append(v)
        streams[nm] = vals
    return streams, n, holes


def register_proto(pid, parent, site, tables, factory, fields, chunk,
                   frame_id, depth):
    streams, n, holes = streams_of(tables)
    protos[pid] = {
        'id': pid, 'parent': parent, 'site': site, 'depth': depth,
        'tables': tables, 'factory': factory, 'fields': fields,
        'chunk': chunk, 'streams': streams, 'n_slots': n, 'holes': holes,
        'frame_id': frame_id,
        'mat': [{}, {}, {}, {}], 'mat_err': [set(), set(), set(), set()],
        'attempted': set(), 'access_results': [], 'census': [],
        'visited': [], 'struct': {}, 'mode_switches': [], 'notes': [],
        'decrypted_strings': {}, 'walk_rounds': 0,
    }
    proto_order.append(pid)
    return protos[pid]


# root proto registration (inputs identical to C1 for the first walk)
root_frame = FRAME_LOG[0] if FRAME_LOG else None
root_tables = list(fz.PROTO_TABLES[0][1:5])
root_streams_json = json.load(open(os.path.join(HERE, 'streams.json')))
root_factory = root_streams_json['factory']
root_fields = {int(k): v for k, v in json.load(
    open(os.path.join(HERE, 'E_fields.json'))).items()}
root_chunk = open(os.path.join(CASE, 'static', 'dst.bin'), 'rb').read()
register_proto('root', None, None, root_tables, root_factory, root_fields,
               root_chunk, root_frame['id'] if root_frame else None, 0)
# root's first walk must use the eager mat (C1 fidelity)
pj = json.load(open(os.path.join(HERE, 'protos.json')))
eager_mat, eager_err = [], []
for t in pj['proto_groups'][0]['tables']:
    eager_mat.append({int(k): v for k, v in t.get('materialized', {}).items()})
    eager_err.append(set(int(k) for k in t.get('errors', {})))
protos['root']['eager_mat'] = eager_mat
protos['root']['eager_err'] = eager_err


def do_walk(rec, mat, mat_err):
    d = d2.Dis(streams=rec['streams'], factory=rec['factory'],
               fields=rec['fields'] if rec['fields'] is not None else {},
               chunk=rec['chunk'] if rec['chunk'] is not None else b'',
               mat=mat, mat_err=mat_err, n_slots=rec['n_slots'])
    fac = rec['factory'] or {}
    letter = MODE_LETTER.get(fac.get('A'), 'A')
    d.run(letter, fac.get('R2') or 1)
    return d


def access_list(d):
    out, seen = [], set()
    for (mode, pc) in d.visited.keys():
        rec = d.struct.get((mode, pc))
        keys = [pc]
        if rec and rec.get('group_span'):
            keys += [pc + k for k in range(1, rec['group_span'] + 1)]
        for key in keys:
            for ti in range(4):
                if (ti, key) not in seen:
                    seen.add((ti, key))
                    out.append((ti, key, mode, pc))
    return out


_om = json.load(open(os.path.join(HERE, 'opcode_map.json')))
OP_BODIES = {}
for _li, _lp in enumerate(_om['loops']):
    for _e in _lp['opcodes']:
        OP_BODIES[(_li, _e['opcode'])] = _e.get('body') or ''
LOOP_IDX = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
K_TI = {'E': 0, 'z': 1, 'X': 2, 'B': 3}
import re as _re
_KREF = _re.compile(r'\b(E|z|X|B)\[P\+(\d)\]')


def referenced_keys(d):
    """(table, key) pairs the executed instructions' bodies actually
    read through the materializer: E/z/X/B[P] at the op's pc, [P+k]
    reads in the body, and group-op slot ranges (all four tables —
    the group bodies read E/z at consecutive slots)."""
    refs = set()
    for (mode, pc), r in d.struct.items():
        for ti in range(4):
            refs.add((ti, pc))
        if r.get('group_span'):
            for k in range(1, r['group_span'] + 1):
                for ti in range(4):
                    refs.add((ti, pc + k))
        body = OP_BODIES.get((LOOP_IDX[mode], r['op_final']), '')
        for m in _KREF.finditer(body):
            refs.add((K_TI[m.group(1)], pc + int(m.group(2))))
    return refs


child_counter = [0]


def materialize_access(rec, ti, key, mode, pc):
    """One access-order materialization; returns result dict. Any Fz
    frames completed under this access become child protos."""
    table = rec['tables'][ti]
    ctx = {'proto': rec['id'], 'table': ti, 'key': key,
           'instr_mode': mode, 'instr_pc': pc}
    frames_before = len(FRAME_LOG)
    res = {'table': ti, 'key': key, 'instr_mode': mode, 'instr_pc': pc}
    if key in table.d:
        res['outcome'] = 'raw'
        res['value'] = enc(table.d[key])
        return res
    def attempt(budget):
        CUR_ACCESS['ctx'] = ctx
        e178_before = ENTERED_178[0]
        signal.setitimer(signal.ITIMER_REAL, budget)
        try:
            v = fz.tget(table, key)
            signal.setitimer(signal.ITIMER_REAL, 0)
            if v is None:
                res['outcome'] = 'nil'
            else:
                res['outcome'] = 'value'
                res['value'] = enc(v)
        except KeyTimeout:
            signal.setitimer(signal.ITIMER_REAL, 0)
            res['outcome'] = 'error'
            res['error'] = f'KeyTimeout >{budget}s'
        except Exception as ex:
            signal.setitimer(signal.ITIMER_REAL, 0)
            res['outcome'] = 'error'
            res['error'] = f'{type(ex).__name__}: {ex}'[:160]
        finally:
            CUR_ACCESS['ctx'] = None
        return ENTERED_178[0] - e178_before

    n178 = attempt(PER_KEY_SECONDS)
    res['entered_178'] = n178
    if res['outcome'] == 'error' and n178 > 0 and not DEEP_RETRY:
        # Tool fast path: the case proved these builds diverge out of
        # context; record the skip instead of burning the deep budget.
        res['deep_retry_skipped'] = True
    if res['outcome'] == 'error' and n178 > 0 and DEEP_RETRY:
        # The key's descriptor routes to materializer state 178: a
        # recursive Fz child build that needs far more than the normal
        # per-key budget in the Python sim. Retry once, deep budget.
        # (Static-analysis device: the failed attempt's partial side
        # effects remain in the sim, as a real erroring __index would
        # also have partial effects before propagating.)
        res['deep_retry'] = True
        res['first_error'] = res.get('error')
        n178 = attempt(DEEP_SECONDS)
        res['entered_178'] = n178
        print(f"  deep retry {rec['id']} t{ti} k{key}: {res['outcome']} "
              f"({time.time() - t_start:.0f}s)", flush=True)
    # child frames directly attributed to this access
    kids = []
    for fr in FRAME_LOG[frames_before:]:
        if fr['ctx'] == ctx and fr['parent_frame'] is None:
            kids.append(fr)
    res['child_frames'] = [fr['id'] for fr in kids]
    for fr in kids:
        dz = None
        for g in fr['groups']:
            if g[0] == 'dz':
                dz = g
                break
        fac = factory_info(fr)
        child_counter[0] += 1
        cid = f'c{child_counter[0]}'
        site = {'proto': rec['id'], 'table': ti, 'key': key,
                'instr_mode': mode, 'instr_pc': pc, 'frame': fr['id'],
                'fz_error': fr['error']}
        if dz is not None and fac is not None and fr['error'] is None:
            register_proto(cid, rec['id'], site, list(dz[1:5]), fac,
                           fr['fields'], fr['chunk'], fr['id'],
                           rec['depth'] + 1)
            res.setdefault('children', []).append(cid)
        else:
            res.setdefault('child_notes', []).append(
                f"frame {fr['id']}: dz group {'ok' if dz else 'MISSING'}, "
                f"factory {'ok' if fac else 'MISSING'}, "
                f"fz_error={fr['error']}, "
                f"groups={[g[0] for g in fr['groups']]}")
    return res


def process_proto(rec):
    mat = rec['eager_mat'] if 'eager_mat' in rec else rec['mat']
    mat_err = rec['eager_err'] if 'eager_err' in rec else rec['mat_err']
    for rnd in range(4):
        rec['walk_rounds'] += 1
        d = do_walk(rec, mat, mat_err)
        if 'referenced' not in rec:
            rec['referenced'] = referenced_keys(d)
        acc = access_list(d)
        todo = [a for a in acc if (a[0], a[1]) not in rec['attempted']]
        if not todo:
            break
        for ti, key, mode, pc in todo:
            if time.time() - t_start > WALL_BUDGET:
                print('WALL BUDGET reached; stopping materialization', flush=True)
                rec['notes'].append('wall budget stop')
                break
            rec['attempted'].add((ti, key))
            r = materialize_access(rec, ti, key, mode, pc)
            rec['access_results'].append(r)
            if r['outcome'] in ('value', 'raw'):
                rec['mat'][ti][key] = r['value']
            elif r['outcome'] == 'error':
                rec['mat_err'][ti].add(key)
        # subsequent rounds walk with the access-order mat
        mat, mat_err = rec['mat'], rec['mat_err']
    # census merge (root only): the fast state-178 probe found
    # root-table keys whose descriptors route to materializer state
    # 178 but which no walked instruction referenced. Tool default:
    # record them as a census with per-descriptor outcomes WITHOUT
    # attempting builds (the case proved out-of-context builds
    # diverge; STAGE2C2 §1.5). CHILD_MINING_ATTEMPT=1 restores the
    # case behavior (materialize them; deep retry applies if enabled;
    # any child protos join the BFS queue).
    if rec['id'] == 'root':
        hits = []
        for probe_name in ('census178.json', 'probe178_all.json',
                           'probe178_first.json', 'probe178_rest.json',
                           'probe178_results.json'):
            probe_path = os.path.join(HERE, probe_name)
            if os.path.exists(probe_path):
                hits += json.load(open(probe_path))
        seen_hits = set()
        for h in hits:
            ti, key = h['table'], h['key']
            if (ti, key) in seen_hits:
                continue
            seen_hits.add((ti, key))
            if (ti, key) in rec['attempted']:
                continue
            if MINING_ATTEMPT:
                rec['attempted'].add((ti, key))
                r = materialize_access(rec, ti, key, None, None)
                r['mined'] = True
                rec['access_results'].append(r)
                if r['outcome'] in ('value', 'raw'):
                    rec['mat'][ti][key] = r['value']
                elif r['outcome'] == 'error':
                    rec['mat_err'][ti].add(key)
            else:
                rec['census'].append({
                    'table': ti, 'key': key,
                    'entered_178': bool(h.get('entered_178', True)),
                    'outcome': 'blocked-in-context-materialization',
                    'build_attempted': False,
                    'note': 'state-178 child-proto descriptor; '
                            'out-of-context Fz builds diverge in the '
                            '_z/v payload-phase cycle (case diagnosis '
                            'STAGE2C2 §1.5); the tool fast path '
                            'censuses the descriptor without '
                            'attempting the build'})
    # final walk with access-order mat -> struct records for the lifter
    d = do_walk(rec, rec['mat'], rec['mat_err'])
    rec['visited'] = [[m, p] for (m, p) in d.visited.keys()]
    rec['struct'] = {f'{m}:{p}': r for (m, p), r in d.struct.items()}
    rec['mode_switches'] = [list(s) for s in d.mode_switches]
    rec['notes'] += list(dict.fromkeys(d.notes))
    rec['decrypted_strings'] = {
        f'{m}:{p}': s.decode('utf-8', 'backslashreplace')
        for (m, p), s in d.decrypted_strings.items()}
    rec['final_walk'] = d
    print(f"proto {rec['id']}: visited={len(rec['visited'])} "
          f"attempted={len(rec['attempted'])} "
          f"children_so_far={child_counter[0]} "
          f"({time.time() - t_start:.0f}s)", flush=True)


# ---------------------------------------------------------------- BFS over protos
children_out = []
mined = {}
qi = 0
while qi < len(proto_order):
    if len(proto_order) > MAX_PROTOS:
        print('MAX_PROTOS reached', flush=True)
        break
    rec = protos[proto_order[qi]]
    qi += 1
    if rec['depth'] > MAX_DEPTH:
        rec['notes'].append(f"depth > {MAX_DEPTH}; not processed")
        continue
    process_proto(rec)
    # checkpoint + incremental outputs (survive a mid-run kill)
    with open(os.path.join(HERE, 'children_partial.json'), 'w') as fo:
        json.dump({'done': proto_order[:qi], 'known': proto_order}, fo)
    try:
        _dfn = globals().get('dump_outputs')
        if _dfn is not None:
            _dfn()
    except Exception as ex:
        print('incremental dump failed:', ex, flush=True)

# ---------------------------------------------------------------- outputs
def consts_summary(rec):
    types = Counter()
    errs = 0
    vals = 0
    for r in rec['access_results']:
        if r['outcome'] in ('value', 'raw'):
            vals += 1
            types[enc_type(r.get('value'))] += 1
        elif r['outcome'] == 'error':
            errs += 1
    return {'materialized': vals, 'errors': errs,
            'attempted': len(rec['access_results']), 'by_type': dict(types)}


def dump_outputs():
    global children_out, mined
    children_out = []
    for pid in proto_order[1:]:
        rec = protos[pid]
        fac = rec['factory'] or {}
        by_mode = Counter(m for m, _ in rec['visited'])
        _pref = protos[rec['parent']].get('referenced', set()) \
            if rec['parent'] in protos else set()
        _site = rec['site'] or {}
        children_out.append({
            'id': pid, 'parent': rec['parent'], 'creation_site': rec['site'],
            'referenced_by_parent_executed_code':
                (_site.get('table'), _site.get('key')) in _pref,
            'mined_from_error_keys': bool(_site.get('instr_pc') is None),
            'factory': fac,
            'mode': fac.get('A'), 'mode_letter': MODE_LETTER.get(fac.get('A')),
            'entry_pc': fac.get('R2'), 'regfile_size': fac.get('u'),
            'n_slots': rec['n_slots'], 'stream_holes_filled0': rec['holes'],
            'visited_pcs': len(rec['visited']), 'visited_by_mode': dict(by_mode),
            'visited': rec['visited'],
            'constants_summary': consts_summary(rec),
            'mode_switches': rec['mode_switches'], 'notes': rec['notes'],
            'walk_rounds': rec['walk_rounds'],
        })

    root_rec = protos['root']
    root_by_mode = Counter(m for m, _ in root_rec['visited'])

    # eager-error mining (root): referenced error keys and their outcomes
    eager_err_keys = {(ti, k) for ti in range(4) for k in eager_err[ti]}
    referenced = set()
    droot = root_rec['final_walk']
    for (mode, pc) in droot.visited.keys():
        referenced.add(pc)
        r = droot.struct.get((mode, pc))
        if r and r.get('group_span'):
            for k in range(1, r['group_span'] + 1):
                referenced.add(pc + k)
    mined = {}
    outcome_by_key = {(r['table'], r['key']): r for r in root_rec['access_results']}
    for ti in range(4):
        ks = sorted(k for k in eager_err[ti] if k in referenced)
        outcomes = Counter()
        for k in ks:
            r = outcome_by_key.get((ti, k))
            outcomes[r['outcome'] if r else 'not-attempted'] += 1
        mined[f'table{ti}'] = {'referenced_error_keys': len(ks),
                               'keys': ks, 'outcomes': dict(outcomes)}

    capture_sites = []
    for (mode, pc), r in droot.struct.items():
        if r['name'] == 'CAPTURE':
            capture_sites.append({'mode': mode, 'pc': pc, 'operands':
                                  {'a': r['i'], 'b': r['S'], 'c': r['f']}})
    group_sites = []
    for (mode, pc), r in droot.struct.items():
        if r.get('group_span'):
            group_sites.append({'mode': mode, 'pc': pc, 'op': r['op_final'],
                                'name': r['name'], 'span': r['group_span']})

    _root_ref = root_rec.get('referenced', set())
    census_out = []
    for c in root_rec.get('census', []):
        cc = dict(c)
        cc['referenced_by_parent_executed_code'] = \
            (c['table'], c['key']) in _root_ref
        census_out.append(cc)

    out = {
        'root': {
            'factory': root_factory,
            'visited_pcs': len(root_rec['visited']),
            'visited_by_mode': dict(root_by_mode),
            'constants_summary': consts_summary(root_rec),
            'capture_sites': capture_sites,
            'group_op_sites': group_sites,
            'frame_factory_calls': factory_info(root_frame),
        },
        'children': children_out,
        'child_descriptor_census': census_out,
        'eager_error_mining': {
            'total_eager_errors': sum(len(s) for s in eager_err),
            'referenced_by_executed_code': mined,
        },
        'access_results': {pid: protos[pid]['access_results'] for pid in proto_order},
        'frames': [{'id': fr['id'], 'ctx': fr['ctx'], 'parent_frame': fr['parent_frame'],
                    'groups': [g[0] for g in fr.get('groups', [])],
                    'factory': factory_info(fr), 'error': fr['error']}
                   for fr in FRAME_LOG],
        'stats': {'protos_total': len(proto_order),
                  'children_total': len(children_out),
                  'child_descriptors_censused': len(census_out),
                  'child_descriptors_blocked': sum(
                      1 for c in census_out
                      if c['outcome'] == 'blocked-in-context-materialization'),
                  'frames_total': len(FRAME_LOG),
                  'wall_seconds': round(time.time() - t_start, 1)},
    }
    with open(os.path.join(HERE, 'children.json'), 'w') as fo:
        json.dump(out, fo, indent=1, default=str)

    structs = {}
    for pid in proto_order:
        rec = protos[pid]
        structs[pid] = {
            'factory': rec['factory'], 'parent': rec['parent'],
            'site': rec['site'],
            'entry': [MODE_LETTER.get((rec['factory'] or {}).get('A'), 'A'),
                      (rec['factory'] or {}).get('R2')],
            'regfile_size': (rec['factory'] or {}).get('u'),
            'n_slots': rec['n_slots'],
            'instructions': [rec['struct'][f'{m}:{p}'] for m, p in rec['visited']],
            'mode_switches': rec['mode_switches'],
            'decrypted_strings': rec['decrypted_strings'],
            'notes': rec['notes'],
        }
    with open(os.path.join(HERE, 'proto_structs.json'), 'w') as fo:
        json.dump(structs, fo, indent=1, default=str)

    # v6.1 (restructuring pass): harvest the final walks' JMPR
    # target unions.  proto_structs.json serializes only each
    # record's FIRST-visit successor; the completed CFG used by
    # stageE/build_cfg2.py needs every target the walk followed.
    # Pure side output — no existing artifact changes.
    try:
        harvest = {}
        for pid in proto_order:
            d = protos[pid].get('final_walk')
            if d is None:
                continue
            harvest[pid] = {
                'jmpr_followed': {
                    f'{m}:{p}': sorted(targets)
                    for (m, p), targets in d.jmpr_followed.items()},
                'unresolved_jmpr': {
                    f'{m}:{p}': r
                    for (m, p), r in d.unresolved_jmpr.items()},
            }
        with open(os.path.join(HERE, 'jmpr_harvest.json'), 'w') as fo:
            json.dump(harvest, fo, indent=1)
    except Exception as ex:
        print('jmpr harvest failed:', ex, flush=True)


dump_outputs()
root_rec = protos['root']
print('children:', len(children_out))
for c in children_out:
    print(' ', c['id'], 'parent', c['parent'], 'site', c['creation_site'],
          'mode', c['mode'], 'entry', c['entry_pc'],
          'visited', c['visited_pcs'], 'consts', c['constants_summary'])
print('root consts:', consts_summary(root_rec))
print('mining:', json.dumps(mined, default=str)[:400])
print(f'done in {time.time() - t_start:.0f}s')
