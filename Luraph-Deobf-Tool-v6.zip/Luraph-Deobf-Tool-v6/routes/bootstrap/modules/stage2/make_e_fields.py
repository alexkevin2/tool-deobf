#!/usr/bin/env python3
"""make_e_fields.py — regenerate E_fields.json for the tool pipeline.

In the case, E_fields.json (E[6] flattened to {index: value}, 781
entries) was produced by an ad-hoc phase-A snippet. Here it is
derived from the oracle-verified stage-1 simulation itself:
fz_sim.build_inputs() captures table E at the wY -> Fz call; E[6] is
the bootstrap's field table. Only numeric (non-bool) values are
emitted — the field table is numeric by construction (the disasm
walk consumes it arithmetically); anything else is counted and
reported rather than silently dropped.
"""
import importlib.util
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def num(v):
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


fz = load('fz_sim', os.path.join(HERE, 'fz_sim.py'))
cap_in = fz.build_inputs()
E6 = cap_in['E'][6]
out = {}
skipped = 0
for k, v in E6.items():
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        skipped += 1
        continue
    out[str(k)] = num(v)
path = os.path.join(HERE, 'E_fields.json')
with open(path, 'w') as f:
    json.dump(out, f, indent=1, sort_keys=True)
print(f'wrote {path}: {len(out)} fields ({skipped} non-numeric skipped)')
