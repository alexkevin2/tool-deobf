#!/usr/bin/env python3
"""v20 fingerprint (Luraph-Deobf-Tool-v6 routes/v20).

Fail-closed, shape-based detection for the Luraph v20.0 layout
(AnimeDice sample, Phase 1 analysis).  Every conjunct matches a
*shape* read from the file; no build-specific literal from any
sample (alphabet, seeds, keys, opcode words) appears here.

Required conjuncts:
  F1  comment-line-anchored ``Luraph Obfuscator v20.`` header in
      the first 2000 chars (same anchoring discipline as the v6
      version-header scan: a payload-embedded header string must
      not route).
  F2  ``local cF={`` + a single ``["SD"]`` long-bracket blob whose
      first 4096 chars are printable ASCII with a large distinct
      set (a base-85-style blob, not a literal alphabet check) +
      the self-cleaning entry shape: a rawset-move of the
      function-keyed VM entry under a fresh table key, followed
      by rawset-nil erasure of that entry, with the file's own
      alias names extracted from its ``local ... = function()
      return end, rawget, rawset, ...`` line (never hardcoded).
  F3  the base-85 decoder shape: an 85-iteration alphabet loop, a
      ``*85`` accumulation, and a ``%128`` varint reader.
Negative conjuncts (F4): no ``string.unpack``, no ``}).t(``
method entry, no bootstrap ``MY=[==[LPH`` / ``Fz=function``
markers.  If F1+F2+F3 hold but F4 fails, the caller must exit 2
with a conflict note -- never fall through to upstream.
"""
import re

_HEADER_RE = re.compile(r'(?m)^[ \t]*--.*Luraph Obfuscator v20\.')
# local HE=function()return end;local Al,nU,YQ,Ui=function()return end,rawget,rawset,...
_ALIAS_RE = re.compile(
    r'local\s+(\w+)\s*=\s*function\(\)\s*return\s+end\s*;\s*'
    r'local\s+(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*='
    r'\s*function\(\)\s*return\s+end\s*,\s*rawget\s*,\s*rawset\s*,')
_CF_RE = re.compile(r'local\s+cF\s*=\s*\{')
_SD_RE = re.compile(r'\["SD"\]\s*=\[=+\[')
_BASE85_LOOP_RE = re.compile(r'for\s+\w+\s*=\s*1\s*,\s*85\b')
_BASE85_ACC_RE = re.compile(r'\*\s*85\s*\+')
_VARINT_RE = re.compile(r'%\s*128\b')


def _blob_spot_check(src, sd_match):
    """First 4096 blob chars: printable ASCII, large distinct set."""
    blob = src[sd_match.end():sd_match.end() + 4096]
    if len(blob) < 1024:
        return False
    if any(ord(c) < 32 or ord(c) > 126 for c in blob):
        return False
    return len(set(blob)) >= 70


def detect_v20(src):
    """Return (matched, evidence dict). matched is True only when
    F1+F2+F3 hold and all F4 negatives hold."""
    ev = {}
    head = src[:2000]
    ev['F1_header_v20'] = bool(_HEADER_RE.search(head))
    cf = _CF_RE.search(src)
    sd = _SD_RE.search(src) if cf else None
    ev['F2_cF_table'] = bool(cf)
    ev['F2_SD_blob'] = bool(sd)
    ev['F2_blob_spot'] = bool(sd and _blob_spot_check(src, sd))
    alias = _ALIAS_RE.search(src)
    ev['F2_alias_line'] = bool(alias)
    ev['F2_self_clean'] = False
    if alias:
        he, _al, rawget_a, rawset_a, _ui = alias.groups()
        move = re.compile(
            re.escape(rawset_a) + r'\s*\(\s*\w+\s*,\s*\w+\s*,\s*' +
            re.escape(rawget_a) + r'\s*\(\s*\w+\s*,\s*' +
            re.escape(he) + r'\s*\)\s*\)')
        erase = re.compile(
            re.escape(rawset_a) + r'\s*\(\s*\w+\s*,\s*' +
            re.escape(he) + r'\s*,\s*nil\s*\)')
        m_move = move.search(src)
        ev['F2_self_clean'] = bool(
            m_move and erase.search(src, m_move.start(),
                                    m_move.start() + 600))
    ev['F3_base85_loop'] = bool(_BASE85_LOOP_RE.search(src))
    ev['F3_base85_acc'] = bool(_BASE85_ACC_RE.search(src))
    ev['F3_varint'] = bool(_VARINT_RE.search(src))
    ev['F4_no_string_unpack'] = 'string.unpack' not in src
    ev['F4_no_method_entry'] = not re.search(r'\}\)\.t\(', src)
    ev['F4_no_bootstrap'] = not (
        'MY=[==[' in src and 'LPH' in src[:2000]
        or re.search(r'\bFz=function', src) is not None)
    required = (ev['F1_header_v20'] and ev['F2_cF_table']
                and ev['F2_SD_blob'] and ev['F2_blob_spot']
                and ev['F2_alias_line'] and ev['F2_self_clean']
                and ev['F3_base85_loop'] and ev['F3_base85_acc']
                and ev['F3_varint'])
    negatives = (ev['F4_no_string_unpack'] and ev['F4_no_method_entry']
                 and ev['F4_no_bootstrap'])
    ev['conflict'] = bool(required and not negatives)
    return bool(required and negatives), ev
