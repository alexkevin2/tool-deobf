#!/usr/bin/env python3
"""luraph_v20.py — Luraph v20.0 route (Luraph-Deobf-Tool-v6).

A NEW route, not a luraph151.py extension: v20.0 shares no stage
with the v15.1 pipeline (single base-85 + varint-framed pool,
lazy per-constant XOR, table instructions + bit-tree dispatch,
stateful activation-dependent decoding).

Stages (in order, each gated before the next):
  1. head parse -- cF table, SD blob, alias names, VM argument
     tuple.  EVERY parameter (alphabet, Pq key, J seed, blob,
     entry key) is read from the file; no sample literal appears
     as a constant in this file.
  2. pool decode -- transcription of the file's own base-85
     decoder + varint framing.  Gate: framing must close exactly
     (length-table end == decoded end, sum(lengths) == BL).
  3. constant decryption -- transcription of the lazy constant
     layer (U/O3/Me/cR/NY/fw/UD/Pq/L6/oB/SZ/Qy).  Gated on an
     end-to-end known-plaintext check before generalisation.
  4. proto + block decode -- js/Ix/hH/le transcription; emits a
     JSON proto dump (instructions as l[0..12] tables + ty
     fields + oC constants).
  5. trace-verified lift -- routes/v20/lift.py, driven ONLY by
     a trace bundle (--trace-bundle <dir>: merged entry trace
     + child traces + continuation records).  Structured control
     flow only from the traced path; covered path only.
  6. qa_report.json recording the assumption + verdict.

Exit codes (house contract, v20 route): this route NEVER exits
0.  5 PARTIAL covers both shapes: (a) no trace bundle / lift
not built -- stages 1-4 proven, blocker named in report.md,
no source file; (b) PARTIAL-with-assumption -- a lifted source
for the covered path IS emitted (lifted.luau + lift_report.json
+ literal_equation.json), valid UNDER the O=0-at-boundary
assumption only, never as unconditional recovery.  2 means
not-this-layout / a stage gate failed before any recovery.
This route never executes the payload outside a Python
transcription/simulation, never fetches a URL from the sample,
and never hardcodes a game id.
"""
import argparse
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL_ROOT = os.path.dirname(os.path.dirname(HERE))
VERSION = '6.4.0'


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for blk in iter(lambda: f.read(1 << 20), b''):
            h.update(blk)
    return h.hexdigest()


# ---------------------------------------------------------------- stage 1
_ALIAS_RE = re.compile(
    r'local\s+(\w+)\s*=\s*function\(\)\s*return\s+end\s*;\s*'
    r'local\s+(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*='
    r'\s*function\(\)\s*return\s+end\s*,\s*rawget\s*,\s*rawset\s*,')
_CF_RE = re.compile(r'local\s+cF\s*=\s*\{')
_SD_RE = re.compile(r'\["SD"\]\s*=\[(=+)\[')
_ALPHABET_RE = re.compile(
    r'for\s+\w+\s*=\s*1\s*,\s*85\s+do\s+\w+\[ng\(\("((?:\\[0-9]{3})+)"\)')
_INNER_PARAMS_RE = re.compile(
    r'return\s*\(\s*function\s*\(([^)]*)\)')
_VM_FN_RE = re.compile(r'\[(\w+)\]\s*=\s*function\s*\(\s*(\w+)\s*,\s*\.\.\.\)\s*return\s*\(')


def _split_top_level(s):
    """Split on top-level commas (respect {}, (), strings, backticks)."""
    parts, cur, depth, quote = [], [], 0, None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == '\\' and i + 1 < len(s):
                cur.append(s[i + 1]); i += 2; continue
            if c == quote:
                quote = None
        elif c in ('"', "'", '`'):
            quote = c; cur.append(c)
        elif c in ('{', '('):
            depth += 1; cur.append(c)
        elif c in ('}', ')'):
            depth -= 1; cur.append(c)
        elif c == ',' and depth == 0:
            parts.append(''.join(cur).strip()); cur = []
        else:
            cur.append(c)
        i += 1
    if cur or not parts:
        parts.append(''.join(cur).strip())
    return parts


def _parse_arg(tok):
    tok = tok.strip()
    if tok == 'nil':
        return None
    if tok == 'false':
        return False
    if tok == 'true':
        return True
    if tok == '{}':
        return {}
    if tok == '...':
        return 'VARARG'
    m = re.fullmatch(r'-?[0-9]+', tok)
    if m:
        return int(tok)
    m = re.fullmatch(r'function\(\)\s*return\s+(-?[0-9]+)\s*end', tok)
    if m:
        return {'const_fn': int(m.group(1))}
    return {'raw': tok}


def head_parse(src):
    """Stage 1. Returns a dict of file-derived parameters."""
    alias = _ALIAS_RE.search(src)
    if not alias:
        raise ValueError('head parse: alias line not found')
    he, _al, rawget_a, rawset_a, _ui = alias.groups()
    cf = _CF_RE.search(src)
    sd = _SD_RE.search(src) if cf else None
    if not sd:
        raise ValueError('head parse: cF SD blob not found')
    level = len(sd.group(1))
    # True blob close: `]=...=` + `]` followed by `,` + a table-entry
    # start.  (A bare `]=]` can occur inside a base-85 blob by chance;
    # the `,` + entry-start conjunct makes a false close negligible,
    # and stage 2's exact-framing gate is the final arbiter.)
    close_re = re.compile(
        r'\]' + '=' * level + r'\]\s*,\s*\[')
    close = close_re.search(src, sd.end())
    if not close:
        raise ValueError('head parse: SD blob close not found')
    blob = src[sd.end():close.start()]
    vm_fn = _VM_FN_RE.search(src)
    if not vm_fn:
        raise ValueError('head parse: VM function entry not found')
    # NOTE: search from vm_fn.start(), not .end(): the VM regex
    # already consumed the inner function's `return(`, so a search
    # from .end() would skip the inner function entirely and land
    # on the file's final entry line instead.
    inner = _INNER_PARAMS_RE.search(src, vm_fn.start())
    if not inner:
        raise ValueError('head parse: VM inner function not found')
    params = [p.strip() for p in inner.group(1).split(',') if p.strip()]
    # VM invocation args sit just before `end,[<alias2>]=` (the
    # marker entry that follows the VM function in cF).  Locate
    # them by a backward balanced-paren scan from that marker --
    # a greedy regex here would swallow the whole VM body.
    marker = src.find('[' + _al + ']=', vm_fn.start())
    if marker < 0:
        raise ValueError('head parse: VM marker entry not found')
    tail = src[:marker]
    if not tail.rstrip().endswith('end,'):
        raise ValueError('head parse: VM invocation tail not found')
    close_paren = tail.rstrip()[:-4].rstrip()
    if not close_paren.endswith(')'):
        raise ValueError('head parse: VM invocation close not found')
    depth = 0
    j = len(close_paren) - 1
    while j >= 0:
        c = close_paren[j]
        if c == ')':
            depth += 1
        elif c == '(':
            depth -= 1
            if depth == 0:
                break
        j -= 1
    if depth != 0 or j < 1 or close_paren[j - 1] != ')':
        raise ValueError('head parse: VM invocation open not found')
    arg_toks = _split_top_level(close_paren[j + 1:-1])
    args = {}
    for name, tok in zip(params, arg_toks):
        args[name] = _parse_arg(tok)
    # The blob argument: the VM fn's first parameter is bound by the
    # entry call to the SD blob, so whichever inner parameter maps
    # to the blob identifier is the pool source.  In the observed
    # shape the inner parameter bound to the VM fn's first argument
    # carries the blob; resolve it by position: the invocation's
    # blob-identifier token is the VM fn's first parameter name.
    vm_first_param = vm_fn.group(2)
    blob_param = None
    for name, tok in zip(params, arg_toks):
        if tok.strip() == vm_first_param:
            blob_param = name
            break
    alpha = _ALPHABET_RE.search(src)
    if not alpha:
        raise ValueError('head parse: base-85 alphabet not found')
    alphabet = ''.join(chr(int(alpha.group(1)[i + 1:i + 4]))
                       for i in range(0, len(alpha.group(1)), 4))
    if len(alphabet) != 85 or len(set(alphabet)) != 85:
        raise ValueError('head parse: alphabet is not 85 distinct '
                         f'chars (got {len(alphabet)})')
    return {
        'vm_key_name': he,
        'rawget_alias': rawget_a,
        'rawset_alias': rawset_a,
        'blob': blob,
        'blob_level': level,
        'code': src[close.start():],
        'inner_params': params,
        'invocation_args': {k: (v if not isinstance(v, dict) else v)
                            for k, v in args.items()},
        'blob_param': blob_param,
        'alphabet': alphabet,
    }


# ---------------------------------------------------------------- stage 2
def base85_decode(text, alphabet):
    """Transcription of the file's UM decoder (group of 5 digits,
    pad with digit 84, emit first Tu-1 bytes big-endian)."""
    index = {ch: i for i, ch in enumerate(alphabet)}
    out = bytearray()
    i = 0
    n = len(text)
    while i < n:
        tu = 0
        ms = 0
        for k in range(5):
            if i + k < n:
                d = index.get(text[i + k])
                if d is None:
                    return None
                ms = ms * 85 + d
                tu += 1
        if tu < 2:
            return None
        for _ in range(tu + 1, 6):
            ms = ms * 85 + 84
        chunk = bytes(((ms >> 24) & 0xFF, (ms >> 16) & 0xFF,
                       (ms >> 8) & 0xFF, ms & 0xFF))
        out += chunk[:tu - 1]
        i += tu
    return bytes(out)


class _VarintReader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def read(self):
        j = 0
        w = 1
        while True:
            if self.pos >= len(self.data):
                raise ValueError('varint overrun')
            o = self.data[self.pos]
            self.pos += 1
            j += (o % 128) * w
            if o < 128:
                return j
            w *= 128


def pool_decode(decoded):
    """Transcription of the file's rm framing:
    [varint xO][varint BL][BL bytes][xO varint lengths].
    Gate: sum(lengths) == BL and the length table ends exactly at
    the end of the decoded blob."""
    r = _VarintReader(decoded)
    x_o = r.read()
    bl = r.read()
    data_start = r.pos
    r.pos = data_start + bl
    lengths = []
    total = 0
    off = 0
    entries = []
    for _ in range(x_o):
        ln = r.read()
        lengths.append(ln)
        # Offsets are ABSOLUTE in the decoded blob (the file's nT
        # returns {decoded, data_start + cumulative, length}).
        entries.append((data_start + off, ln))
        off += ln
        total += ln
    if total != bl:
        raise ValueError(f'pool gate: sum(lengths)={total} != BL={bl}')
    if r.pos != len(decoded):
        raise ValueError(f'pool gate: length table ends at {r.pos}, '
                         f'decoded blob is {len(decoded)} bytes')
    return {
        'xO': x_o, 'BL': bl, 'sum_len': total,
        'decoded_len': len(decoded),
        'data_start': data_start, 'entries': entries,
        'pool_bytes': decoded,
    }


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description='Luraph v20.0 route')
    ap.add_argument('input')
    ap.add_argument('-o', '--outdir', default=None)
    ap.add_argument('--luau', default=None)
    ap.add_argument('--spoof-id', choices=('auto', 'off'), default='auto')
    ap.add_argument('--qa-clean', choices=('on', 'off'), default='on')
    ap.add_argument('--trace-bundle', default=None,
                    help='trace bundle directory for the stage-5 '
                         'lift (merged entry trace + child traces '
                         '+ continuation records).  Without it no '
                         'source file is emitted; with it the '
                         'covered-path lift is emitted as '
                         'PARTIAL-with-assumption (exit 5, never '
                         '0).')
    args = ap.parse_args()

    data = open(args.input, 'rb').read()
    src = data.decode('utf-8', errors='strict')
    sha = hashlib.sha256(data).hexdigest()
    outdir = args.outdir or os.path.splitext(
        os.path.basename(args.input))[0] + '-v20-deobf'
    os.makedirs(outdir, exist_ok=True)
    print(f'[v20] Luraph-Deobf-Tool v{VERSION} (v20 route)')
    print(f'[v20] input: {args.input} ({len(data)} bytes, '
          f'sha256 {sha})')

    # Fingerprint re-check (fail-closed even on --route v20).
    sys.path.insert(0, HERE)
    try:
        import fingerprint as _fp
        ok, ev = _fp.detect_v20(src)
    finally:
        sys.path.remove(HERE)
    print(f'[v20] fingerprint: {ok} {ev}')
    if not ok:
        print('REJECTED: v20 fingerprint does not match.',
              file=sys.stderr)
        return 2

    try:
        head = head_parse(src)
    except ValueError as e:
        print(f'[v20] stage 1 FAILED: {e}', file=sys.stderr)
        return 2
    code = head['code']
    print(f"[v20] stage 1 head: blob {len(head['blob'])} chars, "
          f"alphabet {len(head['alphabet'])} chars, "
          f"inner params {head['inner_params']}, "
          f"blob param {head['blob_param']}")
    # Pq key / J seed are file-derived values, reported by parameter
    # name (never by sample literal): find them by role.
    pq_key = head['invocation_args'].get(head['inner_params'][0]) \
        if head['inner_params'] else None
    print(f"[v20] stage 1: first inner param "
          f"{head['inner_params'][0] if head['inner_params'] else None} "
          f"= {pq_key!r}; invocation args: "
          f"{ {k: (v if not isinstance(v, dict) else v) for k, v in head['invocation_args'].items()} }")

    decoded = base85_decode(head['blob'], head['alphabet'])
    if decoded is None:
        print('[v20] stage 2 FAILED: base-85 decode rejected a '
              'digit', file=sys.stderr)
        return 2
    try:
        pool = pool_decode(decoded)
    except ValueError as e:
        print(f'[v20] stage 2 FAILED: {e}', file=sys.stderr)
        return 2
    print(f"[v20] stage 2 pool: xO={pool['xO']} BL={pool['BL']} "
          f"sum={pool['sum_len']} decoded={pool['decoded_len']} "
          f'(framing closes exactly)')
    with open(os.path.join(outdir, 'pool.bin'), 'wb') as f:
        f.write(pool['pool_bytes'])
    with open(os.path.join(outdir, 'pool_stats.json'), 'w') as f:
        json.dump({'xO': pool['xO'], 'BL': pool['BL'],
                   'sum_len': pool['sum_len'],
                   'decoded_len': pool['decoded_len']}, f, indent=1)
    head_out = {
        'vm_key_name': head['vm_key_name'],
        'rawget_alias': head['rawget_alias'],
        'rawset_alias': head['rawset_alias'],
        'blob_chars': len(head['blob']),
        'blob_level': head['blob_level'],
        'inner_params': head['inner_params'],
        'invocation_args': {k: (v if not isinstance(v, dict) else v)
                            for k, v in head['invocation_args'].items()},
        'blob_param': head['blob_param'],
        'alphabet_len': len(head['alphabet']),
        'pool': {'xO': pool['xO'], 'BL': pool['BL'],
                 'sum_len': pool['sum_len'],
                 'decoded_len': pool['decoded_len']},
    }
    with open(os.path.join(outdir, 'head.json'), 'w') as f:
        json.dump(head_out, f, indent=1)

    # Stage 3 (constant decryption) + stage 4 (proto inventory,
    # incl. field-6 child recursion).  Any failure here is a
    # PARTIAL with a named blocker, never a fabricated lift.
    try:
        stage34 = run_stages_34(head, code, pool, src)
    except Exception as e:
        blocker = f'stage 3/4 failed: {type(e).__name__}: {e}'
        print(f'[v20] PARTIAL: {blocker}')
        _write_report(outdir, len(data), sha, pool, None, blocker,
                      None)
        _write_qa(outdir, blocker)
        print(f'done (PARTIAL v20) -> {outdir}')
        return 5
    with open(os.path.join(outdir, 'protos.json'), 'w') as f:
        json.dump(stage34, f, indent=1, sort_keys=True)
    print(f"[v20] stage 3 constants: {stage34['totals']} "
          f"(entry proto {stage34['entry_constants']} constants, "
          f"{stage34['protos_visited']} protos, "
          f"{stage34['errors']} errors)")
    print(f"[v20] stage 4 proto inventory: entry children "
          f"{stage34['entry_children']}, fields "
          f"{stage34['entry_fields']}")
    # Stage 5 (trace-verified lift): bundle-driven, covered path
    # only.  Without a bundle no source file is emitted --
    # emitting a fragment as "deobfuscated" would repeat the
    # v6.2.0 misroute.  With a bundle the lift is emitted as
    # PARTIAL-with-assumption (exit 5, never 0): valid UNDER the
    # bundle's O-at-boundary assumption only.
    if args.trace_bundle:
        try:
            sys.path.insert(0, HERE)
            import lift as _lift
            protos_for_lift = stage34
            source, lift_rep = _lift.lift_bundle(
                args.trace_bundle, protos=protos_for_lift)
        except Exception as e:
            blocker = (f'stage 5 lift refused/failed: '
                       f'{type(e).__name__}: {e}')
            print(f'[v20] PARTIAL: {blocker}')
            _write_report(outdir, len(data), sha, pool, stage34,
                          blocker, stage34)
            _write_qa(outdir, blocker)
            print(f'done (PARTIAL v20) -> {outdir}')
            return 5
        finally:
            if HERE in sys.path:
                sys.path.remove(HERE)
        with open(os.path.join(outdir, 'lifted.luau'), 'w') as f:
            f.write(source)
        with open(os.path.join(outdir, 'lift_report.json'),
                  'w') as f:
            json.dump(lift_rep, f, indent=1, sort_keys=True)
        with open(os.path.join(outdir, 'literal_equation.json'),
                  'w') as f:
            json.dump(lift_rep['literal_equation'], f, indent=1,
                      sort_keys=True)
        print('[v20] stage 5 lift: covered-path source emitted '
              '(PARTIAL-with-assumption, see lifted.luau header)')
        _write_report(outdir, len(data), sha, pool, stage34, None,
                      stage34, lift_rep=lift_rep)
        _write_qa(outdir, None, lift_rep=lift_rep)
        print(f'done (PARTIAL-with-assumption v20) -> {outdir}')
        return 5
    blocker = ('stage 5 (trace-verified lift) has no trace bundle: '
               'run with --trace-bundle <dir> (merged entry trace '
               '+ child traces + continuation records) to lift '
               'the covered path as PARTIAL-with-assumption; '
               'without it no source file is emitted.  Stages 1-4 '
               'are proven and their artifacts are in protos.json')
    print(f'[v20] PARTIAL: {blocker}')
    _write_report(outdir, len(data), sha, pool, stage34, blocker,
                  stage34)
    _write_qa(outdir, blocker)
    print(f'done (PARTIAL v20) -> {outdir}')
    return 5


def _find_by_path(ep, aliases, path):
    for val in list(ep.values()) + list(aliases.values()):
        if val and val[0] == path:
            return val[1]
    return None


def run_stages_34(head, code, pool, src):
    """Stages 3-4.  Returns the protos.json payload.  Raises
    decode.DecodeError (or ValueError/KeyError) on any gate
    failure -- the caller turns that into a named PARTIAL."""
    sys.path.insert(0, HERE)
    try:
        import decode as dec
    finally:
        sys.path.remove(HERE)
    # Pq key = the invocation argument bound to the VM inner
    # function's FIRST parameter (name read from the file, never
    # assumed).
    pq = dec.make_pq(
        head['invocation_args'][head['inner_params'][0]])
    ta = dec.decode_ta(code)
    params = dec.extract_params(code, pq)
    if params['kb_pool_index'] is None or params['rl_pool_index'] is None \
            or params['second_pool_index'] is None \
            or params['l6_seed'] is None or params['de'] is None \
            or params['magic'] is None:
        raise ValueError(f'stage 3: missing file parameters: '
                         f'{ {k: v for k, v in params.items() if v is None} }')
    entries = pool['entries']
    pool_bytes = pool['pool_bytes']
    qy = dec.decode_qy(dec.pool_entry(pool_bytes, entries,
                                      params['kb_pool_index']))
    l6 = dec.make_l6(params['l6_seed'])
    ep, aliases, _sz = dec.resolve_ep(code, qy, l6, pq, ta)
    bj = _find_by_path(ep, aliases, 'tostring')
    readu8 = _find_by_path(ep, aliases, 'buffer.readu8')
    if bj is None or readu8 is None:
        raise ValueError('stage 3: tostring/buffer.readu8 not '
                         'resolved through ep')
    ud, _lr = dec.make_ud(pq, bj, readu8)
    off, ln = entries[params['rl_pool_index'] - 1]
    # UD is hash-gated (Lr over the ciphertext): a mismatch raises
    # here, so a parsed entry proto is authenticated, not assumed.
    proto_bytes = ud({1: pool_bytes, 2: off + 1, 3: ln},
                     params['ud_key'], params['ud_nt'], params['ud_ik'])
    entry = dec.Proto(proto_bytes, magic=params['magic'])
    # Second stage (entry 740): Gp/lw tables for cR.
    gp_off = entries[params['second_pool_index'] - 1][0]
    gp = pool_bytes
    pos = [gp_off + 1]

    def e3_gp():
        j = 0
        w = 1
        while True:
            o = gp[pos[0] - 1]
            pos[0] += 1
            j += (o % 128) * w
            if o < 128:
                return j
            w *= 128

    lw = {}
    for f in range(1, e3_gp() + 1):
        k7 = e3_gp()
        lw[f] = (pos[0], k7)
        pos[0] += k7
    cr = dec.make_cr(gp, lw)
    fw_fn = lambda b: dec.fw_decode(b, pq)  # noqa: E731

    protos_out = []
    totals = {'number': 0, 'string_printable': 0, 'bytes_binary': 0,
              'table': 0, 'bool': 0, 'nil': 0, 'errors': 0}
    seen = set()

    def visit(data, start, depth, path):
        key = (id(data), start)
        if key in seen or depth > 6 or len(seen) >= 512:
            return
        seen.add(key)
        pr = dec.Proto(data, start=start) if start is not None \
            else dec.Proto(data, magic=params['magic'])
        rec = {'path': '/'.join(map(str, path)) or 'root',
               'fields': {str(bs): (cn[2] if cn[2] is not None
                                     else 'scalar')
                          for bs, cn in sorted(pr.fields.items())},
               'constants': []}
        try:
            oc = pr.field(17)
        except Exception:
            oc = None
        if oc is not None:
            layer = dec.ConstantLayer(oc, ud, fw_fn, cr, None, bj,
                                      params['y2'], params['de'])
            for f in range(1, oc.count + 1):
                try:
                    val = layer.constant(f)
                except Exception as e:
                    totals['errors'] += 1
                    rec['constants'].append(
                        {'index': f, 'kind': 'error',
                         'detail': f'{type(e).__name__}: {e}'[:120]})
                    continue
                if isinstance(val, bytes):
                    try:
                        s = val.decode('utf-8')
                        ratio = sum(c.isprintable() for c in s) \
                            / max(len(s), 1)
                    except UnicodeDecodeError:
                        s, ratio = None, 0.0
                    if s is not None and ratio > 0.9 and len(s) >= 2:
                        totals['string_printable'] += 1
                        rec['constants'].append(
                            {'index': f, 'kind': 'string', 'value': s})
                    else:
                        totals['bytes_binary'] += 1
                        rec['constants'].append(
                            {'index': f, 'kind': 'bytes',
                             'len': len(val)})
                elif isinstance(val, dict):
                    totals['table'] += 1
                    rec['constants'].append(
                        {'index': f, 'kind': 'table',
                         'keys': [str(k) for k in val.keys()]})
                elif isinstance(val, bool):
                    totals['bool'] += 1
                    rec['constants'].append(
                        {'index': f, 'kind': 'bool', 'value': val})
                elif isinstance(val, (int, float)):
                    totals['number'] += 1
                    rec['constants'].append(
                        {'index': f, 'kind': 'number', 'value': val})
                elif val is None:
                    totals['nil'] += 1
                    rec['constants'].append(
                        {'index': f, 'kind': 'nil'})
                else:
                    totals['errors'] += 1
                    rec['constants'].append(
                        {'index': f, 'kind': 'error',
                         'detail': f'unexpected {type(val).__name__}'})
        protos_out.append(rec)
        if depth >= 6:
            return
        try:
            children = pr.field(6) or []
        except Exception:
            children = []
        for ci, (wdata, cur, _clen) in enumerate(children, start=1):
            visit(wdata, cur, depth + 1, path + (ci,))

    visit(proto_bytes, None, 0, ())
    entry_rec = protos_out[0] if protos_out else {}
    return {
        'entry_constants': sum(
            1 for c in entry_rec.get('constants', [])
            if c['kind'] != 'error'),
        'entry_children': entry.fields[6][2],
        'entry_fields': {str(bs): (cn[2] if cn[2] is not None
                                    else 'scalar')
                         for bs, cn in sorted(entry.fields.items())},
        'protos_visited': len(protos_out),
        'totals': totals,
        'errors': totals['errors'],
        'aliases_resolved': {name: (val[0] if val else None)
                             for name, val in aliases.items()},
        'protos': protos_out,
    }


def _write_report(outdir, data_len, sha, pool, stage34, blocker,
                  _unused=None, lift_rep=None):
    with open(os.path.join(outdir, 'report.md'), 'w') as f:
        f.write('# luraph-deobf report — v20 route\n\n')
        f.write(f'- input: {data_len} bytes, sha256 `{sha}`\n')
        f.write('- route: v20.0 (new route, not a v15.1 extension)\n')
        f.write('- stage 1 head parse: PASS (blob, alphabet, '
                'alias names, VM invocation args all file-derived)\n')
        f.write(f"- stage 2 pool decode: PASS (xO={pool['xO']}, "
                f"BL={pool['BL']}, sum={pool['sum_len']}, "
                f"decoded={pool['decoded_len']}; framing closes "
                'exactly)\n')
        if stage34 is not None:
            f.write(f"- stage 3 constant decryption: PASS "
                    f"(entry proto authenticated by its UD/Lr hash; "
                    f"{stage34['protos_visited']} protos, "
                    f"{stage34['totals']} constants, "
                    f"{stage34['errors']} errors; see protos.json)\n")
            f.write(f"- stage 4 proto inventory: PASS (entry "
                    f"children {stage34['entry_children']}; "
                    f"field-6 recursion, depth <= 6)\n")
        else:
            f.write('- stage 3/4: FAILED (see blocker)\n')
        if lift_rep is not None:
            f.write('- stage 5 trace-verified lift: EMITTED '
                    '(covered path only, bundle-driven; see '
                    'lifted.luau + lift_report.json + '
                    'literal_equation.json)\n')
            f.write('- stage 6 source-clean: NOT STARTED '
                    '(lifted source is the traced-path lift, not '
                    'a cleaned general program)\n')
            f.write('- status: **PARTIAL-with-assumption** '
                    '(exit 5, never FULL, never exit 0)\n')
            f.write('- ASSUMPTION (verbatim from the trace '
                    'bundle; the lifted source is valid UNDER '
                    'this assumption only, never unconditionally '
                    'proven):\n')
            for al in lift_rep['assumption'].split('\n'):
                f.write(f'  > {al}\n' if al else '  >\n')
            f.write(f"- unexecuted positions: "
                    f"{lift_rep['unexecuted']}\n")
            f.write('- second stage entered: '
                    f"{lift_rep['second_stage_entered']}\n")
            f.write(f"- terminus: {lift_rep['terminus']}\n")
            f.write(f"- literal equation: "
                    f"{lift_rep['literal_equation']['ok']} "
                    f"(missing "
                    f"{lift_rep['literal_equation']['missing_numbers']} "
                    f"/ "
                    f"{lift_rep['literal_equation']['missing_strings']}; "
                    f"invented "
                    f"{lift_rep['literal_equation']['invented_numbers']} "
                    f"/ "
                    f"{lift_rep['literal_equation']['invented_strings']})\n")
            f.write('- artifacts: pool.bin, pool_stats.json, '
                    'head.json, protos.json, lifted.luau, '
                    'lift_report.json, literal_equation.json, '
                    'qa_report.json\n')
        else:
            f.write('- stage 5 trace-verified lift: NOT EMITTED '
                    '(no trace bundle on this run)\n')
            f.write('- stage 6 source-clean: NOT STARTED\n')
            f.write(f'- status: **PARTIAL** — blocker: {blocker}\n')
            f.write('- artifacts: pool.bin, pool_stats.json, '
                    'head.json, protos.json (decoded constants + '
                    'proto inventory; no source file is emitted '
                    'without a trace bundle)\n')


def _write_qa(outdir, blocker, lift_rep=None):
    # QA report (shared module, audit-only for this route's
    # artifacts).  With a lift, the report records the
    # assumption + verdict explicitly; without one it records
    # the proven stages and the blocker instead of inventing a
    # source file.  The assumption string is copied verbatim
    # from the lift report (which read it from the bundle), so
    # qa_report.json can never drift from lifted.luau's header.
    try:
        sys.path.insert(0, TOOL_ROOT)
        import qa_report as _qr
        defects = []
        if blocker is not None:
            defects.append(
                {'file': None, 'line': None,
                 'category': 'v20-stage-blocker', 'detail': blocker})
        rep = _qr.build_report(
            VERSION, 'method-v20',
            {}, {}, None, {}, defects,
            qa_enabled=False)
        if lift_rep is not None:
            rep['verdict'] = 'PARTIAL-with-assumption'
            rep['assumption'] = lift_rep['assumption']
            rep['assumption_applies'] = \
                lift_rep['assumption_applies']
            rep['lifted_source'] = 'lifted.luau'
            rep['unexecuted'] = lift_rep['unexecuted']
            rep['second_stage_entered'] = \
                lift_rep['second_stage_entered']
            rep['terminus'] = lift_rep['terminus']
            rep['literal_equation_ok'] = \
                lift_rep['literal_equation']['ok']
        with open(os.path.join(outdir, 'qa_report.json'), 'w') as f:
            json.dump(rep, f, indent=1)
    except Exception as e:
        print(f'[v20] qa report not written: {e}')
    finally:
        if TOOL_ROOT in sys.path:
            sys.path.remove(TOOL_ROOT)


if __name__ == '__main__':
    sys.exit(main())
