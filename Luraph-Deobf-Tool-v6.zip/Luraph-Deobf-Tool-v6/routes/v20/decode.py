#!/usr/bin/env python3
"""decode.py — v20.0 decoder transcriptions (Luraph-Deobf-Tool-v6).

Pure-Python transcriptions of the file's own decoder functions,
driven by parameters READ FROM THE FILE (alphabet, Pq key, L6/ns
seeds, pool-entry indices, Y2 key prefix, dE, UD entry-proto
arguments).  No per-build literal from any sample appears here as
a decoder input; the small set of named protocol constants below
(varint framing, fw/oO tag bytes, L6 multipliers) is part of the
v20.0 format itself as transcribed in Phase 1, not per-build data.

Luau value model: Python None = nil, bool, int/float = number,
bytes = Luau string (byte string), dict = Luau table (int keys
are 1-based array slots; 0/-1/-2/-4 keys are the VM's sentinel
slots).  Two sentinel objects stand for the VM's unique tables
(sx = nil-sentinel, fM = unmaterialised-constant set).

Covered: Pq, L6, oB (+ Qy + tA + ep + 17-alias resolution),
NY (number decoder, needs caller keys), UD (all key modes),
Lr (HMAC-SHA256, verified against the entry-proto hash),
fw (tagged-value reader), cR (repeating-key XOR), y0, Me/O3
(lazy constants), js (proto reader: E3/bz/hd/oO/mj/fk/iH +
Nn field scan) + T1 field readers (fields 1..18, incl. the
lazy oC constant table = field 17).
"""
import hashlib
import hmac as _hmac
import re
import struct

MOD = 2147483647

# --- v20.0 decoder-protocol constants (format, not per-build data)
E3_BIAS = 145          # js E3: o = (byte - 145) % 256, then LEB128
FW_TAGS = {'nil': 65, 'false': 81, 'true': 179, 'number': 215,
           'int': 64, 'double': 225, 'string': 149, 'table': 21}
L6_MUL = (65599, 257, 131, 104729, 131, 17, 7919)  # see L6 below


class DecodeError(Exception):
    pass


class _Sentinel:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f'<{self.name}>'


SX = _Sentinel('sx-nil')
FM = _Sentinel('fM-unmaterialised')


# ---------------------------------------------------------------- Luau bits
def _mask32(x):
    return x & 0xFFFFFFFF


def bxor(a, b):
    return _mask32(a) ^ _mask32(b)


def band(a, b):
    return _mask32(a) & _mask32(b)


def bnot(a):
    return _mask32(~a)


def rshift(a, n):
    return (_mask32(a) >> n) & 0xFFFFFFFF


def rrotate(a, n):
    a = _mask32(a)
    n %= 32
    return ((a >> n) | (a << (32 - n))) & 0xFFFFFFFF if n else a


def luau_mod(a, b):
    """Lua/Luau % : floored modulo (Python % already floors)."""
    return a % b


def luau_byte(data, pos):
    """string.byte, 1-based; None out of range."""
    if 1 <= pos <= len(data):
        return data[pos - 1]
    return None


def luau_sub(data, a, b=None):
    """string.sub, 1-based with negative-from-end semantics."""
    n = len(data)
    if b is None:
        b = -1
    if a < 0:
        a = n + a + 1
    if b < 0:
        b = n + b + 1
    a = max(a, 1)
    b = min(b, n)
    if a > b:
        return b''
    return data[a - 1:b]


def luau_tonumber(s, base=None):
    if isinstance(s, (int, float)):
        return s
    try:
        if base is not None:
            return int(s.strip(), base)
        return int(s)
    except (ValueError, TypeError):
        pass
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def luau_tostring(v):
    if isinstance(v, bytes):
        return v
    if v is True:
        return b'true'
    if v is False:
        return b'false'
    if v is None:
        return b'nil'
    if isinstance(v, float):
        if v == int(v) and abs(v) < 1e15:
            return str(int(v)).encode()
        return repr(v).encode()
    return str(v).encode()


# ---------------------------------------------------------------- Pq / L6
def make_pq(l_key):
    """Pq(list): char((o - L - pos) % 256) per 1-based position."""
    def pq(nums):
        return bytes(((o - l_key - (i + 1)) % 256)
                     for i, o in enumerate(nums))
    return pq


def make_l6(seed):
    """L6(name, T, GJ): keyed hash over the name's bytes."""
    m1, m2, m3, c1, lm, pa, c2 = L6_MUL

    def l6(name, t, gj):
        if isinstance(name, str):
            name = name.encode()
        ds = (seed * m1 + t * m2 + gj * m3 + c1) % MOD
        for pos, b in enumerate(name, start=1):
            ds = (ds * lm + b * (pos + pa) + c2) % MOD
        return ds
    return l6


# ---------------------------------------------------------------- pool helpers
def pool_entry(pool, entries, idx):
    """sC(idx): (decoded_bytes, absolute_offset_1based, length).

    entries are (absolute_offset_0based, length) from pool_decode;
    the VM's offsets are 1-based positions in the decoded blob, so
    a slice is decoded[off : off+len] with off 0-based here."""
    off, ln = entries[idx - 1]
    return pool[off:off + ln]


# ---------------------------------------------------------------- Qy + ep
def decode_ta(code):
    """tA: the 20 decimal-escaped library names, in file order."""
    m = re.search(r'local tA,Kb=\{((?:"(?:\\[0-9]{3})+")'
                  r'(?:,(?:"(?:\\[0-9]{3})+"))*)\}', code)
    if not m:
        raise DecodeError('tA table not found')
    names = []
    for lit in re.findall(r'"((?:\\[0-9]{3})+)"', m.group(1)):
        names.append(''.join(chr(int(lit[i + 1:i + 4]))
                             for i in range(0, len(lit), 4)))
    return names


def decode_qy(entry207):
    """d5 varint lists over pool entry 207: Qy[sE] = [varints]."""
    pos = 0

    def d5():
        nonlocal pos
        j = 0
        w = 1
        while True:
            if pos >= len(entry207):
                raise DecodeError('d5 overrun')
            o = entry207[pos]
            pos += 1
            j += (o % 128) * w
            if o < 128:
                return j
            w *= 128
    fc = d5()
    qy = []
    for _ in range(fc):
        hf = d5()
        qy.append([d5() for _ in range(hf)])
    return qy


# Mock _G: function objects are identified by their Luau path; only
# the functions the VM actually resolves through oB need callables.
def _mock_env():
    import math as _math
    bit32 = {'band': ('bit32.band', band),
             'bxor': ('bit32.bxor', bxor),
             'bnot': ('bit32.bnot', bnot),
             'rshift': ('bit32.rshift', rshift),
             'rrotate': ('bit32.rrotate', rrotate),
             'lshift': ('bit32.lshift',
                        lambda a, n: _mask32(a << n)),
             'arshift': ('bit32.arshift',
                         lambda a, n: (_mask32(a) >> n) if a < 2**31
                         else -((~_mask32(a) + 1) >> n)),
             'bor': ('bit32.bor', lambda a, b: _mask32(a) | _mask32(b)),
             'btest': ('bit32.btest', lambda a, b: (a & b) != 0),
             'extract': ('bit32.extract',
                         lambda a, f, w=1: (_mask32(a) >> f) & ((1 << w) - 1)),
             'replace': ('bit32.replace',
                         lambda a, v, f, w=1: (_mask32(a) & ~(((1 << w) - 1) << f)) | ((v & ((1 << w) - 1)) << f)),
             'countlz': ('bit32.countlz', lambda a: 32 - _mask32(a).bit_length() if a else 32),
             'countrz': ('bit32.countrz', lambda a: ( _mask32(a) & -_mask32(a)).bit_length() - 1 if a else 32)}
    string = {'byte': ('string.byte', luau_byte),
              'char': ('string.char', lambda *bs: bytes(bs)),
              'sub': ('string.sub', luau_sub),
              'rep': ('string.rep', lambda s, n: s * n),
              'unpack': ('string.unpack',
                         lambda fmt, data, pos=1: (struct.unpack('<d', data[pos - 1:pos + 7])[0],) if fmt == '<d' else (None,)),
              'len': ('string.len', len),
              'format': ('string.format', None)}
    buffer = {'create': ('buffer.create', lambda n: bytearray(n)),
              'readu8': ('buffer.readu8', lambda b, o: b[o]),
              'writeu8': ('buffer.writeu8',
                          lambda b, o, v: b.__setitem__(o, v & 0xFF)),
              'fromstring': ('buffer.fromstring', lambda s: bytearray(s)),
              'tostring': ('buffer.tostring', lambda b: bytes(b)),
              'len': ('buffer.len', len)}
    table = {'concat': ('table.concat',
                        lambda t, sep=b'', i=1, j=None: sep.join(
                            luau_tostring(t[k]) for k in
                            range(i, (j if j is not None else max(
                                [k for k in t if isinstance(k, int)], default=0)) + 1))),
             'unpack': ('table.unpack', None)}
    env = {'bit32': bit32, 'string': string, 'buffer': buffer,
           'table': table,
           'math': {'floor': ('math.floor', lambda x: int(x // 1))},
           'debug': {'info': ('debug.info', None)},
           'getmetatable': ('getmetatable', None),
           'setmetatable': ('setmetatable', None),
           'rawequal': ('rawequal', lambda a, b: a is b),
           'select': ('select', None),
           'tostring': ('tostring', luau_tostring),
           'tonumber': ('tonumber', luau_tonumber),
           'type': ('type', lambda v: 'boolean' if isinstance(v, bool) else 'table' if isinstance(v, dict) else 'string' if isinstance(v, bytes) else 'number' if isinstance(v, (int, float)) else 'nil'),
           'typeof': ('typeof', lambda v: 'boolean' if isinstance(v, bool) else 'table' if isinstance(v, dict) else 'string' if isinstance(v, bytes) else 'number' if isinstance(v, (int, float)) else 'nil'),
           'unpack': ('unpack', None),
           'rawget': ('rawget', None),
           'rawset': ('rawset', None),
           'pcall': ('pcall', None),
           'error': ('error', None),
           'pairs': ('pairs', None),
           'ipairs': ('ipairs', None),
           'next': ('next', None)}
    return env


def resolve_ep(code, qy, l6, pq, ta_names):
    """Resolve the ep table: direct oB assignments + SZ lazy map,
    then the 17-alias multi-assign.  Returns (ep_dict, aliases,
    sz) where aliases maps alias name -> (path, callable-or-None)
    (None = the key is not resolvable through ep: recorded, not
    guessed)."""
    env = _mock_env()
    ep = {}
    # The env itself: ep[<key>] = (getfenv() or _G), key read from
    # the file (the numeric key is build-specific, not a constant).
    m_env = re.search(r'ep\[(\d+)\]=\(\(getfenv', code)
    if m_env:
        ep[int(m_env.group(1))] = ('_G', env)

    def ob(path_hashes, t):
        r = env
        for f, want in enumerate(path_hashes, start=1):
            found = None
            for name in ta_names:
                if l6(name, t, f) == want:
                    found = name
                    break
            if found is None:
                raise DecodeError(f'oB: no tA name matches hash '
                                  f'{want} (T={t}, step={f})')
            if isinstance(r, dict) and found in r:
                r = r[found]
            else:
                raise DecodeError(f'oB: path step {found!r} not in '
                                  'mock env')
        return r

    # Direct assignments: ep[<key>]=oB(Qy[<n>],<n>)
    for m in re.finditer(r'ep\[("[^"]+"|\d+)\]\s*=\s*oB\(Qy\[(\d+)\],\s*(\d+)\)', code):
        key_tok, qn, t = m.group(1), int(m.group(2)), int(m.group(3))
        key = _unescape_key(key_tok)
        ep[key] = ob(qy[qn - 1], t)
    # SZ lazy map: SZ={[key]=qy_index,...}
    sz = {}
    m = re.search(r'local SZ=\{([^}]*)\}', code)
    if m:
        for km in re.finditer(r'\[("[^"]+"|\d+)\]\s*=\s*(\d+)', m.group(1)):
            sz[_unescape_key(km.group(1))] = int(km.group(2))
    for key, qn in sz.items():
        if key not in ep:
            ep[key] = ob(qy[qn - 1], qn)
    # 17-alias multi-assign: names = ep[...] in order.
    m = re.search(r'local ((?:\w+,)+\w+)=ep\[', code)
    if not m:
        raise DecodeError('alias multi-assign not found')
    names = [n.strip() for n in m.group(1).split(',')]
    keys = []
    seg = code[m.start():]
    for km in re.finditer(r'ep\[("[^"]+"|\d+)\]', seg):
        keys.append(_unescape_key(km.group(1)))
        if len(keys) == len(names):
            break
    aliases = {}
    for name, key in zip(names, keys):
        if key in ep:
            aliases[name] = ep[key]
        else:
            aliases[name] = None
    return ep, aliases, sz


def _unescape_key(tok):
    tok = tok.strip()
    if tok.startswith('"'):
        body = tok[1:-1]
        out = ''
        i = 0
        while i < len(body):
            if body[i] == '\\' and body[i + 1:i + 4].isdigit():
                out += chr(int(body[i + 1:i + 4]))
                i += 4
            else:
                out += body[i]
                i += 1
        return out
    return int(tok)


# ---------------------------------------------------------------- js proto reader
class Proto:
    """Transcription of js(W, UW, Qm) + the T1 field reader.

    data: proto bytes (Luau string).  cursor is 1-based (LW).
    fields: Nn[BS] = (cursor_start, cursor_after, count, entries)
    exactly as scanned by js.  field() mirrors T1's lazy readers
    (memoised; nil results cached as SX internally, returned as
    None).  constants() returns the field-17 oC lazy table.
    """

    def __init__(self, data, start=None, magic=None):
        self.data = data
        if start is None:
            if magic is not None and data[:4] != magic:
                raise DecodeError('js magic mismatch')
            self.cursor = 5
        else:
            self.cursor = start
        self.fields = {}
        self._cache = {}
        self._scan()

    # -- primitive readers (cursor = self.cursor, 1-based)
    def _byte(self):
        b = luau_byte(self.data, self.cursor)
        if b is None:
            raise DecodeError('js byte overrun')
        return b

    def e3(self):
        j = 0
        w = 1
        while True:
            o = self._byte()
            o = (o - E3_BIAS) % 256
            self.cursor += 1
            j += (o % 128) * w
            if o < 128:
                return j
            w *= 128

    def bz(self):
        j = self.e3()
        return j // 2 if j % 2 == 0 else -(j + 1) // 2

    def hd(self):
        k = self.e3()
        s = luau_sub(self.data, self.cursor, self.cursor + k - 1)
        self.cursor += k
        return s

    def oo(self):
        tag = self._byte()
        self.cursor += 1
        if tag == FW_TAGS['nil']:
            return None
        if tag == FW_TAGS['false']:
            return False
        if tag == FW_TAGS['true']:
            return True
        if tag == FW_TAGS['number']:
            return luau_tonumber(self.hd().decode('utf-8', 'replace'))
        if tag == FW_TAGS['int']:
            return self.bz()
        if tag == FW_TAGS['double']:
            raw = luau_sub(self.data, self.cursor, self.cursor + 7)
            self.cursor += 8
            return struct.unpack('<d', raw)[0]
        if tag == FW_TAGS['string']:
            return self.hd()
        if tag == FW_TAGS['table']:
            z = {}
            j = self.e3()
            for f in range(1, j + 1):
                z[f] = self.oo()
            j2 = self.e3()
            for _ in range(j2):
                k = self.oo()
                z[k] = self.oo()
            return z
        raise DecodeError(f'oO unknown tag {tag} at cursor '
                          f'{self.cursor - 1}')

    def mj(self):
        tag = self._byte()
        self.cursor += 1
        if tag in (FW_TAGS['nil'], FW_TAGS['false'], FW_TAGS['true']):
            return
        if tag in (FW_TAGS['number'], FW_TAGS['string']):
            k = self.e3()
            self.cursor += k
            return
        if tag == FW_TAGS['int']:
            self.e3()
            return
        if tag == FW_TAGS['double']:
            self.cursor += 8
            return
        if tag == FW_TAGS['table']:
            j = self.e3()
            for _ in range(j):
                self.mj()
            j2 = self.e3()
            for _ in range(j2):
                self.mj()
                self.mj()
            return
        raise DecodeError(f'mj unknown tag {tag}')

    def ih(self, t7):
        tag = self._byte()
        self.cursor += 1
        if tag != FW_TAGS['table']:
            raise DecodeError('iH: not a table tag')
        j = self.e3()
        cursors = {}
        for f in range(1, j + 1):
            cursors[f] = self.cursor
            self.mj()
        w = self.e3()
        for _ in range(w):
            k = self.oo()
            cursors[k] = self.cursor
            self.mj()
        z = {}
        saved = self.cursor
        for f, cur in cursors.items():
            self.cursor = cur
            if t7 == 1 and (f == 1 or f == 2):
                z[f] = self.ih(2 if f == 2 else 0)
            else:
                z[f] = self.oo()
        self.cursor = saved
        z['__len__'] = j
        return z

    def fk(self, pos=None):
        if pos is not None:
            self.cursor = pos
        return self.cursor

    def _scan(self):
        f = self.fields
        c = self

        def blk(fn):
            t4 = c.cursor
            out = fn()
            return t4, c.cursor, out

        t4, _, _ = blk(lambda: c.e3())
        f[2] = (t4, c.cursor, None, None)
        t4, _, _ = blk(lambda: c.e3())
        f[15] = (t4, c.cursor, None, None)
        t4 = c.cursor
        j = c.e3()
        dj = {}
        for k in range(1, j + 1):
            dj[k] = c.cursor
            c.mj()
        f[17] = (t4, c.cursor, j, dj)
        t4 = c.cursor
        c.mj()
        f[8] = (t4, c.cursor, None, None)
        t4 = c.cursor
        j = c.e3()
        for _ in range(j):
            c.mj()
        f[7] = (t4, c.cursor, j, None)
        t4 = c.cursor
        j = c.e3()
        dj = {}
        for k in range(1, j + 1):
            xn = c.e3()
            dj[k] = (c.cursor, xn)
            for _ in range(xn):
                c.mj()
        f[16] = (t4, c.cursor, j, dj)
        t4 = c.cursor
        c.mj()
        f[1] = (t4, c.cursor, None, None)
        t4, _, _ = blk(lambda: c.e3())
        f[5] = (t4, c.cursor, None, None)
        t4 = c.cursor
        c.mj()
        f[11] = (t4, c.cursor, None, None)
        t4 = c.cursor
        c.cursor += 1
        f[9] = (t4, c.cursor, None, None)
        t4, _, _ = blk(lambda: c.e3())
        f[4] = (t4, c.cursor, None, None)
        t4 = c.cursor
        c.mj()
        f[13] = (t4, c.cursor, None, None)
        t4, _, _ = blk(lambda: c.e3())
        f[10] = (t4, c.cursor, None, None)
        t4 = c.cursor
        j = c.e3()
        for _ in range(j):
            c.e3()
        f[3] = (t4, c.cursor, j, None)
        t4, _, _ = blk(lambda: c.e3())
        f[14] = (t4, c.cursor, None, None)
        t4 = c.cursor
        c.mj()
        f[12] = (t4, c.cursor, None, None)
        t4 = c.cursor
        j = c.e3()
        dj = {}
        for k in range(1, j + 1):
            k7 = c.e3()
            dj[j - k + 1] = (c.cursor, k7)
            c.cursor += k7
        f[6] = (t4, c.cursor, j, dj)
        t4, _, _ = blk(lambda: c.e3())
        f[18] = (t4, c.cursor, None, None)

    # -- T1 field readers (memoised)
    def field(self, bs):
        if bs in self._cache:
            v = self._cache[bs]
            return None if v is SX else v
        cn = self.fields.get(bs)
        if cn is None:
            self._cache[bs] = SX
            return None
        saved = self.cursor
        self.cursor = cn[0]
        try:
            r = self._read_field(bs, cn)
        finally:
            self.cursor = saved
        self._cache[bs] = SX if r is None else r
        return r

    def _read_field(self, bs, cn):
        if bs == 1:
            return self.ih(1)
        if bs == 2:
            return self.e3()
        if bs == 3:
            j = self.e3()
            return [self.bz() for _ in range(j)]
        if bs in (4, 5):
            return self.bz()
        if bs == 6:
            ff = []
            for k in range(1, cn[2] + 1):
                xn = cn[3][k]
                ff.append((self.data, xn[0], xn[1]))
            return ff
        if bs == 7:
            j = self.e3()
            return [self.oo() for _ in range(j)]
        if bs in (8, 11, 12, 13):
            return self.oo()
        if bs == 9:
            return luau_byte(self.data, self.cursor)
        if bs == 10:
            return self.e3()
        if bs in (14, 15):
            return self.bz()
        if bs == 16:
            out = {}
            for k in range(1, cn[2] + 1):
                cur, cnt = cn[3][k]
                saved = self.cursor
                self.cursor = cur
                try:
                    out[k] = [self.oo() for _ in range(cnt)]
                finally:
                    self.cursor = saved
            return out
        if bs == 17:
            return OCLazy(self, cn)
        if bs == 18:
            return self.e3()
        raise DecodeError(f'unknown proto field {bs}')


class OCLazy:
    """Field-17 constant table: Di[f] starts as a thunk
    {[0]=FM, [-1]=cursor}; the loader (Di[-1]) materialises it
    once via oO(); Di[-2]=FM, Di[-4]=SX (nil sentinel)."""

    def __init__(self, proto, cn):
        self.proto = proto
        self.count = cn[2]
        self.cursors = cn[3]
        self._done = set()
        self._vals = {}

    def raw(self, f):
        """U/O3's view of oC[f] before materialisation."""
        if f in self._done:
            return self._vals.get(f, SX)
        if 1 <= f <= self.count:
            return {'thunk': True, 0: FM, -1: self.cursors[f]}
        if f == -2:
            return FM
        if f == -4:
            return SX
        if f == -1:
            return 'loader'
        return None

    def load(self, f):
        if f in self._done:
            return self._vals.get(f)
        if not (1 <= f <= self.count):
            return None
        proto = self.proto
        saved = proto.cursor
        proto.cursor = self.cursors[f]
        try:
            v = proto.oo()
        finally:
            proto.cursor = saved
        self._done.add(f)
        self._vals[f] = v
        return v

    def get(self, f):
        """U(f) without SE handling (see ConstantLayer): thunk
        tables materialise; SX becomes None."""
        r = self.raw(f)
        if isinstance(r, dict) and r.get(0) is FM:
            r = self.load(f)
            return None if r is SX else r
        if r is SX:
            return None
        return r


# ---------------------------------------------------------------- fw
def fw_decode(data, pq):
    """fw: tagged-value reader over a decrypted sub-blob."""
    pos = [1]

    def fi():
        j = 0
        w = 1
        while True:
            o = luau_byte(data, pos[0])
            if o is None or w > 9007199254740991:
                raise DecodeError('fw varint failure')
            pos[0] += 1
            j += (o % 128) * w
            if o < 128:
                return j
            w *= 128

    sub_name = pq([174, 177, 159])

    def i0():
        k = fi()
        if k > len(data) - pos[0] + 1:
            raise DecodeError('fw string overrun')
        s = luau_sub(data, pos[0], pos[0] + k - 1)
        pos[0] += k
        return s

    def tz():
        hn = luau_byte(data, pos[0])
        pos[0] += 1
        if hn == 65:
            return None
        if hn == 81:
            return False
        if hn == 179:
            return True
        if hn == 215:
            return luau_tonumber(i0().decode('utf-8', 'replace'))
        if hn == 64:
            j = fi()
            return j // 2 if j % 2 == 0 else -(j + 1) // 2
        if hn == 149:
            return i0()
        if hn == 21:
            z = {}
            j = fi()
            if j > len(data):
                raise DecodeError('fw table overrun')
            for k in range(1, j + 1):
                z[k] = tz()
            xo = fi()
            if xo > len(data):
                raise DecodeError('fw table overrun')
            for _ in range(xo):
                k = tz()
                z[k] = tz()
            return z
        raise DecodeError(f'fw unknown tag {hn}')

    r = tz()
    if pos[0] != len(data) + 1:
        raise DecodeError('fw trailing bytes')
    return r


# ---------------------------------------------------------------- UD / Lr
def hmac_sha256_hex(key, msg):
    return _hmac.new(key, msg, hashlib.sha256).hexdigest().encode()


def make_ud(pq, bj_tostring, readu8_fn):
    """UD(W, Di, nT, iK) -> decrypted bytes (or raises).
    bj_tostring: BJ callable (tostring).  readu8_fn: ep[911432]
    callable (buffer.readu8 over bytes)."""

    def lr(w, di):
        o = bj_tostring(di)
        if isinstance(o, str):
            o = o.encode()
        if len(o) > 64:
            o = hashlib.sha256(o).digest()
        o = o + b'\x00' * (64 - len(o))
        ipad = bytes(bxor(b, 54) for b in o)
        opad = bytes(bxor(b, 92) for b in o)
        inner = hashlib.sha256(ipad + w).digest()
        return hashlib.sha256(opad + inner).hexdigest().encode()

    def ud(w, di, nt=None, ik=None):
        if isinstance(di, bytes):
            dg = 'string'
        elif isinstance(di, (int, float)):
            dg = 'number'
        elif isinstance(di, dict):
            dg = 'table'
        else:
            raise DecodeError('UD: bad key type')
        if dg == 'string' and len(di) == 0:
            raise DecodeError('UD: empty string key')
        if dg == 'table' and not all(
                isinstance(di.get(k), (int, float)) for k in (1, 2, 3)):
            raise DecodeError('UD: bad table key')
        ne = di
        if dg == 'table':
            ne = (bj_tostring(di[1]) + pq([117]) +
                  bj_tostring(di[2]) + pq([117]) +
                  bj_tostring(di[3]))
            if isinstance(ne, str):
                ne = ne.encode()
        # W[1]==164 slice form
        if isinstance(w, dict) and w.get(1) == 164:
            ww, j = w[4], w[3]
            if not isinstance(ww, bytes) or not isinstance(j, (int, float)):
                raise DecodeError('UD: bad 164 form')
            if j < 1 or len(ww) < j:
                raise DecodeError('UD: bad 164 form')
            if w[2] == 1:
                g6 = luau_sub(ww, 1, j)
                ww = luau_sub(ww, j + 1)
            else:
                g6 = luau_sub(ww, len(ww) - j + 1)
                ww = luau_sub(ww, 1, len(ww) - j)
            w = (119, ww) if w.get(5) == 1 else ww
        tq = None
        if isinstance(w, dict) and isinstance(w.get(1), bytes) \
                and isinstance(w.get(2), (int, float)) \
                and isinstance(w.get(3), (int, float)):
            tq = w
            if ik is not None:
                w = luau_sub(w[1], w[2], w[2] + w[3] - 1)
                tq = None
        if isinstance(w, dict) and w.get(1) == 233:
            nt, ik, w = w[3], w[4], w[2]
        if ik is not None:
            if isinstance(w, bytes):
                d = w
            else:
                raise DecodeError('UD: hash check needs string data')
            bj_ne = bj_tostring(ne)
            if isinstance(bj_ne, str):
                bj_ne = bj_ne.encode()
            salt = (nt if isinstance(nt, bytes) else bytes(nt)) \
                + pq([59]) + bj_ne
            if lr(d, salt) != (ik if isinstance(ik, bytes)
                               else bytes(ik)):
                raise DecodeError('UD: Lr hash mismatch')
            w = d
        if tq is not None:
            dh, vw, j = tq[1], tq[2], tq[3]
        else:
            if not isinstance(w, bytes):
                w = bytes(w)
            j = len(w)
        out = bytearray(j)
        um = int(di) % MOD if dg == 'number' else 0
        c3 = fz = jd = 0
        if dg == 'table':
            c3 = int(di[1]) % MOD
            fz = int(di[2]) % MOD
            jd = int(di[3]) % MOD
        for f in range(j):
            if dg == 'number':
                um = (um * 48271 + (f + 1) * 7919) % MOD
                so = um % 256
            elif dg == 'table':
                z, o, xo = c3, fz, jd
                c3 = (z * 48271 + o * 131 + (f + 1) * 7919 + 17) % MOD
                fz = (o * 65599 + xo * 257 + (f + 1) * 40503 + 31) % MOD
                jd = (xo * 31337 + z * 193 + (f + 1) * 104729 + 73) % MOD
                so = bxor(bxor(c3 % 256, fz % 256), jd % 256)
            else:
                so = luau_byte(di, (f % len(di)) + 1)
            if tq is not None:
                ej = luau_byte(dh, vw + f)
            else:
                ej = readu8_fn(w, f)
            out[f] = bxor(ej, so)
        return bytes(out)

    return ud, lr


# ---------------------------------------------------------------- cR / y0 / Me
def make_cr(gp_bytes, lw_entries):
    """cR(HZ, Di): repeating-key XOR.  HZ is bytes (1-based) or an
    lw index into gp_bytes (absolute 1-based offsets)."""

    def cr(hz, di):
        if isinstance(hz, bytes):
            w, start, k7 = hz, 0, len(hz)
        else:
            off, k7 = lw_entries[hz]
            w, start = gp_bytes, off - 1
        if isinstance(di, str):
            di = di.encode()
        out = bytearray(k7)
        for f in range(k7):
            out[f] = bxor(w[start + f], di[f % len(di)])
        return bytes(out)

    return cr


def make_ns(cu, seed):
    """ns(ji): 12-byte key from the CU triple + seed."""
    def ns(ji):
        ji = luau_tonumber(ji) or 0
        rd = (cu[0] * 48271 + cu[1] * 131 + cu[2] * 17
              + seed * 257 + ji * 31 + 104729) % MOD
        pl = (cu[1] * 65599 + cu[2] * 257 + cu[0] * 31
              + seed * 17 + ji * 313 + 524287) % MOD
        kc = (cu[2] * 31337 + cu[0] * 193 + cu[1] * 73
              + seed * 7919 + ji * 257 + 131071) % MOD
        return b''.join(bytes(((v >> (8 * k)) & 0xFF) for k in range(4))
                        for v in (rd, pl, kc))
    return ns


class ConstantLayer:
    """Me/O3 over one proto's oC table.  cu=None means ns-keyed
    constants cannot be resolved yet (counted, not guessed)."""

    def __init__(self, oc, ud, fw_fn, cr, ns_fn, bj, y2, de):
        self.oc = oc
        self.ud = ud
        self.fw = fw_fn
        self.cr = cr
        self.ns = ns_fn
        self.bj = bj
        self.y2 = y2 if isinstance(y2, bytes) else y2.encode()
        self.de = de
        self.ug = {}
        self.stats = {'ns_blocked': 0, 'tag74': 0, 'tag0': 0,
                      'plain': 0, 'errors': 0}

    def _key_str(self, v3, v4, use_ns):
        if v4 == 1:
            if self.ns is None:
                self.stats['ns_blocked'] += 1
                raise DecodeError('ns key needs CU triple')
            return self.ns(v3)
        if use_ns:
            g = v3
            h = ((g * 7919) % 2147483629 + self.de) % 2147483629
            b = self.bj(h)
            return b if isinstance(b, bytes) else str(b).encode()
        return self.y2 + b':' + (v3 if isinstance(v3, bytes)
                                 else str(v3).encode())

    def materialise(self, v):
        key = id(v) if isinstance(v, dict) else v
        if key in self.ug:
            return self.ug[key][0]
        z = v
        if isinstance(v, dict) and v.get(1) == 74:
            self.stats['tag74'] += 1
            g = v[3]
            k = self._key_str(g, v.get(4), use_ns=True)
            z = self.fw(self.ud(v[2], k, None, None))
        if isinstance(z, dict) and z.get(1) == 0:
            self.stats['tag0'] += 1
            k = self._key_str(z[3], z.get(4), use_ns=False)
            z = self.cr(z[2], k)
        if not (isinstance(v, dict) and v.get(5) == 1):
            self.ug[key] = (z,)
        else:
            self.stats['plain'] += 1
        return z

    def constant(self, f, se=None):
        """U/O3(f): negative f needs SE (per-instruction seed);
        without it the constant is unresolvable statically."""
        if f < 0:
            if se is None:
                raise DecodeError('negative constant index needs SE')
            f = -f - se
        r = self.oc.get(f)
        return self.materialise(r)


# ---------------------------------------------------------------- NY
def make_ny(keys):
    """NY(r, tE, GJ, LW) with caller-supplied key record:
    keys = (fQ, TB, mU, _6).  Tables recurse with LW*257+Di."""
    f_q, t_b, m_u, k6 = keys

    def ny(r, te, gj, lw):
        if isinstance(r, dict):
            out = {}
            for di in sorted(k for k in r if isinstance(k, int)):
                xn = ny(r[di], te, gj, lw * 257 + di)
                if xn is None and r[di] is not None:
                    return None
                out[di] = xn
            return out
        if not isinstance(r, (int, float)) or isinstance(r, bool):
            return r
        c = r - (f_q + ((te * 7919 + gj * 40503 + lw * 193) % 1000003))
        if m_u == 0:
            v = c
        elif m_u == 1:
            v = c / t_b
        elif m_u == 2:
            vd = c / t_b
            v = vd / 2 if vd % 2 == 0 else -(vd + 1) / 2
        else:
            ul = c % 257
            pp = (c - ul) / 257
            ia = ((ul - k6) * 86) % 257
            vd = pp * 257 + ia
            v = vd / 2 if vd % 2 == 0 else -(vd + 1) / 2
        if v % 1 == 0:
            return int(v) if abs(v) < 2**53 else v
        return None
    return ny


# ---------------------------------------------------------------- file parameters
def extract_params(code, pq):
    """Read every build parameter from the VM code region (never
    from sample literals baked into this module)."""
    p = {}
    m = re.search(r'local rl,\S+=\(sC\((\d+)\)\)', code)
    p['rl_pool_index'] = int(m.group(1)) if m else None
    m = re.search(r'local tA,\w+=\{.*?\},sC\((\d+)\)', code, re.DOTALL)
    p['kb_pool_index'] = int(m.group(1)) if m else None
    m = re.search(r"local Y2,v6='([^']+)',sC\((\d+)\)", code)
    if m:
        p['y2'] = m.group(1).encode()
        p['second_pool_index'] = int(m.group(2))
    m = re.search(r'local dE=0;for f=1,8 do local xO=ng\(Pq\(\{([0-9,]+)\}\),f\)',
                  code)
    if m:
        hexstr = pq([int(x) for x in m.group(1).split(',')])
        # The VM loop reads exactly 8 hex digits (f=1..8); the Pq
        # string is longer, but only its first 8 chars form dE.
        p['de'] = int(hexstr[:8].decode(), 16)
    m = re.search(r'local function L6\(M,T,GJ\)local Ds=\((\d+)\*', code)
    p['l6_seed'] = int(m.group(1)) if m else None
    m = re.search(r'CU\[1\]\*48271\+CU\[2\]\*131\+CU\[3\]\*17\+(\d+)\*257',
                  code)
    p['ns_seed'] = int(m.group(1)) if m else None
    m = re.search(r'rl=le\(UD\(rl,"([^"]+)",Pq\(\{([0-9,]+)\}\),'
                  r'Pq\(\{([0-9,]+)\}\)\)\)', code)
    if m:
        p['ud_key'] = m.group(1).encode()
        p['ud_nt'] = pq([int(x) for x in m.group(2).split(',')])
        p['ud_ik'] = pq([int(x) for x in m.group(3).split(',')])
    m = re.search(r'Y0\(W,1,4\)~=Pq\(\{([0-9,]+)\}\)', code)
    p['magic'] = pq([int(x) for x in m.group(1).split(',')]) if m else None
    return p
