#!/usr/bin/env python3
"""lift.py -- Luraph v20.0 trace-verified lifter (Luraph-Deobf-Tool-v6).

Turns a TRACE BUNDLE (not the obfuscated sample, and not stages 1-4
alone) into lifted Luau source for the COVERED PATH ONLY.

Bundle (a directory of JSON/JSONL files produced by the earlier
trace phases, verified from disk before this phase):
  merged_entry_trace.json   entry coverage, per-block ranges,
                            the R477 table-collect record and the
                            R478 auth analysis (all values below
                            are read from here, never typed here)
  child7_upvalue_effect.json  the two traced child-7 calls: args
                            and upvalue write-sets, in call order
  child14_decision.json       the decided child-14 returns and the
                            decided register values they imply
  trace_continuation.jsonl    per-instruction continuation records
                            (slot writes, dy polarities, call sites)

Rules this module obeys (all checked by lift_bundle, and the
checks are reported in literal_equation.json, not just asserted
silently):
  * NO sample literal appears in this file.  Every number, hash
    and key string in the emitted source is read from the bundle
    at run time.  The only numbers this file itself contains are
    structural (list positions, small positional indices, the
    tool version).  The assumption text is likewise read from
    the bundle's own assumption field and embedded verbatim --
    it is never retyped here, so this file cannot drift from
    the trace evidence it claims to lift.
  * The assumption gate is fail-closed: if the bundle's
    assumption does not state the O-at-boundary condition and
    the trap-path consequence, the lift refuses (LiftError).
  * Coverage gate: the bundle must account for every reachable
    instruction and name its skipped/unreachable positions; the
    terminus must be the analysed auth-fail return.  Anything
    else refuses -- the lifter never invents a terminus.
  * Cross-checks, all bundle-internal (no value is trusted from
    a single file): child-14 returns agree; child-7 call-2
    upvalue effects agree with the entry final register state;
    the R477 collected table agrees with the R478 P8 values;
    the R478 auth verdict is a FAIL (computed digest differs
    from expected).  A mismatch refuses.
  * Scope honesty: block 1 (the long prologue) is NOT
    transcribed instruction-by-instruction -- no per-instruction
    semantics layer exists for it in the bundle -- so the lifted
    source transcribes only its DECIDED EXIT STATE (child
    closures created, decided registers, dy truthy at the
    branch) and says so in the header and the report.  Blocks
    after the assumption boundary are transcribed from the
    per-instruction records.  Unexecuted positions are listed
    in the header and in the report, never silently dropped,
    and the second stage is never entered: the source ends at
    the terminus return.
  * Child calls are represented as local functions, not inlined:
    child 14 as a function returning the traced value, child 7
    as a function applying the traced upvalue write-sets for
    exactly the traced argument tuples (any other tuple is an
    explicit error, because it is outside the covered path).
    This preserves the traced path's semantics without
    pretending the children's interiors are decompiled here.

Exit semantics (see luraph_v20.py): a lifted run is still
PARTIAL -- PARTIAL-with-assumption -- never FULL.  The v20 route
never exits 0: the O=0 path is valid UNDER the assumption only.

Static transcription only: this module never executes Luau,
never imports a Luau runtime, never fetches a URL.
"""
import json
import os
import re

VERSION = '6.4.0'

VERDICT = 'PARTIAL-with-assumption'


class LiftError(Exception):
    pass


def _load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def _load_jsonl(path):
    out = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def _ints(obj, acc):
    if isinstance(obj, bool):
        return
    if isinstance(obj, int):
        acc.add(obj)
    elif isinstance(obj, dict):
        for v in obj.values():
            _ints(v, acc)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            _ints(v, acc)


def _strings(obj, acc):
    if isinstance(obj, str):
        acc.add(obj)
    elif isinstance(obj, dict):
        for v in obj.values():
            _strings(v, acc)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            _strings(v, acc)


def _lua_num(value):
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, int):
        return str(value)
    if isinstance(value, str) and re.fullmatch(r'-?\d+', value.strip()):
        return value.strip()
    raise LiftError(f'cannot render as Luau number: {value!r}')


def _lua_str(value):
    if not isinstance(value, str):
        raise LiftError(f'cannot render as Luau string: {value!r}')
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def _parse_table_repr(repr_s):
    """Parse a single-entry table repr like 'table#N{[1]=V}' -> V."""
    m = re.fullmatch(r'table#\d+\{\[1\]=(-?\d+)\}', (repr_s or '').strip())
    return int(m.group(1)) if m else None


def _dy_polarity(record):
    fam = record.get('family') or ''
    if 'truthy' in fam:
        return True
    if 'falsy' in fam:
        return False
    raise LiftError(f'dy record without polarity: {record!r}')


def load_bundle(bundle_dir):
    """Read and validate the trace bundle. Returns a dict of parts."""
    merged_p = os.path.join(bundle_dir, 'merged_entry_trace.json')
    c7_p = os.path.join(bundle_dir, 'child7_upvalue_effect.json')
    c14_p = os.path.join(bundle_dir, 'child14_decision.json')
    cont_p = os.path.join(bundle_dir, 'trace_continuation.jsonl')
    for p in (merged_p, c7_p, c14_p, cont_p):
        if not os.path.isfile(p):
            raise LiftError(f'trace bundle missing file: {p}')
    merged = _load_json(merged_p)
    child7 = _load_json(c7_p)
    child14 = _load_json(c14_p)
    cont = _load_jsonl(cont_p)

    # --- assumption gate (fail-closed) ---
    assumption = merged.get('assumption') or ''
    if 'O=0 at R=384' not in assumption:
        raise LiftError('bundle assumption does not state the '
                        'O-at-boundary condition; refusing to lift')
    if 'trap' not in assumption.lower():
        raise LiftError('bundle assumption does not name the trap-path '
                        'consequence; refusing to lift')

    # --- coverage gate ---
    cov = merged.get('coverage') or {}
    total = cov.get('total_instructions')
    accounted = cov.get('accounted')
    skipped = cov.get('skipped_by_taken_jumps') or []
    unreachable = cov.get('unreachable_terminus') or []
    if total is None or accounted is None:
        raise LiftError('bundle coverage lacks totals')
    if accounted + len(skipped) + len(unreachable) != total:
        raise LiftError(
            f'coverage does not close: accounted={accounted} + '
            f'skipped={len(skipped)} + unreachable={len(unreachable)} '
            f'!= total={total}')
    per_block = merged.get('per_block') or []
    if not per_block:
        raise LiftError('bundle per_block missing')

    # --- terminus gate: R478 must be the analysed auth-fail return ---
    r478 = merged.get('R478') or {}
    if r478.get('auth_pass') is not False:
        raise LiftError('R478 auth verdict is not a FAIL; the covered '
                        'path does not end at an auth-fail return')
    outcome = r478.get('outcome') or ''
    if 'return PE,PE' not in outcome:
        raise LiftError('R478 outcome is not the PE return; refusing')

    # --- R477 / R478 cross-check ---
    r477 = merged.get('R477') or {}
    collected = r477.get('collected_table')
    p8 = r478.get('p8_values_1_to_4')
    if collected is None or p8 is None or list(collected) != list(p8):
        raise LiftError('R477 collected table != R478 P8 values; '
                        'bundle is internally inconsistent')

    # --- child-14 cross-check ---
    if child14.get('decided') is not True:
        raise LiftError('child-14 decision is not decided; refusing')
    c14_vals = [child14['call349']['value'],
                child14['call364']['value']]
    if len(set(c14_vals)) != 1:
        raise LiftError('child-14 calls disagree; refusing')
    c14_ret = c14_vals[0]

    # --- child-7 cross-checks ---
    calls = child7.get('calls') or []
    if len(calls) != 2:
        raise LiftError(f'expected exactly 2 traced child-7 calls, '
                        f'got {len(calls)}')
    order = child7.get('upvalue_slots_field7_order') or []
    if len(order) < len(calls[0].get('p_diff') or {}):
        raise LiftError('child-7 upvalue slot order too short')
    final_m = ((merged.get('final_state') or {}).get('post_477') or {}
               ).get('m') or {}
    for call in calls:
        for p_key, diff in (call.get('p_diff') or {}).items():
            slot = order[int(p_key) - 1]
            mval = final_m.get(str(slot))
            # Final state wins only for call 2; call 1 is checked
            # against call 2's before-values instead (chained).
            if call is calls[-1]:
                after = diff.get('after') or {}
                if str(mval.get('1')) != str(after.get('1')) \
                        if isinstance(mval, dict) else True:
                    raise LiftError(
                        f'child-7 call-2 upvalue slot {slot} does not '
                        f'match entry final state')
    if calls[1].get('p_diff'):
        for p_key, diff in calls[1]['p_diff'].items():
            before = (diff.get('before') or {}).get('1')
            first_after = (calls[0]['p_diff'][p_key]['after'] or {}).get('1')
            if str(before) != str(first_after):
                raise LiftError('child-7 calls are not chained '
                                '(call 2 before != call 1 after)')

    # --- continuation records: call sites + dy sites + slot writes ---
    call_recs = [r for r in cont
                 if r.get('family') == 'call-discard']
    if len(call_recs) != len(calls):
        raise LiftError(f'continuation call sites ({len(call_recs)}) != '
                        f'traced child-7 calls ({len(calls)})')
    dy_recs = {}
    for r in cont:
        if 'dy()' in (r.get('family') or ''):
            dy_recs[r.get('R_before')] = _dy_polarity(r)
    if not dy_recs:
        raise LiftError('no dy branch records in continuation trace')

    # Second-stage pool entry: name-derived, never typed here.
    pool_key = None
    for k in r478.keys():
        if k.startswith('pool_entry_'):
            pool_key = k
            break
    pool_entry = r478.get(pool_key) if pool_key else None

    return {
        'merged': merged, 'child7': child7, 'child14': child14,
        'cont': cont, 'assumption': assumption,
        'coverage': cov, 'skipped': skipped, 'unreachable': unreachable,
        'per_block': per_block, 'r477': r477, 'r478': r478,
        'c14_ret': c14_ret, 'calls': calls, 'order': order,
        'dy_recs': dy_recs, 'pool_key': pool_key,
        'pool_entry': pool_entry, 'final_m': final_m,
        'files': {
            'merged_entry_trace.json': merged_p,
            'child7_upvalue_effect.json': c7_p,
            'child14_decision.json': c14_p,
            'trace_continuation.jsonl': cont_p,
        },
    }


def _block_range(parts, index):
    """per_block[index] -> (start, end) as traced block bounds."""
    blk = parts['per_block'][index]
    lo, hi = blk['block']
    return lo, hi


def build_source(parts):
    """Render the lifted source from validated bundle parts."""
    merged = parts['merged']
    r477 = parts['r477']
    r478 = parts['r478']
    calls = parts['calls']
    order = parts['order']
    cont = parts['cont']
    cov = parts['coverage']
    assumption = parts['assumption']
    skipped = parts['skipped']
    unreachable = parts['unreachable']
    unexecuted = sorted(skipped + unreachable)
    total = cov['total_instructions']
    accounted = cov['accounted']
    pool = parts['pool_entry'] or {}
    pool_suffix = (parts['pool_key'] or 'pool_entry_?').split('_')[-1]
    final_m = parts['final_m']

    def block_label(index):
        lo, hi = _block_range(parts, index)
        return f'block {index + 1} (R{lo}--R{hi})'

    # --- slot-write transcription for the continuation blocks ---
    # Map traced m_writes to readable locals; only writes whose
    # value parses as a plain number are emitted as assignments.
    slot_lines = {}  # R -> [lines]
    table_lines = {}  # R -> [lines]
    for r in cont:
        rb = r.get('R_before')
        if rb is None:
            continue
        for w in (r.get('m_writes') or []):
            if len(w) != 2:
                continue
            target, val = w
            m = re.fullmatch(r'm\[(\d+)\]', target or '')
            m2 = re.fullmatch(r'm\[(\d+)\]\[1\]', target or '')
            if m and re.fullmatch(r'-?\d+', str(val)):
                slot_lines.setdefault(rb, []).append(
                    f'm{m.group(1)} = {val}  -- traced write '
                    f'at R{rb}')
            elif m2 and re.fullmatch(r'-?\d+', str(val)):
                slot_lines.setdefault(rb, []).append(
                    f'slot{m2.group(1)}_first = {val}  -- traced '
                    f'write at R{rb}')
            elif target == 'table-write':
                tv = _parse_table_repr(r.get('stack_top') or '')
                if tv is not None:
                    table_lines.setdefault(rb, []).append(
                        f'local built_table_{rb} = {{ {tv} }}  '
                        f'-- traced table build at R{rb}')
    # Block membership for the continuation records.
    def block_index_of(r_pos):
        for i, blk in enumerate(parts['per_block']):
            lo, hi = blk['block']
            if lo <= r_pos <= hi:
                return i
        return None

    # Continuation blocks in execution order: 3, 5, 6, 4, 7, 8
    # (indices 2, 4, 5, 3, 6, 7 in per_block order: block 5 is
    # the single branch instruction between blocks 3 and 6).
    # Execution order is taken from the continuation record
    # sequence, not assumed: the record R order on the covered
    # path is checked below.
    exec_r = [r.get('R_before') for r in cont
              if r.get('R_before') is not None
              and r.get('executed')]
    # The continuation records start at the branch record; the
    # covered continuation order must visit blocks 3, 6, 4, 7, 8
    # in that order (block 5's single branch instruction sits
    # between blocks 3 and 6).
    seen_blocks = []
    for pos in exec_r:
        bi = block_index_of(pos)
        if bi is not None and (not seen_blocks or seen_blocks[-1] != bi):
            seen_blocks.append(bi)
    # seen_blocks includes block 1 (the branch record) first; the
    # continuation order after it must be 3, 5, 6, 4, 7, 8.
    cont_order = [b for b in seen_blocks if b != 0]
    if cont_order[:6] != [2, 4, 5, 3, 6, 7]:
        raise LiftError(f'unexpected continuation block order: '
                        f'{cont_order}')

    def section_lines(block_idx, include_tables=True):
        """Traced slot/table lines for one block, in R order.

        First write of a slot in the block gets `local`; later
        writes in the same block are plain assignments (the
        block's scope is fresh, so a later block re-declares).
        Block 8's table lines are excluded by the caller: its
        result table is emitted explicitly from the merged
        R478 table values instead, so the per-step build lines
        would only duplicate it.
        """
        lines = []
        seen = set()
        for r in cont:
            rb = r.get('R_before')
            if rb is None or block_index_of(rb) != block_idx:
                continue
            for ln in slot_lines.get(rb, []):
                name = ln.split(' = ', 1)[0]
                if name in seen:
                    lines.append(ln)
                else:
                    seen.add(name)
                    lines.append('local ' + ln)
            if include_tables:
                lines.extend(table_lines.get(rb, []))
        return lines

    # --- child-7 function body (traced tuples only) ---
    c7_lines = []
    c7_lines.append('local upvalues = {}  -- child-7 upvalue slots, '
                    'traced values only')
    first = calls[0]
    for p_key in sorted(first.get('p_diff') or {},
                        key=lambda k: int(k)):
        slot = order[int(p_key) - 1]
        before = (first['p_diff'][p_key].get('before') or {}).get('1')
        c7_lines.append(f'upvalues[{slot}] = {{ {_lua_num(before)} }}'
                        f'  -- slot {slot}, before call 1')
    c7_lines.append('local function child7_call(a, b, c)')
    c7_lines.append('  -- Applies the traced upvalue write-set for '
                    'exactly the traced argument tuple.  Any other '
                    'tuple is outside the covered path.')
    for call in calls:
        args = call.get('args') or []
        if len(args) != 3:
            raise LiftError('child-7 call does not have 3 args')
        cond = ' and '.join(
            f'{nm} == {_lua_num(v)}'
            for nm, v in zip(('a', 'b', 'c'), args))
        c7_lines.append(f'  if {cond} then')
        for p_key in sorted(call.get('p_diff') or {},
                            key=lambda k: int(k)):
            slot = order[int(p_key) - 1]
            after = (call['p_diff'][p_key].get('after') or {}).get('1')
            c7_lines.append(f'    upvalues[{slot}][1] = '
                            f'{_lua_num(after)}')
        c7_lines.append('    return')
        c7_lines.append('  end')
    c7_lines.append('  error("child7_call: argument tuple outside '
                    'the traced covered path")')
    c7_lines.append('end')

    # --- R477 collect ---
    ops = r477.get('operands') or {}
    # Operand positions are bundle positions, not typed here:
    # push order is l[2], l[6], l[3], l[5]; j is l[4].
    push_slots = [ops.get('2'), ops.get('6'), ops.get('3'),
                  ops.get('5')]
    j_val = ops.get('4')
    if any(s is None for s in push_slots) or j_val is None:
        raise LiftError('R477 operands incomplete in bundle')
    p8_key = r478.get('p8_key')
    collected = r477.get('collected_table') or []
    if len(collected) != j_val:
        raise LiftError('R477 collected length != traced j value')
    slot_first = {}
    for s in push_slots:
        mv = final_m.get(str(s)) or {}
        if isinstance(mv, dict):
            slot_first[s] = mv.get('1')
    if any(slot_first.get(s) is None for s in push_slots):
        raise LiftError('R477 push-slot final values missing')
    if [slot_first[s] for s in push_slots] != list(collected):
        raise LiftError('R477 push-slot values != collected table')

    # --- R478 auth ---
    ke_init = r478.get('ke_initial') or []
    ke_upd = r478.get('ke_updated') or []
    diffs = r478.get('diffs') or {}
    lt = r478.get('lt_from_gu') or []
    c_table = r478.get('c_table_1_to_5') or {}
    vchecks = r478.get('auth_verdict_checks') or {}
    key_prefix = (vchecks.get('V10_auth_materials') or {}).get(
        'key_prefix')
    w_w = vchecks.get('V9_wW_literal')
    sb = r478.get('sb_under_guard_pass')
    if key_prefix is None or w_w is None or sb is None:
        raise LiftError('R478 auth materials incomplete in bundle')

    lines = []
    A = lines.append
    A('-- ============================================================')
    A('-- LIFTED SOURCE -- Luraph v20.0 entry activation, COVERED PATH ONLY')
    A('-- Verdict: PARTIAL-with-assumption (never bare FULL).')
    A('-- Tool: Luraph-Deobf-Tool-v6 v' + VERSION + ' (v20 route, lifter).')
    A('--')
    A('-- ASSUMPTION (verbatim from the trace bundle -- read first):')
    for al in assumption.split('\n'):
        A('-- ' + al if al else '--')
    A('--')
    A('-- SCOPE -- covered path only:')
    A(f'--   Entry proto: {accounted} of {total} instructions '
      f'accounted (sim-executed + analysed terminus).')
    A('--   Execution order on this path: block 1 prefix, then '
      'blocks 3, 5, 6, 4, 7, 8 in that order (block 5 is the '
      'single branch instruction; see sections below).')
    A('--   Unexecuted positions (NOT silently omitted, NOT '
      'invented): ' + ', '.join(f'R{x}' for x in unexecuted) + '.')
    A('--   R' + str(sorted(unreachable)[0] if unreachable else '?')
      + ' is unreachable on this path (never a block fetch).')
    A('--   The second stage (pool entry ' + pool_suffix + ') is '
      'NOT entered from the entry trace: the terminus return '
      'below ends the activation before any re-entry, and no '
      'second-stage code is included.')
    A('--   Block 1 is transcribed as DECIDED EXIT STATE ONLY '
      '(child closures created, decided registers, dy truthy '
      'at the branch), not instruction-by-instruction: no '
      'per-instruction semantics layer for it exists in the '
      'bundle, and inventing one would be fabrication.')
    A('--   Child calls are local functions (see below): child 14 '
      'returns the traced value; child 7 applies the traced '
      'upvalue write-sets for exactly the traced tuples.')
    A('--   R478 residual uncertainty (from the bundle, kept):')
    for rl in (r478.get('residual_uncertainty') or '').split('\n'):
        A('-- ' + rl if rl else '--')
    A('--   Under the trap-path alternative this entire path is '
      'NOT what the real VM does; see the assumption above.')
    A('-- ============================================================')
    A('')
    A('-- PE is the VM return sentinel identifier exactly as it '
      'appears in the traced handler text; it is not decoded '
      'to a Luau value on this path.')
    A('')
    # Child 14.
    c14 = parts['child14']
    A('-- Child 14 (traced twice in the prologue; both calls '
      'return the same traced value, which decides the register '
      'chain below).')
    A('local function child14()')
    A(f'  return {_lua_num(parts["c14_ret"])}')
    A('end')
    A('')
    # Prologue exit state.
    A(f'-- Prologue: {block_label(0)} exit state (decided, not '
      f'per-instruction).')
    A('--   Child closures created during the prologue include '
      'the child-7 closure; the child-14 chain decides:')
    A(f'local m29 = {_lua_num(c14.get("m29"))}  -- decided via '
      f'child 14')
    A(f'local m14 = {_lua_num(c14.get("m14"))}  -- decided via '
      f'child 14')
    A(f'local m3 = {_lua_num(c14.get("m3"))}  -- decided via '
      f'child 14')
    A('--   dy() at the prologue branch is the decided comparison '
      '(register == decided zero); it is truthy on this path, '
      'so execution falls through to the unconditional jump.')
    A('local function dy_prologue()')
    A('  return m3 == 0')
    A('end')
    A('')
    for ln in c7_lines:
        A(ln)
    A('')
    A('local function entry_activation()')
    A('  -- Prologue branch: dy() truthy -> fall through, then '
      'the unconditional jump lands at the assumption boundary.')
    A('  if dy_prologue() then')
    A('    -- fall through (traced branch decision)')
    A('  end')
    A('  -- Assumption boundary crossed here: everything below '
      'is valid UNDER the assumption in the header, only.')
    # Block 3 (index 2).
    A(f'  -- {block_label(2)}: setQ, return-push, unconditional '
      f'jump to the block-5 branch.')
    for ln in section_lines(2):
        A('  ' + ln)
    # Block 5 branch (index 4): dy record at its first position.
    lo5, _hi5 = _block_range(parts, 4)
    dy5 = None
    for pos, pol in parts['dy_recs'].items():
        if pos == lo5:
            dy5 = pol
    if dy5 is None:
        raise LiftError('block-5 dy record missing')
    A(f'  -- {block_label(4)}: dy branch; traced polarity: '
      f'{"truthy" if dy5 else "falsy"} -> jump taken to block 6.')
    A(f'  local dy_at_block5 = {"true" if dy5 else "false"}')
    A('  if dy_at_block5 then')
    # Block 6 (index 5) inside the branch.
    A(f'    -- {block_label(5)}: table builds and register '
      f'writes, ending in the dy branch to block 4.')
    for ln in section_lines(5):
        A('    ' + ln)
    dy6 = None
    for pos, pol in parts['dy_recs'].items():
        if block_index_of(pos) == 5:
            dy6 = pol
    if dy6 is None:
        raise LiftError('block-6 dy record missing')
    A(f'    -- Block-6 dy branch (traced polarity: '
      f'{"truthy" if dy6 else "falsy"}): jump taken to block 4, '
      f'skipping the block tail.')
    A(f'    local dy_at_block6 = {"true" if dy6 else "false"}')
    A('    if not dy_at_block6 then')
    # Block 4 (index 3) inside.
    A(f'      -- {block_label(3)}: dy check falls through '
      f'(falsy -> pop), then the unconditional jump to block 7.')
    for ln in section_lines(3):
        A('      ' + ln)
    # Block 7 (index 6).
    A(f'      -- {block_label(6)}: register writes, then the '
      f'child-7 closure is pushed for block 8.')
    for ln in section_lines(6):
        A('      ' + ln)
    A('      local child7 = child7_call')
    # Block 8 (index 7): traced order is the two child-7 calls
    # first (call-discard sites), then the result table build.
    A(f'      -- {block_label(7)} (part 1): the two traced '
      f'child-7 calls, then the result table build.')
    for call in calls:
        args = call.get('args') or []
        A('      child7(' + ', '.join(_lua_num(v) for v in args)
          + ')  -- traced call, results discarded; upvalue '
          'writes are the effect')
    for ln in section_lines(7, include_tables=False):
        A('      ' + ln)
    A('      -- Result table, traced entries in order:')
    ct_vals = [c_table.get(str(i)) for i in
               sorted(c_table.keys(), key=lambda k: int(k))]
    A('      local table49 = { ' + ', '.join(
        _lua_num(v) for v in ct_vals) + ' }')
    A('      -- R477 table-collect: push the traced slots in '
      'handler order, collect into a fresh table, dy-write:')
    push_exprs = []
    for s in push_slots:
        push_exprs.append(f'slot{s}_first')
        A(f'      local slot{s}_first = '
          f'{_lua_num(slot_first[s])}  -- traced slot value')
    A('      local collected = { ' + ', '.join(push_exprs)
      + ' }  -- collected table, length ' + str(len(collected)))
    A(f'      table49[{_lua_num(p8_key)}] = collected')
    # R478 auth.
    A('      -- R478 re-entry leaf, analysed (not simulated): '
      'guard checks pass, witness digests are computed, then '
      'the HMAC auth comparison FAILS on the traced values, '
      'so the activation returns without entering the second '
      'stage.  UD / decode / re-entry are gated by auth and '
      'do NOT run on this path.')
    A('      local guard_pass = true  -- traced guard checks '
      'all pass (see report)')
    A('      local ke_initial = { ' + ', '.join(
        _lua_num(v) for v in ke_init) + ' }')
    A('      local ke_updated = { ' + ', '.join(
        _lua_num(v) for v in ke_upd) + ' }')
    diff_items = ', '.join(
        f'{k} = {_lua_num(v)}'
        for k, v in sorted(diffs.items()))
    A(f'      local diffs = {{ {diff_items} }}')
    A('      local lt_from_gu = { ' + ', '.join(
        _lua_num(v) for v in lt) + ' }')
    A(f'      local gu_hex = {_lua_str(r478.get("gu_hex"))}')
    A(f'      local gl_hex = {_lua_str(r478.get("gl_hex"))}')
    A(f'      local ha = {_lua_str(r478.get("ha"))}')
    A(f'      local key_prefix = {_lua_str(key_prefix)}')
    A(f'      local sb_guard_pass = {_lua_num(sb)}')
    A(f'      local wW_literal = {_lua_num(w_w)}')
    A(f'      local pool_entry_offset = '
      f'{_lua_num(pool.get("offset"))}')
    A(f'      local pool_entry_length = '
      f'{_lua_num(pool.get("length"))}')
    A(f'      local pool_entry_sha = '
      f'{_lua_str(pool.get("sha256"))}')
    A(f'      local auth_computed = '
      f'{_lua_str(r478.get("auth_computed_hex"))}')
    A(f'      local auth_expected = '
      f'{_lua_str(r478.get("auth_expected_hex"))}')
    A('      if guard_pass and auth_computed ~= auth_expected '
      'then')
    A('        return PE, PE  -- terminus: auth-fail branch')
    A('      end')
    A('      -- Auth-pass continuation is OUTSIDE the covered '
      'path and is not lifted; reaching here would mean the '
      'traced auth evidence changed.')
    A('      error("v20 lift: outside the traced covered path '
      '(auth passed unexpectedly)")')
    A('    end')  # not dy_at_block6
    A('  end')  # dy_at_block5
    A('  -- Unreached on the covered path (branch decisions '
      'above are the traced ones).')
    A('  error("v20 lift: outside the traced covered path")')
    A('end')
    A('')
    A('return entry_activation()')
    A('')
    A('-- NOT LIFTED (documented, not omitted):')
    for x in unexecuted:
        A(f'--   R{x}: not executed on the covered path.')
    A('--   Second stage (pool entry ' + pool_suffix + '): not '
      'entered; no code for it is included above.')
    return '\n'.join(lines) + '\n'


def literal_equation(parts, source, protos=None):
    """Check the literal equation for the covered path.

    required: every bundle-derived literal the covered path uses
    must appear in the source.  invented: code literals (numbers
    outside the small positional-index set, and long/hex-like
    strings) must all come from the bundle.  Short lifter prose
    strings (error messages) are listed separately -- they are
    not sample literals.
    """
    merged = parts['merged']
    r477 = parts['r477']
    r478 = parts['r478']
    required_nums = set()
    required_strs = set()

    def add_num(v):
        if isinstance(v, bool):
            return
        if isinstance(v, int):
            required_nums.add(v)
        elif isinstance(v, str) and re.fullmatch(r'-?\d+', v.strip()):
            required_nums.add(int(v.strip()))

    def add_val(v):
        if isinstance(v, str):
            required_strs.add(v)
            add_num(v)
        elif isinstance(v, (int, float)) and not isinstance(v, bool):
            required_nums.add(int(v))
        elif isinstance(v, dict):
            for x in v.values():
                add_val(x)
        elif isinstance(v, list):
            for x in v:
                add_val(x)

    add_val(parts['c14_ret'])
    add_val(parts['child14'].get('m29'))
    add_val(parts['child14'].get('m14'))
    add_val(parts['child14'].get('m3'))
    for call in parts['calls']:
        add_val(call.get('args'))
        for diff in (call.get('p_diff') or {}).values():
            add_val(diff)
    for s in parts['order']:
        required_nums.add(int(s))
    add_val(r477.get('collected_table'))
    # Operands keys 0/1 are the instruction word itself, not
    # literals used by the path; only the operand positions
    # (push slots + j) count as used literals.
    ops = r477.get('operands') or {}
    for k in ('2', '3', '4', '5', '6'):
        add_val(ops.get(k))
    add_val(r478.get('p8_key'))
    add_val(r478.get('c_table_1_to_5'))
    add_val(r478.get('ke_initial'))
    add_val(r478.get('ke_updated'))
    add_val(r478.get('diffs'))
    add_val(r478.get('lt_from_gu'))
    add_val(r478.get('gu_hex'))
    add_val(r478.get('gl_hex'))
    add_val(r478.get('ha'))
    add_val(r478.get('auth_computed_hex'))
    add_val(r478.get('auth_expected_hex'))
    add_val(r478.get('sb_under_guard_pass'))
    vchecks = r478.get('auth_verdict_checks') or {}
    add_val((vchecks.get('V10_auth_materials') or {}).get('key_prefix'))
    add_val(vchecks.get('V9_wW_literal'))
    pool = parts['pool_entry'] or {}
    add_val(pool.get('offset'))
    add_val(pool.get('length'))
    add_val(pool.get('sha256'))
    # Traced slot/table writes from the continuation records.
    for r in parts['cont']:
        for w in (r.get('m_writes') or []):
            if len(w) == 2:
                add_val(w[1])
        tv = _parse_table_repr(r.get('stack_top') or '')
        if tv is not None:
            required_nums.add(tv)

    missing = sorted(
        [n for n in required_nums if str(n) not in source],
        key=lambda x: (x < 0, abs(x)))
    missing_strs = sorted(s for s in required_strs
                          if s and s not in source)

    # Code literals: strip full-line and trailing comments, then
    # mask string contents before scanning numbers.  (Generated
    # string literals never contain ' --', so cutting trailing
    # comments at the first ' --' is safe here.)
    code_lines = []
    for ln in source.split('\n'):
        if ln.lstrip().startswith('--'):
            continue
        if ' --' in ln:
            ln = ln.split(' --', 1)[0]
        code_lines.append(ln)
    code_text = '\n'.join(code_lines)
    str_lits = re.findall(r'"((?:[^"\\]|\\.)*)"', code_text)
    masked = re.sub(r'"(?:[^"\\]|\\.)*"', '""', code_text)
    code_nums = set(int(x) for x in
                    re.findall(r'(?<![\w.])-?\d+', masked))
    positional = {1, 2, 3, 4, 5}
    invented_nums = sorted(code_nums - required_nums - positional)
    bundle_strs = set()
    _strings(parts['merged'], bundle_strs)
    _strings(parts['child7'], bundle_strs)
    _strings(parts['child14'], bundle_strs)
    _strings(parts['cont'], bundle_strs)
    # Sample-data-shaped strings (long hex digests, sha, or
    # colon-joined numeric keys) must be bundle-derived.  Short
    # natural-language prose (error messages) is lifter
    # documentation, not a sample literal, and is listed
    # separately below rather than counted as invented data.
    def _sample_shaped(s):
        return bool(re.fullmatch(r'[0-9a-f]{32,}', s or '')
                    or re.fullmatch(r'[0-9]+(:[0-9]+)+', s or '')
                    or re.fullmatch(r'[0-9a-f]{64}', s or ''))

    invented_strs = sorted(
        s for s in str_lits
        if _sample_shaped(s) and s not in bundle_strs)
    prose_strs = sorted(
        s for s in str_lits
        if s not in bundle_strs and s not in invented_strs)

    ok = not missing and not missing_strs and not invented_nums \
        and not invented_strs
    return {
        'ok': ok,
        'required_numbers_count': len(required_nums),
        'required_strings_count': len(required_strs),
        'missing_numbers': missing,
        'missing_strings': missing_strs,
        'invented_numbers': invented_nums,
        'invented_strings': invented_strs,
        'prose_strings_not_sample_literals': prose_strs,
        'code_numbers_found': sorted(code_nums),
        'protos_provenance': (
            {'entry_constants': protos.get('entry_constants'),
             'protos_visited': protos.get('protos_visited'),
             'errors': protos.get('errors')}
            if isinstance(protos, dict) else None),
        'note': ('P8 / table values are trace-derived, not proto '
                 'constants: they are RL-keystream derived, so '
                 'they are not expected in protos.json.  The '
                 'equation above is over the covered-path bundle '
                 'literals, with protos.json recorded as stage '
                 '3/4 provenance only.'),
    }


def lift_bundle(bundle_dir, protos=None):
    """Full lifter: validate bundle, render source, run equation.

    Returns (source, lift_report dict).  Raises LiftError on any
    gate failure -- the caller must then emit NO source file.
    """
    parts = load_bundle(bundle_dir)
    source = build_source(parts)
    eq = literal_equation(parts, source, protos=protos)
    if not eq['ok']:
        raise LiftError(f'literal equation failed: missing numbers '
                        f'{eq["missing_numbers"]}, missing strings '
                        f'{eq["missing_strings"]}, invented numbers '
                        f'{eq["invented_numbers"]}, invented strings '
                        f'{eq["invented_strings"]}')
    report = {
        'tool': 'Luraph-Deobf-Tool-v6',
        'version': VERSION,
        'route': 'v20',
        'verdict': VERDICT,
        'assumption': parts['assumption'],
        'assumption_applies': ('valid UNDER the assumption only; '
                               'never unconditionally proven; '
                               'under the trap-path alternative '
                               'this path is NOT the real VM path'),
        'coverage': parts['coverage'],
        'unexecuted': sorted(parts['skipped'] + parts['unreachable']),
        'second_stage_entered': False,
        'second_stage_pool_entry_suffix':
            (parts['pool_key'] or '').split('_')[-1],
        'block1_transcription': ('decided exit state only, not '
                                 'per-instruction'),
        'child_representation': ('local functions: child14 returns '
                                 'the traced value; child7 applies '
                                 'the traced upvalue write-sets '
                                 'for exactly the traced tuples'),
        'terminus': 'R478 auth-fail return PE,PE',
        'literal_equation': eq,
        'bundle_files': parts['files'],
        'determinism_note': ('no timestamps, no randomness, no '
                             'set-ordered output: bundle order + '
                             'sorted keys only'),
    }
    return source, report
