#!/bin/sh
# Runs the Luraph v15.1 pipeline on the bundled sample and diffs the
# lifted output against the expected one.
set -e
cd "$(dirname "$0")"
python3 luraph151.py sample/input_v151.lua -o sample-run-out
if cmp -s sample-run-out/lifted.luau sample/output/lifted.luau; then
    echo "SAMPLE OK: lifted.luau matches expected output"
else
    echo "SAMPLE MISMATCH: lifted.luau differs from expected output"
    exit 1
fi
