# Luraph Deobf Tool v5 (standalone)

Full devirtualisation pipeline for **Luraph v15.1** (the method-based
state-machine VM layout that the upstream Deobfuscator-Luraph-V15
cannot read). Older/newer Luraph builds with the same v15.1 layout
work unchanged; handler bodies are classified by normalised signature,
not by name, so per-build renaming is tolerated (see the mutation
test in the main repo).

## Usage

    python3 luraph151.py <input.lua> [-o outdir] [--luau path]

Outputs: folded.luau, protos.json, disasm.txt, ops.json,
lifted.luau (structured reconstruction), report.md.

## Detection

- Header `-- This file was protected using Luraph Obfuscator v15.1`, or
- **structural fingerprint** (new in v3) for header-stripped files:
  `string.unpack` deserializer + long-bracket blob + `}).t(` entry.
  Downstream stages validate (the proto parser must consume the dump
  log exactly; handlers must classify), so false positives abort.
- Buffer-based Luraph variant (no string.unpack): dump + constant
  pool + **body bytecode parser** — the binary is reconstructed from
  the read log and the varint proto grammar is parsed with exact
  consumption validation, emitting protos.json (57 protos / 10,874
  instructions on the case file) + binary.bin. Opcode semantics of
  this variant are still open, so the route stays PARTIAL (exit 5)
  at bytecode level.
- Other Luraph versions (v15.0/v14.x headers): automatically routed
  to the upstream Deobfuscator-Luraph-V15 engine when its clone is
  available (set LURAPH_UPSTREAM_DIR, or keep the clone next to this
  tool); the deobfuscated result lands in the output dir. Without the
  clone the tool prints guidance and exits 3.

## Requirements

Python 3.10+. Luau CLI binaries are bundled in `bin/` (Linux; the
tool prefers `bin/` next to itself, then $LUAU_BIN / PATH installs).

## Sample

`sample/input_v151.lua` + expected outputs in `sample/output/`
(plus behaviour mocks in `sample/behavior-test/`). Run `./run_sample.sh`.
