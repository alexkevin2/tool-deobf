# luraph-v151-deobf report

- input: `1878725522944274.lua.txt` (35760 bytes, sha256 `54df32acd80487567595a15db3b07f3cc6b24ef1a95cabdf6387980004213ab6`)
- detect: {'header_v15.1': True, 'string.unpack deserializer': True, 'ascii85+lz blob': True, 'method entry .t(': True, 'structural_v15.1': True}
- protos: 5, instructions: 604, unpack reads consumed: 3164/3164
- opcodes classified: 40/40 (unknown: none)
- lifted protos structured: 5/5; pc-loop fallback: none
- xor key used: [167, 229, 252, 19, 5, 111, 231, 18, 18, 106, 166, 245, 119] (string score 0.900)
- luau-compile: folded=True, lifted=True; luau-analyze: folded=(1, 0), lifted=(1, 0)

Outputs: folded.luau, protos.json, opnames.json, handlers.json, ops.json,
disasm.txt, lifted.luau, lift_report.json, unpack.log, runner.luau
