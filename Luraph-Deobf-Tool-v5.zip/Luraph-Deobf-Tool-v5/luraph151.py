#!/usr/bin/env python3
"""luraph-v151-deobf — deobfuscator for Luraph v15.1 (state-machine VM layout).

Built on the architecture of caomod2077/Deobfuscator-Luraph-V15 (which only
supports the v15.0 layout) plus a v15.1 engine written from a manual RE of
the v15.1 VM:

  1. detect   header / layout markers for v15.1
  2. fold     conservative integer constant folding (fold.py)
  3. dump     run the target in the standalone Luau CLI with string.unpack
              hooked (runner_template.luau); the deserializer parses the
              whole proto tree eagerly, so all protos/constants are dumped
              in one run
  4. parse    rebuild the proto tree from the unpack log (parse_protos.py);
              the parse must consume the log exactly or the run is rejected
  5. extract  opcode-name table + handler bodies from the folded VM source
              (extract_vm.py), classify handlers into semantic ops
              (semantics.py; "mangled" handlers are superinstructions with a
              fixed core sequence)
  6. lift     devirtualise to structured Luau source (lift.py) and verify
              with luau-compile when available

Safety: stage 3 EXECUTES the target inside the Luau CLI sandbox (no
network, no io in that runtime) to trigger its deserializer — the same
approach as the upstream v15 tool. Only run scripts you own or are
authorised to analyse, on an isolated machine, with no real credentials.

Usage: python3 luraph151.py <input.lua> [-o outdir] [--luau /path/to/luau]
"""
import argparse, hashlib, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fold as fold_mod
import parse_protos
import extract_vm
import semantics
import lift as lift_mod

def find_luau(cli_value):
    cands = [cli_value, os.environ.get('LUAU_BIN'),
             os.path.join(HERE, 'bin', 'luau'),
             os.path.expanduser('~/workspace/roblox_deobf/bin/luau'),
             os.path.join(HERE, '..', 'Deobfuscator-Luraph-V15', 'bin', 'luau'),
             'luau']
    for c in cands:
        if not c: continue
        p = os.path.normpath(c) if '/' in c else c
        try:
            r = subprocess.run([p, '--help'], capture_output=True, timeout=10)
            if r.returncode == 0 or b'Usage' in (r.stdout + r.stderr):
                return p
        except Exception:
            continue
    return None

def luau_compile_ok(luau, path):
    if not luau: return None
    d = os.path.dirname(luau)
    comp = next((os.path.join(d, n) for n in ('luau-compile', 'luau-compile.exe')
                 if os.path.exists(os.path.join(d, n))), None)
    if not comp: return None
    r = subprocess.run([comp, path], capture_output=True, timeout=60)
    return r.returncode == 0

def luau_analyze(luau, path):
    """Return (exit_code, n_warnings) or None when luau-analyze is absent.
    Info only: obfuscated sources always draw warnings."""
    if not luau: return None
    d = os.path.dirname(luau)
    ana = next((os.path.join(d, n) for n in ('luau-analyze', 'luau-analyze.exe')
                if os.path.exists(os.path.join(d, n))), None)
    if not ana: return None
    r = subprocess.run([ana, path], capture_output=True, timeout=120)
    out = (r.stdout + r.stderr).decode('utf-8', errors='replace')
    return (r.returncode, out.count('Warning'))

def extract_key_candidates(folded):
    """Find candidate XOR keys for tag-3 strings: table literals of >=8
    comma-separated arithmetic items that all evaluate to bytes. The real
    key in the sample sits in the deserializer's string helper, its last
    byte written as an arithmetic expression."""
    cands = []
    for m in re.finditer(r'\{([0-9\s,+\-*()]{16,600})\}', folded):
        items = [it.strip() for it in m.group(1).split(',')]
        if len(items) < 8 or len(items) > 40: continue
        vals = []
        for it in items:
            v = fold_mod.safe_eval(it) if it else None
            if v is None or not (0 <= v <= 255): vals = None; break
            vals.append(v)
        if vals and len(vals) >= 8:
            cands.append(vals)
    return cands

def string_score(node):
    """Fraction of decrypted string constants that look like real text."""
    tot, good = 0, 0
    def walk(pr):
        nonlocal tot, good
        for v in pr['consts']:
            if isinstance(v, str):
                tot += 1
                if v and all(ch.isprintable() or ch in '\n\t\r' for ch in v):
                    good += 1
        for c in pr['children']: walk(c)
    walk(node)
    return (good / tot) if tot else 0.0

_BUFFER_READERS = {'readu8','readu16','readi16','readu32','readi32',
                   'readf32','readf64','readstring'}
def is_buffer_variant(src):
    # The buffer build never writes buffer.read* literally: readers are
    # installed into a method/slot table by name. Fingerprint = the buffer
    # global plus most of the reader-name set present in the source.
    if 'buffer' not in src:
        return False
    found = {r for r in _BUFFER_READERS if r in src}
    return len(found) >= 5

def buffer_route(src, data, outdir, luau, sha):
    """Buffer-based Luraph build (no string.unpack): fold, dump every
    buffer.read* via the proxy runner, and harvest the constant pool from
    the log. The header is a tagged-value stream (grammar cracked in the
    luraph_payload case); the body grammar is not yet reversed, so this
    route ends PARTIAL with full recon artifacts."""
    folded = fold_mod.fold_source(src)
    folded_path = os.path.join(outdir, 'folded.luau')
    open(folded_path, 'w', encoding='utf-8').write(folded)
    ok = luau_compile_ok(luau, folded_path)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes; luau-compile folded: {ok}")
    esc = ''.join('\\%03d' % b for b in data)
    template = open(os.path.join(HERE, 'runner_buffer.luau'), encoding='utf-8').read()
    runner_path = os.path.join(outdir, 'runner.luau')
    open(runner_path, 'w', encoding='utf-8').write(template.replace('__TARGET_SOURCE__', esc))
    log_path = os.path.join(outdir, 'buf.log')
    with open(log_path, 'w', encoding='utf-8') as lf:
        r = subprocess.run([luau, runner_path], stdout=lf, stderr=subprocess.STDOUT, timeout=600)
    reads, strings = [], []
    for line in open(log_path, encoding='utf-8', errors='replace'):
        p = line.rstrip('\n').split('\t')
        if len(p) >= 4 and p[0] == 'BUF|':
            reads.append((p[1], int(p[2]), p[3]))
            if p[1] == 'readstring' and p[3].startswith('HEX:'):
                try: strings.append((int(p[2]), bytes.fromhex(p[3][4:]).decode('utf-8', errors='replace')))
                except ValueError: pass
    mono = all(reads[i][1] <= reads[i + 1][1] for i in range(len(reads) - 1))
    with open(os.path.join(outdir, 'constant_pool.txt'), 'w', encoding='utf-8') as f:
        for off, s in strings:
            f.write(f"@{off}\t{s!r}\n")
    print(f"[3] buffer dump: {len(reads)} reads, offsets monotonic: {mono}, strings: {len(strings)}")
    # stage 3b: reconstruct the binary from the read log and try the
    # (case-verified) body grammar on the largest contiguous readu8 run
    body_info = None
    try:
        import struct as _struct
        import buffer_body
        size = max((off for _, off, _ in reads), default=0) + 64
        binbuf = bytearray(size)
        covered = bytearray(size)
        def put(off, bs):
            for n, b in enumerate(bs):
                if off + n < size:
                    binbuf[off + n] = b; covered[off + n] = 1
        for meth, off, val in reads:
            try:
                if meth == 'readu8': put(off, bytes([int(val) & 0xFF]))
                elif meth in ('readu16', 'readi16'): put(off, _struct.pack('<H', int(val) & 0xFFFF))
                elif meth in ('readu32', 'readi32'): put(off, _struct.pack('<I', int(val) & 0xFFFFFFFF))
                elif meth == 'readf32': put(off, _struct.pack('<f', float(val)))
                elif meth == 'readf64': put(off, _struct.pack('<d', float(val)))
                elif meth == 'readstring' and val.startswith('HEX:'):
                    put(off, bytes.fromhex(val[4:]))
            except (ValueError, OverflowError, _struct.error):
                pass
        u8 = sorted({off for meth, off, _ in reads if meth == 'readu8'})
        best = None
        if u8:
            run_s = prev = u8[0]; runs = []
            for o in u8[1:]:
                if o == prev + 1: prev = o; continue
                runs.append((run_s, prev)); run_s = prev = o
            runs.append((run_s, prev))
            best = max(runs, key=lambda r: r[1] - r[0])
        if best and best[1] - best[0] > 1000:
            lo_b, hi_b = best[0], best[1] + 1
            magic, protos = buffer_body.parse_body(bytes(binbuf[lo_b:hi_b]))
            n_instr = sum(len(p['instrs']) for p in protos)
            with open(os.path.join(outdir, 'binary.bin'), 'wb') as f:
                f.write(bytes(binbuf[:max(o for _, o, _ in reads) + 1]))
            with open(os.path.join(outdir, 'protos.json'), 'w') as f:
                json.dump({'magic': magic, 'body_range': [lo_b, hi_b],
                           'protos': protos}, f)
            body_info = (len(protos), n_instr, lo_b, hi_b)
            print(f"[3b] body grammar parsed: {len(protos)} protos, {n_instr} instructions, body [{lo_b}, {hi_b})")
    except Exception as e:
        print(f"[3b] body parse not applied: {e}")
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write("# luraph-v151-deobf report — buffer variant\n\n")
        f.write(f"- input: {len(data)} bytes, sha256 `{sha}`\n")
        f.write(f"- route: buffer-based Luraph build (no string.unpack deserializer)\n")
        f.write(f"- buffer reads logged: {len(reads)} (monotonic offsets: {mono})\n")
        f.write(f"- strings harvested from readstring: {len(strings)} (constant_pool.txt)\n")
        f.write(f"- luau-compile folded: {ok}\n")
        if body_info:
            f.write(f"- body grammar: **parsed** — {body_info[0]} protos, {body_info[1]} instructions, "
                    f"body [{body_info[2]}, {body_info[3]}) (protos.json, binary.bin)\n")
            f.write("- status: **PARTIAL** — bytecode fully recovered and verified "
                    "(parser consumption == read log); opcode semantics of this "
                    "variant (158 packed op words) are the remaining RE phase "
                    "before lifting to source.\n")
        else:
            f.write("- status: **PARTIAL** — deserializer fully dumped; body grammar\n")
            f.write("  parse was not applicable to this build.\n")
    print(f"done (PARTIAL buffer variant) -> {outdir}")
    return 5

def find_upstream():
    for cand in (os.environ.get('LURAPH_UPSTREAM_DIR', ''),
                 os.path.join(HERE, '..', 'Deobfuscator-Luraph-V15'),
                 os.path.expanduser('~/luau-deobf/tools/Deobfuscator-Luraph-V15')):
        if cand and os.path.isfile(os.path.join(cand, 'deob.js')):
            return os.path.abspath(cand)
    return None

def upstream_route(input_path, outdir, version, data_len, sha):
    """Luraph v15.0 / v14.x layouts are handled by the verified upstream
    Deobfuscator-Luraph-V15 (this engine cannot read them). Run it
    directly when the clone is available."""
    up = find_upstream()
    if not up:
        print("    upstream Deobfuscator-Luraph-V15 clone not found "
              "(set LURAPH_UPSTREAM_DIR); cannot process this layout here.")
        return 3
    out_path = os.path.join(outdir, 'deobfuscated_upstream.lua')
    env = dict(os.environ, PYTHON_BIN='python3')
    print(f"[upstream] Luraph v{version} -> upstream tool at {up}")
    try:
        r = subprocess.run(['node', 'deob.js', os.path.abspath(input_path),
                            '-o', out_path], cwd=up, env=env,
                           capture_output=True, text=True, timeout=1800)
    except subprocess.TimeoutExpired:
        print("    upstream tool timed out")
        return 5
    ok = r.returncode == 0 and os.path.isfile(out_path)
    tail = (r.stdout or '')[-500:]
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write("# luraph-deobf report — upstream route\n\n")
        f.write(f"- input: {data_len} bytes, sha256 `{sha}`\n")
        f.write(f"- detected: Luraph v{version} (not the v15.1 layout)\n")
        f.write(f"- engine: upstream Deobfuscator-Luraph-V15 at `{up}`\n")
        f.write(f"- result: {'ok' if ok else 'failed'} (exit {r.returncode})\n")
        f.write(f"- output: deobfuscated_upstream.lua\n\n```\n{tail}\n```\n")
    print(f"    upstream exit={r.returncode} output={'yes' if ok else 'no'}")
    if ok:
        print(tail[-300:])
        return 0
    print("    upstream stderr:", (r.stderr or '')[-300:])
    return 5

def is_v151_structural(src):
    """v15.1 layout fingerprint for files whose header comment was
    stripped: string.unpack proto deserializer + long-bracket blob +
    the `}).t(` method entry. The pipeline's later stages validate
    (exact log consumption + handler classification), so a false
    positive aborts there instead of producing garbage."""
    return ('string.unpack' in src
            and ('[==[' in src or '[=[' in src)
            and bool(re.search(r'\}\)\.t\(', src)))

def detect(src):
    head = src[:400]
    v151 = 'Luraph Obfuscator v15.1' in head
    markers = {
        'header_v15.1': v151,
        'string.unpack deserializer': 'string.unpack' in src,
        'ascii85+lz blob': '[==[' in src or '[=[' in src,
        'method entry .t(': bool(re.search(r'\}\)\.t\(', src)),
        'structural_v15.1': is_v151_structural(src),
    }
    return markers

def main():
    ap = argparse.ArgumentParser(description='Deobfuscate Luraph v15.1 scripts')
    ap.add_argument('input')
    ap.add_argument('-o', '--outdir', default=None)
    ap.add_argument('--luau', default=None)
    ap.add_argument('--force', action='store_true', help='continue even if v15.1 header not found')
    args = ap.parse_args()

    data = open(args.input, 'rb').read()
    src = data.decode('utf-8', errors='strict')
    sha = hashlib.sha256(data).hexdigest()
    outdir = args.outdir or os.path.splitext(os.path.basename(args.input))[0] + '-v151-deobf'
    os.makedirs(outdir, exist_ok=True)
    print(f"[0] input {args.input}  {len(data)} bytes  sha256={sha[:16]}...")

    markers = detect(src)
    print(f"[1] detect: {markers}")

    vm = re.search(r'Luraph Obfuscator v([0-9.]+)', src[:400])
    if vm and vm.group(1) != '15.1':
        return upstream_route(args.input, outdir, vm.group(1), len(data), sha)

    luau = find_luau(args.luau)
    if not luau:
        print("    Luau CLI not found (needed for stage 3/6). Set --luau or LUAU_BIN.")
        return 2
    print(f"    luau: {luau}")

    if not markers['header_v15.1']:
        if is_buffer_variant(src):
            print("    buffer-based Luraph variant detected -> buffer route")
            return buffer_route(src, data, outdir, luau, sha)
        if markers['structural_v15.1']:
            print("    header missing but v15.1 structural fingerprint matches -> proceeding (validated downstream)")
        elif not args.force:
            print("    NOT a Luraph v15.1 file (header missing). Aborting; use --force to try anyway.")
            return 2

    # stage 2: fold
    folded_path = os.path.join(outdir, 'folded.luau')
    folded = fold_mod.fold_source(src)
    open(folded_path, 'w', encoding='utf-8').write(folded)
    ok = luau_compile_ok(luau, folded_path)
    ana = luau_analyze(luau, folded_path)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes; luau-compile folded: {ok}; analyze: {ana}")
    if ok is False:
        print("    folded source does not compile; aborting")
        return 3

    # stage 3: dump unpack log via generated runner (target embedded, no io needed)
    esc = ''.join('\\%03d' % b for b in data)
    template = open(os.path.join(HERE, 'runner_template.luau'), encoding='utf-8').read()
    runner_path = os.path.join(outdir, 'runner.luau')
    open(runner_path, 'w', encoding='utf-8').write(template.replace('__TARGET_SOURCE__', esc))
    log_path = os.path.join(outdir, 'unpack.log')
    with open(log_path, 'w', encoding='utf-8') as lf:
        r = subprocess.run([luau, runner_path], stdout=lf, stderr=subprocess.STDOUT, timeout=300)
    print(f"[3] dump: runner exit={r.returncode}, log={log_path}")

    # stage 4: parse protos (must consume the log exactly). The XOR key for
    # string constants is build-specific in principle, so try every
    # candidate key found in the folded source and keep the parse whose
    # decrypted strings look most like real text.
    reads = parse_protos.load_log(log_path)
    candidates = extract_key_candidates(folded)
    if list(parse_protos.KEY13) not in candidates:
        candidates.append(list(parse_protos.KEY13))
    root_node, p, best = None, None, -1.0
    for cand in candidates:
        parse_protos.set_key(cand)
        try:
            pp = parse_protos.P(reads)
            node = parse_protos.read_proto(pp)
        except Exception:
            continue
        if pp.i != len(reads):
            continue
        score = string_score(node)
        if score > best:
            root_node, p, best, used_key = node, pp, score, cand
        if score >= 0.999:
            break
    if root_node is None:
        print(f"    PARSE MISMATCH: no candidate key consumed the full log "
              f"({len(candidates)} candidates tried); aborting")
        return 4
    print(f"    xor key: {used_key} (string score {best:.3f})")
    protos_path = os.path.join(outdir, 'protos.json')
    json.dump(root_node, open(protos_path, 'w'), indent=1)
    def count(pr):
        sub = [count(c) for c in pr['children']]
        return 1 + sum(s[0] for s in sub), len(pr['code']['A']) + sum(s[1] for s in sub)
    nproto, ninstr = count(root_node)
    print(f"[4] parse: consumed {p.i}/{len(reads)} reads; {nproto} protos, {ninstr} instructions")

    # stage 5: extract + classify
    opnames = extract_vm.extract_y(folded)
    handlers = extract_vm.extract_handlers(folded)
    json.dump({str(k): v for k, v in sorted(opnames.items())},
              open(os.path.join(outdir, 'opnames.json'), 'w'), indent=0)
    json.dump(handlers, open(os.path.join(outdir, 'handlers.json'), 'w'), indent=1)
    extract_vm.disassemble(root_node, opnames, os.path.join(outdir, 'disasm.txt'))
    classes = semantics.classify(handlers)
    json.dump({k: v for k, v in sorted(classes.items())},
              open(os.path.join(outdir, 'ops.json'), 'w'), indent=1)
    unknown = [nm for nm in opnames.values() if classes.get(nm) in (None, 'UNKNOWN')]
    print(f"[5] extract: {len(opnames)} opcodes, {len(handlers)} handlers, unknown ops: {unknown or 'none'}")

    # stage 6: lift + verify
    lifted_path = os.path.join(outdir, 'lifted.luau')
    report_path = os.path.join(outdir, 'lift_report.json')
    sys.argv = ['lift.py', protos_path, os.path.join(outdir, 'opnames.json'),
                os.path.join(outdir, 'handlers.json'), lifted_path, report_path]
    lift_mod.main()
    ok2 = luau_compile_ok(luau, lifted_path)
    ana2 = luau_analyze(luau, lifted_path)
    print(f"[6] lift: luau-compile lifted: {ok2}; analyze: {ana2}")

    lift_report = json.load(open(report_path))
    structured = sum(1 for v in lift_report['protos'].values() if v['structured'])
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write(f"# luraph-v151-deobf report\n\n")
        f.write(f"- input: `{os.path.basename(args.input)}` ({len(data)} bytes, sha256 `{sha}`)\n")
        f.write(f"- detect: {markers}\n")
        f.write(f"- protos: {nproto}, instructions: {ninstr}, unpack reads consumed: {p.i}/{len(reads)}\n")
        f.write(f"- opcodes classified: {len(opnames) - len(unknown)}/{len(opnames)}"
                f" (unknown: {unknown or 'none'})\n")
        f.write(f"- lifted protos structured: {structured}/{len(lift_report['protos'])}"
                f"; pc-loop fallback: {list(lift_report['fallback']) or 'none'}\n")
        f.write(f"- xor key used: {used_key} (string score {best:.3f})\n")
        f.write(f"- luau-compile: folded={ok}, lifted={ok2}; luau-analyze: folded={ana}, lifted={ana2}\n")
        f.write(f"\nOutputs: folded.luau, protos.json, opnames.json, handlers.json, ops.json,\ndisasm.txt, lifted.luau, lift_report.json, unpack.log, runner.luau\n")
    print(f"done -> {outdir}")
    return 0

if __name__ == '__main__':
    sys.exit(main())
