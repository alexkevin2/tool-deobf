#!/usr/bin/env bash
# Luau-Deobf-Tool regression: byte-identical reproduction of the case
# golden outputs, from (a) this tool dir and (b) an unpacked copy of the
# shipped zip in a clean dir. Isolated: fake HOME + TMPDIR on persistent
# storage under this package (never /tmp). Log: tests/regression_results.log
# The zip under test is (re)built from this tree at the start of phase (b)
# and rebuilt once more at the end so the shipped zip carries this log;
# the tool code in both builds is identical.
set -u
TOOL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ZIP_PATH="${ZIP_PATH:-$HOME/workspace/your_files/Luau-Deobf-Tool.zip}"
SCRATCH="$TOOL_DIR/tests/.regression"
LOG="$TOOL_DIR/tests/regression_results.log"
REAL_HOME="$HOME"
export HOME="$SCRATCH/home"
export TMPDIR="$SCRATCH/tmp"
mkdir -p "$HOME" "$TMPDIR" "$SCRATCH"
: > "$LOG"
FAIL=0
say() { echo "$@" | tee -a "$LOG"; }

build_zip() {
  mkdir -p "$(dirname "$ZIP_PATH")"
  python3 - "$TOOL_DIR" "$ZIP_PATH" <<'PYEOF'
import pathlib, sys, zipfile
tool, zipp = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
skip_dirs = {".regression", ".run1", "__pycache__"}
with zipfile.ZipFile(zipp, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(tool.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(tool)
        if any(part in skip_dirs for part in rel.parts):
            continue
        z.write(f, f"Luau-Deobf-Tool/{rel}")
print(f"zip built: {zipp}")
PYEOF
}

check_tree() {  # $1 = tool dir to run, $2 = label, $3 = outroot
  local tool="$1" label="$2" outroot="$3"
  mkdir -p "$outroot"
  local s f found rc
  for s in mos_hub hwf_loader kaitun_cyborg; do
    ( cd "$tool" && python3 luau_deobf.py "tests/samples/$s.lua.txt" -o "$outroot/out_$s" ) >>"$LOG" 2>&1
    rc=$?
    if [ $rc -ne 0 ]; then say "FAIL [$label] $s: CLI exit $rc"; FAIL=1; fi
  done
  for f in mos_hub.deobf.luau mos_hub.payload.bin mos_hub.payload.luau \
           hwf_loader.deobf.luau hwf_loader.payload.luau \
           recovered_constants.luau kaitun_cyborg.deobf.luau; do
    found="$(find "$outroot" -name "$f" | head -1)"
    if [ -n "$found" ] && cmp -s "$found" "$TOOL_DIR/tests/golden/$f"; then
      say "PASS [$label] byte-identical: $f"
    else
      say "FAIL [$label] DIFFERS or missing: $f"; FAIL=1
    fi
  done
  # luau-compile exit 0 for every produced .luau
  while IFS= read -r lf; do
    if "$TOOL_DIR/bin/luau-compile" "$lf" >/dev/null 2>&1; then
      say "PASS [$label] luau-compile 0: $(basename "$lf")"
    else
      say "FAIL [$label] luau-compile nonzero: $lf"; FAIL=1
    fi
  done <<EOF
$(find "$outroot" -name '*.luau' | sort)
EOF
}

say "== Luau-Deobf-Tool regression $(date -u +%Y-%m-%dT%H:%M:%SZ) =="
say "-- phase (a): run from tool dir --"
check_tree "$TOOL_DIR" "tool-dir" "$SCRATCH/a"

say "-- negative control: unknown family must exit 2 --"
NEG="$REAL_HOME/luau-deobf/work/stealaneggs/stealaneggs_raw.luau"
if [ ! -f "$NEG" ]; then
  NEG="$SCRATCH/plain.luau"
  printf -- '-- plain non-obfuscated script\nprint("hello")\n' > "$NEG"
fi
python3 "$TOOL_DIR/luau_deobf.py" "$NEG" -o "$SCRATCH/neg_out" >>"$LOG" 2>&1
rc=$?
if [ $rc -eq 2 ]; then say "PASS [negative] exit 2 on $NEG"; else say "FAIL [negative] exit $rc (want 2) on $NEG"; FAIL=1; fi

say "-- router + spoof checks (tool dir, v2.0) --"
python3 "$TOOL_DIR/tests/check_router.py" "$TOOL_DIR" >>"$LOG" 2>&1
rc=$?
if [ $rc -eq 0 ]; then say "PASS [router] check_router.py"; else say "FAIL [router] check_router.py rc=$rc"; FAIL=1; fi
python3 "$TOOL_DIR/tests/check_spoof.py" "$TOOL_DIR" >>"$LOG" 2>&1
rc=$?
if [ $rc -eq 0 ]; then say "PASS [spoof] check_spoof.py"; else say "FAIL [spoof] check_spoof.py rc=$rc"; FAIL=1; fi

say "-- phase (b): run from unpacked zip in a clean dir --"
build_zip >>"$LOG" 2>&1
rm -rf "$SCRATCH/unpacked"
mkdir -p "$SCRATCH/unpacked"
python3 -c "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])" "$ZIP_PATH" "$SCRATCH/unpacked"
check_tree "$SCRATCH/unpacked/Luau-Deobf-Tool" "zip" "$SCRATCH/b"

if [ $FAIL -eq 0 ]; then
  say "ALL CHECKS PASS"
else
  say "REGRESSION FAILED"
fi
# Final rebuild so the shipped zip contains the completed log (which
# ends with ALL CHECKS PASS). The zip hash goes to stdout only, so the
# log's last line stays ALL CHECKS PASS.
build_zip >/dev/null 2>&1
sha256sum "$ZIP_PATH"
exit $FAIL
