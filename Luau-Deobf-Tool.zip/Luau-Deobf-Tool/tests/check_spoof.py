#!/usr/bin/env python3
"""Spoof-port validation for Luau-Deobf-Tool v2.0 (SPOOF-SPEC §10 Luau).

Usage: python3 tests/check_spoof.py [tool_dir]

Checks (scratch under tests/.regression/spoofcheck; payloads are never
executed outside the tool's existing harnesses, and no URL is fetched):
  S1  Vendored spoof_engine.py is byte-identical to the canonical
      Luraph v6 copy (sha256 d33daef8...).
  S2  Scanner on the synthetic multi-gate fixture
      (tests/fixtures/spoof_gate.luau — clearly-labelled TEST DATA):
      PlaceId eq-const + CreatorId set-membership x2, with sites.
  S3  Dynamic mock-runner controls on that fixture (bundled luau,
      game mock only — the fixture is hand-written test code, not a
      payload): primary-fork seeds -> GATE-PASS; probe serving ->
      DECOY-BRANCH; wrong seed -> DECOY-BRANCH. Seeds are taken from
      the scanner's own extraction (plan_forks primary), never typed
      into the runner template by hand.
  S4  CLI auto runs on the 3 goldens: identity_report.json exists with
      schema spoof-engine/1; route B gates [] (honest: no identity
      reads in the recovered payload); route C PlaceId forked with 6
      eq-const candidates + JobId unknown + seed [] (multi-value
      dispatch, no single value asserted); route A notes carry UNKNOWN
      + the ChaCha20/PRNG blocker and gates [].
  S5  CLI off-mode on the 3 goldens: no identity_report.json, no
      identity section in report.md, and all 7 primary artifacts
      byte-identical to tests/golden/.
  S6  No-hardcode audit: the fixture test values appear 0 times in
      production code (luau_deobf.py + modules/**/*.py + vendored
      spoof_engine.py, excluding tests/); all other 9+-digit literals
      in production code are printed for triage.
  S7  Scanner determinism: scan of the kaitun lifted golden under
      PYTHONHASHSEED=0 and =42 gives identical candidate JSON.
Exit 0 only when every check passes.
"""
import hashlib
import json
import pathlib
import re
import subprocess
import sys

TOOL = pathlib.Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else \
    pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TOOL))
sys.path.insert(0, str(TOOL / "modules"))
import spoof_engine as SE  # noqa: E402
from spoof_scan import scan_source  # noqa: E402

# Canonical tree beside this tool (robust under the regression script's
# fake HOME); if absent (e.g. zip copy run elsewhere), the pinned sha
# below is the identity check itself.
CANON = pathlib.Path(sys.argv[1]).resolve().parent.parent / "tools" / \
    "Luraph-Deobf-Tool-v6" / "spoof_engine.py" if len(sys.argv) > 1 else \
    pathlib.Path(__file__).resolve().parent.parent.parent / \
    "Luraph-Deobf-Tool-v6" / "spoof_engine.py"
CANON_SHA = "d33daef82bd5c0ffb086daef4978fd0423fa30dfd0024741507b080d35230d6b"
FIXTURE_VALUES = ["4000000001", "4000000002", "4000000003"]
FAIL = []


def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + (f" — {detail}" if detail else ""))
    if not cond:
        FAIL.append(name)


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def run_cli(sample, outdir, extra=()):
    return subprocess.run(
        [sys.executable, str(TOOL / "luau_deobf.py"), str(sample),
         "-o", str(outdir), *extra],
        capture_output=True, text=True, cwd=str(TOOL), timeout=900)


def main():
    scratch = TOOL / "tests" / ".regression" / "spoofcheck"
    scratch.mkdir(parents=True, exist_ok=True)

    # S1 — vendored copy identity.
    vend = TOOL / "spoof_engine.py"
    check("S1 vendored spoof_engine byte-identical to canonical",
          sha(vend) == CANON_SHA,
          f"vendored={sha(vend)[:8]} canonical={CANON_SHA[:8]}"
          + (f" canon-file={sha(CANON)[:8]}" if CANON.exists() else " canon-file-absent"))

    # S2 — scanner on the synthetic fixture.
    fx = TOOL / "tests" / "fixtures" / "spoof_gate.luau"
    scan = scan_source(fx.read_text(), "synthetic")
    cands = {f: [(c["value"], c["kind"]) for c in v]
             for f, v in scan["candidates"].items()}
    check("S2 fixture extraction: PlaceId eq-const + CreatorId set x2",
          cands == {"PlaceId": [(4000000001, "eq-const")],
                    "CreatorId": [(4000000002, "set-membership"),
                                  (4000000003, "set-membership")]},
          f"cands={cands}")
    forks, primary = SE.plan_forks(scan["candidates"])
    check("S2 fork plan: primary + 1 one-field variant = 2 forks",
          len(forks) == 2 and primary == {"CreatorId": 4000000002,
                                           "PlaceId": 4000000001},
          f"forks={forks}")

    # S3 — dynamic mock-runner controls (fixture only, bundled luau).
    prelude_tpl = (
        "local __seeds = {SEEDS}\n"
        "local __probe = 7777777777777\n"
        "game = setmetatable({}, { __index = function(_, k)\n"
        "  if __seeds[k] ~= nil then return __seeds[k] end\n"
        "  return __probe\n"
        "end })\n")
    body = fx.read_text()

    def run_mock(seeds):
        seed_luau = ", ".join(f"{k} = {v}" for k, v in sorted(seeds.items()))
        runner = scratch / "mock_runner.luau"
        runner.write_text(prelude_tpl.replace("SEEDS", seed_luau) + body)
        r = subprocess.run([str(TOOL / "bin" / "luau"), str(runner)],
                           capture_output=True, text=True, timeout=60)
        return r.stdout
    out_pass = run_mock(primary)
    out_probe = run_mock({})
    out_wrong = run_mock({"PlaceId": 1, "CreatorId": 4000000002})
    check("S3 seeded primary fork -> GATE-PASS",
          "GATE-PASS" in out_pass and "DECOY" not in out_pass, out_pass.strip()[:80])
    check("S3 probe serving -> DECOY-BRANCH",
          "DECOY-BRANCH" in out_probe, out_probe.strip()[:80])
    check("S3 wrong seed -> DECOY-BRANCH",
          "DECOY-BRANCH" in out_wrong, out_wrong.strip()[:80])

    # S4/S5 — CLI auto + off on the 3 goldens.
    goldens = {
        "mos_hub": ["mos_hub.deobf.luau", "mos_hub.payload.bin", "mos_hub.payload.luau"],
        "hwf_loader": ["hwf_loader.deobf.luau", "hwf_loader.payload.luau"],
        "kaitun_cyborg": ["recovered_constants.luau", "kaitun_cyborg.deobf.luau"],
    }
    for s, artifacts in goldens.items():
        auto = scratch / f"auto_{s}"
        r = run_cli(TOOL / "tests" / "samples" / f"{s}.lua.txt", auto)
        rep_p = auto / "identity_report.json"
        ok = r.returncode == 0 and rep_p.exists()
        rep = json.loads(rep_p.read_text()) if rep_p.exists() else {}
        if s == "hwf_loader":
            ok = ok and rep.get("schema_version") == "spoof-engine/1" \
                and rep.get("route") == "luau-deobf-B" \
                and rep.get("gates") == [] and rep.get("fields_seen") == [] \
                and rep.get("forks") == []
        elif s == "kaitun_cyborg":
            gates = {g["field"]: g for g in rep.get("gates", [])}
            ok = ok and rep.get("route") == "luau-deobf-C" \
                and gates.get("PlaceId", {}).get("status") == "forked" \
                and len(gates.get("PlaceId", {}).get("candidates", [])) == 6 \
                and all(c["kind"] == "eq-const" for c in
                        gates.get("PlaceId", {}).get("candidates", [])) \
                and gates.get("JobId", {}).get("status") == "unknown" \
                and rep.get("seed") == [] and rep.get("forks") == []
        elif s == "mos_hub":
            notes = " ".join(rep.get("notes", []))
            ok = ok and rep.get("route") == "luau-deobf-A" \
                and rep.get("gates") == [] and "UNKNOWN" in notes \
                and "ChaCha20" in notes and "Random" in notes
        check(f"S4 auto identity_report {s}", ok,
              f"rc={r.returncode} gates={[(g['field'], g['status']) for g in rep.get('gates', [])]}")
        off = scratch / f"off_{s}"
        r2 = run_cli(TOOL / "tests" / "samples" / f"{s}.lua.txt", off,
                     extra=("--spoof-id", "off"))
        prim_ok = r2.returncode == 0 and not (off / "identity_report.json").exists() \
            and "Identity spoofing" not in (off / "report.md").read_text()
        for a in artifacts:
            prim_ok = prim_ok and (off / a).exists() and \
                (off / a).read_bytes() == (TOOL / "tests" / "golden" / a).read_bytes()
        check(f"S5 off-mode byte-identity + no identity artifacts {s}",
              prim_ok, f"rc={r2.returncode}")

    # S6 — no-hardcode audit over production code only.
    prod_files = [TOOL / "luau_deobf.py", TOOL / "spoof_engine.py"] + \
        sorted((TOOL / "modules").rglob("*.py"))
    hits = {}
    for p in prod_files:
        t = p.read_text(errors="replace")
        for v in FIXTURE_VALUES:
            if v in t:
                hits.setdefault(v, []).append(str(p.relative_to(TOOL)))
    check("S6 fixture test values absent from production code",
          not hits, f"hits={hits}")
    lits = {}
    for p in prod_files:
        for m in re.finditer(r"\d{9,}", p.read_text(errors="replace")):
            lits.setdefault(m.group(0), set()).add(str(p.relative_to(TOOL)))
    print("S6 triage of 9+-digit literals in production code "
          "(none may be a game ID; expected: probe marker + VM constants):")
    for lit in sorted(lits):
        print(f"  {lit} in {sorted(lits[lit])}")

    # S7 — scanner determinism across hash seeds.
    scan_code = (
        "import sys, json; sys.path.insert(0, 'modules'); "
        "from spoof_scan import scan_source; "
        "t = open('tests/golden/kaitun_cyborg.deobf.luau').read(); "
        "print(json.dumps(scan_source(t, 'lifted')['candidates'], sort_keys=True))")
    outs = []
    for seed in ("0", "42"):
        import os
        env = dict(os.environ, PYTHONHASHSEED=seed)
        r = subprocess.run([sys.executable, "-c", scan_code], capture_output=True,
                           text=True, cwd=str(TOOL), env=env, timeout=120)
        outs.append(r.stdout)
    check("S7 scanner deterministic across PYTHONHASHSEED 0/42",
          outs[0] == outs[1] and outs[0] != "",
          f"len={len(outs[0])}")
    # S7b — full CLI determinism on the fast route B (payload sha).
    import os
    pay_hashes = []
    for seed in ("0", "7"):
        env = dict(os.environ, PYTHONHASHSEED=seed)
        d = scratch / f"det_{seed}"
        r = subprocess.run([sys.executable, str(TOOL / "luau_deobf.py"),
                            str(TOOL / "tests" / "samples" / "hwf_loader.lua.txt"),
                            "-o", str(d), "--spoof-id", "off"],
                           capture_output=True, text=True, cwd=str(TOOL),
                           env=env, timeout=600)
        pay_hashes.append(sha(d / "hwf_loader.payload.luau") if r.returncode == 0 else "rc!=0")
    check("S7b CLI route B payload deterministic across PYTHONHASHSEED 0/7",
          pay_hashes[0] == pay_hashes[1] and pay_hashes[0] != "rc!=0",
          f"payload sha={pay_hashes[0][:12]}")

    print("ALL SPOOF CHECKS PASS" if not FAIL else f"SPOOF FAILED: {FAIL}")
    return 0 if not FAIL else 1


if __name__ == "__main__":
    sys.exit(main())
