#!/usr/bin/env python3
"""spoof_engine.py — SHARED dynamic game-ID spoof engine (v1.0.0).

Single standalone module, pure Python standard library, no Luau
runtime dependency, no tool-specific imports.  It is the common core
for game-ID spoofing across the Luau deobfuscation tool families
(Luraph v6, MoonVeil, Luast, Luau-Deobf-Tool).  Each tool keeps its
own tool-specific scanner / executor hook / runner; this module owns
only the portable semantics, so a port needs no re-derivation:

  * the gate model (which fields count as game identity, which
    comparison shapes count as gates, how strong each shape is);
  * candidate bookkeeping (dedupe by (value, kind), evidence merge,
    deterministic ordering);
  * multi-gate / multi-candidate fork planning (bounded, ordered);
  * seed resolution (exactly-one-candidate fields only);
  * the sentinel / comparison-capture state machine (for Python
    executors whose equality hook sees both operands);
  * identity_report.json construction — a UNIFIED schema (see
    SPOOF-SPEC.md), plus byte-compatible legacy shapes for the two
    Luraph v6 routes so existing goldens keep passing.

NEVER HARDCODE A GAME ID HERE.  There is no game-ID literal in this
file (and there must never be one): every value the engine serves
comes from static extraction over the analysed script, from a
comparison capture during execution, or from the caller-supplied
seed dict (which itself must be derived from extraction, never
typed in).  The only numeric constant that looks ID-shaped is
PROBE_VALUE, and it is NOT a game ID: it is a distinctive probe
marker served for unseeded reads so the tool can tell "this branch
ran without a candidate" apart from "this branch ran with a
candidate".  A probe-served read is logged with source 'probe' and
must never be reported as a candidate or as a gate-PASS value.

SCOPE — local analysis only.  The engine configures mock
environments the analysing tool itself runs.  It never contacts a
server, never fetches a URL, and never executes a remote payload:
remote-load calls (HttpGet & co) stay logged mock interactions
answered with inert values by the tool's own mock layer.  IDs that
are checked server-side cannot be spoofed locally and are out of
scope by construction.  Where a gate value cannot be recovered
statically and is not captured during execution, the engine
reports the field UNKNOWN, forks both branches where the tool
supports forking, and never guesses a value.

Usage pattern for a porting tool (see SPOOF-SPEC.md §7):

    import spoof_engine as se
    cands, seen = se.extract_cooccurrence(instrs)   # or your own
    # scanner feeding se.add_candidate(...) / se.collect_events(...)
    seed = se.build_seed(cands)                     # unambiguous only
    forks, primary = se.plan_forks(cands)           # bounded, ordered
    state = se.SpoofState(enabled=True, seed=seed)  # Python executors
    rep = se.build_report(route='mytool', ...)      # unified schema
"""

# ------------------------------------------------------------------ model
# Canonical identity fields.  Tools may pass EXTRA field names (any
# `game.*` member compared against a constant or a set) via the
# `extra_fields` parameter of the extraction helpers; extras are
# treated exactly like canonical fields but are listed separately
# in the report (`extra_fields`) so a reader can tell the standard
# set from tool-specific extensions.
IDENTITY_FIELDS = ('PlaceId', 'JobId', 'CreatorId', 'PlaceVersion',
                   'GameId')

# Distinctive probe marker for unseeded identity reads.  NOT a game
# ID, never a candidate, never a default seed (see module docstring).
PROBE_VALUE = 7777777777777

# Fork-planning caps, inherited from the validated Luraph v6 method
# route (regression Part E).  Changing them changes fork counts and
# therefore every downstream golden that records forks.
MAX_FORKS_PER_FIELD = 4
MAX_FORKS_TOTAL = 9

# Gate-pattern vocabulary.  `rank` orders candidates for the primary
# fork: strong kinds first, then by str(value) for determinism.
# Legacy kinds keep their legacy ranks (eq-const / set-membership 0,
# lt-bound 1, pool 2) so v6's existing ordering is preserved.
KIND_RANK = {
    'eq-const': 0,
    'set-membership': 0,
    'ne-const': 1,
    'lt-bound': 1,
    'gt-bound': 1,
    'le-bound': 1,
    'ge-bound': 1,
    'same-instruction': 2,
    'proto-consts': 2,
    'pool': 3,
}
STRONG_KINDS = ('eq-const', 'set-membership')
# Kinds whose value is NOT a gate-PASS value: seeding them as-is
# guarantees the decoy branch (ne-const) or is only a bound, not an
# equality target (lt/gt/le/ge-bound).  Fork plans keep them as
# weak candidates for legacy compatibility, but the unified report
# flags them (see build_gates) and ports SHOULD prefer
# expand_bound_candidates() / a non-equal probe for these kinds.
NON_PASS_KINDS = ('ne-const', 'lt-bound', 'gt-bound', 'le-bound',
                  'ge-bound')

# Comparison-event op -> candidate kind (for tool scanners that feed
# collect_events() instead of building candidates directly).
OP_KIND = {
    'eq': 'eq-const',
    'ne': 'ne-const',
    'in-set': 'set-membership',
    'lt': 'lt-bound',
    'gt': 'gt-bound',
    'le': 'le-bound',
    'ge': 'ge-bound',
    'co-occur': 'same-instruction',
    'proto-consts': 'proto-consts',
    'pool': 'pool',
}

SCHEMA_VERSION = 'spoof-engine/1'


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _decode_other(entry):
    """Decode a constant-table entry that may encode a byte string
    as {'other': "b'...'"} or as the bare repr string "b'...'".
    Returns the decoded str, or None for non-string entries."""
    import ast
    if isinstance(entry, dict) and 'other' in entry:
        return _decode_other(entry['other'])
    if isinstance(entry, str):
        if entry.startswith(("b'", 'b"')):
            try:
                b = ast.literal_eval(entry)
            except Exception:
                return None
            if isinstance(b, bytes):
                return b.decode('utf-8', 'replace')
            return None
        return entry
    return None


# ------------------------------------------------------- candidate store
def new_candidate(value, kind, proto=None, pc=None, pattern=None):
    """One candidate record.  `evidence` is a list of site dicts
    {proto, pc, pattern}; callers may pass evidence entries with
    extra keys, which are preserved verbatim."""
    ev = {'proto': proto, 'pc': pc, 'pattern': pattern}
    return {'value': value, 'kind': kind, 'evidence': [ev]}


def add_candidate(candidates, field, value, kind, proto=None, pc=None,
                  pattern=None):
    """Append (or merge evidence into) a candidate.  Dedupe key is
    (value, kind): the same value from a different gate shape is a
    second candidate, not a duplicate.  Insertion order is
    preserved; call sort_candidates() explicitly when a sorted
    order is required (the method route sorts; the bootstrap route
    historically does not, and its adapter keeps scan order)."""
    lst = candidates.setdefault(field, [])
    for c in lst:
        if c['value'] == value and c['kind'] == kind:
            ev = {'proto': proto, 'pc': pc, 'pattern': pattern}
            if ev not in c['evidence']:
                c['evidence'].append(ev)
            return c
    c = new_candidate(value, kind, proto, pc, pattern)
    lst.append(c)
    return c


def sort_candidates(candidates):
    """In-place deterministic sort per field: kind rank, then
    str(value).  This is the method route's legacy ordering."""
    for field in candidates:
        candidates[field].sort(
            key=lambda c: (KIND_RANK.get(c['kind'], 9), str(c['value'])))
    return candidates


def distinct_values(candidates, field):
    """Distinct candidate values for a field, in candidate order."""
    vals = []
    for c in candidates.get(field, []):
        if c['value'] not in vals:
            vals.append(c['value'])
    return vals


def collect_events(candidates, events, fields=None):
    """Feed tool-scanner comparison events into the candidate store.

    Each event is a dict with keys: field (str), op (one of OP_KIND
    keys), value (number or str), proto, pc, pattern.  Events whose
    field is not an identity field (canonical or caller-supplied
    `fields`) are ignored; non-numeric, non-string values are
    ignored.  Returns the updated `candidates` dict."""
    allowed = set(IDENTITY_FIELDS)
    if fields:
        allowed |= set(fields)
    for e in (events or []):
        field = e.get('field')
        if field not in allowed:
            continue
        kind = OP_KIND.get(e.get('op'))
        if kind is None:
            continue
        v = e.get('value')
        if not (_is_num(v) or isinstance(v, str)):
            continue
        add_candidate(candidates, field, v, kind,
                      proto=e.get('proto'), pc=e.get('pc'),
                      pattern=e.get('pattern'))
    return candidates


# ------------------------------------------------- generic static scans
def extract_cooccurrence(structs, fields=None):
    """Bootstrap-route scan, generalised: over {pid: {'instructions':
    [{mode, pc, name, K}]}} (K = resolved operand constants), an
    instruction whose K operands contain an identity field name
    together with numeric operands yields those numbers as
    'same-instruction' candidates for the field.

    Returns (candidates, fields_seen) where fields_seen maps field
    -> ["<pid> <mode>:<pc>", ...] in scan order.  This is weak
    evidence by design (co-occurrence, not a proven comparison);
    tools with a real dataflow pass should prefer collect_events()
    with proven gate shapes."""
    allowed = set(IDENTITY_FIELDS)
    if fields:
        allowed |= set(fields)
    candidates = {}
    fields_seen = {}
    for pid, st in (structs or {}).items():
        if not isinstance(st, dict):
            continue
        for ins in st.get('instructions') or []:
            K = ins.get('K') or []
            names = [s for s in (_decode_other(e) for e in K) if s]
            nums = [e for e in K if _is_num(e)]
            for name in names:
                if name not in allowed:
                    continue
                fields_seen.setdefault(name, [])
                loc = f"{pid} {ins.get('mode')}:{ins.get('pc')}"
                if loc not in fields_seen[name]:
                    fields_seen[name].append(loc)
                for n in nums:
                    # Evidence shape is the bootstrap route's legacy
                    # shape verbatim: {proto, mode, pc, op}.
                    lst = candidates.setdefault(name, [])
                    for c in lst:
                        if c['value'] == n:
                            c['evidence'].append(
                                {'proto': pid,
                                 'mode': ins.get('mode'),
                                 'pc': ins.get('pc'),
                                 'op': ins.get('name')})
                            break
                    else:
                        lst.append(
                            {'value': n, 'kind': 'same-instruction',
                             'evidence': [{'proto': pid,
                                           'mode': ins.get('mode'),
                                           'pc': ins.get('pc'),
                                           'op': ins.get('name')}]})
    return candidates, fields_seen


def extract_field_presence(doc, fields=None):
    """Presence-only scan over an arbitrary JSON-able document
    (e.g. a materializer output): returns {field: [paths]} for
    identity field names occurring as string values.  Presence is
    NOT candidacy: co-occurring numbers in such a document are not
    treated as candidates (the materializer resolves constants out
    of instruction context)."""
    allowed = set(IDENTITY_FIELDS)
    if fields:
        allowed |= set(fields)
    seen = {}

    def walk(o, path):
        if isinstance(o, dict):
            for k, v in o.items():
                walk(v, f'{path}/{k}')
        elif isinstance(o, list):
            for i, v in enumerate(o):
                walk(v, f'{path}/{i}')
        elif isinstance(o, str):
            s = _decode_other(o) if o.startswith("b'") else o
            if s in allowed:
                seen.setdefault(s, []).append(path)

    if isinstance(doc, dict):
        walk(doc, '')
    return seen


# ------------------------------------------------------------ resolution
def build_seed(candidates):
    """Seed only unambiguous fields (exactly one distinct static
    candidate value).  Ambiguous fields stay unseeded so the
    executor's comparison capture (SpoofState) or the fork plan can
    resolve them.  Never invents a value."""
    seed = {}
    for f, lst in (candidates or {}).items():
        if len(distinct_values(candidates, f)) == 1:
            seed[f] = lst[0]['value']
    return seed


def plan_forks(candidates, max_per_field=MAX_FORKS_PER_FIELD,
               max_total=MAX_FORKS_TOTAL):
    """Deterministic fork list.  Fork 0 seeds every field with its
    best (first, i.e. strongest-sorted) candidate; further forks
    vary ONE field at a time over its remaining candidates (up to
    `max_per_field` values per field, `max_total` forks total).
    Fields are visited in sorted order; duplicate seed dicts are
    dropped.  Returns (forks, primary) where forks is a list of
    seed dicts {field: value} and primary is fork 0's seed dict.

    LIMIT (documented, not hidden): one-field-at-a-time forking
    does not cover interacting multi-gate combinations (a
    gate-PASS path that needs two non-primary values at once).
    Such cases surface as: no fork shows gate-PASS evidence, and
    the report's unknown/unresolved fields name the gap.  Full
    cartesian forking is exponential and is deliberately not
    attempted; the bootstrap route's contradiction log is the
    complementary signal for interacting gates."""
    fields = sorted(candidates)
    primary = {}
    for f in fields:
        if candidates[f]:
            primary[f] = candidates[f][0]['value']
    forks = [dict(primary)]
    for f in fields:
        for v in distinct_values(candidates, f)[1:max_per_field]:
            if len(forks) >= max_total:
                break
            fk = dict(primary)
            fk[f] = v
            if fk not in forks:
                forks.append(fk)
        if len(forks) >= max_total:
            break
    return forks, primary


def candidate_source(candidates, field, value):
    """Provenance label for a seeded value: 'static:<kind>' for the
    first matching candidate kind, else 'fork'."""
    for c in candidates.get(field, []):
        if c['value'] == value:
            return 'static:' + c['kind']
    return 'fork'


def expand_bound_candidates(value, kind):
    """OPT-IN helper for sibling ports (NOT used by the v6 legacy
    fork plan, which seeds bound values verbatim for golden
    compatibility).  For a bound kind, the gate-PASS value is not
    the bound itself: lt/le need a value above the bound, gt/ge a
    value below it.  Returns [bound, bound+1, bound-1] filtered to
    the passing side plus the bound itself (kept so the decoy
    branch stays observable): lt/le -> [bound, bound+1];
    gt/ge -> [bound, bound-1].  Non-bound kinds return [value]."""
    if not _is_num(value):
        return [value]
    if kind in ('lt-bound', 'le-bound'):
        return [value, value + 1]
    if kind in ('gt-bound', 'ge-bound'):
        return [value, value - 1]
    return [value]


def build_gates(candidates, fields_read=None, captures=None,
                contradictions=None, extra_fields=None):
    """Per-field gate records for the unified report.  Status is
    derived, never guessed:

      seeded       exactly one distinct candidate (build_seed)
      forked       several candidates (fork plan resolves per fork)
      captured     no static candidate but a comparison capture
                   adopted a value during execution
      contradicted captures/contradictions disagree for the field
      unknown      field read/seen but no candidate and no capture
    `spoofed_value` is set only for seeded/captured fields (the
    value actually served); for forked fields it is the primary
    fork's value with `forked: true`; for unknown fields it is
    null.  Non-pass kinds (bounds, ne-const) are flagged so a
    reader does not mistake a bound for a gate-PASS value."""
    captures = captures or {}
    contradictions = contradictions or {}
    gates = []
    fields = sorted(set(candidates or {}) |
                    set(fields_read or {}) |
                    set(captures) | set(contradictions))
    for f in fields:
        cands = candidates.get(f, [])
        vals = distinct_values(candidates, f)
        non_pass = [c['kind'] for c in cands
                    if c['kind'] in NON_PASS_KINDS]
        if f in contradictions:
            status = 'contradicted'
            spoofed = captures.get(f)
        elif len(vals) == 1:
            status = 'seeded'
            spoofed = vals[0]
        elif len(vals) > 1:
            status = 'forked'
            spoofed = vals[0]
        elif f in captures:
            status = 'captured'
            spoofed = captures[f]
        else:
            status = 'unknown'
            spoofed = None
        gates.append({
            'field': f,
            'status': status,
            'candidates': cands,
            'spoofed_value': spoofed,
            'forked': status == 'forked',
            'non_pass_kinds': sorted(set(non_pass)),
            'extra_field': bool(extra_fields and f in extra_fields),
        })
    return gates


# ------------------------------------------------- sentinel/capture state
class SpoofState:
    """Pure-Python model of the seeded/sentinel/capture mock policy
    (the bootstrap route's executor policy, factored out of the
    mock layer so ports can reuse the semantics with any mock
    object system).

    Policy:
      * enabled=False -> legacy behaviour: no identity logging, no
        sentinel, reads are the caller's business (the mock layer
        serves an ordinary child mock).
      * enabled=True, field seeded -> serve the seed, log
        ('read', field, value, 'static-seed').
      * enabled=True, field adopted via capture -> serve the
        adopted value, log ('read', field, value, 'adopted').
      * enabled=True, otherwise -> serve a sentinel token; the
        first scalar the sentinel is compared against is ADOPTED
        (log ('capture', field, value, site)) and served from then
        on; a later comparison demanding a different value does
        NOT change the adopted value and is logged as
        ('contradiction', field, adopted, compared, site).
      * seed entries are logged as ('seed', field, value, 'static')
        at construction, matching the bootstrap sweep log format.

    Log tuples are the bootstrap format verbatim so log_to_state()
    output is identical to the pre-engine sweep state."""
    SENTINEL = 'sentinel'

    def __init__(self, enabled=True, seed=None):
        self.enabled = bool(enabled)
        self.seed = dict(seed or {})
        self.adopted = {}
        self.log = []
        if self.enabled:
            for f in sorted(self.seed):
                self.log.append(('seed', f, self.seed[f], 'static'))

    def read(self, field):
        """Return (served, source) where served is a concrete value
        or the string 'sentinel' (caller mints its sentinel object),
        and source is 'static-seed' / 'adopted' / 'sentinel' /
        'disabled'.  Concrete serves are logged as reads."""
        if not self.enabled:
            return None, 'disabled'
        if field in self.adopted:
            v = self.adopted[field]
            self.log.append(('read', field, v, 'adopted'))
            return v, 'adopted'
        if field in self.seed:
            v = self.seed[field]
            self.log.append(('read', field, v, 'static-seed'))
            return v, 'static-seed'
        self.log.append(('read', field, None, 'sentinel'))
        return self.SENTINEL, 'sentinel'

    def capture(self, field, value, site):
        """Record a sentinel comparison.  Returns (outcome, served)
        where outcome is 'adopted' (first scalar), 'consistent'
        (matches the adopted value), or 'contradiction' (differs;
        adopted value is kept).  Only numeric/str scalars are
        capturable; other types return ('ignored', None)."""
        if not self.enabled:
            return 'disabled', None
        if not (_is_num(value) or isinstance(value, (bytes, str))):
            return 'ignored', None
        if field not in self.adopted:
            self.adopted[field] = value
            self.log.append(('capture', field, value, site))
            return 'adopted', value
        if self.adopted[field] == value:
            return 'consistent', value
        self.log.append(('contradiction', field, self.adopted[field],
                         value, site))
        return 'contradiction', self.adopted[field]

    def to_state(self):
        """Bootstrap sweep-state shape: {seeded, reads, captures,
        contradictions} as JSON-able dicts."""
        return log_to_state(self.log)


def log_to_state(entries):
    """Log tuples -> JSON-able state dict (bootstrap format)."""
    st = {'seeded': [], 'reads': [], 'captures': [],
          'contradictions': []}
    for e in entries or []:
        kind = e[0]
        if kind == 'seed':
            st['seeded'].append({'field': e[1], 'value': e[2],
                                 'source': e[3]})
        elif kind == 'read':
            st['reads'].append({'field': e[1], 'value': e[2],
                                'source': e[3]})
        elif kind == 'capture':
            st['captures'].append({'field': e[1], 'value': e[2],
                                   'site': list(e[3])})
        elif kind == 'contradiction':
            st['contradictions'].append(
                {'field': e[1], 'adopted': e[2], 'compared': e[3],
                 'site': list(e[4])})
    return st


# ------------------------------------------------------------ reporting
def _candidates_out(candidates):
    return {f: [{'value': c['value'], 'kind': c['kind'],
                 'evidence': c['evidence']} for c in candidates[f]]
            for f in sorted(candidates or {})}


def build_report_legacy_method(route, candidates, fields_read, forks,
                               notes, fields_seen=None):
    """Byte-compatible with routes/method/identity.py build_report
    (key order and value shapes preserved so the Part E golden
    sha256 for identity_report.json is unchanged)."""
    all_reads = []
    for fk in forks or []:
        for r in fk['identity_reads']:
            all_reads.append({'fork': fk['fork'], **r})
    return {
        'feature': 'spoof-id',
        'mode': 'auto',
        'route': route,
        'fields_seen': fields_seen if fields_seen is not None
                       else sorted(fields_read),
        'fields_read': {f: fields_read[f] for f in sorted(fields_read)},
        'candidates': _candidates_out(candidates),
        'forks': forks or [],
        'identity_reads_total': len(all_reads),
        'identity_reads': all_reads[:200],
        'notes': notes,
    }


def build_report_legacy_bootstrap(static_cands, static_seen, mat_seen,
                                  sweep_state, notes):
    """Byte-compatible with routes/bootstrap/modules/stageE/
    identity.py build_report."""
    fields_seen = {}
    for src in (static_seen, mat_seen):
        for f, locs in (src or {}).items():
            fields_seen.setdefault(f, [])
            for loc in locs:
                if loc not in fields_seen[f]:
                    fields_seen[f].append(loc)
    return {
        'feature': 'spoof-id',
        'mode': 'auto',
        'route': 'bootstrap',
        'fields_seen': fields_seen,
        'candidates': {f: static_cands[f]
                       for f in sorted(static_cands or {})},
        'seed': (sweep_state or {}).get('seeded', []),
        'captures': (sweep_state or {}).get('captures', []),
        'contradictions': (sweep_state or {}).get('contradictions',
                                                 []),
        'identity_reads_total': len((sweep_state or {})
                                    .get('reads', [])),
        'identity_reads': (sweep_state or {}).get('reads', [])[:200],
        'notes': notes,
    }


def label_branch(fork, is_pass=None):
    """Branch label for one fork record.  The engine does NOT infer
    gate-PASS from raw signals: the caller supplies is_pass(fork)
    (its own evidence rule, e.g. 'an inert HttpGet mock fired and
    the decoy print signature is absent').  Without a caller rule
    the label is 'unclassified' — never a guessed 'gate-pass'.
    Returns 'gate-pass' / 'other-branch' / 'unclassified'."""
    if is_pass is None:
        return 'unclassified'
    try:
        return 'gate-pass' if is_pass(fork) else 'other-branch'
    except Exception:
        return 'unclassified'


def build_report(route, candidates, fields_read=None, fields_seen=None,
                 forks=None, seed=None, captures=None,
                 contradictions=None, identity_reads=None, notes=None,
                 extra_fields=None, is_pass=None, scope=None):
    """UNIFIED identity_report.json (schema spoof-engine/1).

    Superset of both legacy shapes: every legacy field is present
    (fields_seen as a sorted list when a plain list is passed, or
    as the merged dict when dicts are passed — callers normalise),
    plus gates[] (per-field status, never guessed), unknown_fields,
    and per-fork branch labels (caller-supplied rule only).
    Sibling ports SHOULD emit this shape; Luraph v6 keeps emitting
    the legacy shapes until its goldens are regenerated (see
    SPOOF-SPEC.md §6 for the migration note)."""
    fields_read = fields_read or {}
    captures_d = {}
    for c in captures or []:
        captures_d.setdefault(c.get('field'), c.get('value'))
    contradictions_d = {}
    for c in contradictions or []:
        contradictions_d.setdefault(c.get('field'), c)
    gates = build_gates(candidates, fields_read, captures_d,
                        contradictions_d, extra_fields)
    unknown = [g['field'] for g in gates if g['status'] == 'unknown']
    fork_out = []
    for fk in forks or []:
        rec = dict(fk)
        rec['branch'] = label_branch(fk, is_pass)
        fork_out.append(rec)
    if fields_seen is None:
        fields_seen_out = sorted(
            set(fields_read) | set(candidates or {}))
    else:
        fields_seen_out = fields_seen
    return {
        'schema_version': SCHEMA_VERSION,
        'feature': 'spoof-id',
        'mode': 'auto',
        'route': route,
        'fields_seen': fields_seen_out,
        'fields_read': {f: fields_read[f] for f in sorted(fields_read)},
        'candidates': _candidates_out(candidates),
        'gates': gates,
        'unknown_fields': unknown,
        'seed': seed if seed is not None else [],
        'captures': captures or [],
        'contradictions': contradictions or [],
        'forks': fork_out,
        'identity_reads_total': len(identity_reads or []),
        'identity_reads': (identity_reads or [])[:200],
        'scope': scope or ('local-analysis-only: mock environments '
                           'run by this tool; nothing fetched; '
                           'server-checked IDs out of scope.'),
        'notes': notes or [],
    }


def report_section_legacy_method(rep):
    """Byte-compatible with the method route's report section."""
    L = []
    L.append('')
    L.append('## Identity spoofing (--spoof-id auto)')
    L.append('')
    cands = rep['candidates']
    if not rep['fields_seen'] and not cands:
        L.append('- no game-identity field reads found in the '
                 'recovered protos; no spoofing applied.')
    for f in sorted(cands):
        vals = ', '.join(f"{c['value']!r} ({c['kind']})"
                         for c in cands[f])
        L.append(f'- `{f}` candidates: {vals}')
    for fk in rep['forks']:
        seeds = ', '.join(f"{k}={v['value']!r}"
                          for k, v in fk['seeds'].items()) or '(none)'
        L.append(f"- fork {fk['fork']}: seeds {{{seeds}}} -> "
                 f"prints={fk['prints_total']}, "
                 f"http_attempts={fk['http_attempts']}, "
                 f"mock_calls={fk['mock_calls']}, "
                 f"identity_reads={len(fk['identity_reads'])}")
    for n in rep['notes']:
        L.append(f'- note: {n}')
    L.append('- full detail: identity_report.json')
    return '\n'.join(L) + '\n'


def report_section_legacy_bootstrap(rep):
    """Byte-compatible with the bootstrap route's report section."""
    L = []
    L.append('')
    L.append('## Identity spoofing (--spoof-id auto)')
    L.append('')
    seen = rep.get('fields_seen') or {}
    cands = rep.get('candidates') or {}
    if not seen and not cands:
        L.append('- no game-identity field names found among the '
                 'materialized constants or walked instructions; '
                 'no spoofing was applied.')
    for f in sorted(seen):
        L.append(f'- `{f}` seen at: {", ".join(seen[f][:4])}'
                 + (' ...' if len(seen[f]) > 4 else ''))
    for f in sorted(cands):
        vals = ', '.join(f"{c['value']!r} ({c['kind']})"
                         for c in cands[f])
        L.append(f'- `{f}` candidates: {vals}')
    for s in rep.get('seed') or []:
        L.append(f"- seeded {s['field']} = {s['value']!r} "
                 f"({s['source']})")
    for c in rep.get('captures') or []:
        L.append(f"- captured {c['field']} = {c['value']!r} at "
                 f"{c['site']} (self-calibrating comparison)")
    for c in rep.get('contradictions') or []:
        L.append(f"- contradiction on {c['field']}: adopted "
                 f"{c['adopted']!r} but compared against "
                 f"{c['compared']!r} at {c['site']}")
    L.append(f"- identity reads during the sweep: "
             f"{rep.get('identity_reads_total', 0)}")
    for n in rep.get('notes') or []:
        L.append(f'- note: {n}')
    L.append('- full detail: identity_report.json')
    return '\n'.join(L) + '\n'


def report_section(rep):
    """Unified report section (for unified reports and ports)."""
    L = []
    L.append('')
    L.append('## Identity spoofing (--spoof-id auto)')
    L.append('')
    gates = rep.get('gates') or []
    if not gates:
        L.append('- no game-identity field reads found; '
                 'no spoofing applied.')
    for g in gates:
        vals = ', '.join(f"{c['value']!r} ({c['kind']})"
                         for c in g['candidates'])
        L.append(f"- `{g['field']}`: {g['status']}"
                 + (f", spoofed={g['spoofed_value']!r}"
                    if g['spoofed_value'] is not None else '')
                 + (f" (candidates: {vals})" if vals else '')
                 + (' [non-pass kinds present: '
                    + ', '.join(g['non_pass_kinds']) + ']'
                    if g['non_pass_kinds'] else ''))
    for fk in rep.get('forks') or []:
        seeds = ', '.join(f"{k}={v['value']!r}"
                          for k, v in fk['seeds'].items()) or '(none)'
        L.append(f"- fork {fk['fork']}: seeds {{{seeds}}} -> "
                 f"branch={fk.get('branch', 'unclassified')}, "
                 f"prints={fk['prints_total']}, "
                 f"http_attempts={fk['http_attempts']}, "
                 f"mock_calls={fk['mock_calls']}")
    for n in rep.get('notes') or []:
        L.append(f'- note: {n}')
    L.append('- full detail: identity_report.json')
    return '\n'.join(L) + '\n'
