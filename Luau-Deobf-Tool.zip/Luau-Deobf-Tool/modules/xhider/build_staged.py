#!/usr/bin/env python3
"""XHider v1.2 per-layer staged harness variants.

Ported from the batch-20261023 case script of the same name: the original
read sample_original.lua.txt from the cwd and wrote staged_*.luau files;
here the sample text is a parameter and a {name: source} dict is
returned. Each variant cuts the decoder prefix immediately before one
conversion block and dumps the pool that block is about to convert, which
is how the case attributed each layer. Analysis aid; the production
route uses build_harness only.
"""

DUMP_TPL = r'''
local function __esc(s) local out={} for i=1,#s do local b=string.byte(s,i) if b>=32 and b<127 and b~=92 and b~=34 then out[#out+1]=string.char(b) else out[#out+1]=string.format("\\%03d", b) end end return table.concat(out) end
local function __dump(name, pool) if type(pool)~="table" then print("POOL "..name.." NOTTABLE") return end local mx=0 for k in pairs(pool) do if type(k)=="number" and k>mx then mx=k end end print("POOL "..name.." maxindex="..mx) for i=1,mx do local v=rawget(pool,i) if v~=nil then if type(v)=="string" then print("E "..name.." "..i.." string "..#v.." \""..__esc(v).."\"") else print("E "..name.." "..i.." "..type(v).." "..tostring(v)) end end end end
__DUMPS__
print("STAGED DONE")
'''

STAGES = {
 "s1_pre_a85": (245821, [("o3", "o[3]")]),
 "s1_post_a85": (248202, [("o3", "o[3]")]),
 "s2_pre_block2": (309558, [("o8", "o[8]")]),
 "s3_pre_block3": (333852, [("o11", "o[11]")]),
 "s4_pre_block4": (358824, [("o5", "o[5]")]),
}

def build_staged(sample_text):
    body = sample_text.split('\n', 2)[2]
    start = len("return(function(...)")
    prefix_all = body[start:body.find("return(function(x,m,Y")]
    out = {}
    for name, (abs_cut, pools) in STAGES.items():
        cut = abs_cut - start
        dumps = "\n".join(f'__dump("{n}", {expr})' for n, expr in pools)
        out[name] = prefix_all[:cut] + "\n" + DUMP_TPL.replace("__DUMPS__", dumps)
    return out
