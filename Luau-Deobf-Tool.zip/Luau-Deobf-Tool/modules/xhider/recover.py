#!/usr/bin/env python3
"""XHider v1.2 recovery helpers (batch-20261023 case logic, generalized):

- parse_pool_dump: pull one pool's entries out of a harness dump
  (lines `E <pool> <idx> string <len> "<escaped>"`, escaping produced by
  the harness __esc: printable ASCII raw, everything else \\ddd).
- recovered_constants_luau: emit the final o[5] pool as the deliverable
  Luau table, in exactly the case deliverable's format (the dump's
  escaping is already the deliverable's escaping — verified 674/674 in
  the case).
- extract_interpreter: cut the flattened interpreter (w[23], the
  `function(...) local MM={} ... end` value inside the VM factory) out
  of the sample verbatim, using the ported luaparse parser to find the
  function's exact end. In the case this file was the checkpoint input
  interpreter_raw.luau and is a verbatim substring of the sample.
"""
import re, sys, pathlib

def parse_pool_dump(dump_text, pool="o5"):
    entries = {}
    pat = re.compile(r'^E %s (\d+) string (\d+) "(.*)"$' % re.escape(pool))
    for line in dump_text.splitlines():
        m = pat.match(line)
        if m:
            entries[int(m.group(1))] = m.group(3)
    return entries

def recovered_constants_luau(entries, sample_sha256):
    out = []
    out.append("--// XHider v1.2 -- RECOVERED FINAL CONSTANT POOL (o[5], accessed in the VM as o[2](n) = pool[n + 34818])")
    out.append("--// Recovered by decoder-only harness (capture, no payload execution). 674/674 entries decoded.")
    out.append(f"--// Source sample sha256: {sample_sha256}")
    out.append("local Pool = {")
    for i in sorted(entries):
        out.append(f'\t[{i}] = "{entries[i]}",')
    out.append("}")
    out.append("return Pool")
    return "\n".join(out) + "\n"

def extract_interpreter(sample_text):
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "xhider_vm"))
    from luaparse import tokenize, Parser
    body = sample_text.split('\n', 2)[2]
    vm = body.find("return(function(x,m,Y")
    assert vm >= 0, "VM factory not found"
    m = re.search(r'function\([^)]*\)local MM=\{\}', body[vm:])
    assert m, "interpreter function (local MM={}) not found in VM factory"
    start = vm + m.start()
    src = body[start:]
    toks = tokenize(src)
    parser = Parser(toks)
    parser.parse_prefixexp()
    end = toks[parser.i].pos
    interp = src[:end]
    assert interp.startswith("function") and interp.endswith("end")
    return interp
