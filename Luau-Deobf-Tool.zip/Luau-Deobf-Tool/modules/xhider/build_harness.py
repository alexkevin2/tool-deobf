#!/usr/bin/env python3
"""XHider v1.2 decoder-only harness builder.

Ported from the batch-20261023 case script of the same name: the original
chdir'd into the case dir, read sample_original.lua.txt and wrote
harness_decoder.luau; here the sample text is a parameter and the harness
source is returned. Harness content (mock environment + pool dump) is
unchanged: the sample body is cut immediately before the VM factory, so
only the L0-L5 decoder code runs; loadstring is a capture stub and every
game/executor API is a logging mock. The bundled luau binary has no
network.
"""

HEADER = r'''
-- XHider v1.2 decoder-only harness (built by build_harness.py)
-- MOCK ENVIRONMENT: every external capability is a logged stub.
local __mocklog={}
local function __log(s) __mocklog[#__mocklog+1]=s print("MOCKLOG "..s) end
local __captured={}
local __real_loadstring = loadstring
loadstring = function(s, ...)
    __log("loadstring CALLED argtype="..type(s).." len="..(type(s)=="string" and #s or -1))
    __captured[#__captured+1]=s
    return function(...) __log("loadstring RESULT invoked -- returning nil, payload NOT executed") return nil end
end
local function __mockobj(name)
    local t={}
    return setmetatable(t,{__index=function(_,k) __log("mock."..name.." index "..tostring(k)) return __mockobj(name.."."..tostring(k)) end,
        __call=function(_, ...) __log("mock."..name.." CALLED") return __mockobj(name.."()") end,
        __tostring=function() return "<mock "..name..">" end})
end
game = __mockobj("game")
workspace = __mockobj("workspace")
script = __mockobj("script")
Instance = __mockobj("Instance")
Enum = __mockobj("Enum")
task = __mockobj("task")
print("MOCKENV installed")
'''

DUMP = r'''
-- ===== DUMP DECODED POOLS =====
local function __esc(s)
    local out={}
    for i=1,#s do local b=string.byte(s,i)
        if b>=32 and b<127 and b~=92 and b~=34 then out[#out+1]=string.char(b)
        else out[#out+1]=string.format("\\%03d", b) end
    end
    return table.concat(out)
end
local function __dump(name, pool)
    if type(pool)~="table" then print("POOL "..name.." NOTTABLE "..type(pool)) return end
    local n=0 local mx=0
    for k,v in pairs(pool) do n=n+1 if type(k)=="number" and k>mx then mx=k end end
    print("POOL "..name.." pairs="..n.." maxindex="..mx.." len="..#pool)
    for i=1,mx do local v=rawget(pool,i)
        if v~=nil then local tv=type(v)
            if tv=="string" then print("E "..name.." "..i.." string "..#v.." \""..__esc(v).."\"")
            elseif tv=="number" or tv=="boolean" then print("E "..name.." "..i.." "..tv.." "..tostring(v))
            else print("E "..name.." "..i.." "..tv.." "..tostring(v)) end
        end
    end
    -- non-numeric keys
    for k,v in pairs(pool) do if type(k)~="number" then print("K "..name.." "..tostring(k).." -> "..type(v).." "..(type(v)=="string" and __esc(v) or tostring(v))) end end
end
print("CAPTURED_LOADSTRING_COUNT "..#__captured)
__dump("o3", o[3])
__dump("o8", o[8])
__dump("o11", o[11])
__dump("o5", o[5])
print("MOCKLOG_COUNT "..#__mocklog)
print("HARNESS DONE")
'''

def build_harness(sample_text):
    body = sample_text.split('\n', 2)[2]
    start = len("return(function(...)")
    end = body.find("return(function(x,m,Y")
    assert start < end, (start, end)
    prefix = body[start:end]
    return HEADER + prefix + DUMP
