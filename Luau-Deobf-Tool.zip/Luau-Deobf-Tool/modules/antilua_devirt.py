#!/usr/bin/env python3
"""
antilua_devirt.py — AntiLua obfuscator family RE / devirtualization toolkit.

Scope (Phase 1):
  * census     : AST census via bundled luau-ast; family fingerprinting.
  * normalize  : rewrite obfuscated numeric literals (0x.., 0b.., 1_860, ...)
                 to canonical decimal, string literals untouched. Output is a
                 compile-equivalent Luau source (verified with luau-compile).
  * extract    : dump outer VM table layout (slot map / handler map), payload
                 strings, per-string decryptor call census (hwf `bd"..."`).
  * gen-runner : build an instrumented runner (mock env + logging forwarders
                 for string/table/bit32/buffer/math) that executes the sample
                 under the bundled `luau` binary. NO network exists in that
                 binary; every game/executor API is a logging mock.

Static-first: nothing here fetches URLs. URLs found in samples are only ever
listed, never requested.
"""
import argparse, json, re, subprocess, sys, hashlib, collections, pathlib

DEFAULT_AST = pathlib.Path(__file__).resolve().parent.parent / "bin" / "luau-ast"
DEFAULT_COMPILE = pathlib.Path(__file__).resolve().parent.parent / "bin" / "luau-compile"

# ---------------------------------------------------------------- AST helpers
def get_ast(path, ast_bin):
    out = subprocess.run([str(ast_bin), str(path)], capture_output=True, text=True)
    if out.returncode != 0:
        raise SystemExit(f"luau-ast failed on {path}: {out.stderr[:500]}")
    return json.loads(out.stdout)

def walk(node, fn):
    if isinstance(node, dict):
        fn(node)
        for v in node.values():
            walk(v, fn)
    elif isinstance(node, list):
        for v in node:
            walk(v, fn)

def loc_start(loc):
    a = loc.split(" - ")[0]
    line, col = a.split(",")
    return int(line), int(col)

# ------------------------------------------------------------------- census
def outer_table(ast):
    """Return (table_node, entry_index_name, call_args) for the top-level
    `return (TABLE):Entry(args...)` / `return (TABLE):Entry()(...)` shape."""
    try:
        ret = ast["root"]["body"][0]
        call = ret["list"][0]
        args = call.get("args", [])
        func = call["func"]
        if func["type"] == "AstExprCall":          # (TABLE):d()(...)  (mos)
            inner = func
            idx = inner["func"]
            tbl = idx["expr"]["expr"]
            return tbl, idx.get("index"), args, inner.get("args", [])
        idx = func                                    # (TABLE):Wc(...) (hwf)
        tbl = idx["expr"]["expr"]
        return tbl, idx.get("index"), args, None
    except Exception:
        return None, None, [], None

def describe_value(v):
    t = v["type"]
    if t == "AstExprIndexName":
        base = v["expr"].get("global", "?") if v["expr"]["type"] == "AstExprGlobal" else "?"
        return f"{base}.{v['index']}"
    if t == "AstExprGlobal":
        return f"global {v['global']}"
    if t == "AstExprConstantNumber":
        return f"number {v['value']}"
    if t == "AstExprConstantBool":
        return f"bool {v['value']}"
    if t == "AstExprConstantString":
        return f"string len={len(v['value'])}"
    if t == "AstExprFunction":
        return f"function/{len(v.get('args', []))} args"
    if t == "AstExprTable":
        return f"table[{len(v.get('items', []))}]"
    if t == "AstExprCall":
        return "call-result"
    if t == "AstExprGroup":
        return "group(expr)"
    return t

def census(path, ast_bin):
    data = pathlib.Path(path).read_bytes()
    text = data.decode("utf-8", "replace")
    ast = get_ast(path, ast_bin)
    types = collections.Counter(); globals_ = collections.Counter(); strings = []
    def visit(n):
        t = n.get("type")
        if t: types[t] += 1
        if t == "AstExprGlobal": globals_[n["global"]] += 1
        if t == "AstExprConstantString": strings.append(n["value"])
    walk(ast, visit)
    tbl, entry, args, inner_args = outer_table(ast)
    info = {
        "file": str(path), "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "header": text.splitlines()[0] if text.splitlines() else "",
        "ast_types": dict(types.most_common()),
        "real_globals": {g: c for g, c in globals_.items()},
        "const_strings": len(strings),
        "entry_index": entry,
        "outer_table_items": len(tbl["items"]) if tbl else 0,
    }
    if tbl:
        slots = []
        for i, it in enumerate(tbl["items"]):
            k = it.get("key")
            key = None
            if k:
                key = k.get("value") if k["type"] in ("AstExprConstantNumber", "AstExprConstantString") else k["type"]
            v = it["value"]
            a, b = v["location"].split(" - ")
            size = int(b.split(",")[1]) - int(a.split(",")[1])
            slots.append({"pos": i + 1, "key": key, "value": describe_value(v),
                          "size": size, "loc": v["location"]})
        info["slots"] = slots
    if args and args[0].get("type") == "AstExprTable":
        info["entry_arg0_names"] = [i["value"].get("value") for i in args[0]["items"]]
    if len(args) > 1 and args[1].get("type") == "AstExprConstantString":
        info["entry_arg1"] = args[1]["value"]
    info["big_strings"] = sorted((len(s) for s in strings), reverse=True)[:10]
    return info

# ---------------------------------------------------------------- normalize
STRING_RE = re.compile(r'"(?:[^"\\\n]|\\.)*"|\'(?:[^\'\\\n]|\\.)*\'')
NUM_RE = re.compile(r"""
    (?<![\w.])
    (?:
        0[xX][0-9a-fA-F_]+
      | 0[bB][01_]+
      | \d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?[\d_]+)?
    )
    (?![\w])
""", re.X)

def num_to_canonical(tok):
    t = tok.replace("_", "")
    try:
        if t.lower().startswith("0x"):
            return str(int(t, 16))
        if t.lower().startswith("0b"):
            return str(int(t, 2))
        if re.fullmatch(r"\d+", t):
            return str(int(t))
        return repr(float(t))
    except ValueError:
        return tok

def normalize_text(text):
    out, last, count = [], 0, 0
    for m in STRING_RE.finditer(text):
        seg = text[last:m.start()]
        seg2, n = NUM_RE.subn(lambda mm: num_to_canonical(mm.group(0)), seg)
        count += n
        out.append(seg2); out.append(m.group(0))
        last = m.end()
    seg2, n = NUM_RE.subn(lambda mm: num_to_canonical(mm.group(0)), text[last:])
    count += n
    out.append(seg2)
    return "".join(out), count


# ------------------------------------------------------------- payload dumps
ESCSTR_RE = re.compile(r'"((?:\\.|[^"\\])*)"')

def decode_luau_escapes(s):
    out = bytearray(); i = 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            n = s[i + 1]
            if n.isdigit():
                j = i + 1; v = ""
                while j < len(s) and s[j].isdigit() and len(v) < 3:
                    v += s[j]; j += 1
                out.append(int(v) & 0xFF); i = j
            elif n == "n": out.append(10); i += 2
            elif n == "t": out.append(9); i += 2
            elif n == "r": out.append(13); i += 2
            elif n == "\\": out.append(92); i += 2
            elif n == '"': out.append(34); i += 2
            else: out.append(ord(n) & 0xFF); i += 2
        else:
            out.append(ord(c) & 0xFF); i += 1
    return bytes(out)

def extract_payloads(path, outdir):
    """Dump big constant strings: ANTI-style base-N blob and raw byte strings."""
    text = pathlib.Path(path).read_text()
    outdir = pathlib.Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    found = []
    for m in ESCSTR_RE.finditer(text):
        raw = m.group(1)
        if len(raw) >= 1000:
            data = decode_luau_escapes(raw)
            kind = "anti_blob" if raw.startswith("ANTI") else "raw_bytes"
            dest = outdir / f"{pathlib.Path(path).stem}.{kind}.{m.start()}.bin"
            dest.write_bytes(data if kind == "raw_bytes" else raw.encode())
            found.append({"kind": kind, "src_offset": m.start(),
                          "encoded_len": len(raw), "file": str(dest)})
    # hwf-style per-string decryptor census:  bd"..." literals + resolver pairs
    bd = re.findall(r'\.bd"((?:[^"\\]|\\.)*)"', text)
    if bd:
        (outdir / f"{pathlib.Path(path).stem}.bd_literals.json").write_text(
            json.dumps(sorted(set(bd)), indent=0))
        found.append({"kind": "bd_literals", "calls": len(bd), "unique": len(set(bd))})
    return found

def gen_runner(path, prelude, out):
    sample = pathlib.Path(path).read_text()
    pre = pathlib.Path(prelude).read_text()
    pathlib.Path(out).write_text(pre + "\n-- sample below\n" + sample)
    return out

# ---------------------------------------------------------- decode-payload
# AntiLua v10.1 (mos_hub) payload decoder — cracked round 2 (2026-10-24).
# Full spec in PAYLOAD-REPORT.md. Pipeline:
#   ANTI blob --[A: custom base-85, slot 1994]--> Ew (356,124 B)
#   Ew --[D: slots 1357/547/1948, keyed by (sy, Mh)]--> Gw
#   Gw --[E: slot750 permutation + JG scan]--> FT (340,919 B proto stream)
# sy = 162 is the environment-probe byte (wU=223 branch of slot 1262).
# XM = 3300720440 is QA[1] of the bootstrap register-VM: the value
#   draw1 XOR rotl32(draw2, 16) of Random.new(433198757):NextInteger(0, 2^31-1).
# The engine `Random` algorithm itself was never identified (~250 hypotheses
# rejected); XM was instead recovered by exhaustive search over Mh (bijective
# in XM) using the JG scan as oracle — see round2/brute_mh.c. Mh =
# bxor(3863057042, xorshift32(bxor(sy*16843009 mod 2^32, 1905269810, XM)))
# = 3466555975. Decode is cross-validated byte-exact against the original
# folded slot functions executed under the bundled luau binary
# (round2/gen_harness.py): Gw/FT weighted checksums agree.
MOS_SY = 162
MOS_XM = 3300720440

def _wck(b):
    return sum(x * (i + 1) for i, x in enumerate(b)) % 999999937

def decode_payload(blob_path, outdir):
    r2 = pathlib.Path(__file__).resolve().parent / "round2"
    sys.path.insert(0, str(r2))
    from payload_decode import stage_a            # stage A (slot 1994)
    from stages_np import run_chain_np           # stages D+E (slots 1357/547/1948/750, JG)
    blob = pathlib.Path(blob_path).read_text()
    ew = stage_a(blob)
    gw, _xl, ft = run_chain_np(ew, MOS_SY, MOS_XM)
    if ft is None:
        raise SystemExit("JG scan failed — blob does not match the mos_hub sample")
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    (out / "stageA_Ew.bin").write_bytes(ew)
    (out / "stageE_Gw.bin").write_bytes(gw)
    (out / "mos_hub.payload.bin").write_bytes(ft)
    print(f"stage A base-85   -> Ew {len(ew)} B  wck {_wck(ew)}")
    print(f"stages D+E        -> Gw {len(gw)} B  wck {_wck(gw)}")
    print(f"JG scan           -> FT {len(ft)} B  wck {_wck(ft)}  (proto stream)")
    print(f"wrote {out}/stageA_Ew.bin, stageE_Gw.bin, mos_hub.payload.bin")
    return out

# -------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ast-bin", default=str(DEFAULT_AST))
    ap.add_argument("--compile-bin", default=str(DEFAULT_COMPILE))
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("census", "normalize", "extract"):
        p = sub.add_parser(name)
        p.add_argument("file")
        p.add_argument("-o", "--out")
    p = sub.add_parser("payloads")
    p.add_argument("file"); p.add_argument("-o", "--out", default="payloads")
    p = sub.add_parser("gen-runner")
    p.add_argument("file"); p.add_argument("--prelude", required=True)
    p.add_argument("-o", "--out", required=True)
    p = sub.add_parser("decode-payload")
    p.add_argument("blob", help="path to extract/mos_anti_blob.txt")
    p.add_argument("-o", "--out", default="payload_out")
    a = ap.parse_args()
    if a.cmd == "census":
        info = census(a.file, a.ast_bin)
        s = json.dumps(info, indent=1, ensure_ascii=False)
        (pathlib.Path(a.out).write_text(s) if a.out else print(s))
        if a.out: print(f"census -> {a.out}")
    elif a.cmd == "normalize":
        text = pathlib.Path(a.file).read_text()
        out, n = normalize_text(text)
        dest = a.out or (str(a.file) + ".normalized.luau")
        pathlib.Path(dest).write_text(out)
        print(f"normalized {n} numeric literals -> {dest}")
    elif a.cmd == "payloads":
        found = extract_payloads(a.file, a.out)
        print(json.dumps(found, indent=1))
    elif a.cmd == "gen-runner":
        print("runner ->", gen_runner(a.file, a.prelude, a.out))
    elif a.cmd == "decode-payload":
        decode_payload(a.blob, a.out)
    elif a.cmd == "extract":
        info = census(a.file, a.ast_bin)
        dest = a.out or "extract.json"
        pathlib.Path(dest).write_text(json.dumps(info, indent=1, ensure_ascii=False))
        print(f"extract -> {dest}")

if __name__ == "__main__":
    main()
