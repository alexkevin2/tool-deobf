#!/usr/bin/env python3
"""spoof_scan.py — identity-gate scanner for Luau-Deobf-Tool routes B/C.

Feeds the vendored shared spoof engine (spoof_engine.py, byte-identical
to the Luraph v6 canonical copy) with candidates extracted ONLY from the
analysed script's own recovered text. No literal, default, or "common
ID" list exists anywhere in this module: every candidate value comes
from a comparison site found in the scanned text, and every value is
reported with its site (proto label + line).

Two passes, both static (nothing here executes any payload):

1. Direct pass — plain-Luau gate shapes over the scanned text:
   `game.<Field> == <const>` / `<const> == game.<Field>` (and the
   `~=`, `<`, `>`, `<=`, `>=` variants, with operand-order flips
   mapped), `game["<Field>"]` bracket forms (normalised to dot form
   before matching, line numbers preserved), and set-membership
   `<table>[game.<Field>]` where the table's own literal keys are
   recovered from its assignment in the same text. A set-index with
   no recoverable literal keys is recorded as a read only, never as
   a candidate.

2. Register pass — the lifted-XHider form (route C lifted protos),
   where the gate is spread over register assignments:
   `rX = "game"` -> `rY = w[..][rX]` (env) -> `rZ = "<Field>"` ->
   `rV = rY[rZ]` (field value) -> `rC = rV == <number>`.
   Copy propagation through single-identifier assignments (`rA =
   state`, `state = rY[rZ]`) is tracked; any other assignment to a
   tracked register clears it. Tracking resets at each lifted
   function start (`fn_<digits> = function...`). An index by a
   field-value register into a non-env table is a set-membership
   shape with unrecovered keys: read only, no candidate.

Presence scan — a field name occurring only as a string constant
(e.g. "PlaceId" in the recovered pool or as a lifted register
string with no comparison site) is reported in `fields_seen`
only. Presence is NEVER candidacy (SPOOF-SPEC §3, rule 3).

Returns: {"candidates", "fields_read", "fields_seen", "notes"}.
`candidates` is the engine's candidate store (sorted deterministically
by the engine). `fields_read[field]` lists "<proto>:<line>" sites.
`notes` states the scanned layer and every honesty caveat (e.g. a
multi-value dispatch is not a single pass/fail gate).
"""
import pathlib
import re
import sys

_TOOL_ROOT = pathlib.Path(__file__).resolve().parent.parent
if str(_TOOL_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOL_ROOT))

import spoof_engine as SE  # noqa: E402  (vendored, byte-identical to canonical)

FIELDS = SE.IDENTITY_FIELDS

_NUM = r"(-?\d+(?:\.\d+)?)"
_STR = r'"((?:[^"\\]|\\.)*)"'
_CMP = r"(==|~=|<=|>=|<|>)"
# Engine OP_KIND keys are symbolic; raw Luau operators map to them, and
# a swapped-operand comparison flips the bound direction (eq/ne are
# symmetric). collect_events() silently drops unknown ops, so this
# mapping must stay exact.
_OPMAP = {"==": "eq", "~=": "ne", "<": "lt", ">": "gt", "<=": "le", ">=": "ge"}
_FLIP = {"lt": "gt", "gt": "lt", "le": "ge", "ge": "le", "eq": "eq", "ne": "ne"}

_DIRECT_RE = re.compile(
    r"game\.(" + "|".join(FIELDS) + r")\s*" + _CMP + r"\s*(?:" + _NUM + r"|" + _STR + r")")
_DIRECT_REV_RE = re.compile(
    r"(?:" + _NUM + r"|" + _STR + r")\s*" + _CMP + r"\s*game\.(" + "|".join(FIELDS) + r")")
_SET_RE = re.compile(
    r"([A-Za-z_]\w*)\s*\[\s*game\.(" + "|".join(FIELDS) + r")\s*\]")
_BRACKET_RE = re.compile(
    r'game\s*\[\s*"(' + "|".join(FIELDS) + r')"\s*\]')
_ASSIGN_RE = re.compile(
    r"^\s*([A-Za-z_]\w*)\s*=\s*(.+?)\s*$")
_INDEX_RE = re.compile(r"^(.+)\[([A-Za-z_]\w*)\]$")
_FN_START_RE = re.compile(r"^fn_\d+\s*=\s*function\b")
_KEY_RE = re.compile(r"\[\s*(-?\d+|\"(?:[^\"\\]|\\.)*\")\s*\]\s*=")


def _num_or_str(groups):
    """groups: (num, str) pair from a regex alternative; returns int/str."""
    num, s = groups
    if num is not None and num != "":
        try:
            return int(num)
        except ValueError:
            return float(num)
    return s.replace('\\"', '"').replace("\\\\", "\\") if s is not None else None


def _line_of(text, pos):
    return text.count("\n", 0, pos) + 1


def _set_keys_for(text, var):
    """Literal keys of a set table `var` in the same text, from both
    forms: `var = { [k] = ..., ... }` (braces without nesting) and
    per-key assignments `var[k] = ...`. Returns [] when neither form
    is found (the index site is then read-only, never a candidate)."""
    keys = []
    m = re.search(r"\b" + re.escape(var) + r"\s*=\s*\{([^{}]*)\}", text)
    if m:
        for km in _KEY_RE.finditer(m.group(1)):
            raw = km.group(1)
            if raw.startswith('"'):
                keys.append(raw[1:-1])
            else:
                try:
                    keys.append(int(raw))
                except ValueError:
                    pass
    for km in re.finditer(
            r"\b" + re.escape(var) +
            r"\s*\[\s*(-?\d+|\"(?:[^\"\\]|\\.)*\")\s*\]\s*=", text):
        raw = km.group(1)
        if raw.startswith('"'):
            keys.append(raw[1:-1])
        else:
            try:
                keys.append(int(raw))
            except ValueError:
                pass
    out = []
    for k in keys:
        if k not in out:
            out.append(k)
    return out


def scan_source(text, proto_label):
    """Scan one recovered text layer. See module docstring."""
    candidates = {}
    fields_read = {}

    def read(field, line):
        loc = f"{proto_label}:{line}"
        lst = fields_read.setdefault(field, [])
        if loc not in lst:
            lst.append(loc)

    def event(field, op, value, line, pattern):
        SE.collect_events(candidates, [{
            "field": field, "op": op, "value": value,
            "proto": proto_label, "pc": line, "pattern": pattern}])

    # Bracket forms normalised to dot forms (same line count: the
    # substitution is intra-line only).
    norm = _BRACKET_RE.sub(lambda m: "game." + m.group(1), text)

    # ---- direct pass, line by line (avoids cross-line matches) ----
    for lineno, line in enumerate(norm.splitlines(), 1):
        for m in _DIRECT_RE.finditer(line):
            field, op = m.group(1), _OPMAP[m.group(2)]
            value = _num_or_str((m.group(3), m.group(4)))
            if value is None:
                continue
            read(field, lineno)
            event(field, op, value, lineno,
                  f"game.{field} {m.group(2)} {value!r}")
        for m in _DIRECT_REV_RE.finditer(line):
            op_raw = m.group(4)
            field = m.group(5)
            value = _num_or_str((m.group(1), m.group(2)))
            if value is None:
                continue
            op = _FLIP[_OPMAP[op_raw]]
            read(field, lineno)
            event(field, op, value, lineno,
                  f"{value!r} {op_raw} game.{field} (operands swapped)")
        for m in _SET_RE.finditer(line):
            var, field = m.group(1), m.group(2)
            read(field, lineno)
            keys = _set_keys_for(norm, var)
            for k in keys:
                event(field, "in-set", k, lineno,
                      f"{var}[game.{field}] with literal key {k!r}")

    # ---- register pass (lifted-XHider form) ----
    game_str, env_regs, field_str, field_val, num_regs = {}, {}, {}, {}, {}
    for lineno, line in enumerate(text.splitlines(), 1):
        if _FN_START_RE.match(line):
            game_str, env_regs, field_str, field_val, num_regs = {}, {}, {}, {}, {}
            continue
        m = _ASSIGN_RE.match(line)
        if not m:
            continue
        lhs, rhs = m.group(1), m.group(2)
        # Clear stale tracking for lhs first; each branch re-adds it
        # only when the new value is itself a tracked shape.
        for d in (game_str, env_regs, field_str, field_val, num_regs):
            d.pop(lhs, None)
        sm = re.fullmatch(r'"([^"]*)"', rhs)
        if sm is not None:
            val = sm.group(1)
            if val == "game":
                game_str[lhs] = True
            elif val in FIELDS:
                field_str[lhs] = val
            continue
        if re.fullmatch(r"-?\d+", rhs):
            num_regs[lhs] = int(rhs)
            continue
        if re.fullmatch(r"[A-Za-z_]\w*", rhs):
            # Copy propagation from a tracked register.
            if rhs in game_str:
                game_str[lhs] = True
            elif rhs in env_regs:
                env_regs[lhs] = True
            elif rhs in field_str:
                field_str[lhs] = field_str[rhs]
            elif rhs in field_val:
                field_val[lhs] = field_val[rhs]
            elif rhs in num_regs:
                num_regs[lhs] = num_regs[rhs]
            continue
        im = _INDEX_RE.match(rhs)
        if im is not None:
            base, key = im.group(1), im.group(2)
            if key in game_str:
                env_regs[lhs] = True
            elif base in env_regs and key in field_str:
                field = field_str[key]
                field_val[lhs] = field
                read(field, lineno)
            elif key in field_val:
                # Set-membership shape with unrecovered keys:
                # read only, never a candidate.
                read(field_val[key], lineno)
            continue
        cm = re.fullmatch(
            r"([A-Za-z_]\w*)\s*(==|~=|<=|>=|<|>)\s*([A-Za-z_]\w*|-?\d+)",
            rhs)
        if cm is not None:
            a, op_raw, b = cm.group(1), cm.group(2), cm.group(3)
            op_sym = _OPMAP[op_raw]
            field, value, op = None, None, None
            if a in field_val and b in num_regs:
                field, value, op = field_val[a], num_regs[b], op_sym
            elif b in field_val and a in num_regs:
                field, value, op = field_val[b], num_regs[a], _FLIP[op_sym]
            elif a in field_val and re.fullmatch(r"-?\d+", b):
                field, value, op = field_val[a], int(b), op_sym
            elif b in field_val and re.fullmatch(r"-?\d+", a):
                field, value, op = field_val[b], int(a), _FLIP[op_sym]
            if field is not None:
                event(field, op, value, lineno,
                      f"lifted register comparison: {field} {op} {value!r}")
            continue
        # Any other RHS shape: lhs stays untracked (cleared above).

    SE.sort_candidates(candidates)

    # ---- presence scan (string constants only; never candidacy) ----
    seen = set(fields_read) | set(candidates)
    for field in FIELDS:
        if re.search(r'"' + re.escape(field) + r'"', text):
            seen.add(field)

    notes = [f"scanned layer: {proto_label} (static only; no payload "
             f"execution, no fork run in this port)"]
    if candidates:
        for field in sorted(candidates):
            vals = SE.distinct_values(candidates, field)
            if len(vals) > 1:
                notes.append(
                    f"{field} has {len(vals)} distinct candidates — a "
                    f"multi-value dispatch, not a single pass/fail gate; "
                    f"no single spoofed value is asserted")
    return {"candidates": candidates, "fields_read": fields_read,
            "fields_seen": sorted(seen), "notes": notes}
