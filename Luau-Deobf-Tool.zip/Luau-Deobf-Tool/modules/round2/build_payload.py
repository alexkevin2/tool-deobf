#!/usr/bin/env python3
"""Build hwf payload (flat form): substitute every guarded resolver idiom
   X.cache[SLOT] or X:resolver(args..., SLOT)
with its resolved literal (string plaintext or numeric constant).
Values: strings via decrypt.py (verified vs Luau factories 80/80);
numbers via transcribed formulas (verified vs Luau 2282/2282).

Ported from the batch-20261023 case script of the same name: the original
read extract/hwf_normalized.luau + round2/extracted_funcs.json from
hardcoded case paths and wrote round2/payload_flat.luau; here the
normalized text and the extracted-funcs table are parameters and the
flat payload is returned. Substitution logic is unchanged.
"""
import re, collections
from antilua_devirt import normalize_text
from decrypt import decrypt_pair

def band(x, y): return float((int(x) % 2**32) & (int(y) % 2**32))
def bor(x, y):  return float((int(x) % 2**32) | (int(y) % 2**32))
def bxor(x, y): return float((int(x) % 2**32) ^ (int(y) % 2**32))
def bnot(x):    return float((~(int(x) % 2**32)) % 2**32)

def build_formulas(funcs):
    FORMULAS = {}
    for name in ["Ad", "td", "yd", "Fd", "Gd", "sd", "ud", "zd", "Hd"]:
        norm, _ = normalize_text(funcs[name])
        m = re.search(r'a\.(?:qd|wd|Cd)\[\w+\]=(.*)return a\.(?:qd|wd|Cd)\[\w+\]end', norm)
        e = m.group(1).replace("a.a(", "band(").replace("a.b(", "bor(").replace("a.c(", "bxor(").replace("a.d(", "bnot(")
        FORMULAS[name] = e
    return FORMULAS

def eval_numeric(name, args, FORMULAS):
    if name in ("vd", "Bd", "Ed"): return float(args[0])
    env = {"band": band, "bor": bor, "bxor": bxor, "bnot": bnot}
    for n, v in zip(["b", "c", "d", "e"], args[:-1]): env[n] = float(v)
    return eval(FORMULAS[name], {"__builtins__": {}}, env)

def luau_str(s: str) -> str:
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif 32 <= o < 127: out.append(ch)
        else: out.append(f"\\{o:03d}")
    return '"' + "".join(out) + '"'

def luau_num(v: float) -> str:
    if v == int(v) and abs(v) < 2**53: return str(int(v))
    return repr(v)

STR_IDIOM = re.compile(
    r'([A-Za-z_][\w]*)\.(qd|wd|Cd)\[(-?\d+)\]\s*or\s*\1:(rd|xd|Dd)\(\s*\1\.bd"([^"]*)"\s*,\s*\1\.bd"([^"]*)"\s*,\s*(-?\d+)\s*\)')
NUM_IDIOM = re.compile(
    r'([A-Za-z_][\w]*)\.(qd|wd|Cd)\[(-?\d+)\]\s*or\s*\1:(sd|ud|td|Ad|zd|yd|Hd|Gd|Fd|vd|Bd|Ed)\(\s*(-?\d+(?:\s*,\s*-?\d+)*)\s*\)')

def build_flat(text, funcs):
    FORMULAS = build_formulas(funcs)
    stats = collections.Counter(); exceptions = []

    def sub_str(m):
        recv, cache, gslot, resolver, a, b, slot = m.groups()
        if int(gslot) != int(slot):
            exceptions.append(("slot-mismatch", m.group(0)[:80])); return m.group(0)
        expect = {"rd": "qd", "xd": "wd", "Dd": "Cd"}[resolver]
        if cache != expect:
            exceptions.append(("cache-mismatch", m.group(0)[:80])); return m.group(0)
        pt = decrypt_pair(resolver, a, b).decode("latin-1")
        stats[f"str_{resolver}"] += 1
        return luau_str(pt)
    text2 = STR_IDIOM.sub(sub_str, text)

    def sub_num(m):
        recv, cache, gslot, resolver, argstr = m.groups()
        args = [int(x) for x in argstr.split(",")]
        if args[-1] != int(gslot):
            exceptions.append(("num-slot-mismatch", m.group(0)[:80])); return m.group(0)
        expect = {"sd": "qd", "ud": "qd", "td": "qd", "vd": "qd", "Ad": "wd", "zd": "wd", "yd": "wd", "Bd": "wd", "Hd": "Cd", "Gd": "Cd", "Fd": "Cd", "Ed": "Cd"}[resolver]
        if cache != expect:
            exceptions.append(("num-cache-mismatch", m.group(0)[:80])); return m.group(0)
        v = eval_numeric(resolver, args, FORMULAS)
        stats[f"num_{resolver}"] += 1
        stats["num_noninteger" if v != int(v) else "num_integer"] += 1
        return "(" + luau_num(v) + ")"
    text3 = NUM_IDIOM.sub(sub_num, text2)
    stats["remaining_bd"] = text3.count('.bd"')
    stats["remaining_resolver_calls"] = len(re.findall(r':(rd|xd|Dd|sd|ud|td|Ad|zd|yd|Hd|Gd|Fd|vd|Bd|Ed)\(', text3))
    return text3, stats, exceptions
