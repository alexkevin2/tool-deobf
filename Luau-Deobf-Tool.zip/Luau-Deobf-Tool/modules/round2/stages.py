#!/usr/bin/env python3
"""Stages D+E: slot1357 -> slot547 -> slot1948 transforms, slot750 permutation,
JG chunk scan. Keyed by sy (probe byte) and Mh (from XM via slot1513)."""
import pathlib, struct, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from payload_decode import band, bor, bxor, lshift, rshift, wL, stage_a

M32 = 0xFFFFFFFF
SLOT1389 = [246,124,8,46,233,221,203,212,95,243,140,82,189,187,216]

def slot461(Zl, IU, IY, nY, Te, YH):
    ou = (Zl + IY + IU * nY) % (1 << 32)
    ou = bxor(ou, rshift(ou, 16))
    ou = (ou * Te + YH) % (1 << 32)
    ou = bxor(ou, rshift(ou, 13))
    ou = (ou * (nY - nY % 2 + 1) + IY) % (1 << 32)
    return bxor(ou, rshift(ou, 16))

def slot1513(Kz):
    return wL(Kz)

def derive_sy(wU, sY=46, pq=127):
    WZ = band(sY * 55 + wU * 121 + pq * 1 + 62, 255)
    zm = band(bxor(bxor(lshift(sY, 5), rshift(wU, 2)), lshift(pq, 1)), 255)
    Lm = band(bor(bxor(sY, 46), bxor(bxor(wU, 223), bxor(pq, 127))), 255)
    sy = band(bxor(bxor(WZ, zm), 173) + Lm, 255)
    return sy, Lm, WZ, zm

def slot139_params(sy):
    lh = band(sy * 17 + 1, 255)
    si = band(sy * 31 + 1, 255)
    SU = [band(bxor(bxor(SLOT1389[i], 32), band(sy + (i+1) * lh + ((i+1) % 251) * si, 255)), 255) for i in range(15)]
    vn = bxor(190, band(sy + 253 * lh + 2 * si, 255))
    mn = bxor(118, band(sy + 254 * lh + 3 * si, 255))
    ig = bxor(22, band(sy + 255 * lh + 4 * si, 255))
    return SU, vn, mn, ig

def stage1357(buf, iw, SU, vn, mn, ig):
    b = bytearray(buf)
    KP = 0
    for pd in range(356124):
        dj = pd + 1
        if pd % 4 == 0:
            KP = slot461(iw, pd, 133858480, 53749, 40049, 850725563)
        bO = (vn + dj * mn + (dj % 251) * ig) % 256
        rZ = bxor(SU[pd % 15], bO)
        djb = bxor(b[pd], band(rshift(KP, ((dj - 1) % 4) * 8), 255))
        b[pd] = bxor(djb, rZ)
    return bytes(b), slot1513(iw + 850725563 + 40048)

def stage547(buf, FB):
    b = bytearray(buf)
    pY = 0
    for UE in range(356124):
        if UE % 4 == 0:
            pY = slot461(FB, UE, 1531361870, 36597, 61341, 526090246)
        Mi = bxor(b[UE], band(rshift(pY, (UE % 4) * 8), 255))
        b[UE] = band(bor(rshift(Mi, 3), lshift(Mi, 5)), 255)
    return bytes(b), slot1513(FB + 526090246 + 122682)

def stage1948(buf, fE):
    b = bytearray(buf)
    fj = 0
    for de in range(0, 356123, 2):
        if de % 4 == 0:
            fj = slot461(fE, de, 2001974078, 17680, 11371, 358181248)
        Sj = bxor(b[de], band(rshift(fj, (de % 4) * 8), 255))
        XF = bxor(b[de + 1], band(rshift(fj, ((de + 1) % 4) * 8), 255))
        b[de] = XF; b[de + 1] = Sj
    return bytes(b), slot1513(fE + 358181248 + 34110)

def slot750_perm(Kz):
    def h(Mc):
        OF = band(1514612089 + Mc * 14075 + (Mc % 251) * 7914, M32)
        FI = band(Kz * 16843009, M32)
        OF = bxor(OF, FI)
        OF = bxor(OF, lshift(OF, 13)); OF = bxor(OF, rshift(OF, 17)); OF = bxor(OF, lshift(OF, 5))
        return band(OF, M32)
    LZ = bxor(4270967313, h(197)) % 356124
    yV = bxor(1021168374, h(352)) % 356124
    return LZ, yV

def permute(Cn, sy):
    LZ, yV = slot750_perm(sy)
    Xl = bytearray(342210)
    for Ti in range(1, 342211):
        UY = ((86 + Ti - 1) * LZ + yV) % 356124 + 1
        Xl[Ti - 1] = Cn[UY - 1]
    return bytes(Xl)

def JG(qd):
    kN = 4
    while kN < 342210:
        AM = qd[kN]; kN += 1
        if AM == 3:
            kN += 1
        elif AM == 238:
            mZ = qd[kN]; kN += 1 + mZ
        elif AM == 48:
            mZ = struct.unpack_from('<I', qd, kN)[0]; kN += 4
            if mZ != 340919: return None
            return bytes(qd[kN:kN + mZ])
        else:
            return None
    return None

def run_chain(sy, XM, verbose=True):
    wd = pathlib.Path(__file__).parent
    blob = (wd.parent / "extract/mos_anti_blob.txt").read_text()
    Ew = stage_a(blob)
    SU, vn, mn, ig = slot139_params(sy)
    Mh = bxor(3863057042, slot1513(bxor(band(sy * 16843009, M32), 1905269810, XM)))
    if verbose: print(f"sy={sy} Mh={Mh} SU[:4]={SU[:4]} vn={vn} mn={mn} ig={ig}")
    b1, iw1 = stage1357(Ew, Mh, SU, vn, mn, ig)
    b2, iw2 = stage547(b1, iw1)
    b3, iw3 = stage1948(b2, iw2)
    Xl = permute(b3, sy)
    ft = JG(Xl)
    return b3, Xl, ft

if __name__ == "__main__":
    XM = 0
    for wU in (223, 148):
        sy, Lm, WZ, zm = derive_sy(wU)
        print(f"wU={wU} -> sy={sy} Lm(oj)={Lm} WZ={WZ} zm={zm}")
        b3, Xl, ft = run_chain(sy, XM)
        if ft:
            print(f"  JG SUCCESS: FT {len(ft)} bytes, head {ft[:32].hex()}")
            pathlib.Path(__file__).parent.joinpath(f"FT_sy{sy}.bin").write_bytes(ft)
        else:
            print(f"  JG failed. Xl head: {Xl[:24].hex()}")
