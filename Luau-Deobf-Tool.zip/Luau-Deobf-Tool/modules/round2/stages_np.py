#!/usr/bin/env python3
import pathlib, struct, sys
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from payload_decode import stage_a
from stages import slot139_params, slot750_perm, JG, derive_sy

U32 = np.uint32

def slot461_np(Zl, IU, IY, nY, Te, YH):
    IU = IU.astype(np.uint64)
    ou = (np.uint64(Zl) + np.uint64(IY) + IU * np.uint64(nY)) % (1 << 32)
    ou = ou ^ (ou >> np.uint64(16))
    ou = (ou * np.uint64(Te) + np.uint64(YH)) % (1 << 32)
    ou = ou ^ (ou >> np.uint64(13))
    ou = (ou * np.uint64(nY - nY % 2 + 1) + np.uint64(IY)) % (1 << 32)
    ou = ou ^ (ou >> np.uint64(16))
    return ou.astype(U32)

def xorshift_np(x):
    x = np.uint64(x) & np.uint64(0xFFFFFFFF)
    x ^= (x << np.uint64(13)) & np.uint64(0xFFFFFFFF)
    x ^= x >> np.uint64(17)
    x ^= (x << np.uint64(5)) & np.uint64(0xFFFFFFFF)
    return int(x & np.uint64(0xFFFFFFFF))

def run_chain_np(Ew, sy, XM=0):
    SU, vn, mn, ig = slot139_params(sy)
    Mh = (3863057042 ^ xorshift_np((sy * 16843009) & 0xFFFFFFFF ^ 1905269810 ^ XM)) & 0xFFFFFFFF
    N = 356124
    pd = np.arange(N, dtype=np.uint64)
    # stage 1357
    KPw = slot461_np(Mh, pd[::4], 133858480, 53749, 40049, 850725563)
    KP = np.repeat(KPw, 4)[:N]
    kp_byte = ((KP >> ((pd % 4) * 8)) & 0xFF).astype(np.uint8)
    dj = pd + 1
    bO = ((vn + dj * mn + (dj % 251) * ig) % 256).astype(np.uint8)
    SUa = np.array(SU, dtype=np.uint8)
    rZ = SUa[pd % 15] ^ bO
    b = np.frombuffer(Ew, dtype=np.uint8).copy()
    b = b ^ kp_byte ^ rZ
    iw = xorshift_np(Mh + 850725563 + 40048)
    # stage 547
    pYw = slot461_np(iw, pd[::4], 1531361870, 36597, 61341, 526090246)
    pY = np.repeat(pYw, 4)[:N]
    py_byte = ((pY >> ((pd % 4) * 8)) & 0xFF).astype(np.uint8)
    Mi = b ^ py_byte
    b = ((Mi >> 3) | ((Mi << 5) & 0xFF)).astype(np.uint8)
    iw2 = xorshift_np(iw + 526090246 + 122682)
    # stage 1948
    de = np.arange(0, 356123, 2, dtype=np.uint64)
    fjw = slot461_np(iw2, de[::2], 2001974078, 17680, 11371, 358181248)
    fj = np.repeat(fjw, 2)[:len(de)]
    sj = b[de] ^ ((fj >> ((de % 4) * 8)) & 0xFF).astype(np.uint8)
    xf = b[de + 1] ^ ((fj >> (((de + 1) % 4) * 8)) & 0xFF).astype(np.uint8)
    b[de] = xf; b[de + 1] = sj
    Gw = b.tobytes()
    # permutation
    LZ, yV = slot750_perm(sy)
    Ti = np.arange(1, 342211, dtype=np.uint64)
    UY = ((86 + Ti - 1) * LZ + yV) % 356124
    Xl = np.frombuffer(Gw, dtype=np.uint8)[UY].tobytes()
    return Gw, Xl, JG(Xl)

if __name__ == "__main__":
    wd = pathlib.Path(__file__).parent
    blob = (wd.parent / "extract/mos_anti_blob.txt").read_text()
    Ew = stage_a(blob)
    hits = []
    for sy in range(256):
        Gw, Xl, ft = run_chain_np(Ew, sy)
        if ft:
            hits.append(sy)
            print(f"sy={sy}: JG SUCCESS FT={len(ft)} head={ft[:32].hex()}")
            (wd / f"FT_sy{sy}.bin").write_bytes(ft)
            (wd / f"Gw_sy{sy}.bin").write_bytes(Gw)
    print("hits:", hits)
    if not hits:
        # diagnostics: for the two candidate sys, show Xl structure
        for wU in (223, 148):
            sy, Lm, WZ, zm = derive_sy(wU)
            Gw, Xl, _ = run_chain_np(Ew, sy)
            print(f"candidate wU={wU} sy={sy}: Xl[:16]={Xl[:16].hex()}")
