#!/usr/bin/env python3
"""Format payload_flat.luau into the final payload source using luau-ast
item spans.

Ported from the batch-20261023 case script of the same name: the original
read round2/payload_flat.luau, round2/payload_ast.json (luau-ast output
for the flat file), round2/name_map.json and extract/hwf_census.json from
hardcoded case paths and wrote hwf_loader.payload.luau; here all inputs
are parameters and the formatted source is returned. Labeling logic is
unchanged.
"""
import json

ROLES = {
 "a": "bit32.band (helper)", "b": "bit32.bor (helper)", "c": "bit32.bxor (helper)", "d": "bit32.bnot (helper)",
 "qd": "constant cache table {} (qd)", "wd": "constant cache table {} (wd)", "Cd": "constant cache table {} (Cd)",
 "_": "getfenv() environment table", "g": "iterator helper (pairs/__iter passthrough, IIFE result)",
 "Id": "entry init: instantiates bd/Xc/_d, then calls main factory k",
 "k": "MAIN payload factory (85 KB CPS register machine)",
 "bd": "string decryptor instantiator -> cd factory", "_d": "pair combiner instantiator -> ad factory",
 "Xc": "pair combiner instantiator -> Yc factory", "cd": "bd codec factory (Ascii85 chunk loop)",
 "dd": "Ascii85 chunk codec factory (alphabet in body)", "ad": "_d XOR codec factory (reversed key cycle)",
 "Yc": "Xc XOR codec factory (forward key cycle)",
 "rd": "resolver: qd[slot] = _d(a, b)", "xd": "resolver: wd[slot] = _d(a, b)", "Dd": "resolver: Cd[slot] = Xc(a, b)",
 "sd": "numeric resolver -> qd", "ud": "numeric resolver -> qd", "td": "numeric resolver -> qd", "vd": "numeric resolver -> qd (store)",
 "Ad": "numeric resolver -> wd", "zd": "numeric resolver -> wd", "yd": "numeric resolver -> wd", "Bd": "numeric resolver -> wd (store)",
 "Hd": "numeric resolver -> Cd", "Gd": "numeric resolver -> Cd", "Fd": "numeric resolver -> Cd", "Ed": "numeric resolver -> Cd (store)",
}

HEADER = """-- hwf_loader.payload.luau
-- AntiLua (unversioned, function-obfuscation tier) -- DECRYPTED PAYLOAD SOURCE
-- Original: hwf_loader.lua.txt  sha256 db64db2b62ec053d095536a7323f1d0847404baf24e3e0989b941a690bb3bf64
-- Round 2 (2026-10-23): per-string encryption BROKEN and all constants inlined.
--   * 2,185 string resolver sites (rd/xd/Dd) replaced by plaintext literals
--     (custom-alphabet Ascii85 `bd` + XOR pair combiners _d/Xc; see STRINGS-REPORT.md).
--   * 2,504 numeric resolver sites (sd/ud/td/Ad/zd/yd/Hd/Gd/Fd/vd/Bd/Ed) replaced by
--     their evaluated integer constants (verified 2,282/2,282 distinct calls vs Luau).
--   * Handler-table items are labeled with their state-field names, recovered by
--     lifting the Wc entry permutation: positional item f+1 (0-based f) takes field
--     names[((104743*f + 43311) mod 227) + 1].
--   * Function bodies remain in their faithful CPS register-machine form
--     (AntiLua flattens every function); only constants were substituted.
--     No control flow was rewritten -- see STRINGS-REPORT.md for the per-function outcome.
-- Verified: luau-compile exit 0; mock-harness behaviour identical to the original
-- (102/102 logged milestones, same Fluent HttpGet URL -- listed only, never fetched).
"""

def format_payload(flat, ast, nm, census):
    head, body = flat.split("\n", 1)
    tbl = ast["root"]["body"][0]["list"][0]["func"]["expr"]["expr"]
    items_ast = tbl["items"]
    assert len(items_ast) == 230
    def span(loc):
        a, b = loc.split(" - ")
        la, ca = a.split(","); lb, cb = b.split(",")
        assert la == lb == "1"
        return int(ca), int(cb)
    texts = []
    for it in items_ast:
        vs, ve = span(it["value"]["location"])
        if it.get("key") is not None:
            ks, ke = span(it["key"]["location"])
            texts.append(body[ks:ve])
        else:
            texts.append(body[vs:ve])
    first_vs, _ = span(items_ast[0]["value"]["location"])
    _, last_ve = span(items_ast[-1]["value"]["location"])
    prefix = body[:first_vs]; suffix = body[last_ve:]
    rejoined = prefix + ",".join(texts) + suffix
    assert rejoined == body, "rejoin mismatch"

    pos2name = {v["census_pos"]: k for k, v in nm.items()}
    slots = census["slots"]
    out = [HEADER]
    out.append(prefix.rstrip("{") + "{")
    for n, (item, slot) in enumerate(zip(texts, slots), 1):
        key = slot["key"]
        if key is not None:
            label = f'keyed "{key}"'
            role = {"i": "unpack helper (keyed item)", "Wc": "ENTRY bootstrap (keyed item): LCG field permutation + main dispatch", "h": "pack helper (keyed item)"}[key]
        else:
            name = pos2name[slot["pos"]]
            label = f'field "{name}"'
            role = ROLES.get(name, "payload closure factory (CPS register machine, preserved)")
        out.append(f"-- [{n}/230] {label} -- {role}")
        out.append(item + ("," if n < len(texts) else ""))
    out.append(suffix)
    return "\n".join(out)
