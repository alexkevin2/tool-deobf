#!/usr/bin/env python3
"""AntiLua hwf_loader string decryption — verified reimplementation.

Layer 1 — bd(s) (factory `cd` census pos215 + chunk codec factory `dd` pos213):
  Custom-alphabet Ascii85. Alphabet (85 chars, verbatim from dd):
    0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~
  If len%5: pad with '~' (alphabet max, digit 84) to a multiple of 5.
  Each 5-char chunk -> value v = (((d0)*85+d1)*85+d2)*85+d3)*85+d4,
  emitted as 4 bytes big-endian (dd uses rshift 24/16/8 + band 255 -> char).
  If len%5 = b != 0: drop the last (5-b) bytes (cd returns sub(out,1,b-6)).
Layer 2 — pair combiners (both XOR key-cycles over layer-1 bytes):
  _d(x,y) (factory `ad` pos201; used by rd -> cache qd, xd -> cache wd):
    key byte for position e (0-based) = y[(len(y)-1) - (e % len(y))]
    i.e. y read in REVERSE, cycling. Output length = len(x).
  Xc(x,y) (factory `Yc` pos140; used by Dd -> cache Cd):
    key byte for position e = y[e % len(y)]  (y FORWARD, cycling).
Resolvers rd/xd/Dd are thin cache wrappers:
  rd(a,b,slot): qd[slot] = _d(bd(a), bd(b));  xd: same -> wd;  Dd: Cd = Xc.
"""
ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~"
IDX = {c: i for i, c in enumerate(ALPHABET)}

def bd(s: str) -> bytes:
    b = len(s) % 5
    padded = s if b == 0 else s + "~" * (5 - b)
    out = bytearray()
    for i in range(0, len(padded), 5):
        v = 0
        for ch in padded[i:i+5]:
            v = v * 85 + IDX[ch]
        if v > 0xFFFFFFFF:
            raise ValueError(f"chunk value overflow {v}")
        out += v.to_bytes(4, "big")
    if b:
        del out[len(out) - (5 - b):]
    return bytes(out)

def xor_rev(x: bytes, y: bytes) -> bytes:   # _d
    if not y: raise ValueError("empty key")
    n = len(y)
    return bytes(xe ^ y[(n - 1) - (e % n)] for e, xe in enumerate(x))

def xor_fwd(x: bytes, y: bytes) -> bytes:   # Xc
    if not y: raise ValueError("empty key")
    n = len(y)
    return bytes(xe ^ y[e % n] for e, xe in enumerate(x))

def decrypt_pair(resolver: str, a: str, b: str) -> bytes:
    da, db = bd(a), bd(b)
    return xor_fwd(da, db) if resolver == "Dd" else xor_rev(da, db)
