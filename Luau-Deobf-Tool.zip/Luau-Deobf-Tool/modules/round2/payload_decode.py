#!/usr/bin/env python3
"""AntiLua v10.1 (mos_hub) payload decoder — static reimplementation.
Stages:
  A  slot1994: custom base-85 (alphabet slot1151^32, Qh=71 digit shift,
     digit rotation [2,3,4,0,1], 5 chars -> u32 LE) -> 356124 B
  B  slot1928: hex tail (767 B) + Adler-32; slot1257 LZMA-variant -> Hk 1338 B
  C  bootstrap register-VM over iK stream (TF/Jo, AES-128-CTR string pool)
     -> QA = {XM, DD}
  D  slot1357 -> slot547 -> slot1948 transforms (keyed by sy, Mh(XM))
  E  slot750 permutation (seed sy) + JG chunk scan -> FT 340919 B
All values transcribed from the folded slot sources in slots_fold2/.
"""
import pathlib, struct, sys, math

M32 = 0xFFFFFFFF

# ---------------------------------------------------------------- bit32 (Luau semantics: unsigned 32-bit)
def band(*a):
    r = M32
    for v in a: r &= int(v) & M32
    return r
def bor(*a):
    r = 0
    for v in a: r |= int(v) & M32
    return r
def bxor(*a):
    r = 0
    for v in a: r ^= int(v) & M32
    return r
def lshift(v, n):
    n &= 31
    return (int(v) << n) & M32
def rshift(v, n):
    n &= 31
    return (int(v) & M32) >> n
def lrotate(v, n):
    n &= 31
    v = int(v) & M32
    return ((v << n) | (v >> (32 - n))) & M32 if n else v
def xorshift32(x):
    x = int(x) & M32
    x ^= lshift(x, 13); x ^= rshift(x, 17); x ^= lshift(x, 5)
    return x & M32
# wL in slot619 == slot1513 core == xorshift32
wL = xorshift32

# ---------------------------------------------------------------- stage A: base-85
SLOT1151 = [16,17,30,27,122,120,64,79,12,31,25,103,80,96,4,127,23,15,10,6,86,75,102,8,126,81,84,71,20,76,73,87,65,74,9,89,98,70,67,19,106,113,97,119,83,99,116,121,82,26,104,29,18,100,114,101,28,90,69,112,22,77,85,21,107,5,110,14,115,11,13,68,78,109,72,111,105,108,3,117,1,66,88,24,118]
ALPHABET = ''.join(chr(c ^ 32) for c in SLOT1151)
BM = {c: i for i, c in enumerate(ALPHABET)}
QH = 71  # slot988

def stage_a(blob: str) -> bytes:
    assert len(blob) == 446703 and blob[445168] == '|'
    vg = blob[6:445168]                    # slot1434: sub(tostring,7,445168)
    assert len(vg) == 445162
    ag = BM[vg[6]]                          # Vg[7] 1-based
    out = bytearray()
    Az = 0
    for Pn in range(7, len(vg), 5):
        grp = vg[Pn:Pn+5]
        d = [(BM[grp[k]] - ((Az + k) * QH) % 85 + 17000) % 85 for k in range(5)]
        jE = ((((d[2]*85 + d[3])*85 + d[4])*85 + d[0])*85 + d[1]) % (1 << 32)
        out += struct.pack('<I', jE)
        Az += 5
    return bytes(out[:len(out) - ag])

# ---------------------------------------------------------------- stage B1: slot1928 hex tail + Adler-32
def slot1928(blob: str):
    assert len(blob) == 446703 and blob.encode()[445168] == 124
    et = bytearray()
    cI, nn = 1, 0
    for bR in range(767):
        WW = int(blob[445169 + bR*2: 445169 + bR*2 + 2], 16)
        et.append(WW)
        cI = (cI + WW) % 65521
        nn = (nn + cI) % 65521
    return bytes(et), nn * 65536 + cI

# ---------------------------------------------------------------- stage B2: slot1257 LZMA-variant
class LZMA1257:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0                     # LO.Tc
        self.Vf = bytearray(1338)
        self.WF = 0
        self.vc = 0xFFFFFFFF
        self.sF = 0
        self.Gh = 0
        self.rt = self.hS = self.GT = self.KD = 0
        self.WM = 0
        self.ZG, self.Ni, self.dy, self.Ig, self.Zt, self.pJ = {}, {}, {}, {}, {}, {}
        self.eD = [{}, {}, {}, {}]
        self.ny, self.bX, self.nL = {}, {}, {}
        # len coders: [UP, [FU1], [jK1], lf]  (Lua 1-based FU[DN+1], DN=0)
        self.YM = [{}, [{}], [{}], {}]
        self.GF = [{}, [{}], [{}], {}]
        self.dB = 0
        self.Vc = 2097152

    def iq(self):
        if self.pos >= 767: raise ValueError("slot1584: out of bytes")
        b = self.data[self.pos]; self.pos += 1
        return b

    def bQ(self, pf, nP):
        nP += 1
        LY = pf.get(nP, 1024)
        Ko = rshift(self.vc, 11) * LY
        if self.sF < Ko:
            self.vc = Ko
            pf[nP] = LY + rshift(2048 - LY, 5)
            if self.vc < 16777216:
                self.sF = bor(lshift(self.sF, 8), self.iq()); self.vc = lshift(self.vc, 8)
            return 0
        self.vc -= Ko; self.sF -= Ko
        pf[nP] = LY - rshift(LY, 5)
        if self.vc < 16777216:
            self.sF = bor(lshift(self.sF, 8), self.iq()); self.vc = lshift(self.vc, 8)
        return 1

    def Cv(self, Be):
        Jn = 0
        for _ in range(Be):
            self.vc = rshift(self.vc, 1)
            Jn *= 2
            if self.sF >= self.vc:
                self.sF -= self.vc; Jn += 1
            if self.vc < 16777216:
                self.sF = bor(lshift(self.sF, 8), self.iq()); self.vc = lshift(self.vc, 8)
        return Jn

    def jV(self, pf, Be):
        qP = 1
        for _ in range(Be):
            qP = qP * 2 + self.bQ(pf, qP)
        return qP - (1 << Be)

    def JP(self, pf, nP, Be):
        qP, vV, jZ = 1, 0, 1
        for _ in range(Be):
            ly = self.bQ(pf, nP + qP)
            qP = qP * 2 + ly
            vV += ly * jZ; jZ *= 2
        return vV

    def sm(self, Se, DN):
        UP, FU, jK, lf = Se
        if self.bQ(UP, 0) == 0: return self.jV(FU[DN], 3)
        if self.bQ(UP, 1) == 0: return 8 + self.jV(jK[DN], 3)
        return 16 + self.jV(lf, 8)

    def vH(self, bG):
        MB = self.WF - bG - 1
        if MB < 0: return None
        return self.Vf[MB]

    def yC(self, Uc):
        if self.WF >= 1338: return False
        self.Vf[self.WF] = Uc; self.WF += 1
        return True

    def py(self, bG, VD):
        for _ in range(VD):
            Uc = self.vH(bG)
            if Uc is None or not self.yC(Uc): return False
        return True

    def DP(self, bz):
        Rn = lshift(band(self.WF, self.dB), 4) + rshift(self.WM, 4)
        pf = self.nL.setdefault(Rn, {})
        if self.Gh < 7:
            vV = 1
            while True:
                vV = vV * 2 + self.bQ(pf, vV)
                if vV >= 256: break
            return vV - 256
        vV = 1
        while True:
            oZ = band(rshift(bz, 7), 1); bz = band(lshift(bz, 1), 255)
            cX = self.bQ(pf, (1 + oZ) * 256 + vV)
            vV = vV * 2 + cX
            if oZ != cX:
                while vV < 256: vV = vV * 2 + self.bQ(pf, vV)
                break
            if vV >= 256: break
        return vV - 256

    def run(self):
        for _ in range(5):
            self.sF = bor(lshift(self.sF, 8), self.iq())
        while self.WF < 1338:
            DN = band(self.WF, 0)
            if self.bQ(self.ZG, self.Gh * 16 + DN) == 0:
                bz = 0
                if self.Gh >= 7:
                    bz = self.vH(self.rt)
                    if bz is None: return None
                self.WM = self.DP(bz)
                if not self.yC(self.WM): return None
                if self.Gh < 4: self.Gh = 0
                elif self.Gh < 10: self.Gh -= 3
                else: self.Gh -= 6
            else:
                VD, bG = 0, 0
                if self.bQ(self.Ni, self.Gh) != 0:
                    if self.bQ(self.dy, self.Gh) == 0:
                        if self.bQ(self.pJ, self.Gh * 16 + DN) == 0:
                            self.Gh = 9 if self.Gh < 7 else 11
                            VD = 1
                    else:
                        if self.bQ(self.Ig, self.Gh) == 0:
                            bG = self.hS
                        else:
                            if self.bQ(self.Zt, self.Gh) == 0: bG = self.GT
                            else:
                                bG = self.KD; self.KD = self.GT
                            self.GT = self.hS
                        self.hS = self.rt; self.rt = bG
                    if VD == 0:
                        VD = self.sm(self.GF, DN) + 2
                        self.Gh = 8 if self.Gh < 7 else 11
                else:
                    self.KD = self.GT; self.GT = self.hS; self.hS = self.rt
                    VD = self.sm(self.YM, DN) + 2
                    self.Gh = 7 if self.Gh < 7 else 10
                    Um = VD - 2
                    if Um > 3: Um = 3
                    kf = self.jV(self.eD[Um], 6)
                    if kf >= 4:
                        zf = rshift(kf, 1) - 1
                        self.rt = (2 + band(kf, 1)) * (1 << zf)
                        if kf < 14:
                            self.rt += self.JP(self.ny, self.rt - kf - 1, zf)
                        else:
                            self.rt += self.Cv(zf - 4) * 16 + self.JP(self.bX, 0, 4)
                    else:
                        self.rt = kf
                if self.rt >= self.WF or self.rt >= self.Vc or self.WF + VD > 1338:
                    return None
                if not self.py(self.rt, VD): return None
                self.WM = self.vH(0)
        return bytes(self.Vf)

def slot1257(et: bytes):
    return LZMA1257(et).run()

if __name__ == "__main__":
    wd = pathlib.Path(__file__).parent
    blob = (wd.parent / "extract/mos_anti_blob.txt").read_text()
    a = stage_a(blob)
    (wd / "stageA_base85.bin").write_bytes(a)
    print("stageA:", len(a), "bytes")
    et, adler = slot1928(blob)
    print("et:", len(et), "adler32:", adler, hex(adler))
    hk = slot1257(et)
    if hk is None:
        print("slot1257 FAILED (returned nil)"); sys.exit(1)
    (wd / "stageB_Hk.bin").write_bytes(hk)
    print("Hk:", len(hk), "bytes; ascii-hex?", all(chr(c) in "0123456789abcdef" for c in hk))
    print("Hk head:", hk[:80])
