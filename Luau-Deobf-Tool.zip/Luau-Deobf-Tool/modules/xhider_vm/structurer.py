"""CFG -> structured Luau structurer for one XHider proto.

Input nodes: {sid: {"lines": [str], "exit": exit}} where exit is one of
  {"kind":"goto","to":sid} | {"kind":"cond","guard":str,"true":sid,"false":sid}
  | {"kind":"return"}
Emission uses dominator-based loop detection and region-relative immediate
post-dominators (loop bodies treat header/exits as pseudo-exits). Loops with
several exit targets are emitted with a __lx selector + post-loop dispatch
when all exits reconverge at the header's immediate post-dominator. Nested
loops are supported; transfers to an ancestor loop's header/exit from inside
a nested loop are not. Anything else raises StructErr with a specific
reason; the caller falls back to a scoped per-proto dispatch and records it.
"""

class StructErr(Exception):
    pass

EXIT = "__EXIT__"

class Structurer:
    def __init__(self, nodes, entry):
        self.nodes = nodes
        self.entry = entry
        self.succ = {}
        for sid, nd in nodes.items():
            ex = nd["exit"]
            if ex["kind"] == "goto":
                self.succ[sid] = [ex["to"]]
            elif ex["kind"] == "cond":
                self.succ[sid] = [ex["true"], ex["false"]]
            else:
                self.succ[sid] = [EXIT]
        self.preds = {sid: [] for sid in nodes}
        self.preds[EXIT] = []
        for sid, ts in self.succ.items():
            for t in ts:
                self.preds.setdefault(t, []).append(sid)
        self.dom = self._dominators()
        self.headers = self._loop_headers()
        self._ipdom_cache = {}
        self.active_loops = []          # stack of headers being emitted
        self.region_exits = [frozenset()]
        self.loop_emissions = {}

    # ---------- graph basics ----------
    def _dominators(self):
        nodes = list(self.nodes)
        dom = {n: set(nodes) | {EXIT} for n in nodes}
        dom[self.entry] = {self.entry}
        changed = True
        while changed:
            changed = False
            for n in nodes:
                if n == self.entry:
                    continue
                ps = [p for p in self.preds.get(n, []) if p in dom]
                if not ps:
                    new = {n}
                else:
                    new = set.intersection(*[dom[p] for p in ps]) | {n}
                if new != dom[n]:
                    dom[n] = new; changed = True
        return dom

    def _loop_headers(self):
        headers = set()
        for u, ts in self.succ.items():
            for v in ts:
                if v in self.nodes and v in self.dom.get(u, set()):
                    headers.add(v)
        return headers

    def _ipdoms(self, extra_exits):
        key = frozenset(extra_exits)
        if key in self._ipdom_cache:
            return self._ipdom_cache[key]
        nodes = list(self.nodes)
        def succs(n):
            if n in extra_exits:
                return [EXIT]
            return self.succ[n]
        alln = nodes + [EXIT]
        pdom = {n: set(alln) for n in alln}
        pdom[EXIT] = {EXIT}
        changed = True
        while changed:
            changed = False
            for n in nodes:
                ss = succs(n)
                if not ss:
                    new = {n}
                else:
                    inter = None
                    for s in ss:
                        inter = set(pdom[s]) if inter is None else inter & pdom[s]
                    new = inter | {n}
                if new != pdom[n]:
                    pdom[n] = new; changed = True
        ipdom = {}
        for n in nodes:
            strict = pdom[n] - {n}
            if not strict:
                ipdom[n] = None
                continue
            ipdom[n] = max(strict, key=lambda d: len(pdom[d]))
        self._ipdom_cache[key] = ipdom
        return ipdom

    def ipdom(self, n):
        return self._ipdoms(self.region_exits[-1])[n]

    # ---------- loop regions ----------
    def loop_region(self, H):
        latch = [u for u in self.preds.get(H, [])
                 if u in self.nodes and H in self.dom.get(u, set())]
        region = {H}
        stack = list(latch)
        while stack:
            x = stack.pop()
            if x == H or x in region:
                continue
            if H not in self.dom.get(x, set()):
                continue
            region.add(x)
            stack.extend(self.preds.get(x, []))
        for n in region:
            if n == H:
                continue
            for p in self.preds.get(n, []):
                if p not in region and p in self.nodes:
                    raise StructErr("loop at %s has external entry into %s"
                                    % (H, n))
        return region

    # ---------- emission ----------
    def ind(self, lines, prefix="  "):
        return [prefix + l if l else l for l in lines]

    def emit(self):
        lines, _ = self.seq(self.entry, EXIT, None)
        return lines

    # lctx: (header, exits_frozenset, {exit_node: selector_index}) or None
    def seq(self, start, stop, lctx, first=False):
        if start == stop and not first:
            return [], start
        lines = []
        node = start
        started = first
        seen = set()
        while node is not None and node != EXIT and (not started or node != stop):
            started = True
            if node in seen:
                raise StructErr("fallthrough revisits node %s (cycle without "
                                "dominating header)" % (node,))
            seen.add(node)
            if node in self.headers and node not in self.active_loops:
                lns, node = self.loop(node, stop, lctx)
                lines += lns
                continue
            nd = self.nodes[node]
            lines += nd["lines"]
            ex = nd["exit"]
            if ex["kind"] == "return":
                lines.append("return w[18](retVals)")
                return lines, None
            if ex["kind"] == "goto":
                t = ex["to"]
                if lctx is not None and t in lctx[1]:
                    lines.append("__lx = %d" % lctx[2][t])
                    lines.append("break")
                    return lines, "BROKE"
                if lctx is not None and t == lctx[0]:
                    return lines, "CONT"
                if t == stop or t == EXIT:
                    return lines, t
                node = t
                continue
            lns, node, mode = self.branch(node, ex, stop, lctx)
            lines += lns
            if mode in ("BROKE", "CONT", "DONE"):
                return lines, mode
        return lines, node

    def branch(self, node, ex, stop, lctx):
        J = self.ipdom(node)
        if J is None or J == node:
            raise StructErr("state %s: no immediate post-dominator for branch"
                            % (node,))
        g = ex["guard"]
        a, b = ex["true"], ex["false"]
        a_lines, a_mode = self._side(a, J, stop, lctx)
        b_lines, b_mode = self._side(b, J, stop, lctx)
        lines = []
        if a_mode == "fall" and not a_lines:
            if b_lines:
                lines.append("if not (%s) then" % g)
                lines += self.ind(b_lines)
                lines.append("end")
        elif b_mode == "fall" and not b_lines:
            if a_lines:
                lines.append("if %s then" % g)
                lines += self.ind(a_lines)
                lines.append("end")
        else:
            lines.append("if %s then" % g)
            lines += self.ind(a_lines)
            lines.append("else")
            lines += self.ind(b_lines)
            lines.append("end")
        if a_mode == "fall" or b_mode == "fall":
            return lines, J, "OK"
        if a_mode == "cont" or b_mode == "cont":
            return lines, None, "CONT"
        if a_mode == "break" or b_mode == "break":
            return lines, None, "BROKE"
        return lines, None, "DONE"

    def _side(self, target, J, stop, lctx):
        """Emit one branch side leading toward join J. Modes: 'fall' reaches
        J; 'break'/'cont' leave via the current loop; 'done' returns."""
        if lctx is not None and J == lctx[0]:
            reach_mode, reach_extra = "cont", []
        elif lctx is not None and J in lctx[1]:
            reach_mode = "break"
            reach_extra = ["__lx = %d" % lctx[2][J], "break"]
        else:
            reach_mode, reach_extra = "fall", []
        if target == J:
            return list(reach_extra), reach_mode
        if lctx is not None:
            if target in lctx[1]:
                return ["__lx = %d" % lctx[2][target], "break"], "break"
            if target == lctx[0]:
                raise StructErr("continue-transfer from nested join (target "
                                "header %s, join %s)" % (lctx[0], J))
        lns, end = self.seq(target, J, lctx)
        if end == J:
            return lns + reach_extra, reach_mode
        if end == "BROKE":
            return lns, "break"
        if end == "CONT":
            return lns, "cont"
        if end is None or end == "DONE":
            return lns, "done"
        raise StructErr("branch side from %s ended at %r, expected join %s"
                        % (target, end, J))

    def loop(self, H, stop, outer_lctx):
        """Emit loop headed at H. Returns (lines, continuation_node)."""
        n_emitted = self.loop_emissions.get(H, 0)
        if n_emitted >= 3:
            raise StructErr("loop at %s emitted %d times (re-entry blowup)"
                            % (H, n_emitted))
        self.loop_emissions[H] = n_emitted + 1
        self.total_emitted = getattr(self, "total_emitted", 0) + 1
        if self.total_emitted > 400:
            raise StructErr("loop emission budget exceeded (duplication "
                            "blowup) at %s" % (H,))
        region = self.loop_region(H)
        exits = set()
        for n in region:
            for t in self.succ[n]:
                if t not in region and t != EXIT:
                    exits.add(t)
        bad = exits & set(self.active_loops)
        if bad:
            raise StructErr("loop at %s exits to ancestor loop header %s "
                            "(continue-like transfer)" % (H, sorted(bad)))
        exits = sorted(exits)
        idx = {e: i + 1 for i, e in enumerate(exits)}
        lctx = (H, frozenset(exits), idx)
        nd = self.nodes[H]
        ex = nd["exit"]
        C = self.ipdom(H) if len(exits) > 1 else (exits[0] if exits else None)
        if len(exits) > 1 and C is None:
            raise StructErr("multi-exit loop at %s has no post-dominator "
                            "continuation" % (H,))
        self.active_loops.append(H)
        self.region_exits.append(frozenset({H} | set(exits)))
        try:
            lines = []
            if len(exits) > 1:
                lines.append("local __lx = 0")
            body_done = False
            if ex["kind"] == "cond":
                a, b = ex["true"], ex["false"]
                a_in = a in region; b_in = b in region
                if ((a in idx) != (b in idx)) and (a if b in idx else b) in region:
                    T = a if a_in else b
                    E = a if a in idx else b
                    exitcond = ex["guard"] if a == E else "not (%s)" % ex["guard"]
                    lines.append("while true do")
                    lines += self.ind(nd["lines"])
                    if len(exits) > 1:
                        lines.append("  if %s then" % exitcond)
                        lines.append("    __lx = %d" % idx[E])
                        lines.append("    break")
                        lines.append("  end")
                    else:
                        lines.append("  if %s then break end" % exitcond)
                    if T != H:
                        body, _ = self.seq(T, H, lctx)
                        lines += self.ind(body)
                    lines.append("end")
                    body_done = True
                elif a == H or b == H:
                    T = b if a == H else a
                    lines.append("while true do")
                    lines += self.ind(nd["lines"])
                    if T in region and T != H:
                        cond_to_T = ex["guard"] if a == T else "not (%s)" % ex["guard"]
                        lines.append("  if %s then" % cond_to_T)
                        body, _ = self.seq(T, H, lctx)
                        lines += self.ind(self.ind(body))
                        lines.append("  end")
                    lines.append("end")
                    body_done = True
            if not body_done:
                if ex["kind"] == "goto" and ex["to"] == H and region == {H}:
                    lines.append("while true do")
                    lines += self.ind(nd["lines"])
                    lines.append("end")
                else:
                    body, _ = self.seq(H, H, lctx, first=True)
                    lines.append("while true do")
                    lines += self.ind(body)
                    lines.append("end")
            if len(exits) > 1:
                # post-loop dispatch to the exit-specific regions, all of
                # which reconverge at C
                for i, E in enumerate(exits):
                    kw = "if" if i == 0 else "elseif"
                    lines.append("%s __lx == %d then" % (kw, idx[E]))
                    sub, end = self.seq(E, C, outer_lctx)
                    if end == "CONT":
                        raise StructErr("multi-exit loop at %s: exit region "
                                        "%s ends in outer continue" % (H, E))
                    lines += self.ind(sub)
                lines.append("end")
                return lines, C
            return lines, (exits[0] if exits else None)
        finally:
            self.active_loops.pop()
            self.region_exits.pop()
