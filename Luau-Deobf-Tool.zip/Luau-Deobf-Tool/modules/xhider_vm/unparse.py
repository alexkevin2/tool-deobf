"""AST -> Luau source renderer for the XHider interpreter AST (luaparse tuples).

- Folds pure integer arithmetic.
- Substitutes o[2](<foldable n>) with the recovered plaintext pool entry
  pool[n + 34818] as a string literal.
- pool: dict int->str loaded from ../recovered_constants.luau
"""
import re

def load_pool(path):
    pool = {}
    txt = open(path, encoding="utf-8").read()
    for m in re.finditer(r'\[(\d+)\] = "((?:\\.|[^"\\])*)"', txt):
        idx = int(m.group(1))
        raw = m.group(2)
        pool[idx] = luau_unescape(raw)
    return pool

def luau_unescape(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            n = s[i+1]
            mp = {"n": "\n", "t": "\t", "r": "\r", "\\": "\\", '"': '"', "'": "'", "a": "\a", "b": "\b", "f": "\f", "v": "\v", "0": "\0"}
            if n.isdigit():
                j = i + 1
                while j < len(s) and j < i + 4 and s[j].isdigit():
                    j += 1
                out.append(chr(int(s[i+1:j]))); i = j; continue
            out.append(mp.get(n, n)); i += 2; continue
        out.append(c); i += 1
    return "".join(out)

def luau_escape(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == "\\": out.append("\\\\")
        elif ch == "\n": out.append("\\n")
        elif ch == "\t": out.append("\\t")
        elif ch == "\r": out.append("\\r")
        elif o < 32 or o > 126: out.append("\\%d" % o)
        else: out.append(ch)
    return '"' + "".join(out) + '"'

from luaparse import fold

POOL = {}

def is_mm(e, k=None):
    return (e[0] == "index" and e[1] == ("name", "MM") and e[2][0] == "num"
            and (k is None or e[2][1] == k))

def is_o2_call(e):
    return (e[0] == "call" and e[1][0] == "index" and e[1][1] == ("name", "o")
            and e[1][2][0] == "num" and e[1][2][1] == 2 and len(e[2]) == 1)

# precedence: or=1 and=2 cmp=3 concat=4(right) add=5 mul=6 unary=7 pow=8(right)
PREC = {"or": 1, "and": 2, "<": 3, ">": 3, "<=": 3, ">=": 3, "~=": 3, "==": 3,
        "..": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6, "^": 8}

def render(e, ctx=0):
    tag = e[0]
    if tag == "num":
        v = e[1]
        return str(int(v)) if float(v) == int(v) else repr(v)
    if tag == "str":
        # raw token incl quotes as written in source; VM region has no strings,
        # but keep verbatim
        return e[1]
    if tag == "strkey":
        return e[1]
    if tag == "name":
        return e[1]
    if tag == "nil": return "nil"
    if tag == "bool": return "true" if e[1] else "false"
    if tag == "vararg": return "..."
    if tag == "binop":
        op = e[1]
        fv = fold(e)
        if fv is not None:
            return str(fv)
        p = PREC[op]
        if op in ("..", "^"):
            s = render(e[2], p + 1) + " " + op + " " + render(e[3], p)
        else:
            s = render(e[2], p) + " " + op + " " + render(e[3], p + 1)
        return "(" + s + ")" if p < ctx else s
    if tag == "unop":
        fv = fold(e)
        if fv is not None:
            return str(fv)
        s = e[1] + " " + render(e[2], 7) if e[1] == "not" else e[1] + render(e[2], 7)
        return "(" + s + ")" if 7 < ctx else s
    if tag == "index":
        base = render(e[1], 9)
        k = e[2]
        if k[0] == "strkey":
            return base + "." + k[1]
        kv = fold(k)
        if kv is not None:
            return base + "[" + str(kv) + "]"
        return base + "[" + render(k) + "]"
    if tag == "call":
        if is_o2_call(e):
            n = fold(e[2][0])
            if n is not None:
                idx = n + 34818
                if idx in POOL:
                    return luau_escape(POOL[idx])
                return "o[2](%d)/*POOL MISS %d*/" % (n, idx)
        return render(e[1], 9) + "(" + ", ".join(render(a) for a in e[2]) + ")"
    if tag == "mcall":
        return render(e[1], 9) + ":" + e[2] + "(" + ", ".join(render(a) for a in e[3]) + ")"
    if tag == "table":
        parts = []
        for it in e[1]:
            if it[0] == "kv":
                k = it[1]
                if k[0] == "strkey":
                    parts.append(k[1] + " = " + render(it[2]))
                else:
                    parts.append("[" + render(k) + "] = " + render(it[2]))
            else:
                parts.append(render(it[1]))
        return "{" + ", ".join(parts) + "}"
    if tag == "func":
        return "function(" + ", ".join(e[1]) + ") " + render_block(e[2], " ") + " end"
    return "/*?%s?*/" % (tag,)

def render_stmt(s, ind=""):
    tag = s[0]
    if tag == "local":
        out = "local " + ", ".join(s[1])
        if s[2]:
            out += " = " + ", ".join(render(v) for v in s[2])
        return [ind + out]
    if tag == "localfunc":
        return [ind + "local function " + s[1] + "(" + ", ".join(s[2]) + ")"] + \
               render_block_lines(s[3], ind + "  ") + [ind + "end"]
    if tag == "assign":
        return [ind + ", ".join(render(t) for t in s[1]) + " = " +
                ", ".join(render(v) for v in s[2])]
    if tag == "callstmt":
        return [ind + render(s[1])]
    if tag == "return":
        if s[1]:
            return [ind + "return " + ", ".join(render(v) for v in s[1])]
        return [ind + "return"]
    if tag == "break":
        return [ind + "break"]
    if tag == "do":
        return [ind + "do"] + render_block_lines(s[1], ind + "  ") + [ind + "end"]
    if tag == "if":
        lines = []
        for i, (c, b) in enumerate(s[1]):
            kw = "if" if i == 0 else "elseif"
            lines.append(ind + kw + " " + render(c) + " then")
            lines += render_block_lines(b, ind + "  ")
        if s[2] is not None:
            lines.append(ind + "else")
            lines += render_block_lines(s[2], ind + "  ")
        lines.append(ind + "end")
        return lines
    if tag == "while":
        return [ind + "while " + render(s[1]) + " do"] + \
               render_block_lines(s[2], ind + "  ") + [ind + "end"]
    if tag == "repeat":
        return [ind + "repeat"] + render_block_lines(s[1], ind + "  ") + \
               [ind + "until " + render(s[2])]
    if tag == "fornum":
        st = "for " + s[1] + " = " + render(s[2]) + ", " + render(s[3])
        if s[4] is not None:
            st += ", " + render(s[4])
        return [ind + st + " do"] + render_block_lines(s[5], ind + "  ") + [ind + "end"]
    if tag == "forin":
        return [ind + "for " + ", ".join(s[1]) + " in " +
                ", ".join(render(v) for v in s[2]) + " do"] + \
               render_block_lines(s[3], ind + "  ") + [ind + "end"]
    if tag == "funcdef":
        name = ".".join(s[1])
        if s[2]:
            name += ":" + s[2]
        return [ind + "function " + name + "(" + ", ".join(s[3]) + ")"] + \
               render_block_lines(s[4], ind + "  ") + [ind + "end"]
    return [ind + "/*?stmt %s?*/" % (tag,)]

def render_block_lines(block, ind=""):
    lines = []
    for s in block:
        lines += render_stmt(s, ind)
    return lines

def render_block(block, sep="\n"):
    return sep.join(render_block_lines(block))
