"""XHider v1.2 devirtualizer, stage 2: lift the state graph to structured Luau.

- Per state: remove MM[50] transition machinery (exit assignment + scratch
  writes whose value flows only into it), substitute entry-value reads of
  MM[50] with the state id, promote registers MM[k] to named locals.
- Per proto: structure the CFG (structurer.py); on any structural property
  that cannot be structured, fall back to a scoped per-proto dispatch and
  record the reason (irreducible/complex kernel list for the report).
- Closure factories become bind<k> helpers reproducing each factory's exact
  argument packing (parsed from the factory region of the sample); factory
  call sites become bind<k>(fn_<entry>, <descriptor>).
- Non-factory w[] runtime entries are emitted verbatim as a prelude.

Output: kaitun_cyborg.deobf.luau + lift_stats.json. Static analysis only.
"""
import json, sys
sys.path.insert(0, '.')
import graph_lib as G
from graph_lib import MAIN_ENTRY, FACTORY_W, analyze_block
from luaparse import tokenize, Parser, fold
import unparse
from unparse import render, render_block_lines, is_mm
from structurer import Structurer, StructErr

POOL = unparse.POOL

# ---------------------------------------------------------------- state map
func = G.load_ast()
header_stmts, while_stmt, tail_stmts = G.get_parts(func)
leaves, anomalies = G.split_leaves(while_stmt)
leaf_info = []
for (lo, hi, block) in leaves:
    info = analyze_block(block)
    info["range"] = [lo, hi]
    info["block_ast"] = block
    leaf_info.append(info)

state_values = {MAIN_ENTRY}
for info in leaf_info:
    for tr in info["exit_transitions"]:
        if tr["kind"] == "goto":
            state_values.add(tr["to"])
        elif tr["kind"] == "cond":
            state_values.add(tr["true"]); state_values.add(tr["false"])
    for cs in info["closure_sites"]:
        if cs["entry_state"] is not None:
            state_values.add(cs["entry_state"])

def in_range(v, lo, hi):
    return (lo is None or v >= lo) and (hi is None or v < hi)

states, gap_leaves = {}, []
for info in leaf_info:
    lo, hi = info["range"]
    cands = [v for v in state_values if in_range(v, lo, hi)]
    if len(cands) == 1:
        info["state_id"] = cands[0]
        states[cands[0]] = info
    elif len(cands) == 0:
        gap_leaves.append(info)
    else:
        raise SystemExit("multi-candidate leaf")
print("states:", len(states), "gap leaves:", len(gap_leaves))

proto_map = json.load(open('proto_map.json'))
owner = {int(k): int(v) for k, v in proto_map["owner"].items()}
entries = {int(k): v for k, v in proto_map["entries"].items()}

# orphan units: gap leaf + states reachable from it that no proto owns
def exit_targets(info):
    out = set()
    for tr in info["exit_transitions"]:
        if tr["kind"] == "goto":
            out.add(tr["to"])
        elif tr["kind"] == "cond":
            out.add(tr["true"]); out.add(tr["false"])
    return out

orphan_units = []
for gi, g in enumerate(gap_leaves):
    unit = {"gap_index": gi, "range": g["range"], "gap_info": g, "states": []}
    seen = set()
    stack = list(exit_targets(g))
    while stack:
        s = stack.pop()
        if s in seen or s not in states or s in owner:
            continue
        seen.add(s)
        stack.extend(exit_targets(states[s]))
    unit["states"] = sorted(seen)
    orphan_units.append(unit)
print("orphan units:", [(u["range"], len(u["states"])) for u in orphan_units])

protos = {}
for entry in entries:
    protos[entry] = sorted(s for s, o in owner.items() if o == entry)
print("protos:", len(protos))

# ---------------------------------------------------------------- factory
src = open('../sample_original.lua.txt', encoding='utf-8').read()
fbody_src = src.split('\n')[2]
fi = fbody_src.index('return(function(x,m,Y,I,X,E')
fp = Parser(tokenize(fbody_src[fi:]))
fret = fp.parse_stmt()
fcall = fret[1][0]
ffunc = fcall[1]
fparams = ffunc[1]
fargs = fcall[2]
param_to_arg = {}
for i, pn in enumerate(fparams):
    param_to_arg[pn] = fargs[i] if i < len(fargs) else ("nil",)

wvals = {}
for st in ffunc[2]:
    if st[0] == 'assign':
        for t, v in zip(st[1], st[2]):
            if t[0] == 'index' and t[1] == ('name', 'w') and t[2][0] == 'num':
                wvals[t[2][1]] = v

def subst_factory_params(e):
    if not isinstance(e, tuple):
        return e
    if e[0] == 'name' and e[1] in param_to_arg:
        return param_to_arg[e[1]]
    return tuple(subst_factory_params(c) if isinstance(c, tuple)
                 else [subst_factory_params(x) if isinstance(x, tuple) else x
                       for x in c] if isinstance(c, list) else c for c in e)

def find_inner_factory(wval):
    """Locate the inner closure + its w[23] return inside a factory value."""
    found = []
    def walk(node):
        if isinstance(node, tuple):
            if node[0] == 'func':
                for s in node[2]:
                    if s[0] == 'return' and s[1] and s[1][0][0] == 'call' \
                            and s[1][0][1][0] == 'index' \
                            and s[1][0][1][1] == ('name', 'w') \
                            and s[1][0][1][2] == ('num', 23):
                        found.append((node, s[1][0]))
            for c in node[1:]:
                if isinstance(c, (tuple, list)):
                    walk(c)
        elif isinstance(node, list):
            for c in node:
                if isinstance(c, (tuple, list)):
                    walk(c)
    walk(wval)
    return found[0] if found else None

factory_conv = {}
for k in sorted(FACTORY_W):
    got = find_inner_factory(wvals[k])
    if got is None:
        factory_conv[k] = (["..."], ("table", [("item", ("vararg",))]), "FALLBACK")
        continue
    inner, call23 = got
    params, fbody = inner[1], inner[2]
    packmap = {}
    packname = None
    for s in fbody:
        if s[0] == 'local' and len(s[1]) == 1 and s[2] and s[2][0][0] == 'table' \
                and not s[2][0][1]:
            packname = s[1][0]
        if s[0] == 'assign' and packname:
            ok = all(t[0] == 'index' and t[1] == ('name', packname)
                     and t[2][0] == 'num' for t in s[1])
            if ok:
                for t, v in zip(s[1], s[2]):
                    packmap[t[2][1]] = v
    argtab = call23[2][1]
    if argtab[0] != 'table':
        factory_conv[k] = (params, ("table", [("item", ("vararg",))]), "NONTable")
        continue
    items = []
    for it in argtab[1]:
        e = it[1]
        if packname and e[0] == 'index' and e[1] == ('name', packname) \
                and e[2][0] == 'num' and e[2][1] in packmap:
            e = packmap[e[2][1]]
        items.append(("item", e))
    factory_conv[k] = (params, ("table", items), "ok")
print("factory conventions:", {k: v[2] for k, v in factory_conv.items()})

# ---------------------------------------------------------------- transform
REGNAME = {50: "state", 29: "args", 43: "protoDesc", 55: "envBox",
           13: "retVals", 6: "cell"}
def regname(k):
    return REGNAME.get(k, "r%d" % k)

def is_factory_call(e):
    return (e[0] == 'call' and e[1][0] == 'index' and e[1][1] == ('name', 'w')
            and e[1][2][0] == 'num' and e[1][2][1] in FACTORY_W
            and len(e[2]) == 2 and fold(e[2][0]) is not None)

def transform(node):
    if not isinstance(node, tuple):
        return node
    if is_factory_call(node):
        k = node[1][2][1]
        entry = fold(node[2][0])
        return ("call", ("name", "bind%d" % k),
                [("name", "fn_%d" % entry), transform(node[2][1])])
    if is_mm(node):
        return ("name", regname(node[2][1]))
    return tuple(transform(c) if isinstance(c, tuple)
                 else [transform(x) if isinstance(x, tuple) else x for x in c]
                 if isinstance(c, list) else c for c in node)

def contains_mm50(node):
    if isinstance(node, tuple):
        if is_mm(node, 50):
            return True
        return any(contains_mm50(c) for c in node[1:] if isinstance(c, (tuple, list)))
    if isinstance(node, list):
        return any(contains_mm50(c) for c in node if isinstance(c, (tuple, list)))
    return False

def regs_used(node, acc):
    if isinstance(node, tuple):
        if is_mm(node):
            acc.add(node[2][1])
        for c in node[1:]:
            if isinstance(c, (tuple, list)):
                regs_used(c, acc)
    elif isinstance(node, list):
        for c in node:
            if isinstance(c, (tuple, list)):
                regs_used(c, acc)

def writes_mm50_deep(node):
    if isinstance(node, tuple):
        if node[0] == 'assign':
            return any(is_mm(t, 50) for t in node[1])
        return any(writes_mm50_deep(c) for c in node[1:] if isinstance(c, (tuple, list)))
    if isinstance(node, list):
        return any(writes_mm50_deep(c) for c in node if isinstance(c, (tuple, list)))
    return False

def replace_mm50_reads(node, sid):
    if not isinstance(node, tuple):
        return node
    if is_mm(node, 50):
        return ("num", sid)
    return tuple(replace_mm50_reads(c, sid) if isinstance(c, tuple)
                 else [replace_mm50_reads(x, sid) if isinstance(x, tuple) else x
                       for x in c] if isinstance(c, list) else c for c in node)

# ---------------------------------------------------------------- per-state
class Complex(Exception):
    pass

def analyze_exit(block):
    """Forward pass; returns (transition, exit_stmt, sym_ast_at_exit)."""
    env = {}
    T, Tstmt, Tsym = [], None, None
    for s in block:
        t, a, env = G.stmt_effect(s, env)
        if t:
            if a:
                T, Tstmt, Tsym = t, s, env.get(("sym", 50))
            else:
                T = T + t
                if len(T) > 1:
                    Tstmt = None
        elif a and s[0] == 'return':
            T, Tstmt = [], None
    if len(T) != 1 or Tstmt is None:
        raise Complex("exit transitions=%d (need exactly 1 from one stmt)" % len(T))
    return T[0], Tstmt, Tsym

def mm50_consumers(block):
    """For each top-level MM[50]-writing stmt index, the set of stmt indices
    that read its value (stmts after it, up to the next MM[50] write; the
    next write's own RHS read counts as a consumption by that write)."""
    writes = [i for i, s in enumerate(block)
              if s[0] == 'assign' and any(is_mm(t, 50) for t in s[1])]
    consumers = {}
    for wi, p in enumerate(writes):
        end = writes[wi + 1] if wi + 1 < len(writes) else len(block)
        cons = set()
        for j in range(p + 1, min(end + 1, len(block))):
            if contains_mm50(block[j]):
                cons.add(j)
        consumers[p] = cons
    return writes, consumers

def regs_read(node, acc):
    if isinstance(node, tuple):
        if is_mm(node):
            acc.add(node[2][1])
        for c in node[1:]:
            if isinstance(c, (tuple, list)):
                regs_read(c, acc)
    elif isinstance(node, list):
        for c in node:
            if isinstance(c, (tuple, list)):
                regs_read(c, acc)

def regs_written(node, acc):
    if isinstance(node, tuple):
        if node[0] == 'assign':
            for t in node[1]:
                if is_mm(t):
                    acc.add(t[2][1])
        for c in node[1:]:
            if isinstance(c, (tuple, list)):
                regs_written(c, acc)
    elif isinstance(node, list):
        for c in node:
            if isinstance(c, (tuple, list)):
                regs_written(c, acc)

def has_call(node):
    if isinstance(node, tuple):
        if node[0] in ('call', 'mcall'):
            return True
        return any(has_call(c) for c in node[1:] if isinstance(c, (tuple, list)))
    if isinstance(node, list):
        return any(has_call(c) for c in node if isinstance(c, (tuple, list)))
    return False

def expr_contains(big, small):
    if big == small:
        return True
    if isinstance(big, tuple):
        return any(expr_contains(c, small) for c in big[1:]
                   if isinstance(c, (tuple, list)))
    if isinstance(big, list):
        return any(expr_contains(c, small) for c in big
                   if isinstance(c, (tuple, list)))
    return False

def process_state(sid, block):
    """-> (body_block_ast, exit_dict, n_dropped, mode). Raises Complex.

    Two sound modes:
    - "drop": the exit assignment and its feeder writes (MM[50] writes whose
      value flows only into the transition) are removed; the exit becomes
      control flow with the symbolically composed guard. Requires: all
      feeders single-target, feeder RHS registers not rewritten by later
      kept statements, and no call from a kept write inlined into the guard.
    - "keep": every statement stays (MM[50] becomes the local `state`);
      a cond exit branches on `state == <true target>` (the final machinery
      value is exactly one of the two targets), goto/return exits need
      nothing extra. Always sound.
    """
    tr, exit_stmt, sym = analyze_exit(block)
    if exit_stmt[0] != 'assign':
        raise Complex("exit stmt is %s, not assign" % exit_stmt[0])
    # entry-value read substitution (prefix before first MM[50] write)
    sub = []
    seen_write = False
    for s in block:
        if not seen_write and not writes_mm50_deep(s):
            s = replace_mm50_reads(s, sid)
        if writes_mm50_deep(s):
            seen_write = True
        sub.append(s)
    exit_pos = next(i for i, s in enumerate(sub) if s is exit_stmt)
    writes, consumers = mm50_consumers(sub)
    if not writes or sub[writes[-1]] is not exit_stmt:
        raise Complex("exit stmt is not the last MM[50] write")
    # feeders: writes before the exit whose consumers are all writes in the
    # machinery chain (computed backward from the exit write)
    chain = {exit_pos}
    for p in reversed(writes[:-1]):
        if consumers[p] and consumers[p] <= chain:
            chain.add(p)
    feeders = sorted(chain - {exit_pos})
    body_writes = [p for p in writes if p not in chain]

    def try_drop():
        if len(exit_stmt[1]) > 1:
            return None
        for p in chain:
            if len(sub[p][1]) > 1:
                return None
        if consumers[exit_pos]:
            return None  # body code reads MM[50] after the exit write
        kept = [s for i, s in enumerate(sub) if i not in chain]
        if tr["kind"] == "goto":
            ex = {"kind": "goto", "to": tr["to"]}
        elif tr["kind"] == "return_nil_env":
            ex = {"kind": "return"}
        elif tr["kind"] == "cond":
            if sym is None or sym[0] != 'binop' or sym[1] != 'or' \
                    or sym[2][0] != 'binop' or sym[2][1] != 'and':
                return None
            if fold(sym[2][3]) != tr["true"] or fold(sym[3]) != tr["false"]:
                return None
            guard_ast = sym[2][2]
            # (a) registers the composed guard reads must not be rewritten
            # by kept stmts after the first machinery stmt: the guard is
            # evaluated at block end in structured form, but the original
            # machinery values were captured at their own positions.
            rr = set()
            regs_read(guard_ast, rr)
            rr.discard(50)
            first_chain = min(chain)
            for j, s in enumerate(sub):
                if j > first_chain and j not in chain:
                    wr = set()
                    regs_written(s, wr)
                    if rr & wr:
                        return None
            # (b) a kept write whose value flows into the machinery chain
            # must not have a call in its RHS: the guard inlines its RHS,
            # which would evaluate the call a second time.
            for p in body_writes:
                if consumers[p] & chain:
                    rhs = sub[p][2][0] if len(sub[p][2]) == 1 else None
                    if rhs is not None and has_call(rhs):
                        return None
            if contains_mm50(guard_ast):
                # chain bottoms out at the block-entry value (= sid)
                guard_ast = replace_mm50_reads(guard_ast, sid)
                fv = fold(guard_ast)
                if fv is not None:
                    return (kept, {"kind": "goto",
                                   "to": tr["true"] if fv else tr["false"]},
                            len(chain))
            ex = {"kind": "cond", "guard_ast": guard_ast,
                  "true": tr["true"], "false": tr["false"]}
        else:
            return None
        return kept, ex, len(chain)

    got = try_drop()
    if got is not None:
        kept, ex, ndropped = got
        return kept, ex, ndropped, "drop"
    # keep-all mode
    if tr["kind"] == "goto":
        ex = {"kind": "goto", "to": tr["to"]}
    elif tr["kind"] == "return_nil_env":
        ex = {"kind": "return"}
    elif tr["kind"] == "cond":
        ex = {"kind": "cond",
              "guard_ast": ("binop", "==", ("index", ("name", "MM"), ("num", 50)),
                            ("num", tr["true"])),
              "true": tr["true"], "false": tr["false"]}
    else:
        raise Complex("exit kind %s" % tr["kind"])
    return sub, ex, 0, "keep"

def count_stmts(block):
    n = 0
    for s in block:
        n += 1
        for c in s[1:]:
            if isinstance(c, list):
                for x in c:
                    if isinstance(x, tuple) and x and isinstance(x[0], str):
                        pass
        # count nested statement lists heuristically via tag scan
    return n

def deep_stmt_count(node):
    n = 0
    if isinstance(node, tuple):
        if node[0] in ('assign', 'local', 'localfunc', 'funcdef', 'if', 'while',
                       'do', 'fornum', 'forin', 'return', 'break', 'repeat',
                       'callstmt'):
            n += 1
        for c in node[1:]:
            if isinstance(c, (tuple, list)):
                n += deep_stmt_count(c)
    elif isinstance(node, list):
        for c in node:
            if isinstance(c, (tuple, list)):
                n += deep_stmt_count(c)
    return n

# ---------------------------------------------------------------- emission
def register_decls(ast_list):
    used = set()
    for a in ast_list:
        regs_used(a, used)
    used.discard(50); used.discard(29); used.discard(43); used.discard(55)
    lines = []
    plain = sorted(k for k in used if k not in (6, 13))
    decl = []
    if 13 in used:
        decl.append("retVals")
    decl += [regname(k) for k in plain]
    if decl:
        lines.append("local " + ", ".join(decl))
    if 6 in used:
        lines.append("local cell = {}")
    return lines

def render_fn_header(name):
    return "%s = function(args, protoDesc, envBox)" % name

def lift_proto_structured(entry, sids):
    nodes = {}
    asts = []
    total_mach = 0
    modes = {"drop": 0, "keep": 0}
    for sid in sids:
        block = states[sid]["block_ast"]
        clean, ex, nmach, mode = process_state(sid, block)
        total_mach += nmach
        modes[mode] += 1
        tclean = [transform(s) for s in clean]
        lines = []
        # if the kept body still uses MM[50] (now the `state` local), pin
        # its block-entry value: the original dispatcher enters the block
        # with MM[50] == sid, but a predecessor's dropped exit write no
        # longer sets it.
        if any(contains_mm50(s) for s in clean):
            lines.append("state = %d" % sid)
        for s in tclean:
            lines += render_block_lines([s], "")
        exr = dict(ex)
        if ex["kind"] == "cond":
            exr["guard"] = render(transform(ex["guard_ast"]))
            del exr["guard_ast"]
        nodes[sid] = {"lines": lines, "exit": exr}
        asts += tclean
        if ex["kind"] == "cond":
            asts.append(ex["guard_ast"])
    st = Structurer(nodes, entry)
    body = st.emit()
    out = [render_fn_header("fn_%d" % entry)]
    out += ["  " + l for l in register_decls(asts)]
    out.append("  local state = %d" % entry)
    out += ["  " + l if l else l for l in body]
    out.append("end")
    return out, total_mach, modes

def lift_proto_dispatch(name, entry_state, node_items):
    """node_items: list of (branch_cond_str, block_ast)."""
    out = [render_fn_header(name)]
    asts = [b for _, b in node_items]
    out += ["  " + l for l in register_decls(asts)]
    out.append("  local state = %s" % (entry_state if entry_state is not None else "nil"))
    out.append("  while state do")
    for i, (cond, block) in enumerate(node_items):
        kw = "if" if i == 0 else "elseif"
        out.append("    %s %s then" % (kw, cond))
        for s in block:
            out += render_block_lines([transform(s)], "      ")
    out.append("    end")
    out.append("  end")
    out.append("  return w[18](retVals)")
    out.append("end")
    return out

# ---------------------------------------------------------------- assemble
output = []
output.append("--// XHider v1.2 payload, devirtualized by static state-graph lifting.")
output.append("--// Original: kaitun_cyborg.lua.txt (753,419 B, sha256 320b3796c720218cd1661ad831eed1354f98c3bed9738f1fc09d8b8391c69155)")
output.append("--// Blox Fruits 'Kaitun' Cyborg-race farm script (identity CONFIRMED from recovered constants).")
output.append("--// Structure: runtime prelude (w[] helpers, verbatim from the VM factory),")
output.append("--// one local function per VM proto (fn_<entry state>), closure factories")
output.append("--// reproduced as bind<k> helpers with each factory's exact argument packing.")
output.append("--// Registers promoted to locals: args=MM[29], protoDesc=MM[43], envBox=MM[55],")
output.append("--// retVals=MM[13] (CONFIRMED), cell=MM[6] (INFERRED per-invocation cell), r<k>=MM[k] (UNKNOWN).")
output.append("--// Protos that resisted structuring use a scoped dispatch loop (see DEVIRT-REPORT.md).")
output.append("")

# prelude
output.append("local w = {}")
PRELUDE_SKIP = FACTORY_W | {23}
for k in sorted(wvals):
    if k in PRELUDE_SKIP:
        continue
    v = wvals[k]
    if v[0] == 'func':
        vv = subst_factory_params(v) if False else v
        lines = ["w[%d] = function(%s)" % (k, ", ".join(v[1]))]
        lines += render_block_lines(v[2], "  ")
        lines.append("end")
        output += lines
    else:
        output.append("w[%d] = %s" % (k, render(subst_factory_params(v))))
output.append("")

# binders
for k in sorted(FACTORY_W):
    params, pack, status = factory_conv[k]
    output.append("local function bind%d(fn, desc)" % k)
    output.append("  local envBox = w[17](desc)")
    output.append("  return function(%s) return fn(%s, desc, envBox) end"
                  % (", ".join(params), render(pack)))
    output.append("end")
output.append("")

# forward declarations
fn_names = ["fn_%d" % e for e in sorted(protos)]
for i, u in enumerate(orphan_units):
    fn_names.append("fn_orphan_%d" % i)
output.append("local " + ", ".join(fn_names))
output.append("")

stats = {"protos": {}, "orphans": {}, "total_machinery_dropped": 0,
         "states_structured": 0, "states_dispatch": 0,
         "body_stmts_lifted": 0}
for entry in sorted(protos):
    sids = protos[entry]
    try:
        lines, nmach, modes = lift_proto_structured(entry, sids)
        stats["protos"][str(entry)] = {"mode": "structured", "states": len(sids),
                                       "state_modes": modes}
        stats["states_structured"] += len(sids)
        stats["total_machinery_dropped"] += nmach
        for sid in sids:
            stats["body_stmts_lifted"] += deep_stmt_count(
                states[sid]["block_ast"])
        output += lines
    except (Complex, StructErr) as e:
        reason = "%s: %s" % (type(e).__name__, e)
        items = [("state == %d" % sid, states[sid]["block_ast"]) for sid in sids]
        lines = lift_proto_dispatch("fn_%d" % entry, entry, items)
        stats["protos"][str(entry)] = {"mode": "dispatch", "states": len(sids),
                                       "reason": reason}
        stats["states_dispatch"] += len(sids)
        output += lines
    output.append("")

for i, u in enumerate(orphan_units):
    items = []
    lo, hi = u["range"]
    items.append(("state >= %d and state < %d" % (lo, hi), u["gap_info"]["block_ast"]))
    for sid in u["states"]:
        items.append(("state == %d" % sid, states[sid]["block_ast"]))
    lines = lift_proto_dispatch("fn_orphan_%d" % i, lo, items)
    stats["orphans"][str(i)] = {"range": u["range"], "states": len(u["states"]) + 1}
    output += ["--// ORPHAN proto: entry state id UNKNOWN, bounded by dispatch range "
               "[%d, %d); no literal transition or factory site targets it." % (lo, hi)]
    output += lines
    output.append("")

output.append("return bind3(fn_%d, {})(w[18](w[25]))" % MAIN_ENTRY)
text = "\n".join(output) + "\n"
with open('kaitun_cyborg.deobf.luau', 'w') as f:
    f.write(text)
with open('lift_stats.json', 'w') as f:
    json.dump(stats, f, indent=1)
print("structured states:", stats["states_structured"],
      "| dispatch states:", stats["states_dispatch"])
print("dispatch protos:",
      {k: v["reason"] for k, v in stats["protos"].items() if v["mode"] == "dispatch"})
print("machinery stmts dropped:", stats["total_machinery_dropped"])
print("wrote kaitun_cyborg.deobf.luau", len(text), "bytes")
