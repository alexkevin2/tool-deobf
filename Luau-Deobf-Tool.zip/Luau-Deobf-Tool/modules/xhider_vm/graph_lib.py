"""Shared graph-extraction library for the XHider v1.2 devirtualizer.

Parses interpreter_raw.luau, splits the MM[50] binary-search dispatch into
per-state blocks, and computes exit transitions with a light in-block
constant-propagation pass (registers / register fields assigned foldable
integer literals) so staged transitions like
    MM[6][5] = 13171290 ; MM[50] = MM[35] and MM[6][5] ; MM[35] = 12482204 ;
    MM[50] = MM[50] or MM[35]
resolve to cond(guard, 13171290, 12482204).

Exit kinds: goto / cond / return_nil_env / exit_loop / dynamic.
Pure static analysis; nothing is executed.
"""
import sys
sys.path.insert(0, '.')
from luaparse import tokenize, Parser, fold
import unparse
from unparse import render, render_block_lines, is_mm

unparse.POOL = unparse.load_pool('../recovered_constants.luau')
POOL = unparse.POOL

# w[5] added during devirtualization: its call sites pass exactly the
# dispatch ranges that no literal transition targets (19 sites) -- it is a
# 10th closure factory that ANALYSIS.md's factory list missed.
FACTORY_W = {1, 3, 5, 6, 8, 10, 12, 13, 16, 21}
MAIN_ENTRY = 15645401

def load_ast():
    src = open('interpreter_raw.luau').read()
    p = Parser(tokenize(src))
    func = p.parse_prefixexp()
    return func

def get_parts(func):
    body = func[2]
    wi = next(i for i, s in enumerate(body) if s[0] == 'while')
    return body[:wi], body[wi], body[wi + 1:]

# ---------------- dispatch walk ----------------
def is_dispatch_cond(c):
    return (c[0] == 'binop' and c[1] in ('<', '<=') and is_mm(c[2], 50)
            and fold(c[3]) is not None)

def is_dispatch_if(s):
    return s[0] == 'if' and all(is_dispatch_cond(c) for c, _ in s[1])

def split_leaves(while_stmt):
    leaves, anomalies = [], []
    def rec(block, lo, hi):
        prefix = []
        for s in block:
            if is_dispatch_if(s):
                if prefix:
                    anomalies.append(("prefix_before_dispatch", lo, hi))
                cur = lo
                for cond, arm in s[1]:
                    c = fold(cond[3])
                    arm_hi = c if cond[1] == '<' else c + 1
                    rec(arm, cur, min(hi, arm_hi) if hi is not None else arm_hi)
                    cur = arm_hi
                if s[2] is not None:
                    rec(s[2], cur, hi)
                else:
                    anomalies.append(("dispatch_if_no_else", lo, hi))
                return
            prefix.append(s)
        leaves.append((lo, hi, prefix))
    rec(while_stmt[2], None, None)
    return leaves, anomalies

# ---------------- const-prop ----------------
def reg_key(e):
    """env key for an MM lvalue expr, or None."""
    if is_mm(e):
        return ("r", e[2][1])
    if e[0] == 'index' and is_mm(e[1]):
        j = fold(e[2])
        if j is not None:
            return ("f", e[1][2][1], j)
    return None

def subst_env(e, env):
    if not isinstance(e, tuple):
        return e
    k = reg_key(e)
    if k is not None and k in env:
        return ("num", env[k])
    return tuple(subst_env(c, env) if isinstance(c, tuple)
                 else [subst_env(x, env) if isinstance(x, tuple) else x for x in c]
                 if isinstance(c, list) else c for c in e)

MM50_NODE = ("index", ("name", "MM"), ("num", 50))

def subst_sym(e, symast):
    """Replace MM[50] subexpressions with the pending symbolic MM[50] expr."""
    if not isinstance(e, tuple):
        return e
    if e == MM50_NODE:
        return symast
    return tuple(subst_sym(c, symast) if isinstance(c, tuple)
                 else [subst_sym(x, symast) if isinstance(x, tuple) else x
                       for x in c] if isinstance(c, list) else c for c in e)

def mentions_reg(e, k):
    if not isinstance(e, tuple):
        return False
    if is_mm(e, k):
        return True
    for c in e[1:]:
        if isinstance(c, tuple) and mentions_reg(c, k):
            return True
        if isinstance(c, list) and any(isinstance(x, tuple) and mentions_reg(x, k) for x in c):
            return True
    return False

def classify_rhs(rhs, env):
    """rhs is classified after const substitution; if env holds a symbolic
    pending MM[50] expr under ('sym',50), MM[50] refs in rhs are replaced by
    it first (staged cond: MM[50] = guard and A  ...  MM[50] = MM[50] or B)."""
    r = subst_env(rhs, env)
    sym = env.get(("sym", 50))
    if sym is not None:
        r = subst_sym(r, sym)
    v = fold(r)
    if v is not None:
        return [{"kind": "goto", "to": v}], r
    if r[0] in ('bool', 'nil'):
        return [{"kind": "exit_loop", "value": render(rhs)}], r
    if r[0] == 'binop' and r[1] == 'or':
        a, b = r[2], r[3]
        if a[0] == 'binop' and a[1] == 'and':
            va, vb = fold(a[3]), fold(b)
            if va is not None and vb is not None:
                return [{"kind": "cond", "guard": render(a[2]),
                         "guard_raw": render(rhs), "true": va, "false": vb}], r
    # return-via-nil-env idiom: MM[50] = w[7][o[2](n)] with the env name a
    # random pool token that is never defined anywhere in the VM region.
    if rhs[0] == 'index' and rhs[1][0] == 'index' and rhs[1][1] == ('name', 'w') \
            and rhs[1][2][0] == 'num' and rhs[1][2][1] == 7 \
            and unparse.is_o2_call(rhs[2]):
        n = fold(rhs[2][2][0])
        if n is not None:
            return [{"kind": "return_nil_env", "env_name": POOL.get(n + 34818),
                     "pool": n + 34818}], r
    return [{"kind": "dynamic", "expr": render(rhs)}], r

def apply_assign_env(stmt, env):
    """Update env (in place) for an assign stmt's non-MM[50] effects + return
    the MM[50] transition list if it writes MM[50] (classified with pre-env)."""
    trans = None
    pairs = list(zip(stmt[1], stmt[2]))
    for t, v in pairs:
        if is_mm(t, 50):
            trans, sym_r = classify_rhs(v, env)
            env[("sym", 50)] = sym_r
    for t, v in pairs:
        k = reg_key(t)
        if k is not None:
            fv = fold(subst_env(v, env))
            if fv is not None:
                env[k] = fv
            else:
                env.pop(k, None)
            # NOTE: the pending symbolic MM[50] expr is intentionally NOT
            # invalidated when a register it mentions is overwritten: in the
            # staged-cond idiom (MM[50] = G and A ; MM[35] = B ;
            # MM[50] = MM[50] or MM[35]) the guard register is reused to load
            # the false-state literal AFTER MM[50] was computed, and MM[50]'s
            # stored value already captured the old guard value.
        elif t[0] == 'index':
            # write into some table/register field with unknown key: if base is
            # MM[r], drop field entries for r (conservative)
            base = t[1]
            if is_mm(base):
                for kk in [x for x in env if x[0] == 'f' and x[1] == base[2][1]]:
                    del env[kk]
    return trans

def exits_with_env(block, env):
    """-> (T, A, env_out). T = live-exit transitions; A = all paths write MM[50]."""
    T, A = [], False
    env = dict(env)
    for s in block:
        t, a, env = stmt_effect(s, env)
        if a:
            T = t; A = True
        else:
            T = T + t
    return T, A, env

def stmt_effect(s, env):
    tag = s[0]
    if tag == 'assign':
        tr = apply_assign_env(s, env)
        if tr is not None:
            return tr, True, env
        return [], False, env
    if tag == 'local':
        return [], False, env
    if tag == 'if':
        T, A = [], True
        outs = []
        for _, b in s[1]:
            t, a, eo = exits_with_env(b, env)
            T += t; A = A and a; outs.append(eo)
        if s[2] is not None:
            t, a, eo = exits_with_env(s[2], env)
            T += t; A = A and a; outs.append(eo)
        else:
            A = False; outs.append(dict(env))
        merged = {}
        if outs:
            common = [k for k in outs[0] if all(k in o for o in outs[1:])]
            for k in common:
                if all(o[k] == outs[0][k] for o in outs[1:]):
                    merged[k] = outs[0][k]
        return T, A, merged
    if tag == 'while':
        t, _, _ = exits_with_env(s[2], env)
        return t, False, env
    if tag == 'repeat':
        t, a, _ = exits_with_env(s[1], env)
        return t, a, env
    if tag == 'fornum':
        t, _, _ = exits_with_env(s[5], env)
        return t, False, env
    if tag == 'forin':
        t, _, _ = exits_with_env(s[3], env)
        return t, False, env
    if tag == 'do':
        return exits_with_env(s[1], env)
    if tag == 'return':
        return [], True, env
    return [], False, env

# ---------------- per-block scan (regs, closures, o2, returns) ----------------
def scan_block(block):
    closures, o2 = [], []
    mm_reads, mm_writes = set(), set()
    has_return = [False]
    n_calls = [0]

    def scan_expr(e, writing=False):
        if not isinstance(e, tuple):
            return
        if is_mm(e):
            (mm_writes if writing else mm_reads).add(e[2][1])
            return
        if unparse.is_o2_call(e):
            n = fold(e[2][0])
            if n is not None:
                o2.append({"n": n, "pool": n + 34818, "text": POOL.get(n + 34818)})
        if e[0] == 'call':
            n_calls[0] += 1
            if e[1][0] == 'index' and e[1][1] == ('name', 'w') \
                    and e[1][2][0] == 'num' and e[1][2][1] in FACTORY_W and e[2]:
                sv = fold(e[2][0])
                closures.append({"factory": "w[%d]" % e[1][2][1], "entry_state": sv,
                                 "args": [render(a) for a in e[2]]})
        for ch in e[1:]:
            if isinstance(ch, tuple):
                scan_expr(ch)
            elif isinstance(ch, list):
                for it in ch:
                    if isinstance(it, tuple):
                        scan_expr(it)

    def rec(block):
        for s in block:
            tag = s[0]
            if tag == 'assign':
                for t in s[1]:
                    scan_expr(t, writing=True)
                for v in s[2]:
                    scan_expr(v)
            elif tag == 'if':
                for c, b in s[1]:
                    scan_expr(c); rec(b)
                if s[2] is not None:
                    rec(s[2])
            elif tag == 'while':
                scan_expr(s[1]); rec(s[2])
            elif tag == 'repeat':
                rec(s[1]); scan_expr(s[2])
            elif tag == 'return':
                has_return[0] = True
                for v in s[1]:
                    scan_expr(v)
            elif tag == 'local':
                for v in s[2]:
                    scan_expr(v)
            elif tag == 'fornum':
                for x in s[2:5]:
                    if x is not None: scan_expr(x)
                rec(s[5])
            elif tag == 'forin':
                for v in s[2]: scan_expr(v)
                rec(s[3])
            elif tag == 'do':
                rec(s[1])
            elif tag == 'callstmt':
                scan_expr(s[1])
    rec(block)
    return {"closure_sites": closures, "o2_refs": o2,
            "mm_reads": sorted(mm_reads), "mm_writes": sorted(mm_writes),
            "has_return": has_return[0], "n_calls": n_calls[0]}

def analyze_block(block):
    info = scan_block(block)
    T, A, _ = exits_with_env(block, {})
    info["exit_transitions"] = T
    info["exit_covers_all_paths"] = A
    info["n_stmts"] = len(block)
    info["block_ast"] = block
    info["block_luau"] = "\n".join(render_block_lines(block, "  "))
    return info
