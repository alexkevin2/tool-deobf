"""Minimal Lua tokenizer + recursive-descent parser sufficient for the XHider
interpreter (no strings in VM region, integer arithmetic, table constructors,
calls, index, if/while/for, multi-assign). Expressions keep raw structure;
a folder evaluates pure integer arithmetic."""
import re

KEYWORDS = {"and","or","not","nil","true","false","function","end","if","then",
            "else","elseif","while","do","for","in","return","break","local",
            "repeat","until"}

TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<comment>--\[\[.*?\]\]|--[^\n]*)
  | (?P<name>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<number>\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|\.\d+)
  | (?P<string>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')
  | (?P<op>\.\.\.|\.\.|==|~=|<=|>=|::|[+\-*/%^#<>=()\{\}\[\];:,.])
""", re.VERBOSE)

class Tok:
    __slots__=("kind","val","pos")
    def __init__(s,k,v,p): s.kind,s.val,s.pos=k,v,p
    def __repr__(s): return f"Tok({s.kind},{s.val!r})"

def tokenize(src):
    toks=[]; i=0; n=len(src)
    while i<n:
        m=TOKEN_RE.match(src,i)
        if not m: raise SyntaxError(f"bad char at {i}: {src[i:i+20]!r}")
        i=m.end()
        if m.lastgroup in ("ws","comment"): continue
        kind=m.lastgroup
        v=m.group()
        if kind=="name" and v in KEYWORDS: kind="kw"
        toks.append(Tok(kind,v,m.start()))
    toks.append(Tok("eof","",n))
    return toks

# AST nodes are tuples: (tag, ...)
class Parser:
    def __init__(s,toks): s.toks=toks; s.i=0
    def peek(s,k=0): return s.toks[s.i+k]
    def next(s):
        t=s.toks[s.i]; s.i+=1; return t
    def accept(s,val):
        if s.peek().val==val: s.next(); return True
        return False
    def expect(s,val):
        t=s.next()
        if t.val!=val: raise SyntaxError(f"expected {val!r} got {t.val!r} at {t.pos}")
        return t
    def expect_name(s):
        t=s.next()
        if t.kind!="name": raise SyntaxError(f"expected name got {t.val!r} at {t.pos}")
        return t.val

    # ---------- statements ----------
    def parse_block(s, terminators):
        stmts=[]
        while s.peek().val not in terminators and s.peek().kind!="eof":
            if s.peek().val==";": s.next(); continue
            stmts.append(s.parse_stmt())
        return stmts
    def parse_stmt(s):
        t=s.peek()
        if t.val=="local":
            s.next()
            if s.peek().val=="function":
                s.next(); name=s.expect_name()
                params,body=s.parse_funcbody()
                return ("localfunc",name,params,body)
            names=[s.expect_name()]
            while s.accept(","): names.append(s.expect_name())
            vals=[]
            if s.accept("="): vals=s.parse_exprlist()
            return ("local",names,vals)
        if t.val=="function":
            s.next()
            # function name(.name)* (:name)? body  -- only simple cases expected
            parts=[s.expect_name()]
            while s.accept("."): parts.append(s.expect_name())
            method=None
            if s.accept(":"): method=s.expect_name()
            params,body=s.parse_funcbody()
            return ("funcdef",parts,method,params,body)
        if t.val=="if":
            s.next(); cond=s.parse_expr(); s.expect("then")
            thenb=s.parse_block({"else","elseif","end"})
            arms=[(cond,thenb)]
            elseb=None
            while s.peek().val=="elseif":
                s.next(); c=s.parse_expr(); s.expect("then")
                arms.append((c,s.parse_block({"else","elseif","end"})))
            if s.accept("else"): elseb=s.parse_block({"end"})
            s.expect("end")
            return ("if",arms,elseb)
        if t.val=="while":
            s.next(); cond=s.parse_expr(); s.expect("do")
            body=s.parse_block({"end"}); s.expect("end")
            return ("while",cond,body)
        if t.val=="do":
            s.next(); body=s.parse_block({"end"}); s.expect("end")
            return ("do",body)
        if t.val=="for":
            s.next(); name=s.expect_name()
            if s.accept("="):
                a=s.parse_expr(); s.expect(","); b=s.parse_expr()
                step=None
                if s.accept(","): step=s.parse_expr()
                s.expect("do"); body=s.parse_block({"end"}); s.expect("end")
                return ("fornum",name,a,b,step,body)
            names=[name]
            while s.accept(","): names.append(s.expect_name())
            s.expect("in"); vals=s.parse_exprlist(); s.expect("do")
            body=s.parse_block({"end"}); s.expect("end")
            return ("forin",names,vals,body)
        if t.val=="return":
            s.next(); vals=[]
            if s.peek().val not in ("end","else","elseif","until","eof",";"):
                vals=s.parse_exprlist()
            s.accept(";")
            return ("return",vals)
        if t.val=="break":
            s.next(); return ("break",)
        if t.val=="repeat":
            s.next(); body=s.parse_block({"until"}); s.expect("until")
            cond=s.parse_expr(); return ("repeat",body,cond)
        # expression statement: assignment or call
        e=s.parse_prefixexp()
        if s.peek().val in ("=",","):
            targets=[e]
            while s.accept(","): targets.append(s.parse_prefixexp())
            s.expect("="); vals=s.parse_exprlist()
            return ("assign",targets,vals)
        return ("callstmt",e)
    def parse_funcbody(s):
        s.expect("("); params=[]
        if s.peek().val!=")":
            while True:
                if s.peek().val=="...": s.next(); params.append("...")
                else: params.append(s.expect_name())
                if not s.accept(","): break
        s.expect(")")
        body=s.parse_block({"end"}); s.expect("end")
        return params,body
    def parse_exprlist(s):
        vals=[s.parse_expr()]
        while s.accept(","): vals.append(s.parse_expr())
        return vals

    # ---------- expressions (Lua precedence) ----------
    def parse_expr(s): return s.parse_or()
    def parse_or(s):
        e=s.parse_and()
        while s.peek().val=="or": s.next(); e=("binop","or",e,s.parse_and())
        return e
    def parse_and(s):
        e=s.parse_cmp()
        while s.peek().val=="and": s.next(); e=("binop","and",e,s.parse_cmp())
        return e
    def parse_cmp(s):
        e=s.parse_concat()
        while s.peek().val in ("<",">","<=",">=","~=","=="):
            op=s.next().val; e=("binop",op,e,s.parse_concat())
        return e
    def parse_concat(s):
        e=s.parse_add()
        if s.peek().val=="..":
            s.next(); e=("binop","..",e,s.parse_concat())
        return e
    def parse_add(s):
        e=s.parse_mul()
        while s.peek().val in ("+","-"):
            op=s.next().val; e=("binop",op,e,s.parse_mul())
        return e
    def parse_mul(s):
        e=s.parse_unary()
        while s.peek().val in ("*","/","%","^"):
            op=s.next().val; e=("binop",op,e,s.parse_unary())
        return e
    def parse_unary(s):
        if s.peek().val in ("not","-","#"):
            op=s.next().val; return ("unop",op,s.parse_unary())
        return s.parse_pow()
    def parse_pow(s):
        e=s.parse_prefixexp()
        if s.peek().val=="^":
            s.next(); e=("binop","^",e,s.parse_unary())
        return e
    def parse_prefixexp(s):
        t=s.peek()
        if t.val=="function":
            s.next(); params,body=s.parse_funcbody()
            e=("func",params,body)
        elif t.val=="(":
            s.next(); e=s.parse_expr(); s.expect(")")
        elif t.kind=="name":
            s.next(); e=("name",t.val)
        elif t.kind=="number":
            s.next(); e=("num",float(t.val) if ("." in t.val or "e" in t.val or "E" in t.val) else int(t.val))
        elif t.kind=="string":
            s.next(); e=("str",t.val)
        elif t.val=="{":
            e=s.parse_table()
        elif t.val=="nil": s.next(); e=("nil",)
        elif t.val=="true": s.next(); e=("bool",True)
        elif t.val=="false": s.next(); e=("bool",False)
        elif t.val=="...": s.next(); e=("vararg",)
        else: raise SyntaxError(f"unexpected token {t.val!r} at {t.pos}")
        # suffixes
        while True:
            if s.peek().val=="[":
                s.next(); k=s.parse_expr(); s.expect("]")
                e=("index",e,k)
            elif s.peek().val==".":
                s.next(); e=("index",e,("strkey",s.expect_name()))
            elif s.peek().val==":":
                s.next(); m=s.expect_name()
                args=s.parse_callargs()
                e=("mcall",e,m,args)
            elif s.peek().val=="(" or s.peek().val=="{" or s.peek().kind=="string":
                args=s.parse_callargs()
                e=("call",e,args)
            else: break
        return e
    def parse_callargs(s):
        if s.peek().val=="(":
            s.next()
            if s.peek().val==")": s.next(); return []
            args=s.parse_exprlist(); s.expect(")"); return args
        if s.peek().val=="{":
            return [s.parse_table()]
        t=s.next()
        if t.kind=="string": return [("str",t.val)]
        raise SyntaxError(f"bad call args at {t.pos}")
    def parse_table(s):
        s.expect("{"); items=[]
        while s.peek().val!="}":
            if s.peek().val=="[":
                save=s.i; s.next(); k=s.parse_expr()
                if s.peek().val=="]":
                    s.next()
                    if s.accept("="): items.append(("kv",k,s.parse_expr()))
                    else: s.i=save; items.append(("item",s.parse_expr()))
                else: s.i=save; items.append(("item",s.parse_expr()))
            elif s.peek().kind=="name" and s.peek(1).val=="=":
                k=s.next().val; s.next(); items.append(("kv",("strkey",k),s.parse_expr()))
            else:
                items.append(("item",s.parse_expr()))
            if not (s.accept(",") or s.accept(";")): break
        s.expect("}")
        return ("table",items)

def fold(e):
    """Evaluate pure integer arithmetic; return int or None."""
    if e[0]=="num": return e[1]
    if e[0]=="unop" and e[1]=="-":
        v=fold(e[2]); return -v if v is not None else None
    if e[0]=="binop" and e[1] in ("+","-","*","%"):
        a,b=fold(e[2]),fold(e[3])
        if a is None or b is None: return None
        if e[1]=="+": return a+b
        if e[1]=="-": return a-b
        if e[1]=="*": return a*b
        if e[1]=="%": return a % b if b!=0 else None
    return None
