"""XHider v1.2 devirtualizer, stage 1: state-graph extraction (v3).

Uses graph_lib: dispatch split + env-aware live-exit transition analysis.
Adds proto partitioning: entry states = main entry + every closure-factory
call site's state argument; each state is assigned to the protos that can
reach it. Outputs state_graph.json (checkpoint), states_rendered.txt,
proto_map.json.
"""
import json, sys
sys.path.insert(0, '.')
import graph_lib as G
from graph_lib import MAIN_ENTRY, analyze_block
from unparse import render_block_lines

func = G.load_ast()
header_stmts, while_stmt, tail_stmts = G.get_parts(func)
leaves, anomalies = G.split_leaves(while_stmt)
print("leaves:", len(leaves), "anomalies:", anomalies)

leaf_info = []
for (lo, hi, block) in leaves:
    info = analyze_block(block)
    info["range"] = [lo, hi]
    leaf_info.append(info)

state_values = {MAIN_ENTRY}
for info in leaf_info:
    for tr in info["exit_transitions"]:
        if tr["kind"] == "goto":
            state_values.add(tr["to"])
        elif tr["kind"] == "cond":
            state_values.add(tr["true"]); state_values.add(tr["false"])
    for cs in info["closure_sites"]:
        if cs["entry_state"] is not None:
            state_values.add(cs["entry_state"])
print("state values:", len(state_values))

def in_range(v, lo, hi):
    return (lo is None or v >= lo) and (hi is None or v < hi)

states, gap_leaves = {}, []
for info in leaf_info:
    lo, hi = info["range"]
    cands = [v for v in state_values if in_range(v, lo, hi)]
    if len(cands) == 1:
        info["state_id"] = cands[0]
        states[cands[0]] = info
    elif len(cands) == 0:
        gap_leaves.append(info)
    else:
        raise SystemExit("multi-candidate leaf %s %s" % (info["range"], cands))
print("states extracted:", len(states), "| gap leaves:", len(gap_leaves))
print("state values with no leaf:", sorted(state_values - set(states)))

kinds, edges = {}, {}
for sid, info in states.items():
    es = set()
    for tr in info["exit_transitions"]:
        kinds[tr["kind"]] = kinds.get(tr["kind"], 0) + 1
        if tr["kind"] == "goto":
            es.add(tr["to"])
        elif tr["kind"] == "cond":
            es.add(tr["true"]); es.add(tr["false"])
    edges[sid] = es
print("exit transition kinds:", kinds)
print("resolved edges:", sum(len(v) for v in edges.values()))
print("dynamic exits in states:",
      sum(1 for info in states.values() for tr in info["exit_transitions"]
          if tr["kind"] == "dynamic"))
print("dynamic exits in gap leaves:",
      sum(1 for info in gap_leaves for tr in info["exit_transitions"]
          if tr["kind"] == "dynamic"))

# ---------------- proto partition ----------------
entries = {MAIN_ENTRY: "main (w[3](15645401, {}))"}
for sid, info in states.items():
    for cs in info["closure_sites"]:
        if cs["entry_state"] is not None:
            entries.setdefault(cs["entry_state"],
                               "closure site in state %d via %s" % (sid, cs["factory"]))
for g in gap_leaves:
    for cs in g["closure_sites"]:
        if cs["entry_state"] is not None:
            entries.setdefault(cs["entry_state"], "closure site in gap leaf %s" % (g["range"],))
print("proto entries:", len(entries))

reach = {}
for entry in entries:
    seen, stack = set(), [entry]
    while stack:
        s = stack.pop()
        if s in seen or s not in states:
            continue
        seen.add(s)
        stack.extend(edges.get(s, ()))
    reach[entry] = seen
owner = {}
shared = {}
for entry, ss in reach.items():
    for s in ss:
        if s in owner and owner[s] != entry:
            shared.setdefault(s, [owner[s]]).append(entry)
        owner.setdefault(s, entry)
unreached = set(states) - set(owner)
print("states reached by exactly the partition:", len(owner),
      "| shared states:", len(shared), "| unreached states:", len(unreached))
if unreached:
    print("unreached sample:", sorted(unreached)[:10])

proto_map = {
    "entries": {str(k): v for k, v in sorted(entries.items())},
    "reach_counts": {str(k): len(v) for k, v in sorted(reach.items())},
    "shared_states": {str(k): v for k, v in sorted(shared.items())},
    "unreached_states": sorted(unreached),
    "owner": {str(k): v for k, v in sorted(owner.items())},
}
with open('proto_map.json', 'w') as f:
    json.dump(proto_map, f, indent=1)

def pub(info):
    return {k: v for k, v in info.items() if k != "block_ast"}

graph = {
    "entry_state": MAIN_ENTRY,
    "n_state_values": len(state_values),
    "n_leaves": len(leaves),
    "n_states_extracted": len(states),
    "n_gap_leaves": len(gap_leaves),
    "gap_leaf_ranges": [[g["range"][0], g["range"][1], g["n_stmts"]] for g in gap_leaves],
    "states_without_leaf": sorted(state_values - set(states)),
    "transition_kinds": kinds,
    "resolved_edges": sum(len(v) for v in edges.values()),
    "states": {str(k): pub(states[k]) for k in sorted(states)},
    "gap_leaves": [pub(g) for g in gap_leaves],
    "header_luau": "\n".join(l for s in header_stmts for l in render_block_lines([s], "")),
    "tail_luau": "\n".join(l for s in tail_stmts for l in render_block_lines([s], "")),
}
with open('state_graph.json', 'w') as f:
    json.dump(graph, f, indent=1)
with open('states_rendered.txt', 'w') as f:
    for sid in sorted(states):
        f.write("===== state %d =====\n%s\n" % (sid, states[sid]["block_luau"]))
    for g in gap_leaves:
        f.write("===== GAP range %s..%s =====\n%s\n"
                % (g["range"][0], g["range"][1], g["block_luau"]))
print("WROTE state_graph.json, states_rendered.txt, proto_map.json")
