#!/usr/bin/env python3
"""moonveil2.py — dynamic-link deobfuscator for MoonVeil 2.x "linker" builds.

Profile (verified on MoonVeil 2.1.0): the chunk returns a table of ~97
entries (builder functions + raw helpers) and calls a linker method on
it:  return({...}):l({names...}, "EntryName", ...)
The linker renames entries into a context table; the entry instantiates
runtime closures from builders, then runs the main function. Constants
are encrypted behind cache-backed helpers on the context:

  numeric:  function(a,b,c,d) a.<cache>[d] = <arith>; return a.<cache>[d] end
  strings:  function(a,b,c,d) a.<cache>[d] = a.<m>(b, c); return ... end
            called as h:Str(h.<q>"frag1", h.<q>"frag2", key)

Everything (names, permutation, roles) is DISCOVERED from the file
itself, so other builds with the same architecture work unchanged:
  1. parse the tail call -> names array + entry name + stripped chunk
  2. fold (shared fold.py)
  3. harness: link with a bogus entry; recover the name->index map by
     function identity; classify helpers by body shape
  4. parse the entry's instantiation list; harness: instantiate, then
     evaluate every numeric / string decrypt call site
  5. substitute values back -> decrypted.luau (+ states.json, report)

Exit: 0 = constants+strings decrypted & compile OK; 5 = PARTIAL;
2 = not this profile (caller should fall back to static moonveil.py).
"""
import argparse, hashlib, json, os, re, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fold as fold_mod
import extract_vm
import moonveil as mv_static

TAIL_RE = re.compile(r'\}\s*\)\s*:\s*([A-Za-z_]\w*)\s*\(')
ARGS_NUM = r'(-?\d+(?:\s*,\s*-?\d+)*)'
STR_LIT = r'"((?:[^"\\]|\\.)*)"'

# ------------------------------------------------------------ tail parse
def find_tail(src):
    last = None
    for m in TAIL_RE.finditer(src):
        last = m
    if not last:
        return None
    tail = src[last.start():]
    m = re.match(r'\}\s*\)\s*:\s*([A-Za-z_]\w*)\s*\(\s*\{((?:"(?:[^"\\]|\\.)*",?\s*)+)\}\s*,\s*"([^"]+)"\s*,\s*\.\.\.\s*\)\s*$', tail)
    if not m:
        return None
    names = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(2))
    stripped = src[:last.start() + 1] + ')\n'
    return {'link': m.group(1), 'names': names, 'entry': m.group(3),
            'stripped': stripped}

# ------------------------------------------------------------ table split
def split_table(folded):
    """Split the outer returned table into positional element sources and
    keyed elements (name -> source)."""
    toks = list(extract_vm._tokens(folded))
    start = next(i for i, t in enumerate(toks) if t[1] == '{')
    spans, bdepth, kdepth, cur, pending_do = [], 0, 0, start + 1, 0
    i = start + 1
    while i < len(toks):
        kind, t = toks[i][0], toks[i][1]
        if kind == 'word':
            if t in ('for', 'while'):
                kdepth += 1; pending_do += 1
            elif t == 'do':
                if pending_do: pending_do -= 1
                else: kdepth += 1
            elif t in ('function', 'if', 'repeat'):
                kdepth += 1
            elif t in ('end', 'until'):
                if kdepth == 0 and bdepth == 0: break
                kdepth -= 1
        elif t in ('{', '(', '['): bdepth += 1
        elif t in ('}', ')', ']'):
            if kdepth == 0 and bdepth == 0: break
            bdepth -= 1
        elif t == ',' and kdepth == 0 and bdepth == 0:
            spans.append((cur, i)); cur = i + 1
        i += 1
    spans.append((cur, i))
    pos, keyed = [], {}
    for a, b in spans:
        if b <= a: continue
        tx = folded[toks[a][2]:toks[b - 1][3]]
        m = re.match(r'\s*([A-Za-z_]\w*)\s*=', tx)
        if m and not tx.lstrip().startswith('function'):
            keyed[m.group(1)] = tx
        else:
            pos.append(tx)
    return pos, keyed

# ------------------------------------------------------------ harness
def find_luau(arg):
    if arg: return arg
    for cand in (os.path.join(HERE, 'bin', 'luau'),
                 os.path.expanduser('~/workspace/roblox_deobf/bin/luau'),
                 os.environ.get('LUAU_BIN', '')):
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    return None

def run_luau(luau, code, tag, timeout=600):
    import tempfile
    fd, path = tempfile.mkstemp(suffix=f'-{tag}.luau')
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(code)
        return subprocess.run([luau, path], capture_output=True, text=True,
                              timeout=timeout)
    finally:
        os.unlink(path)

def harness_base(stripped, names, link):
    esc = ''.join('\\%03d' % b for b in stripped.encode())
    names_lua = '{' + ','.join('"%s"' % n.replace('\\', '\\\\').replace('"', '\\"') for n in names) + '}'
    return ('local src = "' + esc + '"\n'
            'local t = assert(loadstring(src))()\n'
            f'local names = {names_lua}\n'
            f'pcall(t.{link}, t, names, "ZZZ_no_entry")\n')

def lua_bytes(raw):
    return '"' + ''.join('\\%03d' % b for b in raw) + '"'

# ------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description='Deobfuscate MoonVeil 2.x linker builds')
    ap.add_argument('input')
    ap.add_argument('-o', '--outdir', default=None)
    ap.add_argument('--luau', default=None)
    ap.add_argument('--trace', action='store_true',
                    help='also run the chunk in a mocked Roblox environment '
                         'and log its behaviour (HttpGet/loadstring stubbed)')
    args = ap.parse_args()

    data = open(args.input, 'rb').read()
    src = data.decode('utf-8', errors='strict')
    sha = hashlib.sha256(data).hexdigest()
    outdir = args.outdir or os.path.splitext(os.path.basename(args.input))[0] + '-moonveil-deobf'
    os.makedirs(outdir, exist_ok=True)
    print(f"[0] input {args.input}  {len(data)} bytes  sha256={sha[:16]}...")

    tail = find_tail(src)
    if not tail:
        print("[1] no linker tail call found -> not the 2.x linker profile")
        return 2
    names, entry, link = tail['names'], tail['entry'], tail['link']
    print(f"[1] linker profile: link=:{link}  names={len(names)}  entry={entry!r}")

    folded = fold_mod.fold_source(src)
    open(os.path.join(outdir, 'folded.luau'), 'w', encoding='utf-8').write(folded)
    print(f"[2] fold: {len(src)} -> {len(folded)} bytes")

    luau = find_luau(args.luau)
    if not luau:
        print("[!] luau binary not found"); return 5

    # phase 1: recover name -> positional index by function identity
    code = harness_base(tail['stripped'], names, link) + '''
for _, n in ipairs(names) do
    local idx = 0
    if t[n] ~= nil then
        for i = 1, #t do
            if t[i] == t[n] then idx = i break end
        end
    end
    print("PERM|" .. n .. "|" .. idx)
end
'''
    r = run_luau(luau, code, 'perm')
    if r.returncode != 0:
        print("[!] link harness failed:", r.stderr[-400:]); return 5
    perm = {}
    for line in r.stdout.splitlines():
        p = line.split('|')
        if len(p) == 3 and p[0] == 'PERM':
            perm[p[1]] = int(p[2])
    inv = {v: k for k, v in perm.items() if v}
    print(f"[3] permutation recovered: {len(inv)}/{len(names)} positional names")

    pos, keyed = split_table(folded)
    print(f"    table elements: {len(pos)} positional, keyed={sorted(keyed)}")

    # cache field: most common `.<name>[k] or` idiom target
    from collections import Counter
    cache_votes = Counter(re.findall(r'\.(\w+)\[\s*-?\d+\s*\]\s*or\s*\w+:', folded))
    if not cache_votes:
        print("[!] cache idiom not found"); return 5
    CACHE = cache_votes.most_common(1)[0][0]
    print(f"    cache field: {CACHE}")

    # classify raw helpers by body shape:
    # function(self, p2, ..., pN) self.CACHE[pN] = rhs return self.CACHE[pN] end
    shape = re.compile(r'function\s*\(\s*(\w+)((?:\s*,\s*\w+)+)\s*\)\s*\1\.' + CACHE +
                       r'\[(\w+)\]\s*=\s*(.+?)\s*return\s+\1\.' + CACHE + r'\[\3\]\s*end', re.S)
    num_methods, str_method, str_m = set(), None, None
    for idx, tx in enumerate(pos, 1):
        m = shape.search(tx)
        if not m: continue
        params = [m.group(1)] + [p.strip() for p in m.group(2).split(',') if p.strip()]
        if m.group(3) != params[-1] or len(params) < 3: continue
        rhs = m.group(4).strip()
        nm = inv.get(idx)
        if nm is None: continue
        ms = re.fullmatch(re.escape(m.group(1)) + r'\.(\w+)\(\s*' +
                          re.escape(params[1]) + r'\s*,\s*' + re.escape(params[2]) + r'\s*\)', rhs)
        if ms:
            str_method, str_m = nm, ms.group(1)
        else:
            num_methods.add(nm)
    print(f"    numeric helpers: {sorted(num_methods)}  string helper: {str_method} (combiner {str_m})")
    if not num_methods and not str_method:
        print("[!] no decrypt helpers classified"); return 5

    # entry instantiation list
    eidx = perm.get(entry, 0)
    entry_src = pos[eidx - 1] if eidx else keyed.get(entry, '')
    pairs_inst = []
    for m in re.finditer(r'((?:\w+\.\w+\s*,\s*)*\w+\.\w+)\s*=\s*((?:\w+:\w+\(\)\s*,\s*)*\w+:\w+\(\))', entry_src):
        lhs = [x.strip().split('.')[-1] for x in m.group(1).split(',')]
        rhs = re.findall(r':(\w+)\(\)', m.group(2))
        if len(lhs) == len(rhs):
            pairs_inst += list(zip(lhs, rhs))
    print(f"    entry instantiation: {pairs_inst}")

    # harvest call sites
    num_alt = '|'.join(sorted(num_methods)) if num_methods else None
    num_sites, str_sites = {}, {}
    QF = None
    if num_alt:
        for m in re.finditer(r'\w+:(' + num_alt + r')\(' + ARGS_NUM + r'\)', folded):
            num_sites[(m.group(1), tuple(int(x) for x in m.group(2).split(',')))] = None
    if str_method:
        sm = re.search(r'\w+:(' + str_method + r')\(\s*\w+\.(\w+)"', folded)
        if sm: QF = sm.group(2)
        if QF:
            pat = (r'\w+:(' + str_method + r')\(\s*\w+\.' + QF + STR_LIT +
                   r'\s*,\s*\w+\.' + QF + STR_LIT + r'\s*,\s*(-?\d+)\s*\)')
            def _raw(u):
                return u if isinstance(u, bytes) else u.encode('latin-1', 'replace')
            for m in re.finditer(pat, folded):
                f1 = _raw(extract_vm.luau_unescape(m.group(2)))
                f2 = _raw(extract_vm.luau_unescape(m.group(3)))
                str_sites[(f1, f2, int(m.group(4)))] = None
    print(f"[4] call sites: {len(num_sites)} numeric, {len(str_sites)} string (frag field {QF})")

    # phase 2 harness: instantiate + evaluate
    lines = [harness_base(tail['stripped'], names, link)]
    if pairs_inst:
        # NOTE: instantiate SEQUENTIALLY in entry order. The entry writes
        # it as one multiple assignment, but in the harness (raw linked
        # table) builders read sibling fields, so one-at-a-time it is.
        lines += [f't.{fld} = t:{meth}()' for fld, meth in pairs_inst]
    for (meth, a) in num_sites:
        argstr = ', '.join(map(str, a))
        lines.append(f'print("DEC|{meth}|{argstr}|" .. tostring(t:{meth}({argstr})))')
    for (f1, f2, key) in str_sites:
        lines.append(f'print("STR|{key}|" .. (t:{str_method}(t.{QF}({lua_bytes(f1)}), t.{QF}({lua_bytes(f2)}), {key}):gsub(".", function(ch) return string.format("\\\\%03d", string.byte(ch)) end)))')
    r = run_luau(luau, '\n'.join(lines) + '\n', 'eval')
    if r.returncode != 0:
        print("[!] eval harness failed:", r.stderr[-400:]); return 5
    values, strings = {}, {}
    def dec_ddd(s):
        out, i = bytearray(), 0
        while i < len(s):
            if s[i] == '\\' and s[i + 1:i + 4].isdigit():
                out.append(int(s[i + 1:i + 4])); i += 4
            else:
                out += s[i].encode('latin-1'); i += 1
        return bytes(out)
    for line in r.stdout.splitlines():
        p = line.split('|')
        if len(p) == 4 and p[0] == 'DEC':
            a = tuple(int(x) for x in p[2].split(', '))
            v = float(p[3]) if ('.' in p[3] or 'e' in p[3]) else int(p[3])
            values[(p[1], a)] = v
        elif len(p) == 3 and p[0] == 'STR':
            strings[int(p[1])] = dec_ddd(p[2])
    print(f"[5] evaluated: {len(values)} numeric constants, {len(strings)} strings")

    # substitute
    def fmt(v):
        s = str(int(v)) if isinstance(v, float) and v == int(v) else repr(v)
        return f"({s})"
    def lua_lit(raw):
        out = []
        for b in raw:
            if b == 34: out.append('\\"')
            elif b == 92: out.append('\\\\')
            elif 32 <= b < 127: out.append(chr(b))
            else: out.append('\\%03d' % b)
        return '"' + ''.join(out) + '"'
    out = folded
    n_sub = 0
    if num_alt:
        sa_num = re.compile(r'\w+\.' + CACHE + r'\[(-?\d+)\]\s*or\s*\w+:(' + num_alt + r')\(' + ARGS_NUM + r'\)')
        def rep_sa_num(m):
            nonlocal n_sub
            a = tuple(int(x) for x in m.group(3).split(','))
            v = values.get((m.group(2), a))
            if v is None: return m.group(0)
            n_sub += 1; return fmt(v)
        out = sa_num.sub(rep_sa_num, out)
        bare_num = re.compile(r'\w+:(' + num_alt + r')\(' + ARGS_NUM + r'\)')
        def rep_num(m):
            nonlocal n_sub
            a = tuple(int(x) for x in m.group(2).split(','))
            v = values.get((m.group(1), a))
            if v is None: return m.group(0)
            n_sub += 1; return fmt(v)
        out = bare_num.sub(rep_num, out)
    if str_method and QF:
        pat = (r'\w+:(' + str_method + r')\(\s*\w+\.' + QF + STR_LIT +
               r'\s*,\s*\w+\.' + QF + STR_LIT + r'\s*,\s*(-?\d+)\s*\)')
        sa_str = re.compile(r'\w+\.' + CACHE + r'\[(-?\d+)\]\s*or\s*(' + pat + r')')
        def rep_sa_str(m):
            nonlocal n_sub
            v = strings.get(int(m.group(1)))   # the Sa[k] key == the Ta key
            if v is None: return m.group(0)
            n_sub += 1; return lua_lit(v)
        out = sa_str.sub(rep_sa_str, out)
        bare_str = re.compile(pat)
        def rep_str(m):
            nonlocal n_sub
            v = strings.get(int(m.group(4)))
            if v is None: return m.group(0)
            n_sub += 1; return lua_lit(v)
        out = bare_str.sub(rep_str, out)
    dec_path = os.path.join(outdir, 'decrypted.luau')
    open(dec_path, 'w', encoding='utf-8').write(out)
    print(f"[6] substituted {n_sub} sites -> decrypted.luau")

    comp = os.path.join(os.path.dirname(luau), 'luau-compile')
    compile_ok = None
    if os.path.isfile(comp):
        rr = subprocess.run([comp, dec_path], capture_output=True)
        compile_ok = rr.returncode == 0
    print(f"    luau-compile: {compile_ok}")

    states = []
    try:
        toks = list(extract_vm._tokens(out))
        for li, (lo, hi, var, kind_loop) in enumerate(mv_static.find_dispatches(toks)):
            for st in mv_static.extract_states(out, toks, lo + 1, hi - 1, var):
                st['loop'] = li; st['loop_kind'] = kind_loop; st['state_var'] = var
                states.append(st)
        print(f"    states: {len(states)} leaf blocks")
    except Exception as e:
        print("    states extraction failed:", e)
    json.dump(states, open(os.path.join(outdir, 'states.json'), 'w'), indent=0)
    json.dump({f"{m}|{','.join(map(str, a))}": v for (m, a), v in values.items()},
              open(os.path.join(outdir, 'constants.json'), 'w'), indent=0)
    json.dump({str(k): v.decode('utf-8', 'replace') for k, v in strings.items()},
              open(os.path.join(outdir, 'strings.json'), 'w'), ensure_ascii=False, indent=0)
    roles = {'cache': CACHE, 'numeric_helpers': sorted(num_methods),
             'string_helper': str_method, 'string_combiner': str_m,
             'fragment_field': QF, 'entry': entry, 'instantiation': pairs_inst,
             'permutation': {k: v for k, v in perm.items() if v}}
    json.dump(roles, open(os.path.join(outdir, 'roles.json'), 'w'), indent=0)
    status = 'DECRYPTED' if (compile_ok and len(values) == len(num_sites)) else 'PARTIAL'
    with open(os.path.join(outdir, 'report.md'), 'w', encoding='utf-8') as f:
        f.write(f"""# MoonVeil 2.x linker-build deobfuscation (moonveil2)

- input: {os.path.basename(args.input)} ({len(data)} bytes, sha256 {sha})
- profile: linker `:{link}`, {len(names)} named entries, entry `{entry}`
- roles discovered: cache `{CACHE}`; numeric helpers {sorted(num_methods)};
  string helper `{str_method}` via combiner `{str_m}` + fragment field `{QF}`
- decrypted: {len(values)} numeric constants, {len(strings)} strings;
  {n_sub} call sites substituted; luau-compile: {compile_ok}
- state graph: {len(states)} leaf blocks (states.json)
- status: {status} (VM state machines remain as while-true dispatch with
  real constants/strings inline; run a mock-env trace to read behaviour)
""")
    # stage 8: linearize the dispatch loops of the decrypted source
    try:
        import linearize as lin_mod
        lin_src, lstats, cfg = lin_mod.linearize_source(out, roles)
        lin_path = os.path.join(outdir, 'linearized.luau')
        open(lin_path, 'w', encoding='utf-8').write(lin_src)
        open(os.path.join(outdir, 'cfg.md'), 'w', encoding='utf-8').write(cfg)
        lin_ok = None
        if os.path.isfile(comp):
            rr = subprocess.run([comp, lin_path], capture_output=True)
            lin_ok = rr.returncode == 0
        print(f"[8] linearize: {lstats} compile={lin_ok}")
        with open(os.path.join(outdir, 'report.md'), 'a', encoding='utf-8') as f:
            f.write(f"- linearized.luau: {lstats}, luau-compile: {lin_ok} "
                    f"(per-function graphs in cfg.md)\n")
    except Exception as e:
        print(f"[8] linearize skipped: {e}")
    print(f"[7] status: {status}")
    if args.trace:
        run_trace(luau, src, outdir)
    return 0 if status == 'DECRYPTED' else 5

def run_trace(luau, src, outdir):
    """Execute the original chunk under the mock-environment template
    (trace_template.luau): Roblox globals are logging proxies, HttpGet
    and loadstring are stubbed — remote code is never fetched or run."""
    tpl_path = os.path.join(HERE, 'trace_template.luau')
    if not os.path.isfile(tpl_path):
        print("[trace] template missing, skipped"); return
    tpl = open(tpl_path, encoding='utf-8').read()
    esc = ''.join('\\%03d' % b for b in src.encode())
    code = tpl.replace('"__SRC__"', '"' + esc + '"')
    import tempfile
    fd, path = tempfile.mkstemp(suffix='-trace.luau')
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(code)
        r = subprocess.run([luau, path], capture_output=True, text=True,
                           timeout=180, errors='replace')
        log = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        log = '(trace timed out after 180s)\n'
    finally:
        os.unlink(path)
    open(os.path.join(outdir, 'trace.log'), 'w', encoding='utf-8').write(log)
    httpgets = re.findall(r'\[HTTPGET\] (\S+)', log)
    instances = re.findall(r'\[Instance\.new\] (\w+)', log)
    texts = re.findall(r'\.Text = "([^"]*)"', log)
    finished = '[chunk finished] ok:\ttrue' in log
    print(f"[trace] finished_ok={finished} instances={len(instances)} "
          f"httpgets={httpgets} texts={texts[:6]}")
    with open(os.path.join(outdir, 'report.md'), 'a', encoding='utf-8') as f:
        f.write(f"\n## behaviour trace (mock env, remote code stubbed)\n\n")
        f.write(f"- ran to completion: {finished}\n")
        f.write(f"- Instance.new: {instances}\n")
        f.write(f"- GUI texts seen: {texts}\n")
        f.write(f"- HttpGet URLs: {httpgets}\n")
        f.write(f"- full log: trace.log\n")

if __name__ == '__main__':
    sys.exit(main())
