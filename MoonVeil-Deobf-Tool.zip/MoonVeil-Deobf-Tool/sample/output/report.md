# MoonVeil 2.x linker-build deobfuscation (moonveil2)

- input: loader_test.lua (168970 bytes, sha256 57b458d441b9c93d433250fed562e2ca255897bc0991c053251d20fd4a363e3d)
- profile: linker `:l`, 97 named entries, entry `Ya`
- roles discovered: cache `Sa`; numeric helpers ['Ua', 'Va', 'Wa', 'Xa'];
  string helper `Ta` via combiner `m` + fragment field `q`
- decrypted: 790 numeric constants, 31 strings;
  899 call sites substituted; luau-compile: True
- state graph: 1481 leaf blocks (states.json)
- status: DECRYPTED (VM state machines remain as while-true dispatch with
  real constants/strings inline; run a mock-env trace to read behaviour)
