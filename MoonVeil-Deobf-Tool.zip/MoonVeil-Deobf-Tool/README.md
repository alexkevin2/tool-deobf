# MoonVeil Deobf Tool (standalone)

Deobfuscator for **MoonVeil 2.x "linker" builds** — the profile where
the chunk returns a table of ~97 entries and calls a linker method on
it: `return({...}):l({names...}, "Entry", ...)`.

## How it works (everything is discovered from the file itself)

1. Parses the tail call -> names array, entry name, stripped chunk.
2. Folds literals (hex/binary/underscores -> decimal).
3. Links the table in a Luau harness with a bogus entry name and
   recovers the name->function permutation by function identity.
4. Classifies the context's decrypt helpers by body shape
   (`a.<cache>[k] = <expr>; return a.<cache>[k]`), finds the string
   combiner + fragment decoder field, and parses the entry's
   builder-instantiation list.
5. Evaluates every numeric-constant and string decrypt call site in
   the harness and substitutes the real values back into the source.

Because names/roles are discovered per file, other 2.x builds with
the same architecture (including older ones) work without changes.
Builds with a different architecture fall back to `moonveil.py`
(static fold + string inventory + state-graph extraction, PARTIAL).

## Usage

    python3 moonveil2.py <input.lua> [-o outdir] [--luau path]

Outputs: decrypted.luau (constants + strings substituted, compiles
clean), linearized.luau (dispatch trees rewritten as flat state-labelled
blocks — per-function graphs in cfg.md; loops that cannot be proven
equivalent keep their original form), constants.json, strings.json,
roles.json, states.json, report.md. With `--trace` the chunk is also
executed in a mocked Roblox environment (HttpGet/loadstring stubbed —
remote code is never fetched) and trace.log records its behaviour.
Exit 0 = decrypted; 5 = PARTIAL; 2 = not this profile.

## Requirements

Python 3.10+. Luau CLI binaries bundled in `bin/` (Linux).

## Sample

`sample/Loader-MoonVeil-2.1.0.lua` — a real MoonVeil 2.1.0 loader
(StarCrow Hub): 790 numeric constants + 31 strings decrypted
(stdlib/metamethod names the VM hides). Run `./run_sample.sh`.
