#!/bin/sh
# Runs the MoonVeil 2.x engine on the bundled Loader sample and diffs
# the decrypted + linearized outputs against the expected ones.
set -e
cd "$(dirname "$0")"
python3 moonveil2.py sample/Loader-MoonVeil-2.1.0.lua -o sample-run-out --trace
cmp -s sample-run-out/decrypted.luau sample/output/decrypted.luau || { echo "SAMPLE MISMATCH: decrypted.luau"; exit 1; }
cmp -s sample-run-out/linearized.luau sample/output/linearized.luau || { echo "SAMPLE MISMATCH: linearized.luau"; exit 1; }
echo "SAMPLE OK: decrypted.luau + linearized.luau match expected output"
